#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_WeaponSkinMapping_type.BP_STRUCT_WeaponSkinMapping_type
// Size: 0x38 // Inherited bytes: 0x00
struct FBP_STRUCT_WeaponSkinMapping_type {
	// Fields
	struct FString OutputDesc_0_4C755C4055DE81011AC086EE07D9D3D3; // Offset: 0x00 // Size: 0x10
	int SkinID_1_6AF5A0C03E8D665F2B8E33D5019212C4; // Offset: 0x10 // Size: 0x04
	int WeaponID_2_1D11360041F2AB4A2B54AC9608775314; // Offset: 0x14 // Size: 0x04
	struct FString URL_3_276895001829BC3265405AC70F011B5C; // Offset: 0x18 // Size: 0x10
	struct FString iconURL_4_1C201F405280621B7F9C0B550EBB3B4C; // Offset: 0x28 // Size: 0x10
};

