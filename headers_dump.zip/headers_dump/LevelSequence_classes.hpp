#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class LevelSequence.LevelSequenceActor
// Size: 0x478 // Inherited bytes: 0x3d8
struct ALevelSequenceActor : AActor {
	// Fields
	char pad_0x3D8[0x8]; // Offset: 0x3d8 // Size: 0x08
	bool bAutoPlay; // Offset: 0x3e0 // Size: 0x01
	char pad_0x3E1[0x7]; // Offset: 0x3e1 // Size: 0x07
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // Offset: 0x3e8 // Size: 0x28
	struct ULevelSequencePlayer* SequencePlayer; // Offset: 0x410 // Size: 0x08
	struct FSoftObjectPath LevelSequence; // Offset: 0x418 // Size: 0x18
	struct TArray<struct AActor*> AdditionalEventReceivers; // Offset: 0x430 // Size: 0x10
	struct ULevelSequenceBurnInOptions* BurnInOptions; // Offset: 0x440 // Size: 0x08
	struct UMovieSceneBindingOverrides* BindingOverrides; // Offset: 0x448 // Size: 0x08
	bool bReduceFrequency; // Offset: 0x450 // Size: 0x01
	char pad_0x451[0x3]; // Offset: 0x451 // Size: 0x03
	int ReduceFrameCount; // Offset: 0x454 // Size: 0x04
	float IgnoreFrameTolerance; // Offset: 0x458 // Size: 0x04
	char bOverrideInstanceData : 1; // Offset: 0x45c // Size: 0x01
	char pad_0x45C_1 : 7; // Offset: 0x45c // Size: 0x01
	char pad_0x45D[0x3]; // Offset: 0x45d // Size: 0x03
	struct UObject* DefaultInstanceData; // Offset: 0x460 // Size: 0x08
	bool bForceAsync; // Offset: 0x468 // Size: 0x01
	char pad_0x469[0x7]; // Offset: 0x469 // Size: 0x07
	struct ULevelSequenceBurnIn* BurnInInstance; // Offset: 0x470 // Size: 0x08

	// Functions

	// Object Name: Function LevelSequence.LevelSequenceActor.SetSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSequence(struct ULevelSequence* InSequence); // Offset: 0x1047e53e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceActor.SetEventReceivers
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEventReceivers(struct TArray<struct AActor*> AdditionalReceivers); // Offset: 0x1047e5304 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LevelSequence.LevelSequenceActor.SetBinding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBinding(struct FMovieSceneObjectBindingID Binding, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset); // Offset: 0x1047e51a8 // Return & Params: Num(3) Size(0x29)

	// Object Name: Function LevelSequence.LevelSequenceActor.SetAllMovieSceneSectionsToKeepState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllMovieSceneSectionsToKeepState(); // Offset: 0x1047e5194 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceActor.ResetBindings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetBindings(); // Offset: 0x1047e5180 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceActor.ResetBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetBinding(struct FMovieSceneObjectBindingID Binding); // Offset: 0x1047e50e0 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function LevelSequence.LevelSequenceActor.RemoveBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor); // Offset: 0x1047e5004 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LevelSequence.LevelSequenceActor.ReceiveInitailizePlayer
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveInitailizePlayer(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceActor.GetSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULevelSequence* GetSequence(bool bLoad, bool bInitializePlayer); // Offset: 0x1047e4f2c // Return & Params: Num(3) Size(0x10)

	// Object Name: Function LevelSequence.LevelSequenceActor.AddBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor, bool bAllowBindingsFromAsset); // Offset: 0x1047e4e0c // Return & Params: Num(3) Size(0x21)
};

// Object Name: Class LevelSequence.DefaultLevelSequenceInstanceData
// Size: 0x70 // Inherited bytes: 0x28
struct UDefaultLevelSequenceInstanceData : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct AActor* TransformOriginActor; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FTransform TransformOrigin; // Offset: 0x40 // Size: 0x30
};

// Object Name: Class LevelSequence.LevelSequence
// Size: 0x3d8 // Inherited bytes: 0x2e0
struct ULevelSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x2e0 // Size: 0x08
	struct FLevelSequenceObjectReferenceMap ObjectReferences; // Offset: 0x2e8 // Size: 0x50
	struct FLevelSequenceBindingReferences BindingReferences; // Offset: 0x338 // Size: 0x50
	struct TMap<struct FString, struct FLevelSequenceObject> PossessedObjects; // Offset: 0x388 // Size: 0x50
};

// Object Name: Class LevelSequence.LevelSequenceBurnInInitSettings
// Size: 0x28 // Inherited bytes: 0x28
struct ULevelSequenceBurnInInitSettings : UObject {
};

// Object Name: Class LevelSequence.LevelSequenceBurnInOptions
// Size: 0x50 // Inherited bytes: 0x28
struct ULevelSequenceBurnInOptions : UObject {
	// Fields
	bool bUseBurnIn; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FSoftClassPath BurnInClass; // Offset: 0x30 // Size: 0x18
	struct ULevelSequenceBurnInInitSettings* Settings; // Offset: 0x48 // Size: 0x08
};

// Object Name: Class LevelSequence.LevelSequenceBurnIn
// Size: 0x2a8 // Inherited bytes: 0x248
struct ULevelSequenceBurnIn : UUserWidget {
	// Fields
	struct FLevelSequencePlayerSnapshot FrameInformation; // Offset: 0x248 // Size: 0x58
	struct ALevelSequenceActor* LevelSequenceActor; // Offset: 0x2a0 // Size: 0x08

	// Functions

	// Object Name: Function LevelSequence.LevelSequenceBurnIn.SetSettings
	// Flags: [Event|Public|BlueprintEvent]
	void SetSettings(struct UObject* InSettings); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceBurnIn.GetSettingsClass
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct ULevelSequenceBurnInInitSettings* GetSettingsClass(); // Offset: 0x1047e5b04 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class LevelSequence.LevelSequencePlayer
// Size: 0x868 // Inherited bytes: 0x7b8
struct ULevelSequencePlayer : UMovieSceneSequencePlayer {
	// Fields
	struct FScriptMulticastDelegate OnCameraCut; // Offset: 0x7b8 // Size: 0x10
	struct FScriptMulticastDelegate OnTrackEvent; // Offset: 0x7c8 // Size: 0x10
	char pad_0x7D8[0x30]; // Offset: 0x7d8 // Size: 0x30
	struct TArray<struct UObject*> AdditionalEventReceivers; // Offset: 0x808 // Size: 0x10
	char pad_0x818[0x50]; // Offset: 0x818 // Size: 0x50

	// Functions

	// Object Name: Function LevelSequence.LevelSequencePlayer.CreateLevelSequencePlayer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct ULevelSequencePlayer* CreateLevelSequencePlayer(struct UObject* WorldContextObject, struct ULevelSequence* LevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct ALevelSequenceActor*& OutActor); // Offset: 0x1047e5ff0 // Return & Params: Num(5) Size(0x48)
};

