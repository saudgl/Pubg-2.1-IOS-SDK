#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_CycleMemoryCfg_type.BP_STRUCT_CycleMemoryCfg_type
// Size: 0x80 // Inherited bytes: 0x00
struct FBP_STRUCT_CycleMemoryCfg_type {
	// Fields
	struct FString EffectLink_0_41179A8006C7EE6C251563420C521DDB; // Offset: 0x00 // Size: 0x10
	int ID_1_5B47A7004DF54A940ADBC4160F57F954; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString ItemDesc_2_6C4187405110E23B69E0FF9F05F65613; // Offset: 0x18 // Size: 0x10
	int ItemId_3_478ED2C06E31B747533417EE0A85F604; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString ItemName_5_262187C079F65F0169EBA34605F7BEB5; // Offset: 0x30 // Size: 0x10
	int ItemType_6_7CEDF0005C5CC8AC69E8E28A05F55AE5; // Offset: 0x40 // Size: 0x04
	int SeasonMatchID_7_56B55C802339DBFA09EB8AB002C76764; // Offset: 0x44 // Size: 0x04
	int SeasonYearID_8_70CCC58025D7D3D66A8F3AA80BEF5964; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FString SoundLength_9_52DA7E806E264530451577C108AAD198; // Offset: 0x50 // Size: 0x10
	struct FString LockedDescImage_12_687DF0C025A0D42121083050041C16B5; // Offset: 0x60 // Size: 0x10
	struct FString LockedDescText_13_223EA1402D2F0E1D2CC7D21B064EEEE4; // Offset: 0x70 // Size: 0x10
};

