#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptBlueprintGeneratedClass bp_chat_voice.bp_chat_voice_C
// Size: 0x528 // Inherited bytes: 0x440
struct Abp_chat_voice_C : ALuaClassObj {
	// Fields
	struct UScriptContextComponent* Generated_ScriptContext; // Offset: 0x440 // Size: 0x08
	bool BP_GlobalChatvoiceMicOpened; // Offset: 0x448 // Size: 0x01
	bool BP_GlobalChatvoiceIsTeamup; // Offset: 0x449 // Size: 0x01
	char pad_0x44A[0x2]; // Offset: 0x44a // Size: 0x02
	int BP_GlobalChatvoiceUploadTime; // Offset: 0x44c // Size: 0x04
	struct FBP_STRUCT_GlobalChatvoiceDownloadData BP_STRUCT_GlobalChatvoiceDownloadData; // Offset: 0x450 // Size: 0x40
	struct TArray<struct FBP_STRUCT_GlobalChatvoiceDownloadData> BP_ARRAY_GlobalChatvoiceDownloadList; // Offset: 0x490 // Size: 0x10
	struct FString BP_GlobalChatvoiceCurrentRoom; // Offset: 0x4a0 // Size: 0x10
	int BP_GlobalChatvoiceCurrentMode; // Offset: 0x4b0 // Size: 0x04
	char pad_0x4B4[0x4]; // Offset: 0x4b4 // Size: 0x04
	struct FString BP_GlobalChatvoiceCurrentStage; // Offset: 0x4b8 // Size: 0x10
	bool BP_GlobalChatvoiceSpeakerOpened; // Offset: 0x4c8 // Size: 0x01
	char pad_0x4C9[0x7]; // Offset: 0x4c9 // Size: 0x07
	struct FString BP_GlobalChatvoiceCurrentPlayFile; // Offset: 0x4d0 // Size: 0x10
	struct FString BP_GlobalChatvoiceToTextContent; // Offset: 0x4e0 // Size: 0x10
	bool BP_GlobalChatvoiceRecordSuccess; // Offset: 0x4f0 // Size: 0x01
	char pad_0x4F1[0x3]; // Offset: 0x4f1 // Size: 0x03
	int BP_GlobalChatvoiceTotalLimit; // Offset: 0x4f4 // Size: 0x04
	struct FString BP_GlobalChatvoiceUploadMsgId; // Offset: 0x4f8 // Size: 0x10
	bool BP_GlobalChatvoiceDefaultOpenTeam; // Offset: 0x508 // Size: 0x01
	char pad_0x509[0x7]; // Offset: 0x509 // Size: 0x07
	struct FString BP_GlobalChatvoiceCurrentRole; // Offset: 0x510 // Size: 0x10
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x520 // Size: 0x08

	// Functions

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventClearGVoiceProcedure_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventClearGVoiceProcedure_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventClearGVoiceProcedure
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventClearGVoiceProcedure(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChangeLobbyRoomState_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChangeLobbyRoomState_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChangeLobbyRoomState
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChangeLobbyRoomState(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventStartPlayGVoiceRecord_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventStartPlayGVoiceRecord_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventStartPlayGVoiceRecord
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventStartPlayGVoiceRecord(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventStartGVoiceRecord_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventStartGVoiceRecord_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventStartGVoiceRecord
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventStartGVoiceRecord(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventStopGVoiceRecord_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventStopGVoiceRecord_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventStopGVoiceRecord
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventStopGVoiceRecord(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventUploadGVoiceRecord_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventUploadGVoiceRecord_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventUploadGVoiceRecord
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventUploadGVoiceRecord(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventStopPlayGVoiceRecord_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventStopPlayGVoiceRecord_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventStopPlayGVoiceRecord
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventStopPlayGVoiceRecord(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifyVoiceChatFailToRecord_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifyVoiceChatFailToRecord_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifyVoiceChatFailToRecord
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifyVoiceChatFailToRecord(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifyVoiceRecordTooShort_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifyVoiceRecordTooShort_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifyVoiceRecordTooShort
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifyVoiceRecordTooShort(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifySystemSpeakerOpen_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifySystemSpeakerOpen_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifySystemSpeakerOpen
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifySystemSpeakerOpen(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifyRecordTooShort_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifyRecordTooShort_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifyRecordTooShort
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifyRecordTooShort(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventTickVoiceRoom_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventTickVoiceRoom_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventTickVoiceRoom
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventTickVoiceRoom(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChangeMicState_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChangeMicState_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChangeMicState
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChangeMicState(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifyVoiceOpenSpeaker_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifyVoiceOpenSpeaker_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifyVoiceOpenSpeaker
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifyVoiceOpenSpeaker(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChangeGVoiceMode_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChangeGVoiceMode_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChangeGVoiceMode
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChangeGVoiceMode(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifySystemMicOpen_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifySystemMicOpen_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifySystemMicOpen
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifySystemMicOpen(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChatVoiceSetInfo_Push_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChatVoiceSetInfo_Push_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChatVoiceSetInfo_Push
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChatVoiceSetInfo_Push(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifySystemVoiceOpen_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifySystemVoiceOpen_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifySystemVoiceOpen
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifySystemVoiceOpen(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifyDownloadFailed_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifyDownloadFailed_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifyDownloadFailed
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifyDownloadFailed(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventMicClickCD_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventMicClickCD_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventMicClickCD
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventMicClickCD(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifyVoiceProcedureFailed_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifyVoiceProcedureFailed_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventNotifyVoiceProcedureFailed
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventNotifyVoiceProcedureFailed(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChangeSpeakerState_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChangeSpeakerState_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChangeSpeakerState
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChangeSpeakerState(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChatRequestPrivacy_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChatRequestPrivacy_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChatRequestPrivacy
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChatRequestPrivacy(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventOnTryOpenMic_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventOnTryOpenMic_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventOnTryOpenMic
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventOnTryOpenMic(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventCheckOpenMicFail_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCheckOpenMicFail_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventCheckOpenMicFail
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCheckOpenMicFail(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventCheckOpenMicSuc_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCheckOpenMicSuc_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventCheckOpenMicSuc
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCheckOpenMicSuc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChatVoiceFetchInfo_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChatVoiceFetchInfo_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChatVoiceFetchInfo
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChatVoiceFetchInfo(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChatRequestPrivacyPre_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChatRequestPrivacyPre_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventChatRequestPrivacyPre
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChatRequestPrivacyPre(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventCancelGVoiceRecord_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCancelGVoiceRecord_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.EventCancelGVoiceRecord
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCancelGVoiceRecord(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_chat_voice.bp_chat_voice_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)
};

