#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_TransColumns_type.BP_STRUCT_TransColumns_type
// Size: 0x20 // Inherited bytes: 0x00
struct FBP_STRUCT_TransColumns_type {
	// Fields
	struct FString Columns_0_47AC24714CA709ABE62AB2B97B02C861; // Offset: 0x00 // Size: 0x10
	struct FString Table_1_B0FEB2B8486D4078687135A2F1589ADF; // Offset: 0x10 // Size: 0x10
};

