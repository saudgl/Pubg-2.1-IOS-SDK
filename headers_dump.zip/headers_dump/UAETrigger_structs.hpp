#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct UAETrigger.TriggerAreaEvent
// Size: 0x18 // Inherited bytes: 0x00
struct FTriggerAreaEvent {
	// Fields
	struct FTriggerEventKeySelector EventKeySelector; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FTriggerEventParamKeySelector> EventParam; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct UAETrigger.TriggerEventParamKeySelector
// Size: 0x18 // Inherited bytes: 0x00
struct FTriggerEventParamKeySelector {
	// Fields
	struct FName SelectedKeyName; // Offset: 0x00 // Size: 0x08
	struct FString ParamData; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct UAETrigger.TriggerEventKeySelector
// Size: 0x08 // Inherited bytes: 0x00
struct FTriggerEventKeySelector {
	// Fields
	struct FName SelectedKeyName; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct UAETrigger.LevelEventListenerList
// Size: 0x50 // Inherited bytes: 0x00
struct FLevelEventListenerList {
	// Fields
	struct TSet<struct ULevelEventListener*> Listeners; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct UAETrigger.TriggerEventListenerTrigger
// Size: 0x08 // Inherited bytes: 0x00
struct FTriggerEventListenerTrigger {
	// Fields
	struct UUAETriggerObject* ListenerTrigger; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct UAETrigger.EventFuncListenerTrigger
// Size: 0x10 // Inherited bytes: 0x00
struct FEventFuncListenerTrigger {
	// Fields
	struct TArray<struct UUAETriggerObject*> ListenerTriggers; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct UAETrigger.LevelInstanceCondition
// Size: 0x18 // Inherited bytes: 0x00
struct FLevelInstanceCondition {
	// Fields
	struct FString TriggerName; // Offset: 0x00 // Size: 0x10
	struct UTriggerCondition* Condition; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct UAETrigger.LevelDirectorInstAction
// Size: 0x10 // Inherited bytes: 0x00
struct FLevelDirectorInstAction {
	// Fields
	int64_t ActionUniqueID; // Offset: 0x00 // Size: 0x08
	struct UTriggerAction* Action; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct UAETrigger.NodeCreateContent
// Size: 0x28 // Inherited bytes: 0x00
struct FNodeCreateContent {
	// Fields
	struct FString NodeName; // Offset: 0x00 // Size: 0x10
	bool DefaultActive; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct TArray<struct FString> TriggerNames; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct UAETrigger.TaskRepData
// Size: 0x18 // Inherited bytes: 0x00
struct FTaskRepData {
	// Fields
	struct FString TaskName; // Offset: 0x00 // Size: 0x10
	int TaskId; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct UAETrigger.UAELevelDirectorRepData
// Size: 0x18 // Inherited bytes: 0x00
struct FUAELevelDirectorRepData {
	// Fields
	struct FUFlowNodeRepData FlowNodeRepData; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct UAETrigger.UFlowNodeRepData
// Size: 0x18 // Inherited bytes: 0x00
struct FUFlowNodeRepData {
	// Fields
	struct FString RepData; // Offset: 0x00 // Size: 0x10
	int NodeID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct UAETrigger.TriggerActionRepData
// Size: 0x30 // Inherited bytes: 0x00
struct FTriggerActionRepData {
	// Fields
	int64_t RepID; // Offset: 0x00 // Size: 0x08
	int64_t UId; // Offset: 0x08 // Size: 0x08
	struct FString ActionClassName; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FTriggerParamRepData> ParamDatas; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct UAETrigger.TriggerParamRepData
// Size: 0x28 // Inherited bytes: 0x00
struct FTriggerParamRepData {
	// Fields
	char ParamType; // Offset: 0x00 // Size: 0x01
	char ParamSubType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct FString ParamName; // Offset: 0x08 // Size: 0x10
	struct TArray<char> ParamData; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct UAETrigger.TriggerClassItem
// Size: 0x28 // Inherited bytes: 0x00
struct FTriggerClassItem {
	// Fields
	struct FString TagName; // Offset: 0x00 // Size: 0x10
	struct FString ClassFullPath; // Offset: 0x10 // Size: 0x10
	float RandomRadius; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct UAETrigger.VariableSetCachedActors
// Size: 0x58 // Inherited bytes: 0x00
struct FVariableSetCachedActors {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
	struct AActor* LastAccessActor; // Offset: 0x50 // Size: 0x08
};

