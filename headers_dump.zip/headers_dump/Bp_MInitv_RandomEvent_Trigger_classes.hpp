#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Bp_MInitv_RandomEvent_Trigger.Bp_MInitv_RandomEvent_Trigger_C
// Size: 0x3f0 // Inherited bytes: 0x3d8
struct ABp_MInitv_RandomEvent_Trigger_C : AActor {
	// Fields
	struct UBoxComponent* Box; // Offset: 0x3d8 // Size: 0x08
	struct FString EventName; // Offset: 0x3e0 // Size: 0x10

	// Functions

	// Object Name: Function Bp_MInitv_RandomEvent_Trigger.Bp_MInitv_RandomEvent_Trigger_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)
};

