#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Global_Voice.Global_Voice_C
// Size: 0x578 // Inherited bytes: 0x400
struct UGlobal_Voice_C : UUAEUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x400 // Size: 0x08
	struct UWidgetAnimation* DX_Transitions_Enter; // Offset: 0x408 // Size: 0x08
	struct UWidgetAnimation* DX_Transitions_StartEnter; // Offset: 0x410 // Size: 0x08
	struct UButton* btn_mic_off; // Offset: 0x418 // Size: 0x08
	struct UButton* btn_mic_on; // Offset: 0x420 // Size: 0x08
	struct UButton* btn_voice_off; // Offset: 0x428 // Size: 0x08
	struct UButton* btn_voice_on; // Offset: 0x430 // Size: 0x08
	struct UButton* BtnSendGifts; // Offset: 0x438 // Size: 0x08
	struct UButton* Button_1; // Offset: 0x440 // Size: 0x08
	struct UButton* Button_2; // Offset: 0x448 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_voice; // Offset: 0x450 // Size: 0x08
	struct UImage* Image_4; // Offset: 0x458 // Size: 0x08
	struct UImage* Image_7; // Offset: 0x460 // Size: 0x08
	struct UImage* Image_8; // Offset: 0x468 // Size: 0x08
	struct UImage* Image_11; // Offset: 0x470 // Size: 0x08
	struct UImage* Image_24; // Offset: 0x478 // Size: 0x08
	struct UImage* Image_26; // Offset: 0x480 // Size: 0x08
	struct UImage* Image_28; // Offset: 0x488 // Size: 0x08
	struct UImage* Image_30; // Offset: 0x490 // Size: 0x08
	struct UCanvasPanel* lobby_root_anchor; // Offset: 0x498 // Size: 0x08
	struct UOverlay* mic_root_anchor; // Offset: 0x4a0 // Size: 0x08
	struct UOverlay* Overlay_1; // Offset: 0x4a8 // Size: 0x08
	struct UOverlay* Overlay_2; // Offset: 0x4b0 // Size: 0x08
	struct UOverlay* voice_root_anchor; // Offset: 0x4b8 // Size: 0x08
	struct UGVoiceInterface* GVoiceHandle; // Offset: 0x4c0 // Size: 0x08
	struct Abp_chat_voice_C* LuaObject; // Offset: 0x4c8 // Size: 0x08
	int GVOICE_REALTIME; // Offset: 0x4d0 // Size: 0x04
	int GVOICE_OFFLINE; // Offset: 0x4d4 // Size: 0x04
	bool VoiceMessageInited; // Offset: 0x4d8 // Size: 0x01
	bool RoleValid; // Offset: 0x4d9 // Size: 0x01
	char pad_0x4DA[0x6]; // Offset: 0x4da // Size: 0x06
	struct FString RoleGID; // Offset: 0x4e0 // Size: 0x10
	int GVoiceResendCounter; // Offset: 0x4f0 // Size: 0x04
	int GVoiceResendRatio; // Offset: 0x4f4 // Size: 0x04
	int GVOICE_TIMER_AUTH; // Offset: 0x4f8 // Size: 0x04
	int GVOICE_TIMER_UPLOAD; // Offset: 0x4fc // Size: 0x04
	int GVOICE_TIMER_TOTEXT; // Offset: 0x500 // Size: 0x04
	int GVOICE_TIMER_RECORD; // Offset: 0x504 // Size: 0x04
	int GVOICE_TIMER_DOWNLOAD; // Offset: 0x508 // Size: 0x04
	int GVOICE_TIMER_PLAYRECORD; // Offset: 0x50c // Size: 0x04
	struct TArray<struct FTimerHandle> GVoiceResendStopTimers; // Offset: 0x510 // Size: 0x10
	struct TArray<struct FTimerHandle> GVoiceResendLoopTimers; // Offset: 0x520 // Size: 0x10
	float GVoiceOfflineLimit; // Offset: 0x530 // Size: 0x04
	float GVoiceProcedureResendTime; // Offset: 0x534 // Size: 0x04
	struct FString lastDownloadRecord; // Offset: 0x538 // Size: 0x10
	bool voiceRecording; // Offset: 0x548 // Size: 0x01
	bool voiceTryDelayRecording; // Offset: 0x549 // Size: 0x01
	bool voiceTryDownloading; // Offset: 0x54a // Size: 0x01
	bool voiceTryRecording; // Offset: 0x54b // Size: 0x01
	bool voiceUploading; // Offset: 0x54c // Size: 0x01
	bool isTeamup; // Offset: 0x54d // Size: 0x01
	char pad_0x54E[0x2]; // Offset: 0x54e // Size: 0x02
	struct USettingConfig_C* userSetting; // Offset: 0x550 // Size: 0x08
	int lastBGMVolume; // Offset: 0x558 // Size: 0x04
	bool lastBGMFade; // Offset: 0x55c // Size: 0x01
	char pad_0x55D[0x3]; // Offset: 0x55d // Size: 0x03
	float thisRecordTime; // Offset: 0x560 // Size: 0x04
	char pad_0x564[0x4]; // Offset: 0x564 // Size: 0x04
	struct FTimerHandle TickTimer; // Offset: 0x568 // Size: 0x08
	bool voiceDownloading; // Offset: 0x570 // Size: 0x01
	bool voiceToTexting; // Offset: 0x571 // Size: 0x01
	bool animationShowUp; // Offset: 0x572 // Size: 0x01
	bool isMicCD; // Offset: 0x573 // Size: 0x01
	float MicClickCD; // Offset: 0x574 // Size: 0x04

	// Functions

	// Object Name: Function Global_Voice.Global_Voice_C.OnChatPrivacyAcceptedPre
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnChatPrivacyAcceptedPre(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnChatPrivacyAccepted
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnChatPrivacyAccepted(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.Transitions_Enter
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Transitions_Enter(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.SyncPushOneData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SyncPushOneData(struct FString prop); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Global_Voice.Global_Voice_C.SyncOneData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SyncOneData(struct FString prop); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Global_Voice.Global_Voice_C.ChangeSpeakerFlag
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ChangeSpeakerFlag(bool Open); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Global_Voice.Global_Voice_C.ChangeMicphoneFlag
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ChangeMicphoneFlag(bool Open); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Global_Voice.Global_Voice_C.OnTryCloseSpeaker
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnTryCloseSpeaker(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.TickVoiceRoom
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void TickVoiceRoom(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.UIHide
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UIHide(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.UIShow
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UIShow(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnUploadRecordFailed
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnUploadRecordFailed(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnTryCloseMic
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnTryCloseMic(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.StopPlayRecordFileAndRecoverBGM
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void StopPlayRecordFileAndRecoverBGM(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.FadeOutBGM
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void FadeOutBGM(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.FadeInBGM
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void FadeInBGM(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.CheckVoiceMessageInited
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CheckVoiceMessageInited(bool& Ret); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Global_Voice.Global_Voice_C.OnClickSpeakerOff
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnClickSpeakerOff(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnClickSpeakerOn
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnClickSpeakerOn(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnClickMicOff
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnClickMicOff(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnClickMicOn
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnClickMicOn(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.ClearAllTimers
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ClearAllTimers(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RefreshSpeakerUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RefreshSpeakerUI(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RefreshMicUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RefreshMicUI(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.SyncTeamupState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SyncTeamupState(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RefreshTeamUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RefreshTeamUI(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.ChangeSpeakerState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ChangeSpeakerState(bool Open); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Global_Voice.Global_Voice_C.ChangeMicState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ChangeMicState(bool State); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Global_Voice.Global_Voice_C.RefreshLobbyUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RefreshLobbyUI(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RefreshStageUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RefreshStageUI(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.StopRecordVoice
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void StopRecordVoice(bool cancel); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Global_Voice.Global_Voice_C.StartRecordVoice
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void StartRecordVoice(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.StopPlayRecordFile
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void StopPlayRecordFile(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.PlayDownloadFile
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PlayDownloadFile(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RequireGVoiceDownload
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void RequireGVoiceDownload(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RecoverGVoiceRealtime
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RecoverGVoiceRealtime(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.LeaveGVoiceOffline
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void LeaveGVoiceOffline(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RetrieveGVoiceOffline
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RetrieveGVoiceOffline(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.GetProcedureTimer
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetProcedureTimer(int Type, bool stopTimer, struct FTimerHandle& Output); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Global_Voice.Global_Voice_C.AddProcedureTimer
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void AddProcedureTimer(struct FTimerHandle Handle, int resendType, bool isStop); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Global_Voice.Global_Voice_C.ClearGVoiceSpeechToTextResendEntry
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ClearGVoiceSpeechToTextResendEntry(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.ClearGVoiceUploadResendEntry
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ClearGVoiceUploadResendEntry(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.ClearGVoiceAuthResendEntry
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ClearGVoiceAuthResendEntry(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.ProcessVoiceProcedure
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void ProcessVoiceProcedure(bool& Output); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Global_Voice.Global_Voice_C.ClearResendProcedure
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ClearResendProcedure(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RequireGVoiceSpeechToText
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RequireGVoiceSpeechToText(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RequireGVoiceUpload
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RequireGVoiceUpload(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RequireGVoiceAuth
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RequireGVoiceAuth(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RequireGVoiceSpeechToTextEntry
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RequireGVoiceSpeechToTextEntry(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RequireGVoiceUploadEntry
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void RequireGVoiceUploadEntry(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RequireGVoiceAuthEntry
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RequireGVoiceAuthEntry(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.ResetGVoiceMode
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ResetGVoiceMode(int Mode); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Global_Voice.Global_Voice_C.ResetTeamVoice
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ResetTeamVoice(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.SyncPushLuaData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SyncPushLuaData(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.SyncLuaData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SyncLuaData(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnTeamVoiceRoomChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnTeamVoiceRoomChanged(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnVoiceModeChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnVoiceModeChanged(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnResetRoleInfo
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnResetRoleInfo(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnClearRoleInfo
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnClearRoleInfo(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnGVoiceInited
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnGVoiceInited(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnAfterRequireAuth
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnAfterRequireAuth(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnRequireAuthResend
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRequireAuthResend(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnClearAuthResend
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnClearAuthResend(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnAfterRequireUpload
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnAfterRequireUpload(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnRequireUploadResend
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRequireUploadResend(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnClearUploadResend
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnClearUploadResend(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnAfterRequireSpeechToText
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnAfterRequireSpeechToText(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnRequireSpeechToTextResend
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRequireSpeechToTextResend(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnClearSpeechToTextResend
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnClearSpeechToTextResend(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnJoinVoiceRoomSuccess
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnJoinVoiceRoomSuccess(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnTryDownloadVoiceRecord
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnTryDownloadVoiceRecord(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnClearDownloadFailedNotify
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnClearDownloadFailedNotify(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnDownloadFileComplete
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnDownloadFileComplete(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnApplyMessageKeyComplete
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnApplyMessageKeyComplete(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnTryStartRecordVoice
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnTryStartRecordVoice(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnTryStopRecordVoice
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnTryStopRecordVoice(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnTryCancelRecordVoice
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnTryCancelRecordVoice(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnUploadRecordFileComplete
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnUploadRecordFileComplete(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnUploadSpeechToTextComplete
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnUploadSpeechToTextComplete(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnGameStageChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnGameStageChanged(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.BndEvt__btn_voice_on_K2Node_ComponentBoundEvent_15_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__btn_voice_on_K2Node_ComponentBoundEvent_15_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.BndEvt__btn_voice_off_K2Node_ComponentBoundEvent_41_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__btn_voice_off_K2Node_ComponentBoundEvent_41_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.BndEvt__btn_mic_on_K2Node_ComponentBoundEvent_58_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__btn_mic_on_K2Node_ComponentBoundEvent_58_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnVoiceMicOpenChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnVoiceMicOpenChanged(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnVoiceSpeakerOpenChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnVoiceSpeakerOpenChanged(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.BndEvt__btn_mic_off_K2Node_ComponentBoundEvent_104_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__btn_mic_off_K2Node_ComponentBoundEvent_104_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnTeamStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnTeamStateChanged(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnTryStopPlayRecordVoice
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnTryStopPlayRecordVoice(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnApplicationDeactivated
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnApplicationDeactivated(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnQuitVoiceRoomSuccess
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnQuitVoiceRoomSuccess(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnUploadRecordFileFailed
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnUploadRecordFileFailed(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnUploadSpeechToTextFailed
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnUploadSpeechToTextFailed(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.OnFinishMicCD
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnFinishMicCD(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.RecruitOpenMic
	// Flags: [BlueprintCallable|BlueprintEvent]
	void RecruitOpenMic(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.BndEvt__BtnSendGifts_K2Node_ComponentBoundEvent_17_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__BtnSendGifts_K2Node_ComponentBoundEvent_17_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Voice.Global_Voice_C.ExecuteUbergraph_Global_Voice
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Global_Voice(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

