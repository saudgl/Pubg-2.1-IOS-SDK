#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass PetMiniTvAvatar_01.PetMiniTvAvatar_01_C
// Size: 0x268 // Inherited bytes: 0x268
struct UPetMiniTvAvatar_01_C : UPetAvatarHandle {
};

