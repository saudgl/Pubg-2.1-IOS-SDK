#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_WeaponDIYMatTable_type.BP_STRUCT_WeaponDIYMatTable_type
// Size: 0x28 // Inherited bytes: 0x00
struct FBP_STRUCT_WeaponDIYMatTable_type {
	// Fields
	int ID_0_23417F401B45618B4AEC918F0E131BC4; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString MatTexturePath_1_414664006E34CD52101931710A03BB38; // Offset: 0x08 // Size: 0x10
	struct FString MatColorString_2_4F78E2004D402EF01AC1DCEC0130D107; // Offset: 0x18 // Size: 0x10
};

