#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_StatEventType_type.BP_STRUCT_StatEventType_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_StatEventType_type {
	// Fields
	struct FString DisplayName_0_7D516B402CBFB7AB2A776EB00D8D1405; // Offset: 0x00 // Size: 0x10
	int id_1_49A788C0256E4AF90B9DAE5205E4F254; // Offset: 0x10 // Size: 0x04
};

