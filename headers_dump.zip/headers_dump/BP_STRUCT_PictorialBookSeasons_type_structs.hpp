#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_PictorialBookSeasons_type.BP_STRUCT_PictorialBookSeasons_type
// Size: 0x60 // Inherited bytes: 0x00
struct FBP_STRUCT_PictorialBookSeasons_type {
	// Fields
	struct FString SeasonDesc_0_2BEEA3002A53AB26250A5F8808A9A993; // Offset: 0x00 // Size: 0x10
	int Season_1_5692E34018539A0F3CD1F5690B05089E; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString SeasonName_2_65CEA3804B698AEC27BE293D08AA4335; // Offset: 0x18 // Size: 0x10
	struct FString SeasonPoster_3_2048828068E9A6EC65A678900873A262; // Offset: 0x28 // Size: 0x10
	struct FString SeasonTitle_4_067163C019D2FB3F0EE2F7D00A8B5BA5; // Offset: 0x38 // Size: 0x10
	int JKSwitch_5_119C4AC03C6E605D5E864D1C0E24C018; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FString SeasonPoster2_6_3F614F004AE5297E2B9EC8C6073A26D2; // Offset: 0x50 // Size: 0x10
};

