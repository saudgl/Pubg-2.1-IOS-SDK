#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_PickUpCountSetting_type.BP_STRUCT_PickUpCountSetting_type
// Size: 0x08 // Inherited bytes: 0x00
struct FBP_STRUCT_PickUpCountSetting_type {
	// Fields
	int ItemID_0_545B594077C2AB55279AB97B0BD162B4; // Offset: 0x00 // Size: 0x04
	int PickUpMaxCount_1_7F45D10069EF87FA21D7CBCA0C4BDCD4; // Offset: 0x04 // Size: 0x04
};

