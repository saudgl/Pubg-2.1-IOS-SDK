#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Reddot_Anchor_Item02.Reddot_Anchor_Item02_C
// Size: 0x2cc // Inherited bytes: 0x2b8
struct UReddot_Anchor_Item02_C : ULuaUserWidget {
	// Fields
	struct UWidgetAnimation* Breathing; // Offset: 0x2b8 // Size: 0x08
	struct UTextBlock* TextBlock_Num; // Offset: 0x2c0 // Size: 0x08
	int PosTemplate; // Offset: 0x2c8 // Size: 0x04
};

