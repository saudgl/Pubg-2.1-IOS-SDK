#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_DiySuitPatternConfig_type.BP_STRUCT_DiySuitPatternConfig_type
// Size: 0x48 // Inherited bytes: 0x00
struct FBP_STRUCT_DiySuitPatternConfig_type {
	// Fields
	int ID_0_1986288022A4FBB87BF37984018D0894; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Icon_1_051847804144FD206B0A47070D08B9DE; // Offset: 0x08 // Size: 0x10
	int ItemID_2_0F4A4C4062CFB54B08ACFC37094B4CD4; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString BPUrl_3_25D5368039F7AA966A5B00C00083445C; // Offset: 0x20 // Size: 0x10
	int Cost_4_22EF0B80079BBB006A2E79840D08E724; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString Name_5_5103258079CB0E186B3912250D0907B5; // Offset: 0x38 // Size: 0x10
};

