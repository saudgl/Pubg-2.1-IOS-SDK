#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Mid_Message_UIBP.Lobby_Mid_Message_UIBP_C
// Size: 0x3a0 // Inherited bytes: 0x248
struct ULobby_Mid_Message_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x248 // Size: 0x08
	struct UImage* 18+; // Offset: 0x250 // Size: 0x08
	struct UButton* Button_1; // Offset: 0x258 // Size: 0x08
	struct UButton* Button_DoubleCardShowTips; // Offset: 0x260 // Size: 0x08
	struct UButton* Button_Observe; // Offset: 0x268 // Size: 0x08
	struct UButton* Button_TeamUp; // Offset: 0x270 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_13; // Offset: 0x278 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_18; // Offset: 0x280 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_32; // Offset: 0x288 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_38; // Offset: 0x290 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_ButtonList; // Offset: 0x298 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_SegmentLimit; // Offset: 0x2a0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_TeamPlatformEntry; // Offset: 0x2a8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_TeamPlatformTips; // Offset: 0x2b0 // Size: 0x08
	struct UCommon_Avatar_BP_C* Common_Avatar_BP; // Offset: 0x2b8 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x2c0 // Size: 0x08
	struct UImage* Image_12; // Offset: 0x2c8 // Size: 0x08
	struct UImage* Image_60; // Offset: 0x2d0 // Size: 0x08
	struct UImage* Image_DoubleIcon; // Offset: 0x2d8 // Size: 0x08
	struct UImage* Image_New; // Offset: 0x2e0 // Size: 0x08
	struct UCanvasPanel* NewbieGuide_TeamPlatformEntry; // Offset: 0x2e8 // Size: 0x08
	struct UReddot_Anchor_C* Reddot_Anchor; // Offset: 0x2f0 // Size: 0x08
	struct UTextBlock* TextBlock_1; // Offset: 0x2f8 // Size: 0x08
	struct UTextBlock* TextBlock_2; // Offset: 0x300 // Size: 0x08
	struct UTextBlock* TextBlock_5; // Offset: 0x308 // Size: 0x08
	struct UTextBlock* TextBlock_20; // Offset: 0x310 // Size: 0x08
	struct UTextBlock* TextBlock_CardNum; // Offset: 0x318 // Size: 0x08
	struct UTextBlock* TextBlock_NickName; // Offset: 0x320 // Size: 0x08
	struct UTextBlock* TextBlock_SegmentLimit; // Offset: 0x328 // Size: 0x08
	struct UTextBlock* TextBlock_Team; // Offset: 0x330 // Size: 0x08
	struct UTextBlock* TextBlock_UID; // Offset: 0x338 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_2; // Offset: 0x340 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_DoubleCardShowTips; // Offset: 0x348 // Size: 0x08
	struct FSlateColor MentorWhiteColor; // Offset: 0x350 // Size: 0x28
	struct FSlateColor MentorYellowColor; // Offset: 0x378 // Size: 0x28
};

