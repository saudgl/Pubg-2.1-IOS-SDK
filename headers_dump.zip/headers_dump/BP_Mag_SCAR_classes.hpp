#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Mag_SCAR.BP_Mag_SCAR_C
// Size: 0x430 // Inherited bytes: 0x430
struct UBP_Mag_SCAR_C : UBattleItemHandle_WeapAttachment_C {
};

