#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Mid_Shop_UIBP.Lobby_Mid_Shop_UIBP_C
// Size: 0x3f8 // Inherited bytes: 0x248
struct ULobby_Mid_Shop_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Anima_Shop; // Offset: 0x248 // Size: 0x08
	struct UWidgetAnimation* Anima_Supply; // Offset: 0x250 // Size: 0x08
	struct UWidgetAnimation* Anima_RP; // Offset: 0x258 // Size: 0x08
	struct UWidgetAnimation* Animation_Hand_Loop; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Animation_Mask; // Offset: 0x268 // Size: 0x08
	struct UWidgetAnimation* eff_ShopStar; // Offset: 0x270 // Size: 0x08
	struct UWidgetAnimation* RP_Warning; // Offset: 0x278 // Size: 0x08
	struct UButton* Button_RP; // Offset: 0x280 // Size: 0x08
	struct UButton* Button_Shop; // Offset: 0x288 // Size: 0x08
	struct UButton* Button_Supply; // Offset: 0x290 // Size: 0x08
	struct UButton* Button_Supply_JK; // Offset: 0x298 // Size: 0x08
	struct UCanvasPanel* Canvas_NewbieGuide; // Offset: 0x2a0 // Size: 0x08
	struct UCanvasPanel* Canvas_Panel_HandGuide; // Offset: 0x2a8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_CRATES; // Offset: 0x2b0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Rp; // Offset: 0x2b8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Shop; // Offset: 0x2c0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Supply; // Offset: 0x2c8 // Size: 0x08
	struct UCanvasPanel* Effect_RP; // Offset: 0x2d0 // Size: 0x08
	struct UCanvasPanel* Effect_Shop; // Offset: 0x2d8 // Size: 0x08
	struct UCanvasPanel* Effect_Supply; // Offset: 0x2e0 // Size: 0x08
	struct UCanvasPanel* FX_Mask; // Offset: 0x2e8 // Size: 0x08
	struct UButton* GuideBtn; // Offset: 0x2f0 // Size: 0x08
	struct UCanvasPanel* GuidePanel; // Offset: 0x2f8 // Size: 0x08
	struct UTextBlock* GuideTipText; // Offset: 0x300 // Size: 0x08
	struct UImage* Image_3; // Offset: 0x308 // Size: 0x08
	struct UImage* Image_4; // Offset: 0x310 // Size: 0x08
	struct UImage* Image_70; // Offset: 0x318 // Size: 0x08
	struct UImage* Image_102; // Offset: 0x320 // Size: 0x08
	struct UImage* Image_Gift; // Offset: 0x328 // Size: 0x08
	struct UImage* Image_Glow1; // Offset: 0x330 // Size: 0x08
	struct UImage* Image_Glow2; // Offset: 0x338 // Size: 0x08
	struct UImage* Image_Glow3; // Offset: 0x340 // Size: 0x08
	struct UImage* Image_JKSupReddot; // Offset: 0x348 // Size: 0x08
	struct UImage* Image_Rp; // Offset: 0x350 // Size: 0x08
	struct UImage* Image_Rp_Mask; // Offset: 0x358 // Size: 0x08
	struct UImage* Image_Shop; // Offset: 0x360 // Size: 0x08
	struct UImage* Image_Shop_KJ; // Offset: 0x368 // Size: 0x08
	struct UImage* Image_Star; // Offset: 0x370 // Size: 0x08
	struct UCanvasPanel* Image_UnknowReddot; // Offset: 0x378 // Size: 0x08
	struct UImage* IsShowPrime; // Offset: 0x380 // Size: 0x08
	struct UMaskBoxItem_C* MaskBoxItem; // Offset: 0x388 // Size: 0x08
	struct UCanvasPanel* Panel_Download; // Offset: 0x390 // Size: 0x08
	struct UCanvasPanel* Panel_UnknowButton; // Offset: 0x398 // Size: 0x08
	struct UReddot_Anchor_C* Reddot_Anchor; // Offset: 0x3a0 // Size: 0x08
	struct UCanvasPanel* Shop_International; // Offset: 0x3a8 // Size: 0x08
	struct UCanvasPanel* Shop_JK; // Offset: 0x3b0 // Size: 0x08
	struct UReddot_Anchor_C* Store_Reddot_Anchor; // Offset: 0x3b8 // Size: 0x08
	struct UReddot_Anchor_C* Sup_Reddot_Anchor; // Offset: 0x3c0 // Size: 0x08
	struct UCanvasPanel* Supply_JK; // Offset: 0x3c8 // Size: 0x08
	struct UTextBlock* TextBlock_Time; // Offset: 0x3d0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_PassReddot; // Offset: 0x3d8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_RP; // Offset: 0x3e0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Shop; // Offset: 0x3e8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Supply; // Offset: 0x3f0 // Size: 0x08
};

