#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ModeTeamTable_type.BP_STRUCT_ModeTeamTable_type
// Size: 0x4c // Inherited bytes: 0x00
struct FBP_STRUCT_ModeTeamTable_type {
	// Fields
	int TeamId_1_53410F803B6D142223F831700D8D5A34; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString ForbidTips_2_348BE0007F26AAEE38819A34033560C3; // Offset: 0x08 // Size: 0x10
	struct FString mapName_6_6BD132404199364D3429D1AC01E8FCC5; // Offset: 0x18 // Size: 0x10
	int Sort_7_163A0C806525C7721036F7960BCDC0A4; // Offset: 0x28 // Size: 0x04
	int LabelStyle_8_759CFEC062B9ACB3170DC30F01D7BF95; // Offset: 0x2c // Size: 0x04
	int LabelWords_9_3A699E405AEED4F11577CC6001D16903; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString SubModeIDs_17_72C14E404114BF3F3B7A06F3099710D3; // Offset: 0x38 // Size: 0x10
	int MaxMember_18_79DAE2001FC5A7202E4AE0DD0088E932; // Offset: 0x48 // Size: 0x04
};

