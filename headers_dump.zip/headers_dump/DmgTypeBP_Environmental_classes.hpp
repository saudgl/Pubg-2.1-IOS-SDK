#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass DmgTypeBP_Environmental.DmgTypeBP_Environmental_C
// Size: 0x40 // Inherited bytes: 0x40
struct UDmgTypeBP_Environmental_C : UDamageType {
};

