#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass VideoMask.VideoMask_C
// Size: 0x248 // Inherited bytes: 0x248
struct UVideoMask_C : UUserWidget {
};

