#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SeasonCardsConfig_type.BP_STRUCT_SeasonCardsConfig_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_SeasonCardsConfig_type {
	// Fields
	int CardType_0_5426D7803E694E0419B277450FCDFC15; // Offset: 0x00 // Size: 0x04
	int EffectiveType_1_0DD95D4046805E1365129D1D05725F15; // Offset: 0x04 // Size: 0x04
	int ItemID_2_6B9D9780696357662EFE4A080DEE0584; // Offset: 0x08 // Size: 0x04
	int Score_3_25DF0F800DCB33C004B129BE05D7F2C5; // Offset: 0x0c // Size: 0x04
	int TimeLimitType_4_3FE53C803A67467C146433D9089E6755; // Offset: 0x10 // Size: 0x04
};

