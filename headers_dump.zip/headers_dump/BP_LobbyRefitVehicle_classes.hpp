#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C
// Size: 0x775 // Inherited bytes: 0x5c0
struct ABP_LobbyRefitVehicle_C : ABP_LobbyVehicle_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x5c0 // Size: 0x08
	struct UStaticMeshComponent* DefaultStaticMesh; // Offset: 0x5c8 // Size: 0x08
	struct UCameraComponent* Camera; // Offset: 0x5d0 // Size: 0x08
	struct USpringArmComponent* SpringArm; // Offset: 0x5d8 // Size: 0x08
	float TimeLine_LerpPosition_degree_BC84527D4F1E3F8A299259BA82D05CD5; // Offset: 0x5e0 // Size: 0x04
	enum class ETimelineDirection TimeLine_LerpPosition__Direction_BC84527D4F1E3F8A299259BA82D05CD5; // Offset: 0x5e4 // Size: 0x01
	char pad_0x5E5[0x3]; // Offset: 0x5e5 // Size: 0x03
	struct UTimelineComponent* TimeLine_LerpPosition; // Offset: 0x5e8 // Size: 0x08
	float Timeline_AutoPlay_yaw_87093ECB435381EB481155BD1C007A5B; // Offset: 0x5f0 // Size: 0x04
	float Timeline_AutoPlay_pitch_87093ECB435381EB481155BD1C007A5B; // Offset: 0x5f4 // Size: 0x04
	enum class ETimelineDirection Timeline_AutoPlay__Direction_87093ECB435381EB481155BD1C007A5B; // Offset: 0x5f8 // Size: 0x01
	char pad_0x5F9[0x7]; // Offset: 0x5f9 // Size: 0x07
	struct UTimelineComponent* Timeline_AutoPlay; // Offset: 0x600 // Size: 0x08
	float TimeLine_BlendCamera_time_16B4579C4F72C1371A81BFBE1D6CF40B; // Offset: 0x608 // Size: 0x04
	enum class ETimelineDirection TimeLine_BlendCamera__Direction_16B4579C4F72C1371A81BFBE1D6CF40B; // Offset: 0x60c // Size: 0x01
	char pad_0x60D[0x3]; // Offset: 0x60d // Size: 0x03
	struct UTimelineComponent* TimeLine_BlendCamera; // Offset: 0x610 // Size: 0x08
	float Timeline_Vehicle_Update_Zoom_in_cameraX_4617DA274820636AAC83688C648EE214; // Offset: 0x618 // Size: 0x04
	enum class ETimelineDirection Timeline_Vehicle_Update_Zoom_in__Direction_4617DA274820636AAC83688C648EE214; // Offset: 0x61c // Size: 0x01
	char pad_0x61D[0x3]; // Offset: 0x61d // Size: 0x03
	struct UTimelineComponent* Timeline_Vehicle_Update_Zoom_in; // Offset: 0x620 // Size: 0x08
	float Timeline_Vehicle_Update_Zoom_out_cameraX_C9815D554EBF979651AC3BA48613EE7F; // Offset: 0x628 // Size: 0x04
	enum class ETimelineDirection Timeline_Vehicle_Update_Zoom_out__Direction_C9815D554EBF979651AC3BA48613EE7F; // Offset: 0x62c // Size: 0x01
	char pad_0x62D[0x3]; // Offset: 0x62d // Size: 0x03
	struct UTimelineComponent* Timeline_Vehicle_Update_Zoom_out; // Offset: 0x630 // Size: 0x08
	float TimeLine_LerpRotator_time_88CF9F274BE419FD7F606D9F8C5776A8; // Offset: 0x638 // Size: 0x04
	enum class ETimelineDirection TimeLine_LerpRotator__Direction_88CF9F274BE419FD7F606D9F8C5776A8; // Offset: 0x63c // Size: 0x01
	char pad_0x63D[0x3]; // Offset: 0x63d // Size: 0x03
	struct UTimelineComponent* TimeLine_LerpRotator; // Offset: 0x640 // Size: 0x08
	enum class ETouchIndex inputFingerIndex; // Offset: 0x648 // Size: 0x01
	char pad_0x649[0x3]; // Offset: 0x649 // Size: 0x03
	float initX; // Offset: 0x64c // Size: 0x04
	float initY; // Offset: 0x650 // Size: 0x04
	float tempX; // Offset: 0x654 // Size: 0x04
	float tempY; // Offset: 0x658 // Size: 0x04
	bool isCloseUp; // Offset: 0x65c // Size: 0x01
	bool isTickRefitTips; // Offset: 0x65d // Size: 0x01
	char pad_0x65E[0x2]; // Offset: 0x65e // Size: 0x02
	struct FTransform tempTransform_ForBlendCameraActor; // Offset: 0x660 // Size: 0x30
	struct FTransform initTransform; // Offset: 0x690 // Size: 0x30
	struct FTransform TargetTransform; // Offset: 0x6c0 // Size: 0x30
	float shortRadius; // Offset: 0x6f0 // Size: 0x04
	float longRadius; // Offset: 0x6f4 // Size: 0x04
	struct ABP_LobbyRefitCloseUp_C* cameraCloseUp; // Offset: 0x6f8 // Size: 0x08
	struct FVector CenterPoint; // Offset: 0x700 // Size: 0x0c
	struct FVector shortVector; // Offset: 0x70c // Size: 0x0c
	struct FVector longVector; // Offset: 0x718 // Size: 0x0c
	int ellipseRotateDirection; // Offset: 0x724 // Size: 0x04
	int targetCloseUpSlotId; // Offset: 0x728 // Size: 0x04
	bool canAutoPlay; // Offset: 0x72c // Size: 0x01
	char pad_0x72D[0x3]; // Offset: 0x72d // Size: 0x03
	float lastAutoPlayTime; // Offset: 0x730 // Size: 0x04
	bool showAllTips; // Offset: 0x734 // Size: 0x01
	char pad_0x735[0x3]; // Offset: 0x735 // Size: 0x03
	float autoPlayInitRotateYaw; // Offset: 0x738 // Size: 0x04
	bool isPlayingUpgradeEffect; // Offset: 0x73c // Size: 0x01
	bool isAutoPlaying; // Offset: 0x73d // Size: 0x01
	bool isResetingCloseUpCamera; // Offset: 0x73e // Size: 0x01
	bool isSwitchCameraEllipse; // Offset: 0x73f // Size: 0x01
	bool isAllMeshLoaded; // Offset: 0x740 // Size: 0x01
	char pad_0x741[0x3]; // Offset: 0x741 // Size: 0x03
	float MeshScale; // Offset: 0x744 // Size: 0x04
	struct URefitVehicleHandle* vehicleHandle; // Offset: 0x748 // Size: 0x08
	struct UMaterialInstance* vehicleGroundMaterialInterface; // Offset: 0x750 // Size: 0x08
	struct ALobbyModelShowActorBP_C* refitVehicleShowActor; // Offset: 0x758 // Size: 0x08
	struct TArray<struct UStaticMesh*> RefitVehicleSTMesh; // Offset: 0x760 // Size: 0x10
	int TryTime; // Offset: 0x770 // Size: 0x04
	bool HightlightSuccess; // Offset: 0x774 // Size: 0x01

	// Functions

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.CanAutoPlayLua
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CanAutoPlayLua(bool& Param); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.CheckRefitTipsFadeLua
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CheckRefitTipsFadeLua(float Yaw, bool showAllTips); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.ShowLoading
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowLoading(bool Show); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.ResetCameraRotation
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ResetCameraRotation(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.CreateDefaultRefitVehicleMesh
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void CreateDefaultRefitVehicleMesh(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.HasRefitVehicleDownloaded
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void HasRefitVehicleDownloaded(bool& HasDownloaded); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.ChangeGroundShadow
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ChangeGroundShadow(struct FString Path); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.GetRefitVehicleHandle
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetRefitVehicleHandle(int VehicleID, struct URefitVehicleHandle*& RefitVehicleHandle); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.InitSlotSocket
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitSlotSocket(struct TMap<int, struct FString> slotSocket); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.TryResetCloseUp
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void TryResetCloseUp(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.SetCastShadow
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCastShadow(bool CastShadow); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.EnableCameraRotationLag
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void EnableCameraRotationLag(bool Enable); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.UpdateLastAutoPlayTime
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdateLastAutoPlayTime(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.CheckAutoPlay
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CheckAutoPlay(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.TryRotateSceneByTouch
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void TryRotateSceneByTouch(bool& rotated); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.TryStopAutoPlay
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void TryStopAutoPlay(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.GetSlotSocketTransform
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FTransform GetSlotSocketTransform(int inInt); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.GetVectorAngle
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetVectorAngle(float& degree); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.DestroyFreeCamera
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void DestroyFreeCamera(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.GetYawToMesh
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	float GetYawToMesh(struct FVector Location); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.CheckRefitTipsFade
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void CheckRefitTipsFade(bool forceShowAll); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.InterpVelocity
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void InterpVelocity(float New, float Old, float& Velocity); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.TimeLine_LerpRotator__FinishedFunc
	// Flags: [BlueprintEvent]
	void TimeLine_LerpRotator__FinishedFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.TimeLine_LerpRotator__UpdateFunc
	// Flags: [BlueprintEvent]
	void TimeLine_LerpRotator__UpdateFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.TimeLine_LerpPosition__FinishedFunc
	// Flags: [BlueprintEvent]
	void TimeLine_LerpPosition__FinishedFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.TimeLine_LerpPosition__UpdateFunc
	// Flags: [BlueprintEvent]
	void TimeLine_LerpPosition__UpdateFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.Timeline_AutoPlay__FinishedFunc
	// Flags: [BlueprintEvent]
	void Timeline_AutoPlay__FinishedFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.Timeline_AutoPlay__UpdateFunc
	// Flags: [BlueprintEvent]
	void Timeline_AutoPlay__UpdateFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.TimeLine_BlendCamera__FinishedFunc
	// Flags: [BlueprintEvent]
	void TimeLine_BlendCamera__FinishedFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.TimeLine_BlendCamera__UpdateFunc
	// Flags: [BlueprintEvent]
	void TimeLine_BlendCamera__UpdateFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.Timeline_Vehicle_Update_Zoom_out__FinishedFunc
	// Flags: [BlueprintEvent]
	void Timeline_Vehicle_Update_Zoom_out__FinishedFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.Timeline_Vehicle_Update_Zoom_out__UpdateFunc
	// Flags: [BlueprintEvent]
	void Timeline_Vehicle_Update_Zoom_out__UpdateFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.Timeline_Vehicle_Update_Zoom_in__FinishedFunc
	// Flags: [BlueprintEvent]
	void Timeline_Vehicle_Update_Zoom_in__FinishedFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.Timeline_Vehicle_Update_Zoom_in__UpdateFunc
	// Flags: [BlueprintEvent]
	void Timeline_Vehicle_Update_Zoom_in__UpdateFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveTick(float DeltaSeconds); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.ReceivePossessed
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePossessed(struct AController* NewController); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.SwitchCloseupCameraEllipse
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SwitchCloseupCameraEllipse(int SlotID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.AutoPlay
	// Flags: [BlueprintCallable|BlueprintEvent]
	void AutoPlay(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.BlendCameraActor
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BlendCameraActor(struct USceneComponent* CameraActor, struct FTransform toTransform); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.SwitchCloseUpCameraLinear
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SwitchCloseUpCameraLinear(int SlotID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.OnVehicleUpgradeSuccess
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnVehicleUpgradeSuccess(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.ResetCloseUpCamera
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ResetCloseUpCamera(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.EventOnAllMeshLoad
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventOnAllMeshLoad(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.ShowLoadingForTime
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ShowLoadingForTime(float Time); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.SetHighLight
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetHighLight(float invincible, float FreExp, float Speed); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.TrySetHilight
	// Flags: [BlueprintCallable|BlueprintEvent]
	void TrySetHilight(float invincible, float Freq, float Speed); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.LuaBeginPlay
	// Flags: [BlueprintCallable|BlueprintEvent]
	void LuaBeginPlay(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitVehicle.BP_LobbyRefitVehicle_C.ExecuteUbergraph_BP_LobbyRefitVehicle
	// Flags: [HasDefaults]
	void ExecuteUbergraph_BP_LobbyRefitVehicle(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

