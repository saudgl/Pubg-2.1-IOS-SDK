#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Quality8Item_UIBP.Quality8Item_UIBP_C
// Size: 0x280 // Inherited bytes: 0x248
struct UQuality8Item_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* NewAnimation_2; // Offset: 0x248 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_1; // Offset: 0x250 // Size: 0x08
	struct UMaskBox* MaskBox_2; // Offset: 0x258 // Size: 0x08
	struct UUIParticleEmitter* UIParticleEmitter_2; // Offset: 0x260 // Size: 0x08
	struct UImage* vx_com_mask_01_vx; // Offset: 0x268 // Size: 0x08
	struct UImage* vx_com_mask_02; // Offset: 0x270 // Size: 0x08
	struct UImage* vx_com_mask_04; // Offset: 0x278 // Size: 0x08
};

