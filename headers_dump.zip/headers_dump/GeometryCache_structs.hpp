#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct GeometryCache.TrackRenderData
// Size: 0x50 // Inherited bytes: 0x00
struct FTrackRenderData {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct GeometryCache.GeometryCacheMeshData
// Size: 0x50 // Inherited bytes: 0x00
struct FGeometryCacheMeshData {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct GeometryCache.GeometryCacheMeshBatchInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FGeometryCacheMeshBatchInfo {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

