#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_PictorialBookItems_type.BP_STRUCT_PictorialBookItems_type
// Size: 0x70 // Inherited bytes: 0x00
struct FBP_STRUCT_PictorialBookItems_type {
	// Fields
	int default_wear_8_5F14AF404087B59B52553B7C0E65F312; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString item_haveIcon_9_7D4181400923B5A1153DEE100EEFD05E; // Offset: 0x08 // Size: 0x10
	int item_id_10_760BC940778A9A4F442CEE7306263614; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString item_notIcon_11_6E638C801E07599268EF6B2D0B0A9B2E; // Offset: 0x20 // Size: 0x10
	struct FString item_source_12_098D3A400F66AE1D1441AF9B0580EEA5; // Offset: 0x30 // Size: 0x10
	int key_13_68AA84C0195344B950BB17B40E03E749; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString layout_14_7D33BA005D065F347D51069E0E4026F4; // Offset: 0x48 // Size: 0x10
	struct FString online_time_15_631FD74069D16323574D0D4C07527335; // Offset: 0x58 // Size: 0x10
	int preview_order_16_52BCD1C01613D7E54498CB3F0E6446C2; // Offset: 0x68 // Size: 0x04
	int topic_id_17_402CE54064FF1B8F45D014DC0E8FC924; // Offset: 0x6c // Size: 0x04
};

