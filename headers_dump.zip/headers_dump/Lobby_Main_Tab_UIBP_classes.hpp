#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Main_Tab_UIBP.Lobby_Main_Tab_UIBP_C
// Size: 0x3c8 // Inherited bytes: 0x248
struct ULobby_Main_Tab_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* NewAnimation_Fold_Mail; // Offset: 0x248 // Size: 0x08
	struct UButton* Button_DepotSystemNew; // Offset: 0x250 // Size: 0x08
	struct UButton* Button_FoldUI_BottomRight; // Offset: 0x258 // Size: 0x08
	struct UButton* Button_FoldUI_Mail; // Offset: 0x260 // Size: 0x08
	struct UButton* Button_Missions; // Offset: 0x268 // Size: 0x08
	struct UButton* Button_Season; // Offset: 0x270 // Size: 0x08
	struct UButton* Button_Workshop; // Offset: 0x278 // Size: 0x08
	struct UCanvasPanel* Canvas_NewbieGuide; // Offset: 0x280 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_1; // Offset: 0x288 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Corps; // Offset: 0x290 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_TeamBtn; // Offset: 0x298 // Size: 0x08
	struct UCommon_RankIntegralLevel_Style_Small_UIBP_C* Common_RankIntegralLevel_Style_Small_UIBP; // Offset: 0x2a0 // Size: 0x08
	struct UReddot_Anchor_C* Fold_Reddot_Anchor; // Offset: 0x2a8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_7; // Offset: 0x2b0 // Size: 0x08
	struct UImage* Image_Club; // Offset: 0x2b8 // Size: 0x08
	struct UImage* Image_Fold_Redpoint; // Offset: 0x2c0 // Size: 0x08
	struct UImage* Image_Liston; // Offset: 0x2c8 // Size: 0x08
	struct UImage* Image_ReserchNew; // Offset: 0x2d0 // Size: 0x08
	struct UImage* Image_SeasonIcon; // Offset: 0x2d8 // Size: 0x08
	struct UImage* Image_TaskNewTips; // Offset: 0x2e0 // Size: 0x08
	struct UImage* Image_Wardrobe_Redpoint; // Offset: 0x2e8 // Size: 0x08
	struct ULobby_Main_Bubble_Workshop_C* Lobby_Main_Bubble_Workshop; // Offset: 0x2f0 // Size: 0x08
	struct ULobby_Main_Tips_Inventory_UIBP_C* Lobby_Main_Tips_Inventory; // Offset: 0x2f8 // Size: 0x08
	struct ULobby_Main_Tips_Season_UIBP_C* Lobby_Main_Tips_Season_UIBP; // Offset: 0x300 // Size: 0x08
	struct ULobby_Main_Tips_Workshop_UIBP_C* Lobby_Main_Tips_Workshop; // Offset: 0x308 // Size: 0x08
	struct ULobby_Tab_Item_UIBP_C* Lobby_Tab_Item_UIBP; // Offset: 0x310 // Size: 0x08
	struct UCanvasPanel* NewbieGuide_Season; // Offset: 0x318 // Size: 0x08
	struct UReddot_Anchor_C* Reddot_Anchor_Season; // Offset: 0x320 // Size: 0x08
	struct UReddot_Anchor_C* Reddot_Anchor_TaskNewTips; // Offset: 0x328 // Size: 0x08
	struct UReddot_Anchor_C* Reddot_Anchor_Wardrobe; // Offset: 0x330 // Size: 0x08
	struct UReddot_Anchor_C* Reddot_Anchor_Workshop; // Offset: 0x338 // Size: 0x08
	struct UReddot_Anchor_Item05_C* SeasonUnlockNew; // Offset: 0x340 // Size: 0x08
	struct USizeBox* SizeBox_13; // Offset: 0x348 // Size: 0x08
	struct USizeBox* SizeBox_Diy; // Offset: 0x350 // Size: 0x08
	struct USizeBox* SizeBox_Inventory; // Offset: 0x358 // Size: 0x08
	struct USizeBox* SizeBox_Missions; // Offset: 0x360 // Size: 0x08
	struct USizeBox* SizeBox_Season; // Offset: 0x368 // Size: 0x08
	struct USizeBox* SizeBox_Workshop; // Offset: 0x370 // Size: 0x08
	struct UTextBlock* TextBlock_3; // Offset: 0x378 // Size: 0x08
	struct UTextBlock* TextBlock_4; // Offset: 0x380 // Size: 0x08
	struct UTextBlock* TextBlock_AmoryTitle; // Offset: 0x388 // Size: 0x08
	struct UTextBlock* TextBlock_Corps; // Offset: 0x390 // Size: 0x08
	struct UTextBlock* TextBlock_DepotTitleNew; // Offset: 0x398 // Size: 0x08
	struct UTextBlock* TextBlock_season; // Offset: 0x3a0 // Size: 0x08
	struct UCanvasPanel* UnlockNew; // Offset: 0x3a8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Fold; // Offset: 0x3b0 // Size: 0x08
	struct UCanvasPanel* WorkshopReddot; // Offset: 0x3b8 // Size: 0x08
	struct UReddot_Anchor_Item05_C* WorkshopUnlockNew; // Offset: 0x3c0 // Size: 0x08
};

