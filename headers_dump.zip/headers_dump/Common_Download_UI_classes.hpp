#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_Download_UI.Common_Download_UI_C
// Size: 0x330 // Inherited bytes: 0x2b8
struct UCommon_Download_UI_C : ULuaUserWidget {
	// Fields
	struct UWidgetAnimation* NewAnimation_2; // Offset: 0x2b8 // Size: 0x08
	struct UButton* Button_Download; // Offset: 0x2c0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_State; // Offset: 0x2c8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_1; // Offset: 0x2d0 // Size: 0x08
	struct UImage* Image_Download; // Offset: 0x2d8 // Size: 0x08
	struct UImage* Image_Downloading; // Offset: 0x2e0 // Size: 0x08
	struct UImage* Image_Gray; // Offset: 0x2e8 // Size: 0x08
	struct UImage* Image_Progress; // Offset: 0x2f0 // Size: 0x08
	struct UImage* Image_Progress_Bg; // Offset: 0x2f8 // Size: 0x08
	struct UImage* Image_State; // Offset: 0x300 // Size: 0x08
	struct UCanvasPanel* Panel_Download; // Offset: 0x308 // Size: 0x08
	struct UCanvasPanel* Panel_NewProgressState; // Offset: 0x310 // Size: 0x08
	struct UProgressBar* ProgressBar_Mask; // Offset: 0x318 // Size: 0x08
	struct UTextBlock* Text_Download; // Offset: 0x320 // Size: 0x08
	struct UTextBlock* Text_Progress; // Offset: 0x328 // Size: 0x08
};

