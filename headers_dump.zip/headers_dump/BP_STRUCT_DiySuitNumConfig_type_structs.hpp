#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_DiySuitNumConfig_type.BP_STRUCT_DiySuitNumConfig_type
// Size: 0x20 // Inherited bytes: 0x00
struct FBP_STRUCT_DiySuitNumConfig_type {
	// Fields
	struct FString IconUrl_0_43EF28C044399FBD0B85F19509DDF67C; // Offset: 0x00 // Size: 0x10
	struct FString ID_1_353BBD004B023124772EBE53059CAFB4; // Offset: 0x10 // Size: 0x10
};

