#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Main_UIBP.Lobby_Main_UIBP_C
// Size: 0x440 // Inherited bytes: 0x248
struct ULobby_Main_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_in_l_L2; // Offset: 0x248 // Size: 0x08
	struct UWidgetAnimation* Anim_in_l_R2; // Offset: 0x250 // Size: 0x08
	struct UWidgetAnimation* Anim_in_l_L; // Offset: 0x258 // Size: 0x08
	struct UWidgetAnimation* Anim_in_l_R; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Anim_in2; // Offset: 0x268 // Size: 0x08
	struct UWidgetAnimation* Ani_Train; // Offset: 0x270 // Size: 0x08
	struct UWidgetAnimation* Ani_Mid_Right; // Offset: 0x278 // Size: 0x08
	struct UWidgetAnimation* Ani_Left_Mid; // Offset: 0x280 // Size: 0x08
	struct UBorder* Border_14; // Offset: 0x288 // Size: 0x08
	struct UBorder* Border_15; // Offset: 0x290 // Size: 0x08
	struct UBorder* Border1; // Offset: 0x298 // Size: 0x08
	struct UBorder* Border2; // Offset: 0x2a0 // Size: 0x08
	struct UBorder* Border3; // Offset: 0x2a8 // Size: 0x08
	struct UBorder* Border4; // Offset: 0x2b0 // Size: 0x08
	struct UBorder* Border_ActorVoice; // Offset: 0x2b8 // Size: 0x08
	struct UBorder* Border_DoubleCard; // Offset: 0x2c0 // Size: 0x08
	struct UBorder* Border_Downloader_Btn; // Offset: 0x2c8 // Size: 0x08
	struct UBorder* Border_ExtraTeam; // Offset: 0x2d0 // Size: 0x08
	struct UBorder* Border_Left_Message; // Offset: 0x2d8 // Size: 0x08
	struct UBorder* Border_LuckyKT; // Offset: 0x2e0 // Size: 0x08
	struct UBorder* Border_Match_Entry; // Offset: 0x2e8 // Size: 0x08
	struct UBorder* Border_matchcenter; // Offset: 0x2f0 // Size: 0x08
	struct UBorder* Border_MedioPlayer; // Offset: 0x2f8 // Size: 0x08
	struct UBorder* Border_MidActivity; // Offset: 0x300 // Size: 0x08
	struct UBorder* Border_MidBanner; // Offset: 0x308 // Size: 0x08
	struct UBorder* Border_MidChat; // Offset: 0x310 // Size: 0x08
	struct UBorder* Border_MidChatVoice; // Offset: 0x318 // Size: 0x08
	struct UBorder* Border_MidExpression; // Offset: 0x320 // Size: 0x08
	struct UBorder* Border_MidFriend; // Offset: 0x328 // Size: 0x08
	struct UBorder* Border_MidMessage; // Offset: 0x330 // Size: 0x08
	struct UBorder* Border_MidMission; // Offset: 0x338 // Size: 0x08
	struct UBorder* Border_MidShop; // Offset: 0x340 // Size: 0x08
	struct UBorder* Border_money; // Offset: 0x348 // Size: 0x08
	struct UBorder* Border_PlayerReturnProfit; // Offset: 0x350 // Size: 0x08
	struct UBorder* Border_PMGC; // Offset: 0x358 // Size: 0x08
	struct UBorder* Border_RecommendDownload; // Offset: 0x360 // Size: 0x08
	struct UBorder* Border_ReddotMessageEntrance; // Offset: 0x368 // Size: 0x08
	struct UBorder* Border_Right_Display; // Offset: 0x370 // Size: 0x08
	struct UBorder* Border_Right_Popularity; // Offset: 0x378 // Size: 0x08
	struct UBorder* Border_Social_Attach; // Offset: 0x380 // Size: 0x08
	struct UBorder* Border_switch; // Offset: 0x388 // Size: 0x08
	struct UBorder* Border_TabRoot; // Offset: 0x390 // Size: 0x08
	struct UBorder* Border_TempButton; // Offset: 0x398 // Size: 0x08
	struct UBorder* Border_Top; // Offset: 0x3a0 // Size: 0x08
	struct UBorder* Border_TrensientXmission; // Offset: 0x3a8 // Size: 0x08
	struct UBorder* Border_wifi; // Offset: 0x3b0 // Size: 0x08
	struct UGridPanel* Grid_Panel_Bottom_Right; // Offset: 0x3b8 // Size: 0x08
	struct UGridPanel* GridPanel_Car_Other; // Offset: 0x3c0 // Size: 0x08
	struct UGridPanel* GridPanel_Chat; // Offset: 0x3c8 // Size: 0x08
	struct UGridPanel* GridPanel_Expression; // Offset: 0x3d0 // Size: 0x08
	struct UGridPanel* GridPanel_Pet; // Offset: 0x3d8 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x3e0 // Size: 0x08
	struct UImage* Image_2; // Offset: 0x3e8 // Size: 0x08
	struct UImage* Image_bg_mask; // Offset: 0x3f0 // Size: 0x08
	struct UImage* Image_Black; // Offset: 0x3f8 // Size: 0x08
	struct UImage* Image_Left_Mid; // Offset: 0x400 // Size: 0x08
	struct UImage* Image_Left_Mid_2; // Offset: 0x408 // Size: 0x08
	struct UImage* image_Mid_Left; // Offset: 0x410 // Size: 0x08
	struct UImage* image_Mid_Left_2; // Offset: 0x418 // Size: 0x08
	struct UImage* Image_Train; // Offset: 0x420 // Size: 0x08
	struct ULobby_Control_Comp_C* Lobby20_Control_Comp; // Offset: 0x428 // Size: 0x08
	struct UImage* XiuGaiZhaoByi; // Offset: 0x430 // Size: 0x08
	int preWidth; // Offset: 0x438 // Size: 0x04
	int preHeight; // Offset: 0x43c // Size: 0x04
};

