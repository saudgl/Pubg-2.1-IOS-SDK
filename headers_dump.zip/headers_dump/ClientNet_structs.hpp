#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ClientNet.IMSDKExtraInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FIMSDKExtraInfo {
	// Fields
	struct TMap<struct FString, struct FString> ExtraInfo; // Offset: 0x00 // Size: 0x50
};

