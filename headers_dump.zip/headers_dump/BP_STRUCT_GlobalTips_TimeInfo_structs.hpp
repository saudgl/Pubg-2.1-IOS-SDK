#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_GlobalTips_TimeInfo.BP_STRUCT_GlobalTips_TimeInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FBP_STRUCT_GlobalTips_TimeInfo {
	// Fields
	bool is_limit_0_C44FFA274459A428B4E947B664175E8A; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString time_s_1_F3B38E0D4CA07B5A44179194CBB4AC32; // Offset: 0x08 // Size: 0x10
};

