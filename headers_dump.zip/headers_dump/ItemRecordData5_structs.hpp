#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct ItemRecordData5.ItemRecordData5
// Size: 0x38 // Inherited bytes: 0x00
struct FItemRecordData5 {
	// Fields
	int ItemID_2_2F9636FC420298B4EF34E588F58E38B0; // Offset: 0x00 // Size: 0x04
	int ItemType_4_B2ED20EE489C1F500EBA389884CAC16D; // Offset: 0x04 // Size: 0x04
	struct FString ItemName_7_DEB27023488D6036B9B24AB5DB114F34; // Offset: 0x08 // Size: 0x10
	struct FString ItemBigIcon_9_A4409DA14B47CD0F4D6A7EBB7CBF2F2F; // Offset: 0x18 // Size: 0x10
	struct FString ItemDesc_11_8AB433674EC5E4AF7F82069136B23CF5; // Offset: 0x28 // Size: 0x10
};

