#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Rifle_SCAR_Wrapper.BP_Rifle_SCAR_Wrapper_C
// Size: 0x840 // Inherited bytes: 0x830
struct ABP_Rifle_SCAR_Wrapper_C : APickUpWrapperActor {
	// Fields
	struct UStaticMeshComponent* Mag; // Offset: 0x830 // Size: 0x08
	struct UStaticMeshComponent* SM_SCAR-L; // Offset: 0x838 // Size: 0x08

	// Functions

	// Object Name: Function BP_Rifle_SCAR_Wrapper.BP_Rifle_SCAR_Wrapper_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)
};

