#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VehicleRefitPatternTable_type.BP_STRUCT_VehicleRefitPatternTable_type
// Size: 0x58 // Inherited bytes: 0x00
struct FBP_STRUCT_VehicleRefitPatternTable_type {
	// Fields
	int IconScale2_0_46572E4071F9B3293BE305FF087656B2; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString IconPath2_1_024EF7804CE8216627C3CAFF038879F2; // Offset: 0x08 // Size: 0x10
	int IconScale1_2_46562E0071F9B3283BE305F8087656B1; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString IconPath1_3_024DF7404CE8216527C3CAFC038879F1; // Offset: 0x20 // Size: 0x10
	int ID_4_3B4768C07AEB475737EB9B560A7BEF14; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString IconOffset_5_59F5A18037D665B02424026A0AB3EDF4; // Offset: 0x38 // Size: 0x10
	struct FString PatternBPPath_6_4B5944C06FBA413D7EB727A808597AD8; // Offset: 0x48 // Size: 0x10
};

