#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass MotionItem_BP.MotionItem_BP_C
// Size: 0x260 // Inherited bytes: 0x248
struct UMotionItem_BP_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x248 // Size: 0x08
	struct UImage* Image_BlackBg; // Offset: 0x250 // Size: 0x08
	struct UImage* Image_Icon; // Offset: 0x258 // Size: 0x08

	// Functions

	// Object Name: Function MotionItem_BP.MotionItem_BP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MotionItem_BP.MotionItem_BP_C.ExecuteUbergraph_MotionItem_BP
	// Flags: [None]
	void ExecuteUbergraph_MotionItem_BP(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

