#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_DragDrop_Widget.Common_DragDrop_Widget_C
// Size: 0x258 // Inherited bytes: 0x248
struct UCommon_DragDrop_Widget_C : UUserWidget {
	// Fields
	struct UImage* DefaultTexture; // Offset: 0x248 // Size: 0x08
	struct UImage* Frame; // Offset: 0x250 // Size: 0x08
};

