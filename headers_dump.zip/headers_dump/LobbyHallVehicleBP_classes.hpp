#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass LobbyHallVehicleBP.LobbyHallVehicleBP_C
// Size: 0x740 // Inherited bytes: 0x740
struct ALobbyHallVehicleBP_C : ALobbyModelShowActorBP_C {
};

