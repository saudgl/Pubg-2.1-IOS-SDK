#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_PMGCLobbyEntryTimeTable_type.BP_STRUCT_PMGCLobbyEntryTimeTable_type
// Size: 0x74 // Inherited bytes: 0x00
struct FBP_STRUCT_PMGCLobbyEntryTimeTable_type {
	// Fields
	struct FString closeTime_0_76AFF8C0315F7047137B2671044FE8D5; // Offset: 0x00 // Size: 0x10
	struct FString endTime_1_3268E1003218D6D26F6AF85506BB7B75; // Offset: 0x10 // Size: 0x10
	struct FString liveEndTime1_2_2FE551402F620DC1304196BD01452771; // Offset: 0x20 // Size: 0x10
	struct FString liveEndTime2_3_2FE651802F620DC2304196BE01452772; // Offset: 0x30 // Size: 0x10
	struct FString liveStartTime1_4_30162F0058577CC87B5B2A7B067D1CD1; // Offset: 0x40 // Size: 0x10
	struct FString liveStartTime2_5_30172F4058577CC97B5B2A78067D1CD2; // Offset: 0x50 // Size: 0x10
	struct FString openTime_6_7DA37FC03FE9973F349875B009AEFBB5; // Offset: 0x60 // Size: 0x10
	int Year_7_2BC1F3C06B4ADBB3135025F40D5714A2; // Offset: 0x70 // Size: 0x04
};

