#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct CommonLib.ServiceCollection
// Size: 0x50 // Inherited bytes: 0x00
struct FServiceCollection {
	// Fields
	struct TMap<struct FString, struct UObject*> ServiceMap; // Offset: 0x00 // Size: 0x50
};

