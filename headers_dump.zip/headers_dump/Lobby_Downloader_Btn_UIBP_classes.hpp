#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Downloader_Btn_UIBP.Lobby_Downloader_Btn_UIBP_C
// Size: 0x270 // Inherited bytes: 0x248
struct ULobby_Downloader_Btn_UIBP_C : UUserWidget {
	// Fields
	struct UCommon_DragDrop_Item_C* CommonDragDropItem; // Offset: 0x248 // Size: 0x08
	struct UImage* Image_Progress; // Offset: 0x250 // Size: 0x08
	struct UImage* Image_RedDot; // Offset: 0x258 // Size: 0x08
	struct UCanvasPanel* Panel_Drag; // Offset: 0x260 // Size: 0x08
	struct UScaleBox* ScaleBox_Downloader; // Offset: 0x268 // Size: 0x08
};

