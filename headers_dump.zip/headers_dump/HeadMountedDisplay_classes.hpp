#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class HeadMountedDisplay.HeadMountedDisplayFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UHeadMountedDisplayFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetWorldToMetersScale
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetWorldToMetersScale(struct UObject* WorldContext, float NewScale); // Offset: 0x103e8580c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetTrackingOrigin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetTrackingOrigin(enum class EHMDTrackingOrigin Origin); // Offset: 0x103e85790 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetSpectatorScreenTexture(struct UTexture* InTexture); // Offset: 0x103e8571c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenModeTexturePlusEyeLayout
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	void SetSpectatorScreenModeTexturePlusEyeLayout(struct FVector2D EyeRectMin, struct FVector2D EyeRectMax, struct FVector2D TextureRectMin, struct FVector2D TextureRectMax, bool bDrawEyeFirst, bool bClearBlack); // Offset: 0x103e8557c // Return & Params: Num(6) Size(0x22)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetSpectatorScreenMode(enum class ESpectatorScreenMode Mode); // Offset: 0x103e85508 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetClippingPlanes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetClippingPlanes(float Near, float Far); // Offset: 0x103e8545c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.ResetOrientationAndPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ResetOrientationAndPosition(float Yaw, enum class EOrientPositionSelector Options); // Offset: 0x103e853ac // Return & Params: Num(2) Size(0x5)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsSpectatorScreenModeControllable
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsSpectatorScreenModeControllable(); // Offset: 0x103e85378 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsInLowPersistenceMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsInLowPersistenceMode(); // Offset: 0x103e85360 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsHeadMountedDisplayEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsHeadMountedDisplayEnabled(); // Offset: 0x103e8532c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsHeadMountedDisplayConnected
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsHeadMountedDisplayConnected(); // Offset: 0x103e852f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.HasValidTrackingPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool HasValidTrackingPosition(); // Offset: 0x103e852c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetWorldToMetersScale
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float GetWorldToMetersScale(struct UObject* WorldContext); // Offset: 0x103e85248 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetVRFocusState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetVRFocusState(bool& bUseFocus, bool& bHasFocus); // Offset: 0x103e85178 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingSensorParameters
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void GetTrackingSensorParameters(struct FVector& Origin, struct FRotator& Rotation, float& LeftFOV, float& RightFOV, float& TopFOV, float& BottomFOV, float& Distance, float& NearPlane, float& FarPlane, bool& IsActive, int Index); // Offset: 0x103e84de4 // Return & Params: Num(11) Size(0x3c)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingOrigin
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	enum class EHMDTrackingOrigin GetTrackingOrigin(); // Offset: 0x103e84da0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetScreenPercentage
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float GetScreenPercentage(); // Offset: 0x103e84d6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetPositionalTrackingCameraParameters
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void GetPositionalTrackingCameraParameters(struct FVector& CameraOrigin, struct FRotator& CameraRotation, float& HFOV, float& VFOV, float& CameraDistance, float& NearPlane, float& FarPlane); // Offset: 0x103e84b10 // Return & Params: Num(7) Size(0x2c)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetOrientationAndPosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void GetOrientationAndPosition(struct FRotator& DeviceRotation, struct FVector& DevicePosition); // Offset: 0x103e84a48 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetNumOfTrackingSensors
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int GetNumOfTrackingSensors(); // Offset: 0x103e84a14 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetHMDWornState
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	enum class EHMDWornState GetHMDWornState(); // Offset: 0x103e849e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetHMDDeviceName
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FName GetHMDDeviceName(); // Offset: 0x103e849ac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnableLowPersistenceMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EnableLowPersistenceMode(bool bEnable); // Offset: 0x103e84940 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnableHMD
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool EnableHMD(bool bEnable); // Offset: 0x103e848bc // Return & Params: Num(2) Size(0x2)
};

// Object Name: Class HeadMountedDisplay.MotionControllerComponent
// Size: 0x760 // Inherited bytes: 0x700
struct UMotionControllerComponent : UPrimitiveComponent {
	// Fields
	int playerIndex; // Offset: 0x700 // Size: 0x04
	enum class EControllerHand Hand; // Offset: 0x704 // Size: 0x01
	char bDisableLowLatencyUpdate : 1; // Offset: 0x705 // Size: 0x01
	char pad_0x705_1 : 7; // Offset: 0x705 // Size: 0x01
	enum class ETrackingStatus CurrentTrackingStatus; // Offset: 0x706 // Size: 0x01
	char pad_0x707[0x59]; // Offset: 0x707 // Size: 0x59

	// Functions

	// Object Name: Function HeadMountedDisplay.MotionControllerComponent.IsTracked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsTracked(); // Offset: 0x103e86300 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UMotionTrackedDeviceFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.SetIsControllerMotionTrackingEnabledByDefault
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetIsControllerMotionTrackingEnabledByDefault(bool Enable); // Offset: 0x103e86940 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsMotionTrackingEnabledForDevice(int playerIndex, enum class EControllerHand Hand); // Offset: 0x103e86888 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsMotionTrackingEnabledForComponent(struct UMotionControllerComponent* MotionControllerComponent); // Offset: 0x103e8680c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackedDeviceCountManagementNecessary
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsMotionTrackedDeviceCountManagementNecessary(); // Offset: 0x103e867d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetMotionTrackingEnabledControllerCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int GetMotionTrackingEnabledControllerCount(); // Offset: 0x103e867a4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetMaximumMotionTrackedControllerCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int GetMaximumMotionTrackedControllerCount(); // Offset: 0x103e86770 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingOfDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool EnableMotionTrackingOfDevice(int playerIndex, enum class EControllerHand Hand); // Offset: 0x103e866b8 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingForComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool EnableMotionTrackingForComponent(struct UMotionControllerComponent* MotionControllerComponent); // Offset: 0x103e8663c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DisableMotionTrackingOfDevice(int playerIndex, enum class EControllerHand Hand); // Offset: 0x103e8658c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfControllersForPlayer
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DisableMotionTrackingOfControllersForPlayer(int playerIndex); // Offset: 0x103e86518 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfAllControllers
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DisableMotionTrackingOfAllControllers(); // Offset: 0x103e86504 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingForComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DisableMotionTrackingForComponent(struct UMotionControllerComponent* MotionControllerComponent); // Offset: 0x103e86490 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class HeadMountedDisplay.VRNotificationsComponent
// Size: 0x1a0 // Inherited bytes: 0x110
struct UVRNotificationsComponent : UActorComponent {
	// Fields
	struct FScriptMulticastDelegate HMDTrackingInitializingAndNeedsHMDToBeTrackedDelegate; // Offset: 0x110 // Size: 0x10
	struct FScriptMulticastDelegate HMDTrackingInitializedDelegate; // Offset: 0x120 // Size: 0x10
	struct FScriptMulticastDelegate HMDRecenteredDelegate; // Offset: 0x130 // Size: 0x10
	struct FScriptMulticastDelegate HMDLostDelegate; // Offset: 0x140 // Size: 0x10
	struct FScriptMulticastDelegate HMDReconnectedDelegate; // Offset: 0x150 // Size: 0x10
	struct FScriptMulticastDelegate HMDConnectCanceledDelegate; // Offset: 0x160 // Size: 0x10
	struct FScriptMulticastDelegate HMDPutOnHeadDelegate; // Offset: 0x170 // Size: 0x10
	struct FScriptMulticastDelegate HMDRemovedFromHeadDelegate; // Offset: 0x180 // Size: 0x10
	struct FScriptMulticastDelegate VRControllerRecenteredDelegate; // Offset: 0x190 // Size: 0x10
};

