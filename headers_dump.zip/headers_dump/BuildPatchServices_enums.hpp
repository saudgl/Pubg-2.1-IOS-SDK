#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum BuildPatchServices.EManifestFileHeader
enum class EManifestFileHeader : uint8 {
	STORED_RAW = 0,
	STORED_COMPRESSED = 1,
	STORED_MAX = 2
};

