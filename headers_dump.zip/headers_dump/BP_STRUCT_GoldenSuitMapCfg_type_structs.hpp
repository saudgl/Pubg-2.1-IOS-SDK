#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_GoldenSuitMapCfg_type.BP_STRUCT_GoldenSuitMapCfg_type
// Size: 0x34 // Inherited bytes: 0x00
struct FBP_STRUCT_GoldenSuitMapCfg_type {
	// Fields
	int AcceptID_0_37D007C06284B9935018648F052EEE94; // Offset: 0x00 // Size: 0x04
	int ExchangeID_2_5A777C8047534EA4004FAEED0CF22BF4; // Offset: 0x04 // Size: 0x04
	int Period_3_184AA94068E2092F7F0475F307503EC4; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString InviteeActionID_12_5492C04044A14FB51C22E421028D9634; // Offset: 0x10 // Size: 0x10
	int InviterActionID_6_14F2C3805AA4F4A224E836A6028E0934; // Offset: 0x20 // Size: 0x04
	int TeamupActionID_7_3DCD264060C758FB3D51A0980D7A1134; // Offset: 0x24 // Size: 0x04
	int BattleActionID_8_2462A24025FC500376EA39190EA7FD14; // Offset: 0x28 // Size: 0x04
	int InviteTextID_10_287C18C03E5ECD896573262E0C757AE4; // Offset: 0x2c // Size: 0x04
	int OtherTeamupActionID_11_716546C055AD8FBB73578527048F8874; // Offset: 0x30 // Size: 0x04
};

