#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_BP_Hair_OPTest01_A.BattleItemHandle_BP_Hair_OPTest01_A_C
// Size: 0xb22 // Inherited bytes: 0xb22
struct UBattleItemHandle_BP_Hair_OPTest01_A_C : UBattleItemHandle_AvatarBP_C {
};

