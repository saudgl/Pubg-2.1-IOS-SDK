#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass WingmanAvatarHandleBase_BP.WingmanAvatarHandleBase_BP_C
// Size: 0x180 // Inherited bytes: 0x178
struct UWingmanAvatarHandleBase_BP_C : UBackpackWingmanAvatarHandle {
	// Fields
	struct AActor* WingmanActorClass; // Offset: 0x178 // Size: 0x08
};

