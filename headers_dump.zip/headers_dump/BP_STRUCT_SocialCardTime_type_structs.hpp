#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SocialCardTime_type.BP_STRUCT_SocialCardTime_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_SocialCardTime_type {
	// Fields
	struct FString Time_0_278EC240369480B1495AD5F102203C35; // Offset: 0x00 // Size: 0x10
	int ID_1_128141C0306283B52028B1E404022144; // Offset: 0x10 // Size: 0x04
};

