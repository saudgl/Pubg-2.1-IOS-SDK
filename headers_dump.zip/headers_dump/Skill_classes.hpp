#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Skill.UTSkillBaseWidget
// Size: 0x60 // Inherited bytes: 0x28
struct UUTSkillBaseWidget : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	bool bWidgetEnabled; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct FString EffectName; // Offset: 0x38 // Size: 0x10
	struct AActor* BuffTargetActor; // Offset: 0x48 // Size: 0x08
	struct TWeakObjectPtr<struct AUTSkill> OwnerSkill; // Offset: 0x50 // Size: 0x08
	struct UActorComponent* CurOwnerActorComponent; // Offset: 0x58 // Size: 0x08

	// Functions

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsWeakObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsWeakObject(struct FUAEBlackboardKeySelector& Key, struct UObject* ObjectValue); // Offset: 0x10515a664 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetValueAsVector(struct FUAEBlackboardKeySelector& Key, struct FVector VectorValue); // Offset: 0x10515a4f0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsString(struct FUAEBlackboardKeySelector& Key, struct FString StringValue); // Offset: 0x10515a330 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsRotator
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetValueAsRotator(struct FUAEBlackboardKeySelector& Key, struct FRotator RotatorValue); // Offset: 0x10515a1bc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsObject(struct FUAEBlackboardKeySelector& Key, struct UObject* ObjectValue); // Offset: 0x10515a068 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsName(struct FUAEBlackboardKeySelector& Key, struct FName NameValue); // Offset: 0x105159eec // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsInt(struct FUAEBlackboardKeySelector& Key, int IntValue); // Offset: 0x105159d98 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsFloat(struct FUAEBlackboardKeySelector& Key, float FloatValue); // Offset: 0x105159c44 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsEnum(struct FUAEBlackboardKeySelector& Key, char EnumValue); // Offset: 0x105159af0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsClass(struct FUAEBlackboardKeySelector& Key, struct UObject* ClassValue); // Offset: 0x10515999c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsBool(struct FUAEBlackboardKeySelector& Key, bool BoolValue); // Offset: 0x105159828 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistWeakObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistWeakObject(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105159728 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistVector
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistVector(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105159628 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistString(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105159528 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistRotator
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistRotator(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105159428 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistObject(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105159328 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistName(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105159228 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistInt(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105159128 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistFloat(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105159028 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistEnum(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105158f28 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistClass(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105158e28 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistBool(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105158d28 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsWeakObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetValueAsWeakObject(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105158c2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsWeakActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetValueAsWeakActor(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105158ae8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetValueAsVector(struct FUAEBlackboardKeySelector& Key); // Offset: 0x1051589d4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FString GetValueAsString(struct FUAEBlackboardKeySelector& Key); // Offset: 0x1051588a8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsRotator
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FRotator GetValueAsRotator(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105158794 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetValueAsObject(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105158698 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FName GetValueAsName(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105158594 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	int GetValueAsInt(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105158498 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	float GetValueAsFloat(struct FUAEBlackboardKeySelector& Key); // Offset: 0x10515839c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	char GetValueAsEnum(struct FUAEBlackboardKeySelector& Key); // Offset: 0x1051582a0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetValueAsClass(struct FUAEBlackboardKeySelector& Key); // Offset: 0x1051581a4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetValueAsBool(struct FUAEBlackboardKeySelector& Key); // Offset: 0x1051580a4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetValueAsActor(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105157f60 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetUAEBlackboardBySkillComp
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAEBlackboard* GetUAEBlackboardBySkillComp(struct UUTSkillManagerComponent* InOwnerSkillManager); // Offset: 0x105157e94 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetUAEBlackboard
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAEBlackboard* GetUAEBlackboard(); // Offset: 0x105157e30 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillBaseWidget.GetOwnerSkillManager
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUTSkillManagerComponent* GetOwnerSkillManager(); // Offset: 0x105157dcc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillBaseWidget.GetOwnerPawn
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetOwnerPawn(); // Offset: 0x105157d68 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillBaseWidget.GetActorBlackboardBySkillComp
	// Flags: [Final|Native|Private|Const]
	struct TMap<struct TWeakObjectPtr<struct AActor>, struct UUAEBlackboard*> GetActorBlackboardBySkillComp(struct UUTSkillManagerComponent* InOwnerSkillManager); // Offset: 0x105157c64 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Skill.UTSkillBaseWidget.GetActorBlackboard
	// Flags: [Final|Native|Private|Const]
	struct TMap<struct TWeakObjectPtr<struct AActor>, struct UUAEBlackboard*> GetActorBlackboard(); // Offset: 0x105157bd8 // Return & Params: Num(1) Size(0x50)
};

// Object Name: Class Skill.UTSkillCondition
// Size: 0x60 // Inherited bytes: 0x60
struct UUTSkillCondition : UUTSkillBaseWidget {
	// Functions

	// Object Name: Function Skill.UTSkillCondition.IsTargetOK
	// Flags: [Native|Event|Public|BlueprintEvent]
	bool IsTargetOK(struct UActorComponent* SkillManagerComponent, struct AActor* Target); // Offset: 0x105157398 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillCondition.IsOK_Internal
	// Flags: [Native|Event|Protected|BlueprintEvent]
	bool IsOK_Internal(); // Offset: 0x105157330 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillCondition.IsOK
	// Flags: [Native|Event|Public|BlueprintEvent]
	bool IsOK(struct UActorComponent* SkillManagerComponent); // Offset: 0x105157260 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillCondition.GetOwnerSkill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct AUTSkill* GetOwnerSkill(); // Offset: 0x105157204 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Skill.UTSkillEffect
// Size: 0x78 // Inherited bytes: 0x60
struct UUTSkillEffect : UUTSkillBaseWidget {
	// Fields
	float fADScale; // Offset: 0x60 // Size: 0x04
	float fAPScale; // Offset: 0x64 // Size: 0x04
	struct TArray<struct UObject*> CacheSoftObject; // Offset: 0x68 // Size: 0x10

	// Functions

	// Object Name: Function Skill.UTSkillEffect.UpdateAction
	// Flags: [Native|Public]
	void UpdateAction(struct UUTSkillManagerComponent* SkillManagerComponent, float DeltaSeconds); // Offset: 0x10515bbb4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillEffect.UndoAction
	// Flags: [Native|Public]
	void UndoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10515baf0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillEffect.PreCloseSkill
	// Flags: [Native|Public]
	void PreCloseSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x10515b9cc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillEffect.PostInitSkill
	// Flags: [Native|Public]
	void PostInitSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x10515b8a8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillEffect.PostActiveSkill
	// Flags: [Native|Public]
	void PostActiveSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x10515b784 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillEffect.OnAsyncLoadSoftPathDone
	// Flags: [Final|Native|Public]
	void OnAsyncLoadSoftPathDone(); // Offset: 0x10515b730 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillEffect.GetOwnerSkill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct AUTSkill* GetOwnerSkill(); // Offset: 0x10515b6d4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillEffect.DoHurtAppearance
	// Flags: [Native|Public]
	void DoHurtAppearance(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim); // Offset: 0x10515b5b0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillEffect.DoAction
	// Flags: [Native|Public]
	bool DoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10515b4e0 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class Skill.UTSkillAction
// Size: 0xa0 // Inherited bytes: 0x78
struct UUTSkillAction : UUTSkillEffect {
	// Fields
	struct FUTSkillActionCreateData BaseData; // Offset: 0x78 // Size: 0x08
	struct UUTSkillAction* OwnerPeriodAction; // Offset: 0x80 // Size: 0x08
	char pad_0x88[0x1]; // Offset: 0x88 // Size: 0x01
	bool bClearTimerAfterReset; // Offset: 0x89 // Size: 0x01
	char pad_0x8A[0x6]; // Offset: 0x8a // Size: 0x06
	struct UObject* EventObj; // Offset: 0x90 // Size: 0x08
	char pad_0x98[0x8]; // Offset: 0x98 // Size: 0x08

	// Functions

	// Object Name: Function Skill.UTSkillAction.UpdateAction_Internal
	// Flags: [Native|Public]
	void UpdateAction_Internal(float DeltaSeconds); // Offset: 0x1051515dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillAction.UpdateAction
	// Flags: [Final|Native|Public]
	void UpdateAction(struct UUTSkillManagerComponent* SkillManagerComponent, float DeltaSeconds); // Offset: 0x1051514c0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillAction.UndoAction_Internal
	// Flags: [Native|Public]
	void UndoAction_Internal(); // Offset: 0x105151464 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillAction.UndoAction
	// Flags: [Final|Native|Public]
	void UndoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x1051513a8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillAction.TimerRealDoAction
	// Flags: [Final|Native|Public]
	void TimerRealDoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x1051512ec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillAction.Reset_Internal
	// Flags: [Native|Public]
	void Reset_Internal(); // Offset: 0x105151290 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillAction.Reset
	// Flags: [Final|Native|Public]
	void Reset(struct UActorComponent* SkillManagerComponent); // Offset: 0x1051511d4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillAction.RealDoAction_Internal
	// Flags: [Native|Public]
	bool RealDoAction_Internal(); // Offset: 0x10515116c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillAction.RealDoAction
	// Flags: [Final|Native|Public]
	bool RealDoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x1051510a4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillAction.PreCloseSkill
	// Flags: [Native|Public]
	void PreCloseSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x105150f80 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillAction.PostInitSkill
	// Flags: [Native|Public]
	void PostInitSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x105150e5c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillAction.PostActiveSkill
	// Flags: [Native|Public]
	void PostActiveSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x105150d38 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillAction.OnAsyncLoadAssetDone
	// Flags: [Final|Native|Public]
	void OnAsyncLoadAssetDone(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x105150c7c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillAction.JudgeNeedPhaseWait
	// Flags: [Native|Public]
	bool JudgeNeedPhaseWait(); // Offset: 0x105150c14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillAction.DoAction
	// Flags: [Native|Public]
	bool DoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x105150b44 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class Skill.UTSkill
// Size: 0x660 // Inherited bytes: 0x3d8
struct AUTSkill : AActor {
	// Fields
	char pad_0x3D8[0x10]; // Offset: 0x3d8 // Size: 0x10
	bool bNeedSync; // Offset: 0x3e8 // Size: 0x01
	char pad_0x3E9[0x7]; // Offset: 0x3e9 // Size: 0x07
	struct FString SkillName; // Offset: 0x3f0 // Size: 0x10
	struct FName SkillGroup; // Offset: 0x400 // Size: 0x08
	bool bSinglePhaseRep; // Offset: 0x408 // Size: 0x01
	enum class ESkillCastType SkillCastType; // Offset: 0x409 // Size: 0x01
	bool bShouldMonopolize; // Offset: 0x40a // Size: 0x01
	bool bMonopolizeSelf; // Offset: 0x40b // Size: 0x01
	int SkillID; // Offset: 0x40c // Size: 0x04
	int SkillTemplateID; // Offset: 0x410 // Size: 0x04
	char pad_0x414[0x4]; // Offset: 0x414 // Size: 0x04
	struct FString SkillDescription; // Offset: 0x418 // Size: 0x10
	struct FString SkillDetailDes; // Offset: 0x428 // Size: 0x10
	bool bMeleeSkill; // Offset: 0x438 // Size: 0x01
	bool bCheckFirstPhaseConditions; // Offset: 0x439 // Size: 0x01
	bool bNeedAutonomousClientSimulate; // Offset: 0x43a // Size: 0x01
	bool bKeepCastingWhenDisconnect; // Offset: 0x43b // Size: 0x01
	bool bClearInputCache; // Offset: 0x43c // Size: 0x01
	char pad_0x43D[0x3]; // Offset: 0x43d // Size: 0x03
	struct FUTSkillCreateData BaseData; // Offset: 0x440 // Size: 0x118
	int SkillCategory; // Offset: 0x558 // Size: 0x04
	bool bUseNewSkillCD; // Offset: 0x55c // Size: 0x01
	char pad_0x55D[0x3]; // Offset: 0x55d // Size: 0x03
	struct TArray<struct FUAEBlackboardParameter> BlackboardParamList; // Offset: 0x560 // Size: 0x10
	bool bSetBlackboardDefaultData; // Offset: 0x570 // Size: 0x01
	bool bGsListener; // Offset: 0x571 // Size: 0x01
	char pad_0x572[0x6]; // Offset: 0x572 // Size: 0x06
	struct FString SkillTimeScaleAttrName; // Offset: 0x578 // Size: 0x10
	struct TMap<struct UObject*, int> InstancedNodeNameToMemoryMap; // Offset: 0x588 // Size: 0x50
	int InstancedNodesTotalSize; // Offset: 0x5d8 // Size: 0x04
	char pad_0x5DC[0x4]; // Offset: 0x5dc // Size: 0x04
	struct TArray<struct FString> ParentFolderPath; // Offset: 0x5e0 // Size: 0x10
	int64_t LastEditBluePrintTime; // Offset: 0x5f0 // Size: 0x08
	int CurComponentNameIndex; // Offset: 0x5f8 // Size: 0x04
	bool IsSkillEnabled; // Offset: 0x5fc // Size: 0x01
	char pad_0x5FD[0x53]; // Offset: 0x5fd // Size: 0x53
	struct TWeakObjectPtr<struct UUTSkillManagerComponent> SpecificSkillCompRef; // Offset: 0x650 // Size: 0x08
	struct TWeakObjectPtr<struct UUAEBlackboard> SpecificBlackBlackRef; // Offset: 0x658 // Size: 0x08

	// Functions

	// Object Name: Function Skill.UTSkill.StopSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	void StopSkillCoolDown(struct UUTSkillManagerComponent* SkillManagerComponent, int CoolDownIndex); // Offset: 0x1051500f4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkill.SetSkillPhasePercentage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSkillPhasePercentage(struct UUTSkillManagerComponent* SkillManagerComponent, float Percentage); // Offset: 0x10514ffd8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkill.OnEvent
	// Flags: [Native|Public|BlueprintCallable]
	bool OnEvent(struct UUTSkillManagerComponent* SkillManagerComponent, enum class UTSkillEventType TheEventType, int PhaseIndex); // Offset: 0x10514fe48 // Return & Params: Num(4) Size(0x11)

	// Object Name: Function Skill.UTSkill.IsEnableSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	bool IsEnableSkillCoolDown(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10514fd78 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkill.IsCDOK
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	bool IsCDOK(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10514fca8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkill.GetSpecificSkillManager
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UUTSkillManagerComponent* GetSpecificSkillManager(); // Offset: 0x10514fc4c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkill.GetSpecificBlackboard
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UUAEBlackboard* GetSpecificBlackboard(); // Offset: 0x10514fbf0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkill.GetSkillPhasePercentage
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetSkillPhasePercentage(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10514fb2c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkill.GetSkillPhaseByName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	struct UUTSkillPhase* GetSkillPhaseByName(struct FString PhaseName); // Offset: 0x10514fa1c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkill.GetSkillPhase
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	struct UUTSkillPhase* GetSkillPhase(int PhaseIndex); // Offset: 0x10514f950 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkill.GetSkillEffectByPhaseName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	struct UUTSkillBaseWidget* GetSkillEffectByPhaseName(struct FString PhaseName, struct FString EffectName); // Offset: 0x10514f7b0 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Skill.UTSkill.GetSkillEffectByPhaseIndex
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	struct UUTSkillBaseWidget* GetSkillEffectByPhaseIndex(int PhaseIndex, struct FString EffectName); // Offset: 0x10514f640 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Skill.UTSkill.DoSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	void DoSkillCoolDown(struct UUTSkillManagerComponent* SkillManagerComponent, int CoolDownIndex); // Offset: 0x10514f51c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkill.CanBePlayed
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	bool CanBePlayed(struct UUTSkillManagerComponent* SkillManagerComponent, bool bShowErrorMsg); // Offset: 0x10514f3c4 // Return & Params: Num(3) Size(0xa)
};

// Object Name: Class Skill.UTSkillManagerComponent
// Size: 0x800 // Inherited bytes: 0x1d8
struct UUTSkillManagerComponent : ULuaActorComponent {
	// Fields
	char pad_0x1D8[0x58]; // Offset: 0x1d8 // Size: 0x58
	struct APawn* OwnerPawn; // Offset: 0x230 // Size: 0x08
	char pad_0x238[0x20]; // Offset: 0x238 // Size: 0x20
	bool bEnableSkillCoolDown; // Offset: 0x258 // Size: 0x01
	char pad_0x259[0x7]; // Offset: 0x259 // Size: 0x07
	struct AActor* OwnerActor; // Offset: 0x260 // Size: 0x08
	bool DestroySkillsOnDie; // Offset: 0x268 // Size: 0x01
	char pad_0x269[0x7]; // Offset: 0x269 // Size: 0x07
	struct TMap<int, struct TWeakObjectPtr<struct AUTSkill>> SkillIDToSkills; // Offset: 0x270 // Size: 0x50
	struct TArray<struct TWeakObjectPtr<struct UUAEUserWidget>> AsyncLoadedSkillUI; // Offset: 0x2c0 // Size: 0x10
	struct UUAEUserWidget* SkillUIRoot; // Offset: 0x2d0 // Size: 0x08
	struct UPanelWidget* SkillUIRootPanel; // Offset: 0x2d8 // Size: 0x08
	struct TMap<struct TWeakObjectPtr<struct AUTSkill>, struct UUAEBlackboard*> SkillsBlackboardMap; // Offset: 0x2e0 // Size: 0x50
	struct TMap<struct TWeakObjectPtr<struct AActor>, struct UUAEBlackboard*> ActorBlackboardMap; // Offset: 0x330 // Size: 0x50
	struct FScriptMulticastDelegate ChangeActorBlackboard; // Offset: 0x380 // Size: 0x10
	struct AActor* Target; // Offset: 0x390 // Size: 0x08
	struct TMap<int, struct FUTSkillCreateData> SkillBaseDataMaps; // Offset: 0x398 // Size: 0x50
	struct TArray<struct FUTSkillLastCastInfo> LastCastArray; // Offset: 0x3e8 // Size: 0x10
	struct FScriptMulticastDelegate OnSkillHit; // Offset: 0x3f8 // Size: 0x10
	struct FScriptMulticastDelegate OnSkillCast; // Offset: 0x408 // Size: 0x10
	float PhasePercentage; // Offset: 0x418 // Size: 0x04
	char pad_0x41C[0x4]; // Offset: 0x41c // Size: 0x04
	struct TMap<int, int> IDToSyncSkillActiveStateData; // Offset: 0x420 // Size: 0x50
	struct TArray<struct FSkillActiveRepData> SyncSkillActiveStateDatas; // Offset: 0x470 // Size: 0x10
	struct TMap<int, int> IDToSyncSkillCDDatas; // Offset: 0x480 // Size: 0x50
	struct FSkillDynamicRepData SyncDynamicRepData; // Offset: 0x4d0 // Size: 0x10
	struct TArray<struct FSkillCDRepData> SyncSkillCDDatas; // Offset: 0x4e0 // Size: 0x10
	char pad_0x4F0[0x8]; // Offset: 0x4f0 // Size: 0x08
	struct FUTSkillHitInfo SkillHitInfo; // Offset: 0x4f8 // Size: 0x30
	struct FUTSkillHitEnvInfo SkillHitEnvInfo; // Offset: 0x528 // Size: 0x30
	struct TArray<struct FString> MutexMontageGroupBeenPlayed; // Offset: 0x558 // Size: 0x10
	char pad_0x568[0x8]; // Offset: 0x568 // Size: 0x08
	struct FString LastESkillTargetDesc; // Offset: 0x570 // Size: 0x10
	int SkillSynRandomSeed; // Offset: 0x580 // Size: 0x04
	struct FRandomStream SkillSynRandStream; // Offset: 0x584 // Size: 0x08
	int SkillSynRandomSeedExpireCount; // Offset: 0x58c // Size: 0x04
	struct TMap<struct FString, struct FTimerHandle> SkillTimerMap; // Offset: 0x590 // Size: 0x50
	char pad_0x5E0[0x8]; // Offset: 0x5e0 // Size: 0x08
	float ZombieModeUseSkillCD; // Offset: 0x5e8 // Size: 0x04
	char pad_0x5EC[0x4]; // Offset: 0x5ec // Size: 0x04
	int ZombieModeMaxSkillPropLevel; // Offset: 0x5f0 // Size: 0x04
	char pad_0x5F4[0x14]; // Offset: 0x5f4 // Size: 0x14
	struct TArray<struct FSkillParamater> SkillParamaters; // Offset: 0x608 // Size: 0x10
	struct TArray<struct FUTMutilSkillSynData> SkillSynData; // Offset: 0x618 // Size: 0x10
	char pad_0x628[0x10]; // Offset: 0x628 // Size: 0x10
	struct TArray<struct FUTSkillSynSinglePhaseData> SkillSynSinglePhaseData; // Offset: 0x638 // Size: 0x10
	char pad_0x648[0x18]; // Offset: 0x648 // Size: 0x18
	struct TMap<struct AUTSkill*, int> SkillCurPhaseIndexes; // Offset: 0x660 // Size: 0x50
	struct TMap<struct AUTSkill*, int> LastPhaseIndexes; // Offset: 0x6b0 // Size: 0x50
	char pad_0x700[0x60]; // Offset: 0x700 // Size: 0x60
	struct FScriptMulticastDelegate OnSkillInitSignature; // Offset: 0x760 // Size: 0x10
	struct FScriptMulticastDelegate SkillStartEvent; // Offset: 0x770 // Size: 0x10
	struct FScriptMulticastDelegate SkillStopEvent; // Offset: 0x780 // Size: 0x10
	struct TArray<int> PendingRemoveSkillID; // Offset: 0x790 // Size: 0x10
	struct TMap<int, char> CurSKillLevels; // Offset: 0x7a0 // Size: 0x50
	struct TArray<struct FUTReplaceSkillData> ReplacedSkillDatas; // Offset: 0x7f0 // Size: 0x10

	// Functions

	// Object Name: Function Skill.UTSkillManagerComponent.UpdateSyncSkillCDData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateSyncSkillCDData(int SkillID); // Offset: 0x10516c44c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.UpdateSyncSkillActiveState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateSyncSkillActiveState(int SkillID); // Offset: 0x10516c390 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.UnRegisterActorBlackBorad
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegisterActorBlackBorad(struct AActor* InActor); // Offset: 0x10516c2d4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.TryDeleteOneSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TryDeleteOneSkill(int SkillID, bool IsImmediately); // Offset: 0x10516c198 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.TryAddOneSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TryAddOneSkill(int SkillID, bool bActive); // Offset: 0x10516c05c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.TriggerEvent_WithID
	// Flags: [Native|Public|HasOutParms]
	void TriggerEvent_WithID(int InSkillID, enum class UTSkillEventType InEventType, struct FUTSkillBBUploadData& SkillBBUploadData); // Offset: 0x10516be68 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.TriggerEvent
	// Flags: [Native|Public|BlueprintCallable]
	void TriggerEvent(int SkillID, enum class UTSkillEventType EventType); // Offset: 0x10516bd44 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.TraceTarget
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	bool TraceTarget(struct FVector StartTrace, struct FVector EndTrace, enum class UTPickerTargetType TargetType, float Radius, struct AActor*& TargetActor); // Offset: 0x10516ba7c // Return & Params: Num(6) Size(0x29)

	// Object Name: Function Skill.UTSkillManagerComponent.SyncOneSkillState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SyncOneSkillState(bool RepSkillCD, bool RepSkillActiveState, int RequestID); // Offset: 0x10516b8c8 // Return & Params: Num(3) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkillWithSlot
	// Flags: [Native|Public]
	bool StopSkillWithSlot(int SkillSlot, enum class UTSkillStopReason StopReason); // Offset: 0x10516b798 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkillSpecific
	// Flags: [Final|Native|Public]
	void StopSkillSpecific(struct AUTSkill* Skill, enum class UTSkillStopReason StopReason); // Offset: 0x10516b67c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkillAll
	// Flags: [Native|Public|BlueprintCallable]
	void StopSkillAll(enum class UTSkillStopReason StopReason); // Offset: 0x10516b5b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkill_WithID
	// Flags: [Native|Public]
	int StopSkill_WithID(int SkillID, enum class UTSkillStopReason StopReason); // Offset: 0x10516b48c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkill
	// Flags: [Native|Public]
	void StopSkill(int SkillID, enum class UTSkillStopReason StopReason); // Offset: 0x10516b368 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.ShouldTriggerEvent
	// Flags: [Native|Public|BlueprintCallable]
	bool ShouldTriggerEvent(int SkillID, enum class UTSkillEventType EventType); // Offset: 0x10516b238 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Skill.UTSkillManagerComponent.SetupOwnerAndSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetupOwnerAndSystem(); // Offset: 0x10516b1d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillState
	// Flags: [Final|Native|Public|HasOutParms]
	void SetSkillState(struct TArray<struct FUTSkillStateSyncData>& InSyncStateDatas); // Offset: 0x10516b098 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillOwner
	// Flags: [Native|Public|BlueprintCallable]
	void SetSkillOwner(struct AActor* tempActor); // Offset: 0x10516afd4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSkillLevel(int SkillID, int SkillLevel); // Offset: 0x10516aeb8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillLastPhase
	// Flags: [Final|Native|Public]
	void SetSkillLastPhase(struct AUTSkill* Skill, int PhaseIndex); // Offset: 0x10516ad9c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillCurPhase
	// Flags: [Final|Native|Public]
	void SetSkillCurPhase(struct AUTSkill* Skill, int PhaseIndex); // Offset: 0x10516ac80 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillActive
	// Flags: [Native|Public|BlueprintCallable]
	bool SetSkillActive(int SkillID, bool bActive, bool bForceSet); // Offset: 0x10516aaac // Return & Params: Num(4) Size(0x7)

	// Object Name: Function Skill.UTSkillManagerComponent.SetModSkillUIRoot
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetModSkillUIRoot(struct UUAEUserWidget* ModSkillUIRoot); // Offset: 0x10516a9f0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.SetCurSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCurSkill(int SkillID, int SkillSlot); // Offset: 0x10516a8d4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.SetAutoSkillID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoSkillID(int InSkillID); // Offset: 0x10516a818 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerTriggerEvent_WithParams
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerTriggerEvent_WithParams(int SkillID, enum class UTSkillEventType EventType, struct TArray<struct FUAEBlackboardKeySelector> KeySelectors, struct TArray<char> Content); // Offset: 0x10516a524 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerTriggerEvent_WithID
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerTriggerEvent_WithID(int SkillID, enum class UTSkillEventType EventType); // Offset: 0x10516a3d4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerTriggerEvent
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerTriggerEvent(int SkillID, enum class UTSkillEventType EventType); // Offset: 0x10516a284 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerStartSkill
	// Flags: [Native|Public|BlueprintCallable]
	bool ServerStartSkill(int SkillID, bool bAutoCast); // Offset: 0x10516a12c // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerNotifyRandomSeed
	// Flags: [Net|Native|Event|Public|NetServer|NetValidate]
	void ServerNotifyRandomSeed(int Seed); // Offset: 0x10516a040 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.ResetSkillCollDown
	// Flags: [Native|Public|BlueprintCallable]
	void ResetSkillCollDown(int SkillID); // Offset: 0x105169f7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.ResetAllSkillCollDown
	// Flags: [Native|Public|BlueprintCallable]
	void ResetAllSkillCollDown(); // Offset: 0x105169f20 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.RequestSkillStates
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	void RequestSkillStates(bool RepSkillCD, bool RepSkillActiveState, struct TArray<int> RequestIDs); // Offset: 0x105169cc4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.RepSkillHitInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RepSkillHitInfo(); // Offset: 0x105169c70 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.RepOneSkillSynData
	// Flags: [Final|Native|Public]
	void RepOneSkillSynData(int SkillSlot, int InLastSkillID); // Offset: 0x105169b54 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.RepLastCastTime
	// Flags: [Final|Native|Public]
	void RepLastCastTime(); // Offset: 0x105169b00 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.ReplaceSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReplaceSkill(int OldSkillID, int NewSkillID); // Offset: 0x1051699e4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.RemoveReplacedSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveReplacedSkill(int OldSkillID); // Offset: 0x105169928 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.RemoveAllSkillUIWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveAllSkillUIWidget(); // Offset: 0x1051698d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.RegistSkillUIWidgetBP
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void RegistSkillUIWidgetBP(struct FString SkillClassName, struct FSoftObjectPath ObjPath); // Offset: 0x105169704 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function Skill.UTSkillManagerComponent.RegisterActorBlackBorad
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterActorBlackBorad(struct AActor* InActor, struct UUAEBlackboard* RegisterBlackboard); // Offset: 0x1051695e8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.RandRangeSyn
	// Flags: [Final|Native|Public]
	int RandRangeSyn(int StartIndex, int EndIndex); // Offset: 0x1051694c4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.PlayHurtSkillEffect
	// Flags: [Native|Public]
	void PlayHurtSkillEffect(struct FUTSkillHitInfo TheSkillHitInfo); // Offset: 0x1051693a8 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Skill.UTSkillManagerComponent.OnStopSkill
	// Flags: [Native|Public]
	void OnStopSkill(struct AUTSkill* Skill, enum class UTSkillStopReason StopReason); // Offset: 0x105169284 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillManagerComponent.OnSameTeam
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool OnSameTeam(struct AActor* A, struct AActor* B); // Offset: 0x105169168 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRespawned
	// Flags: [Native|Public]
	void OnRespawned(); // Offset: 0x10516910c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_SkillSynSinglePhaseData
	// Flags: [Native|Public]
	void OnRep_SkillSynSinglePhaseData(); // Offset: 0x1051690b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_SkillSynData
	// Flags: [Native|Public]
	void OnRep_SkillSynData(); // Offset: 0x105169054 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_SkillHitInfo
	// Flags: [Native|Public]
	void OnRep_SkillHitInfo(); // Offset: 0x105168ff8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_SkillCDDatas
	// Flags: [Final|Native|Public]
	void OnRep_SkillCDDatas(); // Offset: 0x105168fa4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_SkillActiveState
	// Flags: [Final|Native|Public]
	void OnRep_SkillActiveState(); // Offset: 0x105168f50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_ReplaceSkill
	// Flags: [Final|Native|Public]
	void OnRep_ReplaceSkill(); // Offset: 0x105168efc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_DynamicRepData
	// Flags: [Final|Native|Public]
	void OnRep_DynamicRepData(); // Offset: 0x105168ea8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRecycled
	// Flags: [Native|Public]
	void OnRecycled(); // Offset: 0x105168e4c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnInterruptSkill
	// Flags: [Native|Public]
	void OnInterruptSkill(struct AUTSkill* Skill, enum class UTSkillStopReason StopReason); // Offset: 0x105168d28 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillManagerComponent.IsUsingSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsUsingSkill(int SkillID); // Offset: 0x105168c60 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsSkillCanUse
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsSkillCanUse(); // Offset: 0x105168c00 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.IsSkillActived
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsSkillActived(int SkillID); // Offset: 0x105168b38 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsReadyToCastSkill
	// Flags: [Native|Public]
	bool IsReadyToCastSkill(int SkillID); // Offset: 0x105168a68 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsEnableSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	bool IsEnableSkillCoolDown(); // Offset: 0x105168a00 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.IsCurrentUseSkillID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsCurrentUseSkillID(int InSkillID); // Offset: 0x105168938 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsCastingSkillID
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsCastingSkillID(int InSkillID); // Offset: 0x105168868 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsCastingSkill
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsCastingSkill(); // Offset: 0x105168800 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.HandleTriggerParamsEvent
	// Flags: [Event|Public|BlueprintEvent]
	bool HandleTriggerParamsEvent(int SkillID, enum class UTSkillEventType EventType); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Skill.UTSkillManagerComponent.HandleSkillStop
	// Flags: [Native|Public]
	void HandleSkillStop(int SkillID, enum class UTSkillStopReason StopReason); // Offset: 0x1051686dc // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.HandleSkillStart
	// Flags: [Native|Public]
	void HandleSkillStart(int SkillID); // Offset: 0x105168618 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.GetUAEBlackboardBySkillId
	// Flags: [Native|Public|BlueprintCallable]
	struct UUAEBlackboard* GetUAEBlackboardBySkillId(int SkillID); // Offset: 0x10516854c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetUAEBlackboard
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEBlackboard* GetUAEBlackboard(struct AUTSkill* InSkill); // Offset: 0x105168488 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillWidget
	// Flags: [Native|Public|BlueprintCallable]
	struct UUTSkillWidget* GetSkillWidget(int SkillID); // Offset: 0x1051683bc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillState
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FUTSkillStateSyncData> GetSkillState(); // Offset: 0x105168330 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillSlotBySkillID
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetSkillSlotBySkillID(int SkillID); // Offset: 0x10516826c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillSlotBySkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetSkillSlotBySkill(struct AUTSkill* Skill); // Offset: 0x1051681a8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillsByGroup
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct AUTSkill*> GetSkillsByGroup(struct FName SkillGroup); // Offset: 0x105168084 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillLevel
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetSkillLevel(int SkillID); // Offset: 0x105167fc0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillLastPhase
	// Flags: [Final|Native|Public]
	int GetSkillLastPhase(struct AUTSkill* Skill); // Offset: 0x105167efc // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillIDFromSkillIndex
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetSkillIDFromSkillIndex(int InSkillIndex); // Offset: 0x105167e30 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillIDByClass
	// Flags: [Native|Public|BlueprintCallable]
	int GetSkillIDByClass(struct UObject* SkillClass); // Offset: 0x105167d64 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillCurPhase
	// Flags: [Final|Native|Public]
	int GetSkillCurPhase(struct AUTSkill* Skill); // Offset: 0x105167ca0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillByName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AUTSkill* GetSkillByName(struct FString SkillName); // Offset: 0x105167b64 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillByClassName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AUTSkill* GetSkillByClassName(struct FString SkillClassName); // Offset: 0x105167a28 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillBaseData
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FUTSkillCreateData GetSkillBaseData(int SkillID); // Offset: 0x105167960 // Return & Params: Num(2) Size(0x120)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkill
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AUTSkill* GetSkill(int SkillID); // Offset: 0x105167894 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetReplacedSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetReplacedSkill(int OldSkillID); // Offset: 0x1051677d0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetRealOwnerRoleSafety
	// Flags: [Native|Public|BlueprintCallable]
	enum class ENetRole GetRealOwnerRoleSafety(); // Offset: 0x10516775c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.GetLastCastTime
	// Flags: [Final|Native|Public]
	float GetLastCastTime(int SkillID); // Offset: 0x105167698 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetLastCastFinishTime
	// Flags: [Final|Native|Public]
	float GetLastCastFinishTime(int SkillID); // Offset: 0x1051675d4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurUsingSkillIDS
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<int> GetCurUsingSkillIDS(); // Offset: 0x105167548 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkills
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct AUTSkill*> GetCurSkills(); // Offset: 0x1051674bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkillPhases
	// Flags: [Final|Native|Public]
	struct TArray<struct UUTSkillPhase*> GetCurSkillPhases(); // Offset: 0x105167430 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkillPhase
	// Flags: [Final|Native|Public]
	struct UUTSkillPhase* GetCurSkillPhase(int InSkillSlot); // Offset: 0x10516736c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkillIDs
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<int> GetCurSkillIDs(); // Offset: 0x10516730c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkillID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	int GetCurSkillID(struct AUTSkill* Skill); // Offset: 0x105167248 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AUTSkill* GetCurSkill(int InSkillSlot); // Offset: 0x105167184 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurMonopolizeSkills
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<int> GetCurMonopolizeSkills(); // Offset: 0x1051670f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.FindRelatedCurSkillID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int FindRelatedCurSkillID(int SkillID, int& OutRelatedSkillSlot, bool bPeekSlotIndex); // Offset: 0x105166f24 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.DynamicRemoveSkill
	// Flags: [Native|Public|BlueprintCallable]
	void DynamicRemoveSkill(int InSkillID); // Offset: 0x105166e60 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.DynamicAddSkill
	// Flags: [Native|Public|BlueprintCallable]
	void DynamicAddSkill(int InSkillID); // Offset: 0x105166d9c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.ClientStartSkill
	// Flags: [Native|Public|BlueprintCallable]
	void ClientStartSkill(int SkillID, bool bAutoCast); // Offset: 0x105166c58 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.ClearSkill
	// Flags: [Native|Public]
	void ClearSkill(); // Offset: 0x105166bfc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.ClearRepParams
	// Flags: [Native|Public]
	void ClearRepParams(); // Offset: 0x105166ba0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.ClearInitParams
	// Flags: [Native|Public]
	void ClearInitParams(); // Offset: 0x105166b44 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.CacheSkillWidget
	// Flags: [Native|Public|BlueprintCallable]
	void CacheSkillWidget(int SkillID, struct UUTSkillWidget* Widget); // Offset: 0x105166a20 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Skill.UTSkillEventEffectMapForEditor
// Size: 0xa8 // Inherited bytes: 0x60
struct UUTSkillEventEffectMapForEditor : UUTSkillBaseWidget {
	// Fields
	enum class UTSkillEventType SkillEventType; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x7]; // Offset: 0x61 // Size: 0x07
	struct TArray<struct FName> InterestedOwnerTags; // Offset: 0x68 // Size: 0x10
	struct FName PreEventActionTag; // Offset: 0x78 // Size: 0x08
	struct UUTSkillEffect* SkillEffect; // Offset: 0x80 // Size: 0x08
	struct TArray<struct FSkillConditionWarpper> Conditions; // Offset: 0x88 // Size: 0x10
	struct TArray<struct FSkillConditionWarpper> TargetConditions; // Offset: 0x98 // Size: 0x10
};

// Object Name: Class Skill.UTSkillInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillInterface : UInterface {
	// Functions

	// Object Name: Function Skill.UTSkillInterface.TriggerEvent
	// Flags: [Native|Event|Public|BlueprintEvent]
	void TriggerEvent(int SkillID, enum class UTSkillEventType EventType); // Offset: 0x1051659b8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillInterface.HasSkillToken
	// Flags: [Native|Public]
	bool HasSkillToken(int SkillID); // Offset: 0x1051658e8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillInterface.HandleSkillStart
	// Flags: [Native|Event|Public|BlueprintEvent]
	void HandleSkillStart(int SkillID); // Offset: 0x105165824 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillInterface.HandleSkillEnd
	// Flags: [Native|Event|Public|BlueprintEvent]
	void HandleSkillEnd(int SkillID, enum class UTSkillStopReason Reason); // Offset: 0x105165700 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillInterface.ClearSkillToken
	// Flags: [Native|Public]
	void ClearSkillToken(int SkillID); // Offset: 0x10516563c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillInterface.ClearAllSkillToken
	// Flags: [Native|Public]
	void ClearAllSkillToken(); // Offset: 0x1051655e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillInterface.AddSkillToken
	// Flags: [Native|Public]
	void AddSkillToken(int SkillID); // Offset: 0x10516551c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Skill.UTSkillPhase
// Size: 0x110 // Inherited bytes: 0x28
struct UUTSkillPhase : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FString PhaseName; // Offset: 0x30 // Size: 0x10
	struct FString PhaseDescription; // Offset: 0x40 // Size: 0x10
	bool bPhaseEnabled; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x3]; // Offset: 0x51 // Size: 0x03
	struct TWeakObjectPtr<struct AUTSkill> OwnerSkill; // Offset: 0x54 // Size: 0x08
	int PhaseIndex; // Offset: 0x5c // Size: 0x04
	char pad_0x60[0x18]; // Offset: 0x60 // Size: 0x18
	int ActionsTopHalfCount; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
	struct FUTSkillPhaseCreateData BaseData; // Offset: 0x80 // Size: 0x88
	struct UUTSkillPicker* InEffectPickerOnAction; // Offset: 0x108 // Size: 0x08

	// Functions

	// Object Name: Function Skill.UTSkillPhase.TryJumpToPhase
	// Flags: [Final|Native|Public]
	bool TryJumpToPhase(struct UUTSkillManagerComponent* SkillManagerComponent, int PhaseId); // Offset: 0x10517a564 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Skill.UTSkillPhase.StopPhase
	// Flags: [Native|Public]
	void StopPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10517a4a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.StartPhase
	// Flags: [Native|Public]
	void StartPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10517a3dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.RepeatPhase
	// Flags: [Native|Public]
	void RepeatPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10517a318 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.PlaySkillHurtEffect
	// Flags: [Native|Public]
	bool PlaySkillHurtEffect(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim); // Offset: 0x10517a1e8 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillPhase.PlaySkillHurtAppearances
	// Flags: [Native|Public]
	bool PlaySkillHurtAppearances(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim); // Offset: 0x10517a0b8 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillPhase.PickTargets
	// Flags: [Native|Public]
	void PickTargets(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x105179ff4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.OnEvent
	// Flags: [Native|Public]
	bool OnEvent(struct UUTSkillManagerComponent* SkillManagerComponent, enum class UTSkillEventType TheEventType); // Offset: 0x105179ec4 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function Skill.UTSkillPhase.OnCustomEvent
	// Flags: [Native|Public]
	bool OnCustomEvent(struct UUTSkillManagerComponent* SkillManagerComponent, enum class UTSkillEventType TheEventType); // Offset: 0x105179d94 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function Skill.UTSkillPhase.GetChargePhaseRate
	// Flags: [Final|Native|Public]
	float GetChargePhaseRate(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x105179cd0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillPhase.ForceStopPhase
	// Flags: [Native|Public]
	bool ForceStopPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x105179c00 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillPhase.ClearAttachments
	// Flags: [Final|Native|Public]
	bool ClearAttachments(); // Offset: 0x105179ba0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillPhase.AfterStartPhase
	// Flags: [Native|Public]
	void AfterStartPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x105179adc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.AddSkillConditionLua
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddSkillConditionLua(struct AUTSkill* InSkill, struct FString InLuaPath); // Offset: 0x105179988 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillPhase.AddSkillActionLua
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddSkillActionLua(struct AUTSkill* InSkill, struct FString InLuaPath); // Offset: 0x105179834 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Skill.UTSkillPicker
// Size: 0xb0 // Inherited bytes: 0x60
struct UUTSkillPicker : UUTSkillBaseWidget {
	// Fields
	struct FUTSkillPickerCreateData BaseData; // Offset: 0x60 // Size: 0x20
	char pad_0x80[0x10]; // Offset: 0x80 // Size: 0x10
	struct TArray<struct FUTSkillPickedTarget> PickedResultTargets; // Offset: 0x90 // Size: 0x10
	struct TArray<struct UUTSkillPickerFilter*> Filters; // Offset: 0xa0 // Size: 0x10

	// Functions

	// Object Name: Function Skill.UTSkillPicker.PickTargetsInner
	// Flags: [Native|Protected|HasDefaults|BlueprintCallable]
	bool PickTargetsInner(struct FVector OriginPoint); // Offset: 0x10517b7a8 // Return & Params: Num(2) Size(0xd)

	// Object Name: Function Skill.UTSkillPicker.PickTargets
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	bool PickTargets(struct FVector OriginPoint); // Offset: 0x10517b6c0 // Return & Params: Num(2) Size(0xd)
};

// Object Name: Class Skill.UTSkillPickerFilter
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillPickerFilter : UObject {
	// Functions

	// Object Name: Function Skill.UTSkillPickerFilter.HandleFilterArray
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void HandleFilterArray(struct TArray<struct FUTSkillPickedTarget>& inArray, struct AActor* Owner); // Offset: 0x10517b300 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Skill.UTSkillWidget
// Size: 0x490 // Inherited bytes: 0x478
struct UUTSkillWidget : ULuaUAEUserWidget {
	// Fields
	struct UUTSkillManagerComponent* SkillManager; // Offset: 0x478 // Size: 0x08
	int SkillID; // Offset: 0x480 // Size: 0x04
	float TickInterval; // Offset: 0x484 // Size: 0x04
	bool bEnableTick; // Offset: 0x488 // Size: 0x01
	char pad_0x489[0x7]; // Offset: 0x489 // Size: 0x07

	// Functions

	// Object Name: Function Skill.UTSkillWidget.TriggerPassiveEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TriggerPassiveEvent(enum class UTSkillEventType SkillEvent); // Offset: 0x10517d0cc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillWidget.TriggerEvent
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void TriggerEvent(enum class UTSkillEventType SkillEvent); // Offset: 0x10517d008 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillWidget.SetSkillManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSkillManager(struct UUTSkillManagerComponent* manager); // Offset: 0x10517cf4c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillWidget.SetSkillID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSkillID(int InSkillID); // Offset: 0x10517ce90 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillWidget.GetSkillManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUTSkillManagerComponent* GetSkillManager(); // Offset: 0x10517ce34 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillWidget.GetSkillID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetSkillID(); // Offset: 0x10517cdd8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillWidget.GetSkillCDBases
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct UUTSkillCDBase*> GetSkillCDBases(); // Offset: 0x10517cd78 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillWidget.GetSkill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AUTSkill* GetSkill(); // Offset: 0x10517cd1c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillWidget.GetLocalPlayerController
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct APlayerController* GetLocalPlayerController(); // Offset: 0x10517ccc0 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Skill.UTSkillLocationPicker
// Size: 0x60 // Inherited bytes: 0x60
struct UUTSkillLocationPicker : UUTSkillBaseWidget {
};

// Object Name: Class Skill.AddNewSkillToOwnerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UAddNewSkillToOwnerInterface : UInterface {
	// Functions

	// Object Name: Function Skill.AddNewSkillToOwnerInterface.GetSkillTemplates
	// Flags: [Native|Event|Public|BlueprintEvent]
	struct TArray<struct FItemSkillsConfig> GetSkillTemplates(); // Offset: 0x10514e910 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Skill.SharedDelegate
// Size: 0x40 // Inherited bytes: 0x28
struct USharedDelegate : UObject {
	// Fields
	struct UObject* RedirectObject; // Offset: 0x28 // Size: 0x08
	struct UObject* FunctionOuter; // Offset: 0x30 // Size: 0x08
	struct FName FunctionName; // Offset: 0x38 // Size: 0x08

	// Functions

	// Object Name: Function Skill.SharedDelegate.EventTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EventTrigger(); // Offset: 0x10514ee74 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Skill.SharedDelegateManager
// Size: 0xd0 // Inherited bytes: 0x30
struct USharedDelegateManager : UWorldSubsystem {
	// Fields
	struct TMap<struct FSharedDelegateWrap, struct USharedDelegate*> DelegateMap; // Offset: 0x30 // Size: 0x50
	struct TMap<struct FMultiSharedDelegateWrap, struct USharedDelegate*> MultiDelegateMap; // Offset: 0x80 // Size: 0x50
};

// Object Name: Class Skill.UTSkillAction_Lua
// Size: 0x160 // Inherited bytes: 0xa0
struct UUTSkillAction_Lua : UUTSkillAction {
	// Fields
	char pad_0xA0[0x60]; // Offset: 0xa0 // Size: 0x60
	struct TMap<struct FName, struct FString> ActionParams; // Offset: 0x100 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x150 // Size: 0x10

	// Functions

	// Object Name: Function Skill.UTSkillAction_Lua.GetVectorValue
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|Const]
	struct FVector GetVectorValue(struct FName& Key); // Offset: 0x105152194 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Skill.UTSkillAction_Lua.GetStringValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	struct FString GetStringValue(struct FName& Key); // Offset: 0x105152050 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillAction_Lua.GetIntValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	int GetIntValue(struct FName& Key); // Offset: 0x105151f3c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillAction_Lua.GetFloatValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	float GetFloatValue(struct FName& Key); // Offset: 0x105151e28 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillAction_Lua.GetBoolValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetBoolValue(struct FName& Key); // Offset: 0x105151d10 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class Skill.UTSkillBlackboardInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillBlackboardInterface : UInterface {
	// Functions

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsWeakObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsWeakObject(int SkillID, struct FUAEBlackboardKeySelector& Key, struct UObject* ObjectValue); // Offset: 0x105155580 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsVector
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetValueAsVector(int SkillID, struct FUAEBlackboardKeySelector& Key, struct FVector VectorValue); // Offset: 0x1051553a4 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsString(int SkillID, struct FUAEBlackboardKeySelector& Key, struct FString StringValue); // Offset: 0x10515516c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsRotator
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetValueAsRotator(int SkillID, struct FUAEBlackboardKeySelector& Key, struct FRotator VectorValue); // Offset: 0x105154f90 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsObject(int SkillID, struct FUAEBlackboardKeySelector& Key, struct UObject* ObjectValue); // Offset: 0x105154dd4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsName(int SkillID, struct FUAEBlackboardKeySelector& Key, struct FName NameValue); // Offset: 0x105154bf0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsInt(int SkillID, struct FUAEBlackboardKeySelector& Key, int IntValue); // Offset: 0x105154a34 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsFloat(int SkillID, struct FUAEBlackboardKeySelector& Key, float FloatValue); // Offset: 0x105154878 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsEnum(int SkillID, struct FUAEBlackboardKeySelector& Key, char EnumValue); // Offset: 0x1051546bc // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsClass(int SkillID, struct FUAEBlackboardKeySelector& Key, struct UObject* ClassValue); // Offset: 0x105154500 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsBool(int SkillID, struct FUAEBlackboardKeySelector& Key, bool BoolValue); // Offset: 0x105154324 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistWeakObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistWeakObject(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x1051541bc // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistVector
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistVector(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105154054 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistString(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105153eec // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistRotator
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistRotator(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105153d84 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistObject(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105153c1c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistName(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105153ab4 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistInt(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10515394c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistFloat(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x1051537e4 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistEnum(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10515367c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistClass(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105153514 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistBool(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x1051533ac // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsVector
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct FVector GetValueAsVector(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105153230 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct FString GetValueAsString(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10515309c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsRotator
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct FRotator GetValueAsRotator(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105152f20 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct FName GetValueAsName(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105152db4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	int GetValueAsInt(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105152c50 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	float GetValueAsFloat(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105152aec // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	char GetValueAsEnum(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105152988 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct UObject* GetValueAsClass(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x105152824 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool GetValueAsBool(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x1051526bc // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetUAEBlackboardBySkillId
	// Flags: [Native|Public|BlueprintCallable]
	struct UUAEBlackboard* GetUAEBlackboardBySkillId(int SkillID); // Offset: 0x1051525f0 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Skill.UTSkillCDBase
// Size: 0xc8 // Inherited bytes: 0xa0
struct UUTSkillCDBase : ULuaObject {
	// Fields
	struct TWeakObjectPtr<struct UUTSkillManagerComponent> OwnerSkillManager; // Offset: 0xa0 // Size: 0x08
	struct TWeakObjectPtr<struct AUTSkill> OwnerSkill; // Offset: 0xa8 // Size: 0x08
	struct TArray<char> SyncContent; // Offset: 0xb0 // Size: 0x10
	struct UUTSkillManagerComponent* CurOwnerManager; // Offset: 0xc0 // Size: 0x08
};

// Object Name: Class Skill.UTSkillCD_CastEnergyByOwner
// Size: 0xd0 // Inherited bytes: 0xc8
struct UUTSkillCD_CastEnergyByOwner : UUTSkillCDBase {
	// Fields
	char pad_0xC8[0x8]; // Offset: 0xc8 // Size: 0x08
};

// Object Name: Class Skill.UTSkillCD_EnergyOfSkill
// Size: 0xc8 // Inherited bytes: 0xc8
struct UUTSkillCD_EnergyOfSkill : UUTSkillCDBase {
};

// Object Name: Class Skill.UTSkillCD_CastEnergyBySkill
// Size: 0xc8 // Inherited bytes: 0xc8
struct UUTSkillCD_CastEnergyBySkill : UUTSkillCD_EnergyOfSkill {
};

// Object Name: Class Skill.UTSkillCD_CastTime
// Size: 0xc8 // Inherited bytes: 0xc8
struct UUTSkillCD_CastTime : UUTSkillCDBase {
};

// Object Name: Class Skill.UTSkillCD_TickEnergyBySkill
// Size: 0xc8 // Inherited bytes: 0xc8
struct UUTSkillCD_TickEnergyBySkill : UUTSkillCD_EnergyOfSkill {
};

// Object Name: Class Skill.UTSkillCondition_Lua
// Size: 0xd0 // Inherited bytes: 0x60
struct UUTSkillCondition_Lua : UUTSkillCondition {
	// Fields
	char pad_0x60[0x60]; // Offset: 0x60 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0xc0 // Size: 0x10
};

// Object Name: Class Skill.UTSkillEvent
// Size: 0x30 // Inherited bytes: 0x28
struct UUTSkillEvent : UObject {
	// Fields
	enum class UTSkillEventType SkillEventType; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: Class Skill.UTSkillInstancedNodeContainerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillInstancedNodeContainerInterface : UInterface {
};

// Object Name: Class Skill.UTSkillInstancedNodeInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillInstancedNodeInterface : UInterface {
};

// Object Name: Class Skill.UTSkillFunctionBase
// Size: 0x78 // Inherited bytes: 0x60
struct UUTSkillFunctionBase : UUTSkillBaseWidget {
	// Fields
	struct FSkillFuncNameSelector DoActionFuncKey; // Offset: 0x60 // Size: 0x08
	struct FSkillFuncNameSelector UndoActionFuncKey; // Offset: 0x68 // Size: 0x08
	struct FSkillFuncNameSelector ConditionFuncKey; // Offset: 0x70 // Size: 0x08
};

// Object Name: Class Skill.UTSkillSpecificAction
// Size: 0xb0 // Inherited bytes: 0xa0
struct UUTSkillSpecificAction : UUTSkillAction {
	// Fields
	struct FSkillFuncNameSelector DoActionFuncKey; // Offset: 0xa0 // Size: 0x08
	struct FSkillFuncNameSelector UndoActionFuncKey; // Offset: 0xa8 // Size: 0x08

	// Functions

	// Object Name: Function Skill.UTSkillSpecificAction.UpdateAction_Internal
	// Flags: [Native|Public|BlueprintCallable]
	void UpdateAction_Internal(float DeltaSeconds); // Offset: 0x10517c290 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillSpecificAction.UndoAction_Internal
	// Flags: [Native|Public|BlueprintCallable]
	void UndoAction_Internal(); // Offset: 0x10517c234 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillSpecificAction.Reset_Internal
	// Flags: [Native|Public|BlueprintCallable]
	void Reset_Internal(); // Offset: 0x10517c1d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillSpecificAction.RealDoAction_Internal
	// Flags: [Native|Public|BlueprintCallable]
	bool RealDoAction_Internal(); // Offset: 0x10517c170 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillSpecificAction.PreCloseSkill
	// Flags: [Native|Public]
	void PreCloseSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x10517c04c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillSpecificAction.PostInitSkill
	// Flags: [Native|Public]
	void PostInitSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x10517bf28 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillSpecificAction.PostActiveSkill
	// Flags: [Native|Public]
	void PostActiveSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x10517be04 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Skill.UTSkillSpecificCondition
// Size: 0x68 // Inherited bytes: 0x60
struct UUTSkillSpecificCondition : UUTSkillCondition {
	// Fields
	struct FSkillFuncNameSelector ConditionFuncKey; // Offset: 0x60 // Size: 0x08
};

// Object Name: Class Skill.SkillUtil
// Size: 0x28 // Inherited bytes: 0x28
struct USkillUtil : UBlueprintFunctionLibrary {
};

