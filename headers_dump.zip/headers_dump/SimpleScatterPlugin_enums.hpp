#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum SimpleScatterPlugin.EPropertyUpdateGroup
enum class EPropertyUpdateGroup : uint8 {
	InstancersPropertiesUpdate = 0,
	ScatterUpdate = 1,
	TracedPointsUpdate = 2,
	EverythingUpdate = 3,
	EPropertyUpdateGroup_MAX = 4
};

// Object Name: Enum SimpleScatterPlugin.ESurfaceAlignMode
enum class ESurfaceAlignMode : uint8 {
	WorldAlign = 0,
	NormalAlign = 1,
	ESurfaceAlignMode_MAX = 2
};

// Object Name: Enum SimpleScatterPlugin.EScaleMode
enum class EScaleMode : uint8 {
	X = 0,
	XZ = 1,
	XYZ = 2,
	EScaleMode_MAX = 3
};

// Object Name: Enum SimpleScatterPlugin.EDistributionMode
enum class EDistributionMode : uint8 {
	RandomDistribution = 0,
	GridDistribution = 1,
	EDistributionMode_MAX = 2
};

