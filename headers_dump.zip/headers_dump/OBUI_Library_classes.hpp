#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass OBUI_Library.OBUI_Library_C
// Size: 0x28 // Inherited bytes: 0x28
struct UOBUI_Library_C : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function OBUI_Library.OBUI_Library_C.GetPlayerMakeupPicbyUID
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetPlayerMakeupPicbyUID(struct FString UId, struct UObject* __WorldContext, bool& bFind, struct FString& logoPath, struct UTexture2D*& LogoObject); // Offset: 0x103bcc798 // Return & Params: Num(5) Size(0x38)

	// Object Name: Function OBUI_Library.OBUI_Library_C.IsAllStarGame
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void IsAllStarGame(struct UObject* WorldContextObj, struct UObject* __WorldContext, bool& bRes); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function OBUI_Library.OBUI_Library_C.GetCustomTeammatePicByName
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetCustomTeammatePicByName(struct TArray<struct FString>& Resolution, struct FString PlayerName, struct UObject* __WorldContext, bool& bFind, struct FString& logoPath, struct UTexture2D*& LogoObject); // Offset: 0x103bcc798 // Return & Params: Num(6) Size(0x48)

	// Object Name: Function OBUI_Library.OBUI_Library_C.GetCustomCornerMarkByTeamID
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetCustomCornerMarkByTeamID(int TeamID, struct UObject* __WorldContext, bool& bFind, struct FString& CornerMark); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function OBUI_Library.OBUI_Library_C.GetCustomKillInfoByTeamID
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetCustomKillInfoByTeamID(int TeamID, struct UObject* __WorldContext, bool& bFind, struct FString& logoPath, struct UTexture2D*& LogoObject); // Offset: 0x103bcc798 // Return & Params: Num(5) Size(0x30)

	// Object Name: Function OBUI_Library.OBUI_Library_C.GetCustomTeamNameByTeamID
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetCustomTeamNameByTeamID(int TeamID, struct UObject* __WorldContext, bool& bFind, struct FString& TeamName); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function OBUI_Library.OBUI_Library_C.IsTeamMatch
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsTeamMatch(struct UObject* __WorldContext, bool& BRet); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function OBUI_Library.OBUI_Library_C.GetCustomTeamLogoByTeamID
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetCustomTeamLogoByTeamID(int TeamID, struct TArray<struct FString>& Resolution, struct UObject* __WorldContext, bool& bFind, struct FString& logoPath, struct UTexture2D*& LogoObject); // Offset: 0x103bcc798 // Return & Params: Num(6) Size(0x40)

	// Object Name: Function OBUI_Library.OBUI_Library_C.GetPlayerNameColorByTeamID
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetPlayerNameColorByTeamID(int TeamID, struct UObject* __WorldContext, struct FColor& PlayerNameColor); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function OBUI_Library.OBUI_Library_C.GetPlayerColorByTeamID
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetPlayerColorByTeamID(int TeamID, struct UObject* __WorldContext, struct FColor& PlayerColor); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x14)
};

