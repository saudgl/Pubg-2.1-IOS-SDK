#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_AchievementParamCfg_type.BP_STRUCT_AchievementParamCfg_type
// Size: 0x10 // Inherited bytes: 0x00
struct FBP_STRUCT_AchievementParamCfg_type {
	// Fields
	int SubID_0_29ECADC024299EA3780717AF046D3394; // Offset: 0x00 // Size: 0x04
	int Param_1_2E08BC406FAA613D7AF3C5F404610D3D; // Offset: 0x04 // Size: 0x04
	int EventID_2_4D0883C00734A59D4F6FF3780B4F1CA4; // Offset: 0x08 // Size: 0x04
	int ID_3_51A443402791CC5F4EA069CF085447A4; // Offset: 0x0c // Size: 0x04
};

