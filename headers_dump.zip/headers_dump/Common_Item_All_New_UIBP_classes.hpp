#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_Item_All_New_UIBP.Common_Item_All_New_UIBP_C
// Size: 0x648 // Inherited bytes: 0x400
struct UCommon_Item_All_New_UIBP_C : UUAEUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x400 // Size: 0x08
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x408 // Size: 0x08
	struct UImage* BG; // Offset: 0x410 // Size: 0x08
	struct UImage* Box; // Offset: 0x418 // Size: 0x08
	struct UButton* Button_Item; // Offset: 0x420 // Size: 0x08
	struct UCanvasPanel* Canvas; // Offset: 0x428 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_LimitTime; // Offset: 0x430 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Wish; // Offset: 0x438 // Size: 0x08
	struct UCanvasPanel* CombatReadiness; // Offset: 0x440 // Size: 0x08
	struct UCommon_selected_UIBP_C* Common_selected_UIBP; // Offset: 0x448 // Size: 0x08
	struct UTextBlock* cost_num; // Offset: 0x450 // Size: 0x08
	struct UHorizontalBox* cost_root; // Offset: 0x458 // Size: 0x08
	struct UTextBlock* Count; // Offset: 0x460 // Size: 0x08
	struct UTextBlock* countL; // Offset: 0x468 // Size: 0x08
	struct UTextBlock* GetText; // Offset: 0x470 // Size: 0x08
	struct UTextBlock* have_num; // Offset: 0x478 // Size: 0x08
	struct UImage* Image_2; // Offset: 0x480 // Size: 0x08
	struct UImage* Image_3; // Offset: 0x488 // Size: 0x08
	struct UImage* Image_4; // Offset: 0x490 // Size: 0x08
	struct UImage* Image_5; // Offset: 0x498 // Size: 0x08
	struct UImage* Image_6; // Offset: 0x4a0 // Size: 0x08
	struct UImage* Image_7; // Offset: 0x4a8 // Size: 0x08
	struct UImage* Image_8; // Offset: 0x4b0 // Size: 0x08
	struct UImage* Image_9; // Offset: 0x4b8 // Size: 0x08
	struct UImage* Image_12; // Offset: 0x4c0 // Size: 0x08
	struct UImage* Image_25; // Offset: 0x4c8 // Size: 0x08
	struct UImage* Image_01; // Offset: 0x4d0 // Size: 0x08
	struct UImage* Image_02; // Offset: 0x4d8 // Size: 0x08
	struct UImage* Image_03; // Offset: 0x4e0 // Size: 0x08
	struct UImage* Image_04; // Offset: 0x4e8 // Size: 0x08
	struct UImage* Image_05; // Offset: 0x4f0 // Size: 0x08
	struct UImage* Image_Available; // Offset: 0x4f8 // Size: 0x08
	struct UImage* Image_Bg_Default; // Offset: 0x500 // Size: 0x08
	struct UImage* Image_Bg_Lucky; // Offset: 0x508 // Size: 0x08
	struct UImage* Image_BlackBg; // Offset: 0x510 // Size: 0x08
	struct UImage* Image_BlackMask; // Offset: 0x518 // Size: 0x08
	struct UImage* Image_BlackMask2; // Offset: 0x520 // Size: 0x08
	struct UImage* Image_Discount; // Offset: 0x528 // Size: 0x08
	struct UImage* Image_Emotion; // Offset: 0x530 // Size: 0x08
	struct UImage* Image_Gift; // Offset: 0x538 // Size: 0x08
	struct UImage* Image_Goods; // Offset: 0x540 // Size: 0x08
	struct UImage* Image_HasGet; // Offset: 0x548 // Size: 0x08
	struct UImage* Image_Icon; // Offset: 0x550 // Size: 0x08
	struct UImage* Image_IconQuality; // Offset: 0x558 // Size: 0x08
	struct UImage* Image_LimitTime; // Offset: 0x560 // Size: 0x08
	struct UImage* Image_Lock; // Offset: 0x568 // Size: 0x08
	struct UImage* Image_Quality; // Offset: 0x570 // Size: 0x08
	struct UImage* Image_RedEmotion; // Offset: 0x578 // Size: 0x08
	struct UImage* Image_Reflit; // Offset: 0x580 // Size: 0x08
	struct UImage* Image_Right; // Offset: 0x588 // Size: 0x08
	struct UCanvasPanel* Image_Select; // Offset: 0x590 // Size: 0x08
	struct UCanvasPanel* Image_SourceBook_Using; // Offset: 0x598 // Size: 0x08
	struct UImage* Image_SubTransparentBg; // Offset: 0x5a0 // Size: 0x08
	struct UImage* Image_SuperReflit; // Offset: 0x5a8 // Size: 0x08
	struct UImage* Image_tag1; // Offset: 0x5b0 // Size: 0x08
	struct UImage* Image_tag2; // Offset: 0x5b8 // Size: 0x08
	struct UCanvasPanel* Image_Using; // Offset: 0x5c0 // Size: 0x08
	struct UCanvasPanel* Panel_Download; // Offset: 0x5c8 // Size: 0x08
	struct UCanvasPanel* Panel_Light; // Offset: 0x5d0 // Size: 0x08
	struct UQuality8Item_UIBP_C* Quality8Item_UIBP; // Offset: 0x5d8 // Size: 0x08
	struct UScaleBox* ScaleBox_Count; // Offset: 0x5e0 // Size: 0x08
	struct UImage* SpecialIcon; // Offset: 0x5e8 // Size: 0x08
	struct UWidgetSwitcher* Switcher_Joint; // Offset: 0x5f0 // Size: 0x08
	struct UTextBlock* Text_ExtraGet; // Offset: 0x5f8 // Size: 0x08
	struct UTextBlock* Text_new; // Offset: 0x600 // Size: 0x08
	struct UTextBlock* Text_New2; // Offset: 0x608 // Size: 0x08
	struct UTextBlock* Text_RandomGet; // Offset: 0x610 // Size: 0x08
	struct UTextBlock* Text_Title; // Offset: 0x618 // Size: 0x08
	struct UTextBlock* TextBlock_7; // Offset: 0x620 // Size: 0x08
	struct UTextBlock* TextBlock_Isolated; // Offset: 0x628 // Size: 0x08
	struct UHorizontalBox* TimePanel; // Offset: 0x630 // Size: 0x08
	struct UTextBlock* TimeText; // Offset: 0x638 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Reflit; // Offset: 0x640 // Size: 0x08

	// Functions

	// Object Name: Function Common_Item_All_New_UIBP.Common_Item_All_New_UIBP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_All_New_UIBP.Common_Item_All_New_UIBP_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Destruct(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_All_New_UIBP.Common_Item_All_New_UIBP_C.ExecuteUbergraph_Common_Item_All_New_UIBP
	// Flags: [None]
	void ExecuteUbergraph_Common_Item_All_New_UIBP(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

