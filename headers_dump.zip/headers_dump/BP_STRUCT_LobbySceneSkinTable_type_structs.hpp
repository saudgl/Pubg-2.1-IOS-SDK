#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_LobbySceneSkinTable_type.BP_STRUCT_LobbySceneSkinTable_type
// Size: 0x64 // Inherited bytes: 0x00
struct FBP_STRUCT_LobbySceneSkinTable_type {
	// Fields
	struct FString SkinStreamLevelName_0_3781FCC026A707C5085B0B8D0763C135; // Offset: 0x00 // Size: 0x10
	int SkinID_1_11FAE6C0633AFB313233DCF907356724; // Offset: 0x10 // Size: 0x04
	int SkinStyleKey1_6_3E24BE404C85800940BF19450D807901; // Offset: 0x14 // Size: 0x04
	int SkinStyleKey2_7_3E25BE804C85800A40BF19440D807902; // Offset: 0x18 // Size: 0x04
	int SkinStyleKey3_8_3E26BEC04C85800B40BF19470D807903; // Offset: 0x1c // Size: 0x04
	int SkinStyleKey4_9_3E27BF004C85800C40BF19460D807904; // Offset: 0x20 // Size: 0x04
	int SkinStyleKey5_10_3E28BF404C85800D40BF19410D807905; // Offset: 0x24 // Size: 0x04
	int SkinStyleKey6_11_3E29BF804C85800E40BF19400D807906; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString hallMaskPic1_12_547A3CC06D45501D04D1A1C60CD4F9A1; // Offset: 0x30 // Size: 0x10
	struct FString hallMaskPic2_13_547B3D006D45501E04D1A1C50CD4F9A2; // Offset: 0x40 // Size: 0x10
	struct FString hallMaskPic3_14_547C3D406D45501F04D1A1C40CD4F9A3; // Offset: 0x50 // Size: 0x10
	int SkinStreamLevelSequence_15_44C54AC019B77F5B7D933C0F0B8CE785; // Offset: 0x60 // Size: 0x04
};

