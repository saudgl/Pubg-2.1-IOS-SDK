#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct IOSRuntimeSettings.IOSBuildResourceDirectory
// Size: 0x10 // Inherited bytes: 0x00
struct FIOSBuildResourceDirectory {
	// Fields
	struct FString Path; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct IOSRuntimeSettings.IOSBuildResourceFilePath
// Size: 0x10 // Inherited bytes: 0x00
struct FIOSBuildResourceFilePath {
	// Fields
	struct FString FilePath; // Offset: 0x00 // Size: 0x10
};

