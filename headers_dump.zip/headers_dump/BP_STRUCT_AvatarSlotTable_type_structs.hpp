#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_AvatarSlotTable_type.BP_STRUCT_AvatarSlotTable_type
// Size: 0xa8 // Inherited bytes: 0x00
struct FBP_STRUCT_AvatarSlotTable_type {
	// Fields
	int SlotID_0_07B16B8074758AC65DD345920E3BDC84; // Offset: 0x00 // Size: 0x04
	int TemplateID_1_2691320079AF0A7A6A1748830376BD24; // Offset: 0x04 // Size: 0x04
	struct FString RecoverReplaceFlagsWhenSelfHidden_2_1E3059803295C22634A0ED8E0030856E; // Offset: 0x08 // Size: 0x10
	struct FString HideFlags_3_237919800A408D2A273633DC01DAD293; // Offset: 0x18 // Size: 0x10
	struct FString ConflictConfig_4_4BB661C01D3BCD3F6F3FB665067D3C67; // Offset: 0x28 // Size: 0x10
	struct FString RecoverReplaceFlagsWhenSelfReplaced_5_1EC56E80372E83625B067765035DA8E4; // Offset: 0x38 // Size: 0x10
	struct FString RecoverHideFlagsWhenSelfHidden_6_6B26A900172EBB763595428E0B36164E; // Offset: 0x48 // Size: 0x10
	struct FString ReplaceFlags_7_2D4E8A0019E3B1AC0C7FEA5807A9C1C3; // Offset: 0x58 // Size: 0x10
	struct FString RecoverHideFlagsWhenSelfReplaced_8_1D3C3E0039C7C5D033D65C0505EE83E4; // Offset: 0x68 // Size: 0x10
	int SubSlotID_9_5DE936007C7E6AFA71E4CC580CE889E4; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
	struct FString ConflictConfigWhenSelfReplaced_10_426690C043D8722F5C5A3A8F03A0F1A4; // Offset: 0x80 // Size: 0x10
	struct FString HideBoneNames_11_774C9C40779C7AFB2332C67001F5BD73; // Offset: 0x90 // Size: 0x10
	int HideBoneType_12_394DA7C05E9425853B3A77F80B1DBD85; // Offset: 0xa0 // Size: 0x04
	int HideBoneSlotID_13_7901AB002CDD9D2C1F43E7310DA083C4; // Offset: 0xa4 // Size: 0x04
};

