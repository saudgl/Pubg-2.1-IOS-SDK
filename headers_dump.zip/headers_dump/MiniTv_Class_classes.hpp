#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass MiniTv_Class.MiniTv_Class_C
// Size: 0x4c8 // Inherited bytes: 0x4a0
struct AMiniTv_Class_C : ALuaActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4a0 // Size: 0x08
	struct UMinitvAvatarComponent_BP_C* MinitvAvatarComponent_BP; // Offset: 0x4a8 // Size: 0x08
	struct USkeletalMeshComponent* SkeletalMesh; // Offset: 0x4b0 // Size: 0x08
	struct UCapsuleComponent* Capsule; // Offset: 0x4b8 // Size: 0x08
	struct USkeletalMeshComponent* PhoneMesh; // Offset: 0x4c0 // Size: 0x08

	// Functions

	// Object Name: Function MiniTv_Class.MiniTv_Class_C.DestoryPhoneMesh
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void DestoryPhoneMesh(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Class.MiniTv_Class_C.PlayPhoneAnim
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PlayPhoneAnim(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Class.MiniTv_Class_C.TouchEnd
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void TouchEnd(enum class ETouchIndex finger); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MiniTv_Class.MiniTv_Class_C.TouchStart
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void TouchStart(enum class ETouchIndex finger); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MiniTv_Class.MiniTv_Class_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Class.MiniTv_Class_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveTick(float DeltaSeconds); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MiniTv_Class.MiniTv_Class_C.BndEvt__SkeletalMesh_K2Node_ComponentBoundEvent_0_ComponentOnInputTouchBeginSignature__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__SkeletalMesh_K2Node_ComponentBoundEvent_0_ComponentOnInputTouchBeginSignature__DelegateSignature(enum class ETouchIndex FingerIndex, struct UPrimitiveComponent* TouchedComponent); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MiniTv_Class.MiniTv_Class_C.BndEvt__SkeletalMesh_K2Node_ComponentBoundEvent_1_ComponentOnInputTouchEndSignature__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__SkeletalMesh_K2Node_ComponentBoundEvent_1_ComponentOnInputTouchEndSignature__DelegateSignature(enum class ETouchIndex FingerIndex, struct UPrimitiveComponent* TouchedComponent); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MiniTv_Class.MiniTv_Class_C.ExecuteUbergraph_MiniTv_Class
	// Flags: [None]
	void ExecuteUbergraph_MiniTv_Class(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

