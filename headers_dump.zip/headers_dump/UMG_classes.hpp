#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UMG.Visual
// Size: 0x28 // Inherited bytes: 0x28
struct UVisual : UObject {
};

// Object Name: Class UMG.Widget
// Size: 0x100 // Inherited bytes: 0x28
struct UWidget : UVisual {
	// Fields
	struct UPanelSlot* Slot; // Offset: 0x28 // Size: 0x08
	DelegateProperty bIsEnabledDelegate; // Offset: 0x30 // Size: 0x10
	struct FText ToolTipText; // Offset: 0x40 // Size: 0x18
	DelegateProperty ToolTipTextDelegate; // Offset: 0x58 // Size: 0x10
	struct UWidget* ToolTipWidget; // Offset: 0x68 // Size: 0x08
	DelegateProperty ToolTipWidgetDelegate; // Offset: 0x70 // Size: 0x10
	DelegateProperty VisibilityDelegate; // Offset: 0x80 // Size: 0x10
	struct FWidgetTransform RenderTransform; // Offset: 0x90 // Size: 0x1c
	struct FVector2D RenderTransformPivot; // Offset: 0xac // Size: 0x08
	char bIsVariable : 1; // Offset: 0xb4 // Size: 0x01
	char bCreatedByConstructionScript : 1; // Offset: 0xb4 // Size: 0x01
	char bIsEnabled : 1; // Offset: 0xb4 // Size: 0x01
	char bOverride_Cursor : 1; // Offset: 0xb4 // Size: 0x01
	char bIsVolatile : 1; // Offset: 0xb4 // Size: 0x01
	char bWriteSceneZBuffer : 1; // Offset: 0xb4 // Size: 0x01
	char pad_0xB4_6 : 2; // Offset: 0xb4 // Size: 0x01
	char UsedLayerPolicy; // Offset: 0xb5 // Size: 0x01
	char PreservedLayerNum; // Offset: 0xb6 // Size: 0x01
	enum class EMouseCursor Cursor; // Offset: 0xb7 // Size: 0x01
	enum class EWidgetClipping Clipping; // Offset: 0xb8 // Size: 0x01
	enum class ESlateVisibility Visibility; // Offset: 0xb9 // Size: 0x01
	bool bVisiblePass; // Offset: 0xba // Size: 0x01
	enum class EWidgetVisible WidgetVisible; // Offset: 0xbb // Size: 0x01
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct UWidgetNavigation* Navigation; // Offset: 0xc0 // Size: 0x08
	char pad_0xC8[0x28]; // Offset: 0xc8 // Size: 0x28
	struct TArray<struct UPropertyBinding*> NativeBindings; // Offset: 0xf0 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Widget.SetWidgetRender
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWidgetRender(enum class EWidgetVisible InWidgetVisible); // Offset: 0x104643994 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetVisibility
	// Flags: [Native|Public|BlueprintCallable]
	void SetVisibility(enum class ESlateVisibility InVisibility); // Offset: 0x104643910 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUserFocus(struct APlayerController* PlayerController); // Offset: 0x104643894 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetToolTipText
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetToolTipText(struct FText& InToolTipText); // Offset: 0x1046437e8 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.Widget.SetToolTip
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetToolTip(struct UWidget* Widget); // Offset: 0x10464376c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderTranslation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetRenderTranslation(struct FVector2D Translation); // Offset: 0x1046436f4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderTransformPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetRenderTransformPivot(struct FVector2D Pivot); // Offset: 0x10464367c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRenderTransform(struct FWidgetTransform InTransform); // Offset: 0x1046435d0 // Return & Params: Num(1) Size(0x1c)

	// Object Name: Function UMG.Widget.SetRenderShear
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetRenderShear(struct FVector2D Shear); // Offset: 0x104643558 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetRenderScale(struct FVector2D Scale); // Offset: 0x1046434e0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRenderAngle(float Angle); // Offset: 0x104643464 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Widget.SetNavigationRule
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNavigationRule(enum class EUINavigation Direction, enum class EUINavigationRule Rule, struct FName WidgetToFocus); // Offset: 0x104643370 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function UMG.Widget.SetKeyboardFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetKeyboardFocus(); // Offset: 0x10464335c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.Widget.SetIsEnabled
	// Flags: [Native|Public|BlueprintCallable]
	void SetIsEnabled(bool bInIsEnabled); // Offset: 0x1046432d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetCursor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCursor(enum class EMouseCursor InCursor); // Offset: 0x104643254 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetClipping
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClipping(enum class EWidgetClipping InClipping); // Offset: 0x1046431d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetAllNavigationRules
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllNavigationRules(enum class EUINavigationRule Rule, struct FName WidgetToFocus); // Offset: 0x104643120 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.Widget.ResetCursor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetCursor(); // Offset: 0x10464310c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.Widget.RemoveFromParent
	// Flags: [Native|Public|BlueprintCallable]
	void RemoveFromParent(); // Offset: 0x1046430f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction UMG.Widget.OnReply__DelegateSignature
	// Flags: [Public|Delegate]
	struct FEventReply OnReply__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0xb8)

	// Object Name: DelegateFunction UMG.Widget.OnPointerEvent__DelegateSignature
	// Flags: [Public|Delegate|HasOutParms]
	struct FEventReply OnPointerEvent__DelegateSignature(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.Widget.IsVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsVisible(); // Offset: 0x1046430bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.IsHovered
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsHovered(); // Offset: 0x104643088 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.InvalidateLayoutAndVolatility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InvalidateLayoutAndVolatility(); // Offset: 0x104643074 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.Widget.HasUserFocusedDescendants
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasUserFocusedDescendants(struct APlayerController* PlayerController); // Offset: 0x104642fe8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.Widget.HasUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasUserFocus(struct APlayerController* PlayerController); // Offset: 0x104642f5c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.Widget.HasMouseCapture
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasMouseCapture(); // Offset: 0x104642f28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.HasKeyboardFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasKeyboardFocus(); // Offset: 0x104642ef4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.HasFocusedDescendants
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasFocusedDescendants(); // Offset: 0x104642ec0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.HasAnyUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasAnyUserFocus(); // Offset: 0x104642e8c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.GetWidgetRender
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EWidgetVisible GetWidgetRender(); // Offset: 0x104642e58 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetWidget__DelegateSignature
	// Flags: [Public|Delegate]
	struct UWidget* GetWidget__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.GetVisibility
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ESlateVisibility GetVisibility(); // Offset: 0x104642e24 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.GetTheTemplate
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UWidget* GetTheTemplate(); // Offset: 0x104642df0 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction UMG.Widget.GetText__DelegateSignature
	// Flags: [Public|Delegate]
	struct FText GetText__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.Widget.GetSlateVisibility__DelegateSignature
	// Flags: [Public|Delegate]
	enum class ESlateVisibility GetSlateVisibility__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetSlateColor__DelegateSignature
	// Flags: [Public|Delegate]
	struct FSlateColor GetSlateColor__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x28)

	// Object Name: DelegateFunction UMG.Widget.GetSlateBrush__DelegateSignature
	// Flags: [Public|Delegate]
	struct FSlateBrush GetSlateBrush__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.Widget.GetParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UPanelWidget* GetParent(); // Offset: 0x104642dbc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.GetOwningPlayer
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APlayerController* GetOwningPlayer(); // Offset: 0x104642d80 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction UMG.Widget.GetMouseCursor__DelegateSignature
	// Flags: [Public|Delegate]
	enum class EMouseCursor GetMouseCursor__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetLinearColor__DelegateSignature
	// Flags: [Public|Delegate|HasDefaults]
	struct FLinearColor GetLinearColor__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Widget.GetIsEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsEnabled(); // Offset: 0x104642d4c // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetInt32__DelegateSignature
	// Flags: [Public|Delegate]
	int GetInt32__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction UMG.Widget.GetFloat__DelegateSignature
	// Flags: [Public|Delegate]
	float GetFloat__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Widget.GetDesiredSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetDesiredSize(); // Offset: 0x104642d14 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.GetClipping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EWidgetClipping GetClipping(); // Offset: 0x104642ce0 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetCheckBoxState__DelegateSignature
	// Flags: [Public|Delegate]
	enum class ECheckBoxState GetCheckBoxState__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.GetCachedGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGeometry GetCachedGeometry(); // Offset: 0x104642ca8 // Return & Params: Num(1) Size(0x38)

	// Object Name: Function UMG.Widget.GetCachedAllottedGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGeometry GetCachedAllottedGeometry(); // Offset: 0x104642c70 // Return & Params: Num(1) Size(0x38)

	// Object Name: DelegateFunction UMG.Widget.GetBool__DelegateSignature
	// Flags: [Public|Delegate]
	bool GetBool__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GenerateWidgetForString__DelegateSignature
	// Flags: [Public|Delegate]
	struct UWidget* GenerateWidgetForString__DelegateSignature(struct FString Item); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction UMG.Widget.GenerateWidgetForObject__DelegateSignature
	// Flags: [Public|Delegate]
	struct UWidget* GenerateWidgetForObject__DelegateSignature(struct UObject* Item); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.Widget.ForceVolatile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForceVolatile(bool bForce); // Offset: 0x104642bec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.ForceLayoutPrepass
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForceLayoutPrepass(); // Offset: 0x104642bd8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.Widget.AdaptationWidgetSlot
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AdaptationWidgetSlot(struct FMargin& InOffset); // Offset: 0x104642b4c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.UserWidget
// Size: 0x248 // Inherited bytes: 0x100
struct UUserWidget : UWidget {
	// Fields
	char pad_0x100[0x8]; // Offset: 0x100 // Size: 0x08
	struct FLinearColor ColorAndOpacity; // Offset: 0x108 // Size: 0x10
	DelegateProperty ColorAndOpacityDelegate; // Offset: 0x118 // Size: 0x10
	struct FSlateColor ForegroundColor; // Offset: 0x128 // Size: 0x28
	DelegateProperty ForegroundColorDelegate; // Offset: 0x150 // Size: 0x10
	struct FMargin Padding; // Offset: 0x160 // Size: 0x10
	struct TArray<struct UUMGSequencePlayer*> ActiveSequencePlayers; // Offset: 0x170 // Size: 0x10
	struct TArray<struct UUMGSequencePlayer*> StoppedSequencePlayers; // Offset: 0x180 // Size: 0x10
	DelegateProperty OnTouchStart; // Offset: 0x190 // Size: 0x10
	DelegateProperty OnTouchMove; // Offset: 0x1a0 // Size: 0x10
	DelegateProperty OnTouchEnd; // Offset: 0x1b0 // Size: 0x10
	struct TArray<struct FNamedSlotBinding> NamedSlotBindings; // Offset: 0x1c0 // Size: 0x10
	struct UWidgetTree* WidgetTree; // Offset: 0x1d0 // Size: 0x08
	int Priority; // Offset: 0x1d8 // Size: 0x04
	char bSupportsKeyboardFocus : 1; // Offset: 0x1dc // Size: 0x01
	char bIsFocusable : 1; // Offset: 0x1dc // Size: 0x01
	char bStopAction : 1; // Offset: 0x1dc // Size: 0x01
	char bCanEverTick : 1; // Offset: 0x1dc // Size: 0x01
	char bCanEverPaint : 1; // Offset: 0x1dc // Size: 0x01
	char bDontPaintWhenChildEmpty : 1; // Offset: 0x1dc // Size: 0x01
	char pad_0x1DC_6 : 1; // Offset: 0x1dc // Size: 0x01
	char bCookedWidgetTree : 1; // Offset: 0x1dc // Size: 0x01
	bool needAutoPlay; // Offset: 0x1dd // Size: 0x01
	bool isAutoLoop; // Offset: 0x1de // Size: 0x01
	char pad_0x1DF[0x1]; // Offset: 0x1df // Size: 0x01
	struct TArray<struct FName> autoPlayNameList; // Offset: 0x1e0 // Size: 0x10
	struct UInputComponent* InputComponent; // Offset: 0x1f0 // Size: 0x08
	char pad_0x1F8[0x50]; // Offset: 0x1f8 // Size: 0x50

	// Functions

	// Object Name: Function UMG.UserWidget.UnregisterInputComponent
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void UnregisterInputComponent(); // Offset: 0x10463e47c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function UMG.UserWidget.StopListeningForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void StopListeningForInputAction(struct FName ActionName, enum class EInputEvent EventType); // Offset: 0x10463e3bc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.StopListeningForAllInputActions
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void StopListeningForAllInputActions(); // Offset: 0x10463e3a8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.StopAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void StopAnimation(struct UWidgetAnimation* InAnimation); // Offset: 0x10463e32c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.SetPositionInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	void SetPositionInViewport(struct FVector2D Position, bool bRemoveDPIScale); // Offset: 0x10463e270 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.SetPlaybackSpeed
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetPlaybackSpeed(struct UWidgetAnimation* InAnimation, float PlaybackSpeed); // Offset: 0x10463e1b8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.UserWidget.SetPadding
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x10463e138 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UserWidget.SetOwningPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetOwningPlayer(struct APlayerController* LocalPlayerController); // Offset: 0x10463e0bc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.SetOwningLocalPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetOwningLocalPlayer(struct ULocalPlayer* LocalPlayer); // Offset: 0x10463e040 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.SetNumLoopsToPlay
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetNumLoopsToPlay(struct UWidgetAnimation* InAnimation, int NumLoopsToPlay); // Offset: 0x10463df88 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.UserWidget.SetInputActionPriority
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetInputActionPriority(int NewPriority); // Offset: 0x10463df0c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UserWidget.SetInputActionBlocking
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetInputActionBlocking(bool bShouldBlock); // Offset: 0x10463de88 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.SetForegroundColor
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetForegroundColor(struct FSlateColor InForegroundColor); // Offset: 0x10463dd84 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.UserWidget.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x10463dd00 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.SetDesiredSizeInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	void SetDesiredSizeInViewport(struct FVector2D Size); // Offset: 0x10463dc88 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.SetColorAndOpacity
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Offset: 0x10463dc0c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UserWidget.SetAnchorsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetAnchorsInViewport(struct FAnchors Anchors); // Offset: 0x10463db8c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UserWidget.SetAlignmentInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	void SetAlignmentInViewport(struct FVector2D Alignment); // Offset: 0x10463db14 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.ReverseAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void ReverseAnimation(struct UWidgetAnimation* InAnimation); // Offset: 0x10463da98 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.RemoveFromViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void RemoveFromViewport(); // Offset: 0x10463da84 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.RegisterInputComponent
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void RegisterInputComponent(); // Offset: 0x10463da70 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.PlaySound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void PlaySound(struct USoundBase* SoundToPlay); // Offset: 0x10463d9f4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.PlayAnimationTo
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void PlayAnimationTo(struct UWidgetAnimation* InAnimation, float StartAtTime, float EndAtTime, int NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed); // Offset: 0x10463d850 // Return & Params: Num(6) Size(0x1c)

	// Object Name: Function UMG.UserWidget.PlayAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void PlayAnimation(struct UWidgetAnimation* InAnimation, float StartAtTime, int NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed); // Offset: 0x10463d6e4 // Return & Params: Num(5) Size(0x18)

	// Object Name: Function UMG.UserWidget.PauseAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	float PauseAnimation(struct UWidgetAnimation* InAnimation); // Offset: 0x10463d658 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.UserWidget.OnTouchStarted
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchStarted(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnTouchMoved
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchMoved(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnTouchGesture
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchGesture(struct FGeometry MyGeometry, struct FPointerEvent& GestureEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnTouchEnded
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchEnded(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnRemovedFromFocusPath
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnRemovedFromFocusPath(struct FFocusEvent InFocusEvent); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.OnPreviewMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnPreviewMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnPreviewKeyDown
	// Flags: [Event|Public|BlueprintEvent]
	struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x130)

	// Object Name: Function UMG.UserWidget.OnPaint
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent|Const]
	void OnPaint(struct FPaintContext& Context); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function UMG.UserWidget.OnMouseWheel
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnMouseMove
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnMouseLeave
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnMouseLeave(struct FPointerEvent& MouseEvent); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x78)

	// Object Name: Function UMG.UserWidget.OnMouseEnter
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0xb0)

	// Object Name: Function UMG.UserWidget.OnMouseCaptureLost
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnMouseCaptureLost(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.OnMouseButtonUp
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnMouseButtonDoubleClick
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseButtonDoubleClick(struct FGeometry InMyGeometry, struct FPointerEvent& InMouseEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnMotionDetected
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnMotionDetected(struct FGeometry MyGeometry, struct FMotionEvent InMotionEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x140)

	// Object Name: Function UMG.UserWidget.OnKeyUp
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x130)

	// Object Name: Function UMG.UserWidget.OnKeyDown
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x130)

	// Object Name: Function UMG.UserWidget.OnKeyChar
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnKeyChar(struct FGeometry MyGeometry, struct FCharacterEvent InCharacterEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x118)

	// Object Name: Function UMG.UserWidget.OnFocusReceived
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xf8)

	// Object Name: Function UMG.UserWidget.OnFocusLost
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnFocusLost(struct FFocusEvent InFocusEvent); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.OnDrop
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	bool OnDrop(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0xb9)

	// Object Name: Function UMG.UserWidget.OnDragOver
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	bool OnDragOver(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0xb9)

	// Object Name: Function UMG.UserWidget.OnDragLeave
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnDragLeave(struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x80)

	// Object Name: Function UMG.UserWidget.OnDragEnter
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnDragEnter(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xb8)

	// Object Name: Function UMG.UserWidget.OnDragDetected
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnDragDetected(struct FGeometry MyGeometry, struct FPointerEvent& PointerEvent, struct UDragDropOperation*& Operation); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xb8)

	// Object Name: Function UMG.UserWidget.OnDragCancelled
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnDragCancelled(struct FPointerEvent& PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x80)

	// Object Name: Function UMG.UserWidget.OnAnimationStarted
	// Flags: [BlueprintCosmetic|Native|Event|Public|BlueprintEvent]
	void OnAnimationStarted(struct UWidgetAnimation* Animation); // Offset: 0x10463d5d4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.OnAnimationFinished
	// Flags: [BlueprintCosmetic|Native|Event|Public|BlueprintEvent]
	void OnAnimationFinished(struct UWidgetAnimation* Animation); // Offset: 0x10463d550 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.OnAnalogValueChanged
	// Flags: [Event|Public|BlueprintEvent]
	struct FEventReply OnAnalogValueChanged(struct FGeometry MyGeometry, struct FAnalogInputEvent InAnalogInputEvent); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x138)

	// Object Name: Function UMG.UserWidget.OnAddedToFocusPath
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnAddedToFocusPath(struct FFocusEvent InFocusEvent); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.ListenForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void ListenForInputAction(struct FName ActionName, enum class EInputEvent EventType, bool bConsume, DelegateProperty Callback); // Offset: 0x10463d3f4 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function UMG.UserWidget.IsPlayingAnimation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlayingAnimation(); // Offset: 0x10463d3d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.IsListeningForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	bool IsListeningForInputAction(struct FName ActionName); // Offset: 0x10463d344 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.IsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInViewport(); // Offset: 0x10463d310 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.IsInteractable
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent|Const]
	bool IsInteractable(); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.IsAnyAnimationPlaying
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsAnyAnimationPlaying(); // Offset: 0x10463d2dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.IsAnimationPlayingForward
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	bool IsAnimationPlayingForward(struct UWidgetAnimation* InAnimation); // Offset: 0x10463d250 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.IsAnimationPlaying
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsAnimationPlaying(struct UWidgetAnimation* InAnimation); // Offset: 0x10463d1c4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.GetWidgetFromName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	struct UWidget* GetWidgetFromName(struct FName& Name); // Offset: 0x10463d128 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.UserWidget.GetOwningPlayerPawn
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APawn* GetOwningPlayerPawn(); // Offset: 0x10463d0f4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.GetOwningPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APlayerController* GetOwningPlayer(); // Offset: 0x10463d0b8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.GetOwningLocalPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULocalPlayer* GetOwningLocalPlayer(); // Offset: 0x10463d084 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.GetIsVisible
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsVisible(); // Offset: 0x10463d050 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x10463d01c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.GetAnimationCurrentTime
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAnimationCurrentTime(struct UWidgetAnimation* InAnimation); // Offset: 0x10463cf90 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.UserWidget.GetAnchorsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FAnchors GetAnchorsInViewport(); // Offset: 0x10463cf50 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UserWidget.GetAlignmentInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetAlignmentInViewport(); // Offset: 0x10463cf18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Destruct(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.AddToViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void AddToViewport(int ZOrder); // Offset: 0x10463ce9c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UserWidget.AddToPlayerScreen
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	bool AddToPlayerScreen(int ZOrder); // Offset: 0x10463ce10 // Return & Params: Num(2) Size(0x5)
};

// Object Name: Class UMG.PanelWidget
// Size: 0x118 // Inherited bytes: 0x100
struct UPanelWidget : UWidget {
	// Fields
	struct TArray<struct UPanelSlot*> Slots; // Offset: 0x100 // Size: 0x10
	char pad_0x110[0x8]; // Offset: 0x110 // Size: 0x08

	// Functions

	// Object Name: Function UMG.PanelWidget.RemoveChildAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveChildAt(int Index); // Offset: 0x10462f768 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function UMG.PanelWidget.RemoveChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveChild(struct UWidget* Content); // Offset: 0x10462f6dc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.PanelWidget.HasChild
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasChild(struct UWidget* Content); // Offset: 0x10462f650 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.PanelWidget.HasAnyChildren
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasAnyChildren(); // Offset: 0x10462f61c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.PanelWidget.GetChildrenCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetChildrenCount(); // Offset: 0x10462f5e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.PanelWidget.GetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetChildIndex(struct UWidget* Content); // Offset: 0x10462f55c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.PanelWidget.GetChildAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetChildAt(int Index); // Offset: 0x10462f4d0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.PanelWidget.ClearChildren
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearChildren(); // Offset: 0x10462f4bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.PanelWidget.AddChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UPanelSlot* AddChild(struct UWidget* Content); // Offset: 0x10462f430 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.CanvasPanel
// Size: 0x130 // Inherited bytes: 0x118
struct UCanvasPanel : UPanelWidget {
	// Fields
	char pad_0x118[0x10]; // Offset: 0x118 // Size: 0x10
	bool bDontPaintWhenChildEmpty; // Offset: 0x128 // Size: 0x01
	char pad_0x129[0x7]; // Offset: 0x129 // Size: 0x07

	// Functions

	// Object Name: Function UMG.CanvasPanel.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x104624ad0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CanvasPanel.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x104624a9c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CanvasPanel.AddChildToCanvas
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UCanvasPanelSlot* AddChildToCanvas(struct UWidget* Content); // Offset: 0x104624a10 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.ScrollBox
// Size: 0xb28 // Inherited bytes: 0x118
struct UScrollBox : UPanelWidget {
	// Fields
	struct FScrollBoxStyle WidgetStyle; // Offset: 0x118 // Size: 0x2e8
	struct FScrollBarStyle WidgetBarStyle; // Offset: 0x400 // Size: 0x680
	struct USlateWidgetStyleAsset* Style; // Offset: 0xa80 // Size: 0x08
	struct USlateWidgetStyleAsset* BarStyle; // Offset: 0xa88 // Size: 0x08
	enum class EOrientation Orientation; // Offset: 0xa90 // Size: 0x01
	enum class ESlateVisibility ScrollBarVisibility; // Offset: 0xa91 // Size: 0x01
	enum class EConsumeMouseWheel ConsumeMouseWheel; // Offset: 0xa92 // Size: 0x01
	char pad_0xA93[0x1]; // Offset: 0xa93 // Size: 0x01
	struct FVector2D ScrollbarThickness; // Offset: 0xa94 // Size: 0x08
	bool AlwaysShowScrollbar; // Offset: 0xa9c // Size: 0x01
	bool AllowOverscroll; // Offset: 0xa9d // Size: 0x01
	enum class EDescendantScrollDestination NavigationDestination; // Offset: 0xa9e // Size: 0x01
	char pad_0xA9F[0x1]; // Offset: 0xa9f // Size: 0x01
	float NavigationScrollPadding; // Offset: 0xaa0 // Size: 0x04
	float EdgePadding; // Offset: 0xaa4 // Size: 0x04
	bool bAllowRightClickDragScrolling; // Offset: 0xaa8 // Size: 0x01
	bool bDontPaintWhenChildEmpty; // Offset: 0xaa9 // Size: 0x01
	char pad_0xAAA[0x6]; // Offset: 0xaaa // Size: 0x06
	struct FScriptMulticastDelegate OnUserScrolled; // Offset: 0xab0 // Size: 0x10
	struct FScriptMulticastDelegate OnUserScrolledUnused; // Offset: 0xac0 // Size: 0x10
	struct FScriptMulticastDelegate OnBeginScroll; // Offset: 0xad0 // Size: 0x10
	struct FScriptMulticastDelegate OnEndScroll; // Offset: 0xae0 // Size: 0x10
	struct FScriptMulticastDelegate OnTouchStartEvent; // Offset: 0xaf0 // Size: 0x10
	struct FScriptMulticastDelegate OnTouchEndEvent; // Offset: 0xb00 // Size: 0x10
	char pad_0xB10[0x18]; // Offset: 0xb10 // Size: 0x18

	// Functions

	// Object Name: Function UMG.ScrollBox.StopScroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopScroll(); // Offset: 0x104633734 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ScrollBox.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollOffset(float NewScrollOffset); // Offset: 0x1046336b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScrollBox.SetScrollBarVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollBarVisibility(enum class ESlateVisibility NewScrollBarVisibility); // Offset: 0x10463363c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetScrollbarThickness
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetScrollbarThickness(struct FVector2D& NewScrollbarThickness); // Offset: 0x1046335b4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.ScrollBox.SetOrientation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOrientation(enum class EOrientation NewOrientation); // Offset: 0x104633538 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x1046334b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetAlwaysShowScrollbar
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAlwaysShowScrollbar(bool NewAlwaysShowScrollbar); // Offset: 0x104633430 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetAllowOverscroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllowOverscroll(bool NewAllowOverscroll); // Offset: 0x1046333ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.ScrollWidgetIntoView
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollWidgetIntoView(struct UWidget* WidgetToFind, bool AnimateScroll, enum class EDescendantScrollDestination ScrollDestination); // Offset: 0x1046332a8 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function UMG.ScrollBox.ScrollToStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToStart(); // Offset: 0x104633294 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ScrollBox.ScrollToEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToEnd(); // Offset: 0x104633280 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ScrollBox.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScrollOffset(); // Offset: 0x10463324c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScrollBox.GetScrollEndOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScrollEndOffset(); // Offset: 0x104633218 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScrollBox.GetIsScrolling
	// Flags: [Final|Native|Public]
	bool GetIsScrolling(); // Offset: 0x1046331f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x1046331bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.GetCacheOverscrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetCacheOverscrollOffset(); // Offset: 0x104633188 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.ComboBoxString
// Size: 0x1050 // Inherited bytes: 0x100
struct UComboBoxString : UWidget {
	// Fields
	struct TArray<struct FString> DefaultOptions; // Offset: 0x100 // Size: 0x10
	struct FString SelectedOption; // Offset: 0x110 // Size: 0x10
	struct FComboBoxStyle WidgetStyle; // Offset: 0x120 // Size: 0x4f8
	struct FTableRowStyle ItemStyle; // Offset: 0x618 // Size: 0x8f8
	struct FMargin ContentPadding; // Offset: 0xf10 // Size: 0x10
	float MaxListHeight; // Offset: 0xf20 // Size: 0x04
	bool HasDownArrow; // Offset: 0xf24 // Size: 0x01
	bool EnableGamepadNavigationMode; // Offset: 0xf25 // Size: 0x01
	char pad_0xF26[0x2]; // Offset: 0xf26 // Size: 0x02
	struct FSlateFontInfo Font; // Offset: 0xf28 // Size: 0x58
	struct FSlateColor ForegroundColor; // Offset: 0xf80 // Size: 0x28
	bool bIsFocusable; // Offset: 0xfa8 // Size: 0x01
	char pad_0xFA9[0x7]; // Offset: 0xfa9 // Size: 0x07
	DelegateProperty OnGenerateWidgetEvent; // Offset: 0xfb0 // Size: 0x10
	char pad_0xFC0[0x20]; // Offset: 0xfc0 // Size: 0x20
	struct FScriptMulticastDelegate OnSelectionChanged; // Offset: 0xfe0 // Size: 0x10
	struct FScriptMulticastDelegate OnOpening; // Offset: 0xff0 // Size: 0x10
	char pad_0x1000[0x50]; // Offset: 0x1000 // Size: 0x50

	// Functions

	// Object Name: Function UMG.ComboBoxString.SetSelectedOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSelectedOption(struct FString Option); // Offset: 0x104626cb8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ComboBoxString.RemoveOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveOption(struct FString Option); // Offset: 0x104626c10 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UMG.ComboBoxString.RefreshOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshOptions(); // Offset: 0x104626bfc // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction UMG.ComboBoxString.OnSelectionChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSelectionChangedEvent__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x11)

	// Object Name: DelegateFunction UMG.ComboBoxString.OnOpeningEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnOpeningEvent__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ComboBoxString.GetSelectedOption
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSelectedOption(); // Offset: 0x104626b98 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ComboBoxString.GetOptionCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetOptionCount(); // Offset: 0x104626b64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ComboBoxString.GetOptionAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetOptionAtIndex(int Index); // Offset: 0x104626ab0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UMG.ComboBoxString.FindOptionIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int FindOptionIndex(struct FString Option); // Offset: 0x104626a08 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function UMG.ComboBoxString.CloseComboBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseComboBox(); // Offset: 0x1046269f4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ComboBoxString.ClearSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearSelection(); // Offset: 0x1046269e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ComboBoxString.ClearOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearOptions(); // Offset: 0x1046269cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ComboBoxString.AddOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddOption(struct FString Option); // Offset: 0x104626934 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.PanelSlot
// Size: 0x38 // Inherited bytes: 0x28
struct UPanelSlot : UVisual {
	// Fields
	struct UPanelWidget* Parent; // Offset: 0x28 // Size: 0x08
	struct UWidget* Content; // Offset: 0x30 // Size: 0x08
};

// Object Name: Class UMG.WidgetComponent
// Size: 0x890 // Inherited bytes: 0x730
struct UWidgetComponent : UMeshComponent {
	// Fields
	bool bAntialiased; // Offset: 0x725 // Size: 0x01
	float RTScale; // Offset: 0x728 // Size: 0x04
	enum class EWidgetSpace Space; // Offset: 0x72c // Size: 0x01
	enum class EWidgetTimingPolicy TimingPolicy; // Offset: 0x72d // Size: 0x01
	struct UUserWidget* WidgetClass; // Offset: 0x730 // Size: 0x08
	struct FIntPoint DrawSize; // Offset: 0x738 // Size: 0x08
	bool bManuallyRedraw; // Offset: 0x740 // Size: 0x01
	bool bRedrawRequested; // Offset: 0x741 // Size: 0x01
	float RedrawTime; // Offset: 0x744 // Size: 0x04
	char pad_0x74D[0x3]; // Offset: 0x74d // Size: 0x03
	struct FIntPoint CurrentDrawSize; // Offset: 0x750 // Size: 0x08
	char pad_0x758[0x4]; // Offset: 0x758 // Size: 0x04
	bool bDrawAtDesiredSize; // Offset: 0x75c // Size: 0x01
	char pad_0x75D[0x3]; // Offset: 0x75d // Size: 0x03
	struct FVector2D Pivot; // Offset: 0x760 // Size: 0x08
	bool bReceiveHardwareInput; // Offset: 0x768 // Size: 0x01
	bool bWindowFocusable; // Offset: 0x769 // Size: 0x01
	char pad_0x76A[0x6]; // Offset: 0x76a // Size: 0x06
	struct ULocalPlayer* OwnerPlayer; // Offset: 0x770 // Size: 0x08
	struct FLinearColor BackgroundColor; // Offset: 0x778 // Size: 0x10
	struct FLinearColor TintColorAndOpacity; // Offset: 0x788 // Size: 0x10
	float OpacityFromTexture; // Offset: 0x798 // Size: 0x04
	enum class EWidgetBlendMode BlendMode; // Offset: 0x79c // Size: 0x01
	bool bIsTwoSided; // Offset: 0x79d // Size: 0x01
	bool TickWhenOffscreen; // Offset: 0x79e // Size: 0x01
	char pad_0x79F[0x1]; // Offset: 0x79f // Size: 0x01
	struct UUserWidget* Widget; // Offset: 0x7a0 // Size: 0x08
	char pad_0x7A8[0x20]; // Offset: 0x7a8 // Size: 0x20
	struct UBodySetup* BodySetup; // Offset: 0x7c8 // Size: 0x08
	struct UMaterialInterface* TranslucentMaterialAA; // Offset: 0x7d0 // Size: 0x08
	struct UMaterialInterface* TranslucentMaterialAA_OneSided; // Offset: 0x7d8 // Size: 0x08
	struct UMaterialInterface* TranslucentMaterial; // Offset: 0x7e0 // Size: 0x08
	struct UMaterialInterface* TranslucentMaterial_OneSided; // Offset: 0x7e8 // Size: 0x08
	struct UMaterialInterface* OpaqueMaterial; // Offset: 0x7f0 // Size: 0x08
	struct UMaterialInterface* OpaqueMaterial_OneSided; // Offset: 0x7f8 // Size: 0x08
	struct UMaterialInterface* MaskedMaterial; // Offset: 0x800 // Size: 0x08
	struct UMaterialInterface* MaskedMaterial_OneSided; // Offset: 0x808 // Size: 0x08
	struct UTextureRenderTarget2D* RenderTarget; // Offset: 0x810 // Size: 0x08
	struct UMaterialInstanceDynamic* MaterialInstance; // Offset: 0x818 // Size: 0x08
	bool bAddedToScreen; // Offset: 0x820 // Size: 0x01
	bool bEditTimeUsable; // Offset: 0x821 // Size: 0x01
	char pad_0x822[0x6]; // Offset: 0x822 // Size: 0x06
	struct FName SharedLayerName; // Offset: 0x828 // Size: 0x08
	int LayerZOrder; // Offset: 0x830 // Size: 0x04
	enum class EWidgetGeometryMode GeometryMode; // Offset: 0x834 // Size: 0x01
	char pad_0x835[0x3]; // Offset: 0x835 // Size: 0x03
	float CylinderArcAngle; // Offset: 0x838 // Size: 0x04
	char pad_0x83C[0x54]; // Offset: 0x83c // Size: 0x54

	// Functions

	// Object Name: Function UMG.WidgetComponent.SetWidget
	// Flags: [Native|Public|BlueprintCallable]
	void SetWidget(struct UUserWidget* Widget); // Offset: 0x10464928c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.SetTintColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetTintColorAndOpacity(struct FLinearColor NewTintColorAndOpacity); // Offset: 0x104649210 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WidgetComponent.SetOwnerPlayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOwnerPlayer(struct ULocalPlayer* LocalPlayer); // Offset: 0x104649194 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.SetDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetDrawSize(struct FVector2D Size); // Offset: 0x10464911c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBackgroundColor(struct FLinearColor NewBackgroundColor); // Offset: 0x1046490a0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WidgetComponent.RequestRedraw
	// Flags: [Native|Public|BlueprintCallable]
	void RequestRedraw(); // Offset: 0x104649084 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WidgetComponent.GetUserWidgetObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUserWidget* GetUserWidgetObject(); // Offset: 0x104649050 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetRenderTarget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UTextureRenderTarget2D* GetRenderTarget(); // Offset: 0x10464901c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetOwnerPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULocalPlayer* GetOwnerPlayer(); // Offset: 0x104648fe8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetMaterialInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetMaterialInstance(); // Offset: 0x104648fb4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetDrawSize(); // Offset: 0x104648f7c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.Slider
// Size: 0x498 // Inherited bytes: 0x100
struct USlider : UWidget {
	// Fields
	float Value; // Offset: 0x100 // Size: 0x04
	char pad_0x104[0x4]; // Offset: 0x104 // Size: 0x04
	DelegateProperty ValueDelegate; // Offset: 0x108 // Size: 0x10
	struct FSliderStyle WidgetStyle; // Offset: 0x118 // Size: 0x2f0
	enum class EOrientation Orientation; // Offset: 0x408 // Size: 0x01
	char pad_0x409[0x3]; // Offset: 0x409 // Size: 0x03
	struct FLinearColor SliderBarColor; // Offset: 0x40c // Size: 0x10
	struct FLinearColor SliderHandleColor; // Offset: 0x41c // Size: 0x10
	bool IndentHandle; // Offset: 0x42c // Size: 0x01
	bool Locked; // Offset: 0x42d // Size: 0x01
	char pad_0x42E[0x2]; // Offset: 0x42e // Size: 0x02
	float StepSize; // Offset: 0x430 // Size: 0x04
	bool IsFocusable; // Offset: 0x434 // Size: 0x01
	char pad_0x435[0x3]; // Offset: 0x435 // Size: 0x03
	struct FScriptMulticastDelegate OnMouseCaptureBegin; // Offset: 0x438 // Size: 0x10
	struct FScriptMulticastDelegate OnMouseCaptureEnd; // Offset: 0x448 // Size: 0x10
	struct FScriptMulticastDelegate OnControllerCaptureBegin; // Offset: 0x458 // Size: 0x10
	struct FScriptMulticastDelegate OnControllerCaptureEnd; // Offset: 0x468 // Size: 0x10
	struct FScriptMulticastDelegate OnValueChanged; // Offset: 0x478 // Size: 0x10
	char pad_0x488[0x10]; // Offset: 0x488 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Slider.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetValue(float InValue); // Offset: 0x10463681c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Slider.SetStepSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStepSize(float InValue); // Offset: 0x1046367a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Slider.SetSliderHandleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSliderHandleColor(struct FLinearColor InValue); // Offset: 0x104636724 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Slider.SetSliderBarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSliderBarColor(struct FLinearColor InValue); // Offset: 0x1046366a8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Slider.SetLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLocked(bool InValue); // Offset: 0x104636624 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Slider.SetIndentHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIndentHandle(bool InValue); // Offset: 0x1046365a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Slider.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetValue(); // Offset: 0x10463656c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.ContentWidget
// Size: 0x118 // Inherited bytes: 0x118
struct UContentWidget : UPanelWidget {
	// Functions

	// Object Name: Function UMG.ContentWidget.SetContent
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UPanelSlot* SetContent(struct UWidget* Content); // Offset: 0x10462719c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.ContentWidget.GetContentSlot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UPanelSlot* GetContentSlot(); // Offset: 0x104627168 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.ContentWidget.GetContent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetContent(); // Offset: 0x104627134 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.Button
// Size: 0x518 // Inherited bytes: 0x118
struct UButton : UContentWidget {
	// Fields
	struct USlateWidgetStyleAsset* Style; // Offset: 0x118 // Size: 0x08
	struct FButtonStyle WidgetStyle; // Offset: 0x120 // Size: 0x338
	struct FLinearColor ColorAndOpacity; // Offset: 0x458 // Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0x468 // Size: 0x10
	enum class EButtonClickMethod ClickMethod; // Offset: 0x478 // Size: 0x01
	enum class EButtonTouchMethod TouchMethod; // Offset: 0x479 // Size: 0x01
	bool IsFocusable; // Offset: 0x47a // Size: 0x01
	bool IsPassMouseEvent; // Offset: 0x47b // Size: 0x01
	float nClickCd; // Offset: 0x47c // Size: 0x04
	bool bTouchPass; // Offset: 0x480 // Size: 0x01
	char pad_0x481[0x7]; // Offset: 0x481 // Size: 0x07
	struct FScriptMulticastDelegate OnClicked; // Offset: 0x488 // Size: 0x10
	struct FScriptMulticastDelegate OnPressed; // Offset: 0x498 // Size: 0x10
	struct FScriptMulticastDelegate OnReleased; // Offset: 0x4a8 // Size: 0x10
	struct FScriptMulticastDelegate OnHovered; // Offset: 0x4b8 // Size: 0x10
	struct FScriptMulticastDelegate OnUnhovered; // Offset: 0x4c8 // Size: 0x10
	struct FScriptMulticastDelegate OnPressedParam; // Offset: 0x4d8 // Size: 0x10
	DelegateProperty OnMouseButtonDownEvent; // Offset: 0x4e8 // Size: 0x10
	enum class EButtonOnClickSound OnClickSoundType; // Offset: 0x4f8 // Size: 0x01
	char pad_0x4F9[0x1f]; // Offset: 0x4f9 // Size: 0x1f

	// Functions

	// Object Name: Function UMG.Button.SetTouchMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod); // Offset: 0x104624304 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Button.SetStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetStyle(struct FButtonStyle& InStyle); // Offset: 0x104624250 // Return & Params: Num(1) Size(0x338)

	// Object Name: Function UMG.Button.SetOnClickSound
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetOnClickSound(DelegateProperty onSound); // Offset: 0x1046241c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Button.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Offset: 0x10462414c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Button.SetClickSoundType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickSoundType(enum class EButtonOnClickSound onSoundType); // Offset: 0x1046240d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Button.SetClickMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickMethod(enum class EButtonClickMethod InClickMethod); // Offset: 0x104624054 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Button.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBackgroundColor(struct FLinearColor InBackgroundColor); // Offset: 0x104623fd8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Button.Release
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Release(); // Offset: 0x104623fc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction UMG.Button.OnButtonSoundEvent__DelegateSignature
	// Flags: [Public|Delegate]
	void OnButtonSoundEvent__DelegateSignature(char Sound); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Button.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPressed(); // Offset: 0x104623f90 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.AsyncTaskDownloadImage
// Size: 0x48 // Inherited bytes: 0x28
struct UAsyncTaskDownloadImage : UBlueprintAsyncActionBase {
	// Fields
	struct FScriptMulticastDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnFail; // Offset: 0x38 // Size: 0x10

	// Functions

	// Object Name: Function UMG.AsyncTaskDownloadImage.DownloadImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAsyncTaskDownloadImage* DownloadImage(struct FString URL); // Offset: 0x104621c64 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class UMG.BackgroundBlur
// Size: 0x2c8 // Inherited bytes: 0x118
struct UBackgroundBlur : UContentWidget {
	// Fields
	struct FMargin Padding; // Offset: 0x114 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x124 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x125 // Size: 0x01
	bool bApplyAlphaToBlur; // Offset: 0x126 // Size: 0x01
	float BlurStrength; // Offset: 0x128 // Size: 0x04
	bool bOverrideAutoRadiusCalculation; // Offset: 0x12c // Size: 0x01
	enum class EBlurType BlurType; // Offset: 0x12d // Size: 0x01
	float BlurDirection; // Offset: 0x130 // Size: 0x04
	struct FVector2D BlurCenter; // Offset: 0x134 // Size: 0x08
	int BlurRadius; // Offset: 0x13c // Size: 0x04
	struct UTexture* BlurMask; // Offset: 0x140 // Size: 0x08
	struct FSlateBrush LowQualityFallbackBrush; // Offset: 0x148 // Size: 0xb8
	struct FSlateBrush BlurMaskBrush; // Offset: 0x200 // Size: 0xb8
	char pad_0x2B9[0xf]; // Offset: 0x2b9 // Size: 0x0f

	// Functions

	// Object Name: Function UMG.BackgroundBlur.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x104622314 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.BackgroundBlur.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x104622294 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.BackgroundBlur.SetLowQualityFallbackBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetLowQualityFallbackBrush(struct FSlateBrush& InBrush); // Offset: 0x1046221e8 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.BackgroundBlur.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10462216c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.BackgroundBlur.SetBlurStrength
	// Flags: [Native|Public|BlueprintCallable]
	void SetBlurStrength(float InStrength); // Offset: 0x1046220e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.BackgroundBlur.SetBlurRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBlurRadius(int InBlurRadius); // Offset: 0x10462206c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.BackgroundBlur.SetBlurMask
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBlurMask(struct UTexture* InTexture); // Offset: 0x104621ff0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.BackgroundBlur.SetBlurDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBlurDirection(float InDirection); // Offset: 0x104621f74 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.BackgroundBlur.SetBlurCenter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBlurCenter(struct FVector2D InCenter); // Offset: 0x104621efc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.BackgroundBlur.SetApplyAlphaToBlur
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetApplyAlphaToBlur(bool bInApplyAlphaToBlur); // Offset: 0x104621e78 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.BackgroundBlurSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UBackgroundBlurSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.BackgroundBlurSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x104622884 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.BackgroundBlurSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x104622804 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.BackgroundBlurSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104622788 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.PropertyBinding
// Size: 0x48 // Inherited bytes: 0x28
struct UPropertyBinding : UObject {
	// Fields
	struct TWeakObjectPtr<struct UObject> SourceObject; // Offset: 0x28 // Size: 0x08
	struct FDynamicPropertyPath SourcePath; // Offset: 0x30 // Size: 0x10
	struct FName DestinationProperty; // Offset: 0x40 // Size: 0x08
};

// Object Name: Class UMG.BoolBinding
// Size: 0x48 // Inherited bytes: 0x48
struct UBoolBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.BoolBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	bool GetValue(); // Offset: 0x104622ad4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.Border
// Size: 0x290 // Inherited bytes: 0x118
struct UBorder : UContentWidget {
	// Fields
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x111 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x112 // Size: 0x01
	char bShowEffectWhenDisabled : 1; // Offset: 0x113 // Size: 0x01
	struct FLinearColor ContentColorAndOpacity; // Offset: 0x114 // Size: 0x10
	DelegateProperty ContentColorAndOpacityDelegate; // Offset: 0x128 // Size: 0x10
	struct FMargin Padding; // Offset: 0x138 // Size: 0x10
	struct FSlateBrush Background; // Offset: 0x148 // Size: 0xb8
	DelegateProperty BackgroundDelegate; // Offset: 0x200 // Size: 0x10
	struct FLinearColor BrushColor; // Offset: 0x210 // Size: 0x10
	DelegateProperty BrushColorDelegate; // Offset: 0x220 // Size: 0x10
	struct FVector2D DesiredSizeScale; // Offset: 0x230 // Size: 0x08
	DelegateProperty OnMouseButtonDownEvent; // Offset: 0x238 // Size: 0x10
	DelegateProperty OnMouseButtonUpEvent; // Offset: 0x248 // Size: 0x10
	DelegateProperty OnMouseMoveEvent; // Offset: 0x258 // Size: 0x10
	DelegateProperty OnMouseDoubleClickEvent; // Offset: 0x268 // Size: 0x10
	bool bDontPaintWhenChildEmpty; // Offset: 0x278 // Size: 0x01
	bool bDontPaintWhenAlphaZero; // Offset: 0x279 // Size: 0x01
	char pad_0x27C_1 : 7; // Offset: 0x27c // Size: 0x01
	char pad_0x27D[0x13]; // Offset: 0x27d // Size: 0x13

	// Functions

	// Object Name: Function UMG.Border.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10462329c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Border.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x10462321c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Border.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1046231a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Border.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x10462311c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Border.SetDontPaintWhenAlphaZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenAlphaZero(bool Enable); // Offset: 0x104623098 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Border.SetDesiredSizeScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetDesiredSizeScale(struct FVector2D InScale); // Offset: 0x104623020 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.SetContentColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetContentColorAndOpacity(struct FLinearColor InContentColorAndOpacity); // Offset: 0x104622fa4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Border.SetBrushFromTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromTexture(struct UTexture2D* Texture); // Offset: 0x104622f28 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.SetBrushFromMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromMaterial(struct UMaterialInterface* Material); // Offset: 0x104622eac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.SetBrushFromAsset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromAsset(struct USlateBrushAsset* Asset); // Offset: 0x104622e30 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.SetBrushColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBrushColor(struct FLinearColor InBrushColor); // Offset: 0x104622db4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Border.SetBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBrush(struct FSlateBrush& InBrush); // Offset: 0x104622d08 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.Border.GetDynamicMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMaterialInstanceDynamic* GetDynamicMaterial(); // Offset: 0x104622cd4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x104622ca0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Border.GetDontPaintWhenAlphaZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenAlphaZero(); // Offset: 0x104622c6c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.BorderSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UBorderSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.BorderSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x104623944 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.BorderSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1046238c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.BorderSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104623848 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.BrushBinding
// Size: 0x50 // Inherited bytes: 0x48
struct UBrushBinding : UPropertyBinding {
	// Fields
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08

	// Functions

	// Object Name: Function UMG.BrushBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	struct FSlateBrush GetValue(); // Offset: 0x104623b98 // Return & Params: Num(1) Size(0xb8)
};

// Object Name: Class UMG.ButtonSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UButtonSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.ButtonSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1046247c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ButtonSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x104624744 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ButtonSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1046246c8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.CanvasPanelSlot
// Size: 0x70 // Inherited bytes: 0x38
struct UCanvasPanelSlot : UPanelSlot {
	// Fields
	struct FAnchorData LayoutData; // Offset: 0x38 // Size: 0x28
	bool bAutoSize; // Offset: 0x60 // Size: 0x01
	bool bSupportNotch; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x2]; // Offset: 0x62 // Size: 0x02
	int ZOrder; // Offset: 0x64 // Size: 0x04
	char pad_0x68[0x8]; // Offset: 0x68 // Size: 0x08

	// Functions

	// Object Name: Function UMG.CanvasPanelSlot.SetZOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetZOrder(int InZOrder); // Offset: 0x104625518 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.CanvasPanelSlot.SetSupportNotch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSupportNotch(bool InSupportNotch); // Offset: 0x104625494 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CanvasPanelSlot.SetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSize(struct FVector2D InSize); // Offset: 0x10462541c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.SetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetPosition(struct FVector2D InPosition); // Offset: 0x1046253a4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.SetOffsets
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOffsets(struct FMargin InOffset); // Offset: 0x104625324 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.CanvasPanelSlot.SetMinimum
	// Flags: [Final|Native|Public|HasDefaults]
	void SetMinimum(struct FVector2D InMinimumAnchors); // Offset: 0x1046252ac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.SetMaximum
	// Flags: [Final|Native|Public|HasDefaults]
	void SetMaximum(struct FVector2D InMaximumAnchors); // Offset: 0x104625234 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.SetLayout
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetLayout(struct FAnchorData& InLayoutData); // Offset: 0x1046251a4 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.CanvasPanelSlot.SetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoSize(bool InbAutoSize); // Offset: 0x104625120 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CanvasPanelSlot.SetAnchors
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnchors(struct FAnchors InAnchors); // Offset: 0x1046250a0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.CanvasPanelSlot.SetAlignment
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetAlignment(struct FVector2D InAlignment); // Offset: 0x104625028 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.GetZOrder
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetZOrder(); // Offset: 0x104624ff4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.CanvasPanelSlot.GetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetSize(); // Offset: 0x104624fbc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.GetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetPosition(); // Offset: 0x104624f84 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.GetOffsets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FMargin GetOffsets(); // Offset: 0x104624f44 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.CanvasPanelSlot.GetLayout
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FAnchorData GetLayout(); // Offset: 0x104624ef4 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.CanvasPanelSlot.GetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetAutoSize(); // Offset: 0x104624ec0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CanvasPanelSlot.GetAnchors
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FAnchors GetAnchors(); // Offset: 0x104624e80 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.CanvasPanelSlot.GetAlignment
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetAlignment(); // Offset: 0x104624e48 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.GeSupportNotch
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GeSupportNotch(); // Offset: 0x104624e14 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.CheckBox
// Size: 0x910 // Inherited bytes: 0x118
struct UCheckBox : UContentWidget {
	// Fields
	enum class ECheckBoxState CheckedState; // Offset: 0x111 // Size: 0x01
	DelegateProperty CheckedStateDelegate; // Offset: 0x118 // Size: 0x10
	struct FCheckBoxStyle WidgetStyle; // Offset: 0x128 // Size: 0x730
	struct USlateWidgetStyleAsset* Style; // Offset: 0x858 // Size: 0x08
	struct USlateBrushAsset* UncheckedImage; // Offset: 0x860 // Size: 0x08
	struct USlateBrushAsset* UncheckedHoveredImage; // Offset: 0x868 // Size: 0x08
	struct USlateBrushAsset* UncheckedPressedImage; // Offset: 0x870 // Size: 0x08
	struct USlateBrushAsset* CheckedImage; // Offset: 0x878 // Size: 0x08
	struct USlateBrushAsset* CheckedHoveredImage; // Offset: 0x880 // Size: 0x08
	struct USlateBrushAsset* CheckedPressedImage; // Offset: 0x888 // Size: 0x08
	struct USlateBrushAsset* UndeterminedImage; // Offset: 0x890 // Size: 0x08
	struct USlateBrushAsset* UndeterminedHoveredImage; // Offset: 0x898 // Size: 0x08
	struct USlateBrushAsset* UndeterminedPressedImage; // Offset: 0x8a0 // Size: 0x08
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x8a8 // Size: 0x01
	char pad_0x8AA[0x2]; // Offset: 0x8aa // Size: 0x02
	struct FMargin Padding; // Offset: 0x8ac // Size: 0x10
	char pad_0x8BC[0x4]; // Offset: 0x8bc // Size: 0x04
	struct FSlateColor BorderBackgroundColor; // Offset: 0x8c0 // Size: 0x28
	bool IsFocusable; // Offset: 0x8e8 // Size: 0x01
	char pad_0x8E9[0x7]; // Offset: 0x8e9 // Size: 0x07
	struct FScriptMulticastDelegate OnCheckStateChanged; // Offset: 0x8f0 // Size: 0x10
	char pad_0x900[0x10]; // Offset: 0x900 // Size: 0x10

	// Functions

	// Object Name: Function UMG.CheckBox.SetIsChecked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsChecked(bool InIsChecked); // Offset: 0x104625d54 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.SetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCheckedState(enum class ECheckBoxState InCheckedState); // Offset: 0x104625cd8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPressed(); // Offset: 0x104625ca4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.IsChecked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsChecked(); // Offset: 0x104625c70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.GetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECheckBoxState GetCheckedState(); // Offset: 0x104625c3c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.CheckedStateBinding
// Size: 0x50 // Inherited bytes: 0x48
struct UCheckedStateBinding : UPropertyBinding {
	// Fields
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08

	// Functions

	// Object Name: Function UMG.CheckedStateBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	enum class ECheckBoxState GetValue(); // Offset: 0x10462605c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.CircularThrobber
// Size: 0x1e8 // Inherited bytes: 0x100
struct UCircularThrobber : UWidget {
	// Fields
	int NumberOfPieces; // Offset: 0x100 // Size: 0x04
	float Period; // Offset: 0x104 // Size: 0x04
	float Radius; // Offset: 0x108 // Size: 0x04
	char pad_0x10C[0x4]; // Offset: 0x10c // Size: 0x04
	struct USlateBrushAsset* PieceImage; // Offset: 0x110 // Size: 0x08
	struct FSlateBrush Image; // Offset: 0x118 // Size: 0xb8
	bool bEnableRadius; // Offset: 0x1d0 // Size: 0x01
	char pad_0x1D1[0x17]; // Offset: 0x1d1 // Size: 0x17

	// Functions

	// Object Name: Function UMG.CircularThrobber.SetRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRadius(float InRadius); // Offset: 0x1046262dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.CircularThrobber.SetPeriod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPeriod(float InPeriod); // Offset: 0x104626260 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.CircularThrobber.SetNumberOfPieces
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNumberOfPieces(int InNumberOfPieces); // Offset: 0x1046261e4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.ColorBinding
// Size: 0x50 // Inherited bytes: 0x48
struct UColorBinding : UPropertyBinding {
	// Fields
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08

	// Functions

	// Object Name: Function UMG.ColorBinding.GetSlateValue
	// Flags: [Final|Native|Public|Const]
	struct FSlateColor GetSlateValue(); // Offset: 0x104626578 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.ColorBinding.GetLinearValue
	// Flags: [Final|Native|Public|HasDefaults|Const]
	struct FLinearColor GetLinearValue(); // Offset: 0x104626538 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.ComboBox
// Size: 0x138 // Inherited bytes: 0x100
struct UComboBox : UWidget {
	// Fields
	struct TArray<struct UObject*> Items; // Offset: 0x100 // Size: 0x10
	DelegateProperty OnGenerateWidgetEvent; // Offset: 0x110 // Size: 0x10
	bool bIsFocusable; // Offset: 0x120 // Size: 0x01
	char pad_0x121[0x17]; // Offset: 0x121 // Size: 0x17
};

// Object Name: Class UMG.DragDropOperation
// Size: 0x88 // Inherited bytes: 0x28
struct UDragDropOperation : UObject {
	// Fields
	struct FString Tag; // Offset: 0x28 // Size: 0x10
	struct UObject* Payload; // Offset: 0x38 // Size: 0x08
	struct UWidget* DefaultDragVisual; // Offset: 0x40 // Size: 0x08
	enum class EDragPivot Pivot; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	struct FVector2D Offset; // Offset: 0x4c // Size: 0x08
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FScriptMulticastDelegate OnDrop; // Offset: 0x58 // Size: 0x10
	struct FScriptMulticastDelegate OnDragCancelled; // Offset: 0x68 // Size: 0x10
	struct FScriptMulticastDelegate OnDragged; // Offset: 0x78 // Size: 0x10

	// Functions

	// Object Name: Function UMG.DragDropOperation.Drop
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void Drop(struct FPointerEvent& PointerEvent); // Offset: 0x1046278ac // Return & Params: Num(1) Size(0x78)

	// Object Name: Function UMG.DragDropOperation.Dragged
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void Dragged(struct FPointerEvent& PointerEvent); // Offset: 0x1046277b4 // Return & Params: Num(1) Size(0x78)

	// Object Name: Function UMG.DragDropOperation.DragCancelled
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void DragCancelled(struct FPointerEvent& PointerEvent); // Offset: 0x1046276bc // Return & Params: Num(1) Size(0x78)
};

// Object Name: Class UMG.EditableText
// Size: 0x4e8 // Inherited bytes: 0x100
struct UEditableText : UWidget {
	// Fields
	struct FText Text; // Offset: 0x100 // Size: 0x18
	DelegateProperty TextDelegate; // Offset: 0x118 // Size: 0x10
	struct FText HintText; // Offset: 0x128 // Size: 0x18
	DelegateProperty HintTextDelegate; // Offset: 0x140 // Size: 0x10
	struct FEditableTextStyle WidgetStyle; // Offset: 0x150 // Size: 0x2b0
	struct USlateWidgetStyleAsset* Style; // Offset: 0x400 // Size: 0x08
	struct USlateBrushAsset* BackgroundImageSelected; // Offset: 0x408 // Size: 0x08
	struct USlateBrushAsset* BackgroundImageComposing; // Offset: 0x410 // Size: 0x08
	struct USlateBrushAsset* CaretImage; // Offset: 0x418 // Size: 0x08
	struct FSlateFontInfo Font; // Offset: 0x420 // Size: 0x58
	struct FSlateColor ColorAndOpacity; // Offset: 0x478 // Size: 0x28
	bool IsReadOnly; // Offset: 0x4a0 // Size: 0x01
	bool IsPassword; // Offset: 0x4a1 // Size: 0x01
	char pad_0x4A2[0x2]; // Offset: 0x4a2 // Size: 0x02
	float MinimumDesiredWidth; // Offset: 0x4a4 // Size: 0x04
	bool IsCaretMovedWhenGainFocus; // Offset: 0x4a8 // Size: 0x01
	bool SelectAllTextWhenFocused; // Offset: 0x4a9 // Size: 0x01
	bool RevertTextOnEscape; // Offset: 0x4aa // Size: 0x01
	bool ClearKeyboardFocusOnCommit; // Offset: 0x4ab // Size: 0x01
	bool SelectAllTextOnCommit; // Offset: 0x4ac // Size: 0x01
	bool AllowContextMenu; // Offset: 0x4ad // Size: 0x01
	enum class EVirtualKeyboardType KeyboardType; // Offset: 0x4ae // Size: 0x01
	char pad_0x4AF[0x1]; // Offset: 0x4af // Size: 0x01
	struct FShapedTextOptions ShapedTextOptions; // Offset: 0x4b0 // Size: 0x04
	char pad_0x4B4[0x4]; // Offset: 0x4b4 // Size: 0x04
	struct FScriptMulticastDelegate OnTextChanged; // Offset: 0x4b8 // Size: 0x10
	struct FScriptMulticastDelegate OnTextCommitted; // Offset: 0x4c8 // Size: 0x10
	char pad_0x4D8[0x10]; // Offset: 0x4d8 // Size: 0x10

	// Functions

	// Object Name: Function UMG.EditableText.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x104627fdc // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableText.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReadOnly(bool InbIsReadyOnly); // Offset: 0x104627f58 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableText.SetIsPassword
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsPassword(bool InbIsPassword); // Offset: 0x104627ed4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableText.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHintText(struct FText InHintText); // Offset: 0x104627e14 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.EditableText.OnEditableTextCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x19)

	// Object Name: DelegateFunction UMG.EditableText.OnEditableTextChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnEditableTextChangedEvent__DelegateSignature(struct FText& Text); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableText.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x104627db0 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UMG.EditableTextBox
// Size: 0xca0 // Inherited bytes: 0x100
struct UEditableTextBox : UWidget {
	// Fields
	struct FText Text; // Offset: 0x100 // Size: 0x18
	DelegateProperty TextDelegate; // Offset: 0x118 // Size: 0x10
	struct FEditableTextBoxStyle WidgetStyle; // Offset: 0x128 // Size: 0xa68
	struct USlateWidgetStyleAsset* Style; // Offset: 0xb90 // Size: 0x08
	struct FText HintText; // Offset: 0xb98 // Size: 0x18
	DelegateProperty HintTextDelegate; // Offset: 0xbb0 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0xbc0 // Size: 0x58
	struct FLinearColor ForegroundColor; // Offset: 0xc18 // Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0xc28 // Size: 0x10
	struct FLinearColor ReadOnlyForegroundColor; // Offset: 0xc38 // Size: 0x10
	bool IsReadOnly; // Offset: 0xc48 // Size: 0x01
	bool IsPassword; // Offset: 0xc49 // Size: 0x01
	char pad_0xC4A[0x2]; // Offset: 0xc4a // Size: 0x02
	float MinimumDesiredWidth; // Offset: 0xc4c // Size: 0x04
	struct FMargin Padding; // Offset: 0xc50 // Size: 0x10
	bool IsCaretMovedWhenGainFocus; // Offset: 0xc60 // Size: 0x01
	bool SelectAllTextWhenFocused; // Offset: 0xc61 // Size: 0x01
	bool RevertTextOnEscape; // Offset: 0xc62 // Size: 0x01
	bool ClearKeyboardFocusOnCommit; // Offset: 0xc63 // Size: 0x01
	bool SelectAllTextOnCommit; // Offset: 0xc64 // Size: 0x01
	bool AllowContextMenu; // Offset: 0xc65 // Size: 0x01
	enum class EVirtualKeyboardType KeyboardType; // Offset: 0xc66 // Size: 0x01
	char pad_0xC67[0x1]; // Offset: 0xc67 // Size: 0x01
	struct FShapedTextOptions ShapedTextOptions; // Offset: 0xc68 // Size: 0x04
	char pad_0xC6C[0x4]; // Offset: 0xc6c // Size: 0x04
	struct FScriptMulticastDelegate OnTextChanged; // Offset: 0xc70 // Size: 0x10
	struct FScriptMulticastDelegate OnTextCommitted; // Offset: 0xc80 // Size: 0x10
	char pad_0xC90[0x10]; // Offset: 0xc90 // Size: 0x10

	// Functions

	// Object Name: Function UMG.EditableTextBox.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x104629b34 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableTextBox.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReadOnly(bool bReadOnly); // Offset: 0x104629ab0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableTextBox.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHintText(struct FText InText); // Offset: 0x1046299f0 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableTextBox.SetError
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetError(struct FText InError); // Offset: 0x104629930 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.EditableTextBox.OnEditableTextBoxCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x19)

	// Object Name: DelegateFunction UMG.EditableTextBox.OnEditableTextBoxChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableTextBox.HasError
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasError(); // Offset: 0x1046298fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableTextBox.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x104629898 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableTextBox.ClearError
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearError(); // Offset: 0x104629884 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.ExpandableArea
// Size: 0x3c0 // Inherited bytes: 0x100
struct UExpandableArea : UWidget {
	// Fields
	char pad_0x100[0x8]; // Offset: 0x100 // Size: 0x08
	struct FExpandableAreaStyle Style; // Offset: 0x108 // Size: 0x180
	struct FSlateBrush BorderBrush; // Offset: 0x288 // Size: 0xb8
	struct FSlateColor BorderColor; // Offset: 0x340 // Size: 0x28
	bool bIsExpanded; // Offset: 0x368 // Size: 0x01
	char pad_0x369[0x3]; // Offset: 0x369 // Size: 0x03
	float MaxHeight; // Offset: 0x36c // Size: 0x04
	struct FMargin HeaderPadding; // Offset: 0x370 // Size: 0x10
	struct FMargin AreaPadding; // Offset: 0x380 // Size: 0x10
	struct FScriptMulticastDelegate OnExpansionChanged; // Offset: 0x390 // Size: 0x10
	struct UWidget* HeaderContent; // Offset: 0x3a0 // Size: 0x08
	struct UWidget* BodyContent; // Offset: 0x3a8 // Size: 0x08
	char pad_0x3B0[0x10]; // Offset: 0x3b0 // Size: 0x10

	// Functions

	// Object Name: Function UMG.ExpandableArea.SetIsExpanded_Animated
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsExpanded_Animated(bool IsExpanded); // Offset: 0x10462a008 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ExpandableArea.SetIsExpanded
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsExpanded(bool IsExpanded); // Offset: 0x104629f84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ExpandableArea.GetIsExpanded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsExpanded(); // Offset: 0x104629f50 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.FloatBinding
// Size: 0x48 // Inherited bytes: 0x48
struct UFloatBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.FloatBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	float GetValue(); // Offset: 0x10462a294 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.GridPanel
// Size: 0x150 // Inherited bytes: 0x118
struct UGridPanel : UPanelWidget {
	// Fields
	struct TArray<float> ColumnFill; // Offset: 0x118 // Size: 0x10
	struct TArray<float> RowFill; // Offset: 0x128 // Size: 0x10
	bool bDontPaintWhenChildEmpty; // Offset: 0x138 // Size: 0x01
	char pad_0x139[0x17]; // Offset: 0x139 // Size: 0x17

	// Functions

	// Object Name: Function UMG.GridPanel.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x10462a4dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.GridPanel.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x10462a4a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.GridPanel.AddChildToGrid
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UGridSlot* AddChildToGrid(struct UWidget* Content); // Offset: 0x10462a41c // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.GridSlot
// Size: 0x70 // Inherited bytes: 0x38
struct UGridSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x2]; // Offset: 0x4a // Size: 0x02
	int Row; // Offset: 0x4c // Size: 0x04
	int RowSpan; // Offset: 0x50 // Size: 0x04
	int Column; // Offset: 0x54 // Size: 0x04
	int ColumnSpan; // Offset: 0x58 // Size: 0x04
	int Layer; // Offset: 0x5c // Size: 0x04
	struct FVector2D Nudge; // Offset: 0x60 // Size: 0x08
	char pad_0x68[0x8]; // Offset: 0x68 // Size: 0x08

	// Functions

	// Object Name: Function UMG.GridSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10462ab08 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.GridSlot.SetRowSpan
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRowSpan(int InRowSpan); // Offset: 0x10462aa8c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.GridSlot.SetRow
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRow(int InRow); // Offset: 0x10462aa10 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.GridSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x10462a990 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.GridSlot.SetLayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLayer(int InLayer); // Offset: 0x10462a914 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.GridSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10462a898 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.GridSlot.SetColumnSpan
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColumnSpan(int InColumnSpan); // Offset: 0x10462a81c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.GridSlot.SetColumn
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColumn(int InColumn); // Offset: 0x10462a7a0 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.HorizontalBox
// Size: 0x128 // Inherited bytes: 0x118
struct UHorizontalBox : UPanelWidget {
	// Fields
	bool bDontPaintWhenChildEmpty; // Offset: 0x111 // Size: 0x01
	char pad_0x119[0xf]; // Offset: 0x119 // Size: 0x0f

	// Functions

	// Object Name: Function UMG.HorizontalBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x10462af98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.HorizontalBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x10462af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.HorizontalBox.AddChildToHorizontalBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UHorizontalBoxSlot* AddChildToHorizontalBox(struct UWidget* Content); // Offset: 0x10462aed8 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.HorizontalBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UHorizontalBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	struct FSlateChildSize Size; // Offset: 0x48 // Size: 0x08
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x50 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0xe]; // Offset: 0x52 // Size: 0x0e

	// Functions

	// Object Name: Function UMG.HorizontalBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10462b3b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.HorizontalBoxSlot.SetSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSize(struct FSlateChildSize InSize); // Offset: 0x10462b318 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.HorizontalBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x10462b298 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.HorizontalBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10462b21c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.Image
// Size: 0x248 // Inherited bytes: 0x100
struct UImage : UWidget {
	// Fields
	bool bIsEnhancedImage; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x7]; // Offset: 0x101 // Size: 0x07
	struct FSlateBrush Brush; // Offset: 0x108 // Size: 0xb8
	DelegateProperty BrushDelegate; // Offset: 0x1c0 // Size: 0x10
	struct FLinearColor ColorAndOpacity; // Offset: 0x1d0 // Size: 0x10
	DelegateProperty ColorAndOpacityDelegate; // Offset: 0x1e0 // Size: 0x10
	bool bIsUseEnhancedHitTest; // Offset: 0x1f0 // Size: 0x01
	bool bVersionImg; // Offset: 0x1f1 // Size: 0x01
	char pad_0x1F2[0x6]; // Offset: 0x1f2 // Size: 0x06
	struct FString imageSrcPath; // Offset: 0x1f8 // Size: 0x10
	float HitTestAreaRadius; // Offset: 0x208 // Size: 0x04
	bool bFixOverScale; // Offset: 0x20c // Size: 0x01
	char pad_0x20D[0x3]; // Offset: 0x20d // Size: 0x03
	DelegateProperty OnMouseButtonDownEvent; // Offset: 0x210 // Size: 0x10
	bool bDontPaintWhenAlphaZero; // Offset: 0x220 // Size: 0x01
	bool bDontPaintWhenColorZero; // Offset: 0x221 // Size: 0x01
	char pad_0x222[0x26]; // Offset: 0x222 // Size: 0x26

	// Functions

	// Object Name: Function UMG.Image.SetOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOpacity(float InOpacity); // Offset: 0x10462bdd0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Image.SetDontPaintWhenColorZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenColorZero(bool Enable); // Offset: 0x10462bd4c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Image.SetDontPaintWhenAlphaZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenAlphaZero(bool Enable); // Offset: 0x10462bcc8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Image.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Offset: 0x10462bc4c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Image.SetBrushFromTextureDynamic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromTextureDynamic(struct UTexture2DDynamic* Texture, bool bMatchSize); // Offset: 0x10462bb8c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.Image.SetBrushFromTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromTexture(struct UTexture2D* Texture, bool bMatchSize); // Offset: 0x10462bacc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.Image.SetBrushFromPathAsync
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromPathAsync(struct FString ResourcePath, bool bMatchSize); // Offset: 0x10462b9ec // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UMG.Image.SetBrushFromMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromMaterial(struct UMaterialInterface* Material); // Offset: 0x10462b970 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Image.SetBrushFromAtlasInterface
	// Flags: [Native|Public|BlueprintCallable]
	void SetBrushFromAtlasInterface(struct TScriptInterface<Class> AtlasRegion, bool bMatchSize); // Offset: 0x10462b888 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UMG.Image.SetBrushFromAsset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromAsset(struct USlateBrushAsset* Asset); // Offset: 0x10462b80c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Image.SetBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBrush(struct FSlateBrush& InBrush); // Offset: 0x10462b760 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.Image.SeFixOverScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SeFixOverScale(bool Enable); // Offset: 0x10462b6dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Image.GetDynamicMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMaterialInstanceDynamic* GetDynamicMaterial(); // Offset: 0x10462b6a8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Image.GetDontPaintWhenColorZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenColorZero(); // Offset: 0x10462b674 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Image.GetDontPaintWhenAlphaZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenAlphaZero(); // Offset: 0x10462b640 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.InputKeySelector
// Size: 0x798 // Inherited bytes: 0x100
struct UInputKeySelector : UWidget {
	// Fields
	struct FButtonStyle WidgetStyle; // Offset: 0x100 // Size: 0x338
	struct FTextBlockStyle TextStyle; // Offset: 0x438 // Size: 0x250
	struct FInputChord SelectedKey; // Offset: 0x688 // Size: 0x20
	struct FSlateFontInfo Font; // Offset: 0x6a8 // Size: 0x58
	struct FMargin Margin; // Offset: 0x700 // Size: 0x10
	struct FLinearColor ColorAndOpacity; // Offset: 0x710 // Size: 0x10
	struct FText KeySelectionText; // Offset: 0x720 // Size: 0x18
	struct FText NoKeySpecifiedText; // Offset: 0x738 // Size: 0x18
	bool bAllowModifierKeys; // Offset: 0x750 // Size: 0x01
	bool bAllowGamepadKeys; // Offset: 0x751 // Size: 0x01
	char pad_0x752[0x6]; // Offset: 0x752 // Size: 0x06
	struct TArray<struct FKey> EscapeKeys; // Offset: 0x758 // Size: 0x10
	struct FScriptMulticastDelegate OnKeySelected; // Offset: 0x768 // Size: 0x10
	struct FScriptMulticastDelegate OnIsSelectingKeyChanged; // Offset: 0x778 // Size: 0x10
	char pad_0x788[0x10]; // Offset: 0x788 // Size: 0x10

	// Functions

	// Object Name: Function UMG.InputKeySelector.SetTextBlockVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTextBlockVisibility(enum class ESlateVisibility InVisibility); // Offset: 0x10462c810 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InputKeySelector.SetSelectedKey
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSelectedKey(struct FInputChord& InSelectedKey); // Offset: 0x10462c754 // Return & Params: Num(1) Size(0x20)

	// Object Name: Function UMG.InputKeySelector.SetNoKeySpecifiedText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNoKeySpecifiedText(struct FText InNoKeySpecifiedText); // Offset: 0x10462c694 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.InputKeySelector.SetKeySelectionText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetKeySelectionText(struct FText InKeySelectionText); // Offset: 0x10462c5d4 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.InputKeySelector.SetAllowModifierKeys
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllowModifierKeys(bool bInAllowModifierKeys); // Offset: 0x10462c550 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InputKeySelector.SetAllowGamepadKeys
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllowGamepadKeys(bool bInAllowGamepadKeys); // Offset: 0x10462c4cc // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.InputKeySelector.OnKeySelected__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x20)

	// Object Name: DelegateFunction UMG.InputKeySelector.OnIsSelectingKeyChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnIsSelectingKeyChanged__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.InputKeySelector.GetIsSelectingKey
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsSelectingKey(); // Offset: 0x10462c498 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.Int32Binding
// Size: 0x48 // Inherited bytes: 0x48
struct UInt32Binding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.Int32Binding.GetValue
	// Flags: [Final|Native|Public|Const]
	int GetValue(); // Offset: 0x10462cb5c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.InvalidationBox
// Size: 0x128 // Inherited bytes: 0x118
struct UInvalidationBox : UContentWidget {
	// Fields
	bool bCanCache; // Offset: 0x111 // Size: 0x01
	bool CacheRelativeTransforms; // Offset: 0x112 // Size: 0x01
	bool bDontPaintWhenChildEmpty; // Offset: 0x113 // Size: 0x01
	char pad_0x11B[0xd]; // Offset: 0x11b // Size: 0x0d

	// Functions

	// Object Name: Function UMG.InvalidationBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x10462cde4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InvalidationBox.SetCanCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCanCache(bool CanCache); // Offset: 0x10462cd60 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InvalidationBox.InvalidateCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InvalidateCache(); // Offset: 0x10462cd4c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.InvalidationBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x10462cd18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InvalidationBox.GetCanCache
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetCanCache(); // Offset: 0x10462cce4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.TableViewBase
// Size: 0x100 // Inherited bytes: 0x100
struct UTableViewBase : UWidget {
};

// Object Name: Class UMG.ListView
// Size: 0x140 // Inherited bytes: 0x100
struct UListView : UTableViewBase {
	// Fields
	float ItemHeight; // Offset: 0x100 // Size: 0x04
	char pad_0x104[0x4]; // Offset: 0x104 // Size: 0x04
	struct TArray<struct UObject*> Items; // Offset: 0x108 // Size: 0x10
	enum class ESelectionMode SelectionMode; // Offset: 0x118 // Size: 0x01
	char pad_0x119[0x7]; // Offset: 0x119 // Size: 0x07
	DelegateProperty OnGenerateRowEvent; // Offset: 0x120 // Size: 0x10
	char pad_0x130[0x10]; // Offset: 0x130 // Size: 0x10
};

// Object Name: Class UMG.MenuAnchor
// Size: 0x158 // Inherited bytes: 0x118
struct UMenuAnchor : UContentWidget {
	// Fields
	struct UUserWidget* MenuClass; // Offset: 0x118 // Size: 0x08
	DelegateProperty OnGetMenuContentEvent; // Offset: 0x120 // Size: 0x10
	enum class EMenuPlacement Placement; // Offset: 0x130 // Size: 0x01
	bool ShouldDeferPaintingAfterWindowContent; // Offset: 0x131 // Size: 0x01
	bool UseApplicationMenuStack; // Offset: 0x132 // Size: 0x01
	char pad_0x133[0x5]; // Offset: 0x133 // Size: 0x05
	struct FScriptMulticastDelegate OnMenuOpenChanged; // Offset: 0x138 // Size: 0x10
	char pad_0x148[0x10]; // Offset: 0x148 // Size: 0x10

	// Functions

	// Object Name: Function UMG.MenuAnchor.ToggleOpen
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ToggleOpen(bool bFocusOnOpen); // Offset: 0x10462d3c8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.ShouldOpenDueToClick
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool ShouldOpenDueToClick(); // Offset: 0x10462d394 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.Open
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Open(bool bFocusMenu); // Offset: 0x10462d310 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.IsOpen
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOpen(); // Offset: 0x10462d2dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.HasOpenSubMenus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasOpenSubMenus(); // Offset: 0x10462d2a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.GetMenuPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetMenuPosition(); // Offset: 0x10462d270 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.MenuAnchor.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Close(); // Offset: 0x10462d25c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.MouseCursorBinding
// Size: 0x48 // Inherited bytes: 0x48
struct UMouseCursorBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.MouseCursorBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	enum class EMouseCursor GetValue(); // Offset: 0x10462d774 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.MovieScene2DTransformSection
// Size: 0x3c8 // Inherited bytes: 0xb0
struct UMovieScene2DTransformSection : UMovieSceneSection {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
	struct FRichCurve Translation[0x2]; // Offset: 0xb8 // Size: 0xe0
	struct FRichCurve Rotation; // Offset: 0x198 // Size: 0x70
	struct FRichCurve Scale[0x2]; // Offset: 0x208 // Size: 0xe0
	struct FRichCurve Shear[0x2]; // Offset: 0x2e8 // Size: 0xe0
};

// Object Name: Class UMG.MovieScene2DTransformTrack
// Size: 0x80 // Inherited bytes: 0x80
struct UMovieScene2DTransformTrack : UMovieScenePropertyTrack {
};

// Object Name: Class UMG.MovieSceneMarginSection
// Size: 0x278 // Inherited bytes: 0xb0
struct UMovieSceneMarginSection : UMovieSceneSection {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
	struct FRichCurve TopCurve; // Offset: 0xb8 // Size: 0x70
	struct FRichCurve LeftCurve; // Offset: 0x128 // Size: 0x70
	struct FRichCurve RightCurve; // Offset: 0x198 // Size: 0x70
	struct FRichCurve BottomCurve; // Offset: 0x208 // Size: 0x70
};

// Object Name: Class UMG.MovieSceneMarginTrack
// Size: 0x80 // Inherited bytes: 0x80
struct UMovieSceneMarginTrack : UMovieScenePropertyTrack {
};

// Object Name: Class UMG.MovieSceneWidgetMaterialTrack
// Size: 0x80 // Inherited bytes: 0x68
struct UMovieSceneWidgetMaterialTrack : UMovieSceneMaterialTrack {
	// Fields
	struct TArray<struct FName> BrushPropertyNamePath; // Offset: 0x68 // Size: 0x10
	struct FName TrackName; // Offset: 0x78 // Size: 0x08
};

// Object Name: Class UMG.TextLayoutWidget
// Size: 0x128 // Inherited bytes: 0x100
struct UTextLayoutWidget : UWidget {
	// Fields
	struct FShapedTextOptions ShapedTextOptions; // Offset: 0x100 // Size: 0x04
	enum class ETextJustify Justification; // Offset: 0x104 // Size: 0x01
	enum class ETextVerticalJustify VerticalJustification; // Offset: 0x105 // Size: 0x01
	bool AutoWrapText; // Offset: 0x106 // Size: 0x01
	char pad_0x107[0x1]; // Offset: 0x107 // Size: 0x01
	float WrapTextAt; // Offset: 0x108 // Size: 0x04
	enum class ETextWrappingPolicy WrappingPolicy; // Offset: 0x10c // Size: 0x01
	char pad_0x10D[0x3]; // Offset: 0x10d // Size: 0x03
	struct FMargin Margin; // Offset: 0x110 // Size: 0x10
	float LineHeightPercentage; // Offset: 0x120 // Size: 0x04
	char pad_0x124[0x4]; // Offset: 0x124 // Size: 0x04
};

// Object Name: Class UMG.MultiLineEditableText
// Size: 0x450 // Inherited bytes: 0x128
struct UMultiLineEditableText : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x128 // Size: 0x18
	struct FText HintText; // Offset: 0x140 // Size: 0x18
	DelegateProperty HintTextDelegate; // Offset: 0x158 // Size: 0x10
	struct FTextBlockStyle WidgetStyle; // Offset: 0x168 // Size: 0x250
	bool bIsReadOnly; // Offset: 0x3b8 // Size: 0x01
	char pad_0x3B9[0x7]; // Offset: 0x3b9 // Size: 0x07
	struct FSlateFontInfo Font; // Offset: 0x3c0 // Size: 0x58
	bool AllowContextMenu; // Offset: 0x418 // Size: 0x01
	char pad_0x419[0x7]; // Offset: 0x419 // Size: 0x07
	struct FScriptMulticastDelegate OnTextChanged; // Offset: 0x420 // Size: 0x10
	struct FScriptMulticastDelegate OnTextCommitted; // Offset: 0x430 // Size: 0x10
	char pad_0x440[0x10]; // Offset: 0x440 // Size: 0x10

	// Functions

	// Object Name: Function UMG.MultiLineEditableText.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x10462e27c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableText.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReadOnly(bool bReadOnly); // Offset: 0x10462e1f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MultiLineEditableText.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHintText(struct FText InText); // Offset: 0x10462e138 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.MultiLineEditableText.OnMultiLineEditableTextCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMultiLineEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x19)

	// Object Name: DelegateFunction UMG.MultiLineEditableText.OnMultiLineEditableTextChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMultiLineEditableTextChangedEvent__DelegateSignature(struct FText& Text); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableText.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x10462e0d4 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UMG.MultiLineEditableTextBox
// Size: 0xee8 // Inherited bytes: 0x128
struct UMultiLineEditableTextBox : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x128 // Size: 0x18
	struct FText HintText; // Offset: 0x140 // Size: 0x18
	DelegateProperty HintTextDelegate; // Offset: 0x158 // Size: 0x10
	struct FEditableTextBoxStyle WidgetStyle; // Offset: 0x168 // Size: 0xa68
	struct FTextBlockStyle TextStyle; // Offset: 0xbd0 // Size: 0x250
	bool bIsReadOnly; // Offset: 0xe20 // Size: 0x01
	bool AllowContextMenu; // Offset: 0xe21 // Size: 0x01
	char pad_0xE22[0x6]; // Offset: 0xe22 // Size: 0x06
	struct USlateWidgetStyleAsset* Style; // Offset: 0xe28 // Size: 0x08
	struct FSlateFontInfo Font; // Offset: 0xe30 // Size: 0x58
	struct FLinearColor ForegroundColor; // Offset: 0xe88 // Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0xe98 // Size: 0x10
	struct FLinearColor ReadOnlyForegroundColor; // Offset: 0xea8 // Size: 0x10
	struct FScriptMulticastDelegate OnTextChanged; // Offset: 0xeb8 // Size: 0x10
	struct FScriptMulticastDelegate OnTextCommitted; // Offset: 0xec8 // Size: 0x10
	char pad_0xED8[0x10]; // Offset: 0xed8 // Size: 0x10

	// Functions

	// Object Name: Function UMG.MultiLineEditableTextBox.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x10462e860 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableTextBox.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReadOnly(bool bReadOnly); // Offset: 0x10462e7dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MultiLineEditableTextBox.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHintText(struct FText InText); // Offset: 0x10462e71c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableTextBox.SetError
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetError(struct FText InError); // Offset: 0x10462e65c // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.MultiLineEditableTextBox.OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x19)

	// Object Name: DelegateFunction UMG.MultiLineEditableTextBox.OnMultiLineEditableTextBoxChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMultiLineEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableTextBox.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x10462e5f8 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UMG.NamedSlot
// Size: 0x128 // Inherited bytes: 0x118
struct UNamedSlot : UContentWidget {
	// Fields
	char pad_0x118[0x10]; // Offset: 0x118 // Size: 0x10
};

// Object Name: Class UMG.NamedSlotInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UNamedSlotInterface : UInterface {
};

// Object Name: Class UMG.NativeWidgetHost
// Size: 0x110 // Inherited bytes: 0x100
struct UNativeWidgetHost : UWidget {
	// Fields
	char pad_0x100[0x10]; // Offset: 0x100 // Size: 0x10
};

// Object Name: Class UMG.Overlay
// Size: 0x128 // Inherited bytes: 0x118
struct UOverlay : UPanelWidget {
	// Fields
	char pad_0x118[0x10]; // Offset: 0x118 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Overlay.AddChildToOverlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UOverlaySlot* AddChildToOverlay(struct UWidget* Content); // Offset: 0x10462ee44 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.OverlaySlot
// Size: 0x58 // Inherited bytes: 0x38
struct UOverlaySlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0xe]; // Offset: 0x4a // Size: 0x0e

	// Functions

	// Object Name: Function UMG.OverlaySlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10462f124 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.OverlaySlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x10462f0a4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.OverlaySlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10462f028 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.ProgressBar
// Size: 0x3a0 // Inherited bytes: 0x100
struct UProgressBar : UWidget {
	// Fields
	struct FProgressBarStyle WidgetStyle; // Offset: 0x100 // Size: 0x230
	struct USlateWidgetStyleAsset* Style; // Offset: 0x330 // Size: 0x08
	struct USlateBrushAsset* BackgroundImage; // Offset: 0x338 // Size: 0x08
	struct USlateBrushAsset* FillImage; // Offset: 0x340 // Size: 0x08
	struct USlateBrushAsset* MarqueeImage; // Offset: 0x348 // Size: 0x08
	float percent; // Offset: 0x350 // Size: 0x04
	enum class EProgressBarFillType BarFillType; // Offset: 0x354 // Size: 0x01
	bool bIsMarquee; // Offset: 0x355 // Size: 0x01
	char pad_0x356[0x2]; // Offset: 0x356 // Size: 0x02
	struct FVector2D BorderPadding; // Offset: 0x358 // Size: 0x08
	DelegateProperty PercentDelegate; // Offset: 0x360 // Size: 0x10
	struct FLinearColor FillColorAndOpacity; // Offset: 0x370 // Size: 0x10
	DelegateProperty FillColorAndOpacityDelegate; // Offset: 0x380 // Size: 0x10
	char pad_0x390[0x10]; // Offset: 0x390 // Size: 0x10

	// Functions

	// Object Name: Function UMG.ProgressBar.SetPercent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPercent(float InPercent); // Offset: 0x104631908 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ProgressBar.SetIsMarquee
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsMarquee(bool InbIsMarquee); // Offset: 0x104631884 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ProgressBar.SetFillColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetFillColorAndOpacity(struct FLinearColor InColor); // Offset: 0x104631808 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.RetainerBox
// Size: 0x140 // Inherited bytes: 0x118
struct URetainerBox : UContentWidget {
	// Fields
	bool RenderOnInvalidation; // Offset: 0x111 // Size: 0x01
	bool RenderOnPhase; // Offset: 0x112 // Size: 0x01
	int Phase; // Offset: 0x114 // Size: 0x04
	int PhaseCount; // Offset: 0x118 // Size: 0x04
	struct UMaterialInterface* EffectMaterial; // Offset: 0x120 // Size: 0x08
	struct FName TextureParameter; // Offset: 0x128 // Size: 0x08
	char pad_0x132[0xe]; // Offset: 0x132 // Size: 0x0e

	// Functions

	// Object Name: Function UMG.RetainerBox.SkipCurrentFrameRender
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SkipCurrentFrameRender(); // Offset: 0x104631da0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.RetainerBox.SetTextureParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTextureParameter(struct FName TextureParameter); // Offset: 0x104631d24 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.RetainerBox.SetEffectMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEffectMaterial(struct UMaterialInterface* EffectMaterial); // Offset: 0x104631ca8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.RetainerBox.RequestRender
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RequestRender(); // Offset: 0x104631c94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.RetainerBox.GetEffectMaterial
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetEffectMaterial(); // Offset: 0x104631c60 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.RichTextBlock
// Size: 0x428 // Inherited bytes: 0x128
struct URichTextBlock : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x128 // Size: 0x18
	DelegateProperty TextDelegate; // Offset: 0x140 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x150 // Size: 0x58
	struct FLinearColor Color; // Offset: 0x1a8 // Size: 0x10
	struct TArray<struct URichTextBlockDecorator*> Decorators; // Offset: 0x1b8 // Size: 0x10
	char pad_0x1C8[0x260]; // Offset: 0x1c8 // Size: 0x260
};

// Object Name: Class UMG.RichTextBlockDecorator
// Size: 0x30 // Inherited bytes: 0x28
struct URichTextBlockDecorator : UObject {
	// Fields
	bool bReveal; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int RevealedIndex; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class UMG.SafeZone
// Size: 0x128 // Inherited bytes: 0x118
struct USafeZone : UContentWidget {
	// Fields
	bool PadLeft; // Offset: 0x111 // Size: 0x01
	bool PadRight; // Offset: 0x112 // Size: 0x01
	bool PadTop; // Offset: 0x113 // Size: 0x01
	bool PadBottom; // Offset: 0x114 // Size: 0x01
	char pad_0x11C[0xc]; // Offset: 0x11c // Size: 0x0c

	// Functions

	// Object Name: Function UMG.SafeZone.SetSidesToPad
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSidesToPad(bool InPadLeft, bool InPadRight, bool InPadTop, bool InPadBottom); // Offset: 0x104632218 // Return & Params: Num(4) Size(0x4)
};

// Object Name: Class UMG.SafeZoneSlot
// Size: 0x60 // Inherited bytes: 0x38
struct USafeZoneSlot : UPanelSlot {
	// Fields
	bool bIsTitleSafe; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	struct FMargin SafeAreaScale; // Offset: 0x3c // Size: 0x10
	enum class EHorizontalAlignment HAlign; // Offset: 0x4c // Size: 0x01
	enum class EVerticalAlignment VAlign; // Offset: 0x4d // Size: 0x01
	char pad_0x4E[0x2]; // Offset: 0x4e // Size: 0x02
	struct FMargin Padding; // Offset: 0x50 // Size: 0x10
};

// Object Name: Class UMG.ScaleBox
// Size: 0x130 // Inherited bytes: 0x118
struct UScaleBox : UContentWidget {
	// Fields
	enum class EStretch Stretch; // Offset: 0x111 // Size: 0x01
	enum class EStretchDirection StretchDirection; // Offset: 0x112 // Size: 0x01
	float UserSpecifiedScale; // Offset: 0x114 // Size: 0x04
	float UserSpecifiedScaleBias; // Offset: 0x118 // Size: 0x04
	bool IgnoreInheritedScale; // Offset: 0x11c // Size: 0x01
	bool bSingleLayoutPass; // Offset: 0x11d // Size: 0x01
	char pad_0x124[0xc]; // Offset: 0x124 // Size: 0x0c

	// Functions

	// Object Name: Function UMG.ScaleBox.SetUserSpecifiedScaleBias
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUserSpecifiedScaleBias(float InUserSpecifiedScaleBias); // Offset: 0x104632828 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScaleBox.SetUserSpecifiedScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUserSpecifiedScale(float InUserSpecifiedScale); // Offset: 0x1046327ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScaleBox.SetStretchDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStretchDirection(enum class EStretchDirection InStretchDirection); // Offset: 0x104632730 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScaleBox.SetStretch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStretch(enum class EStretch InStretch); // Offset: 0x1046326b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScaleBox.SetIgnoreInheritedScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIgnoreInheritedScale(bool bInIgnoreInheritedScale); // Offset: 0x104632630 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.ScaleBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UScaleBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.ScaleBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x104632c1c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScaleBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x104632b9c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ScaleBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104632b20 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.ScrollBar
// Size: 0x7a8 // Inherited bytes: 0x100
struct UScrollBar : UWidget {
	// Fields
	struct FScrollBarStyle WidgetStyle; // Offset: 0x100 // Size: 0x680
	struct USlateWidgetStyleAsset* Style; // Offset: 0x780 // Size: 0x08
	bool bAlwaysShowScrollbar; // Offset: 0x788 // Size: 0x01
	enum class EOrientation Orientation; // Offset: 0x789 // Size: 0x01
	char pad_0x78A[0x2]; // Offset: 0x78a // Size: 0x02
	struct FVector2D Thickness; // Offset: 0x78c // Size: 0x08
	char pad_0x794[0x14]; // Offset: 0x794 // Size: 0x14

	// Functions

	// Object Name: Function UMG.ScrollBar.SetState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetState(float InOffsetFraction, float InThumbSizeFraction); // Offset: 0x104632e6c // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class UMG.ScrollBoxSlot
// Size: 0x58 // Inherited bytes: 0x38
struct UScrollBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0xf]; // Offset: 0x49 // Size: 0x0f

	// Functions

	// Object Name: Function UMG.ScrollBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x104633d90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ScrollBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104633d14 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.ShareWidgetRT
// Size: 0x90 // Inherited bytes: 0x28
struct UShareWidgetRT : UObject {
	// Fields
	struct UTextureRenderTarget2D* RenderTarget; // Offset: 0x28 // Size: 0x08
	struct TSet<struct UObject*> AllSharedWidget; // Offset: 0x30 // Size: 0x50
	char pad_0x80[0x10]; // Offset: 0x80 // Size: 0x10
};

// Object Name: Class UMG.ShareWidgetRTManager
// Size: 0x428 // Inherited bytes: 0x3d8
struct AShareWidgetRTManager : AActor {
	// Fields
	struct TMap<struct UObject*, struct UShareWidgetRT*> SharedWidgetRTMap; // Offset: 0x3d8 // Size: 0x50
};

// Object Name: Class UMG.SizeBox
// Size: 0x140 // Inherited bytes: 0x118
struct USizeBox : UContentWidget {
	// Fields
	char bOverride_WidthOverride : 1; // Offset: 0x111 // Size: 0x01
	char bOverride_HeightOverride : 1; // Offset: 0x111 // Size: 0x01
	char bOverride_MinDesiredWidth : 1; // Offset: 0x111 // Size: 0x01
	char bOverride_MinDesiredHeight : 1; // Offset: 0x111 // Size: 0x01
	char bOverride_MaxDesiredWidth : 1; // Offset: 0x111 // Size: 0x01
	char bOverride_MaxDesiredHeight : 1; // Offset: 0x111 // Size: 0x01
	char bOverride_MaxAspectRatio : 1; // Offset: 0x111 // Size: 0x01
	char bDontPaintWhenChildEmpty : 1; // Offset: 0x111 // Size: 0x01
	float WidthOverride; // Offset: 0x114 // Size: 0x04
	float HeightOverride; // Offset: 0x118 // Size: 0x04
	float MinDesiredWidth; // Offset: 0x11c // Size: 0x04
	float MinDesiredHeight; // Offset: 0x120 // Size: 0x04
	float MaxDesiredWidth; // Offset: 0x124 // Size: 0x04
	float MaxDesiredHeight; // Offset: 0x128 // Size: 0x04
	float MaxAspectRatio; // Offset: 0x12c // Size: 0x04
	char pad_0x135[0xb]; // Offset: 0x135 // Size: 0x0b

	// Functions

	// Object Name: Function UMG.SizeBox.SetWidthOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWidthOverride(float InWidthOverride); // Offset: 0x1046345bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredWidth(float InMinDesiredWidth); // Offset: 0x104634540 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMinDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredHeight(float InMinDesiredHeight); // Offset: 0x1046344c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMaxDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxDesiredWidth(float InMaxDesiredWidth); // Offset: 0x104634448 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMaxDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxDesiredHeight(float InMaxDesiredHeight); // Offset: 0x1046343cc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMaxAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxAspectRatio(float InMaxAspectRatio); // Offset: 0x104634350 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetHeightOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHeightOverride(float InHeightOverride); // Offset: 0x1046342d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x104634250 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.SizeBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x10463421c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.SizeBox.ClearWidthOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearWidthOverride(); // Offset: 0x104634208 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinDesiredWidth(); // Offset: 0x1046341f4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMinDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinDesiredHeight(); // Offset: 0x1046341e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMaxDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxDesiredWidth(); // Offset: 0x1046341cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMaxDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxDesiredHeight(); // Offset: 0x1046341b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMaxAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxAspectRatio(); // Offset: 0x1046341a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearHeightOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearHeightOverride(); // Offset: 0x104634190 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.SizeBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct USizeBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.SizeBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x104634ce0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.SizeBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x104634c60 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.SizeBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104634be4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.SlateBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct USlateBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UMG.SlateBlueprintLibrary.ScreenToWidgetLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void ScreenToWidgetLocal(struct UObject* WorldContextObject, struct FGeometry& Geometry, struct FVector2D ScreenPosition, struct FVector2D& LocalCoordinate); // Offset: 0x104635950 // Return & Params: Num(4) Size(0x50)

	// Object Name: Function UMG.SlateBlueprintLibrary.ScreenToWidgetAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void ScreenToWidgetAbsolute(struct UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D& AbsoluteCoordinate); // Offset: 0x10463585c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function UMG.SlateBlueprintLibrary.ScreenToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void ScreenToViewport(struct UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D& ViewportPosition); // Offset: 0x104635768 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function UMG.SlateBlueprintLibrary.LocalToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void LocalToViewport(struct UObject* WorldContextObject, struct FGeometry& Geometry, struct FVector2D LocalCoordinate, struct FVector2D& PixelPosition, struct FVector2D& ViewportPosition); // Offset: 0x1046355d4 // Return & Params: Num(5) Size(0x58)

	// Object Name: Function UMG.SlateBlueprintLibrary.LocalToAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D LocalToAbsolute(struct FGeometry& Geometry, struct FVector2D LocalCoordinate); // Offset: 0x104635500 // Return & Params: Num(3) Size(0x48)

	// Object Name: Function UMG.SlateBlueprintLibrary.IsUnderLocation
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	bool IsUnderLocation(struct FGeometry& Geometry, struct FVector2D& AbsoluteCoordinate); // Offset: 0x104635420 // Return & Params: Num(3) Size(0x41)

	// Object Name: Function UMG.SlateBlueprintLibrary.GetLocalSize
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetLocalSize(struct FGeometry& Geometry); // Offset: 0x10463538c // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.SlateBlueprintLibrary.GetAbsoluteSize
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetAbsoluteSize(struct FGeometry& Geometry); // Offset: 0x1046352f8 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.SlateBlueprintLibrary.GetAbsolutePosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetAbsolutePosition(struct FGeometry& Geometry); // Offset: 0x104635264 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.SlateBlueprintLibrary.EqualEqual_SlateBrush
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool EqualEqual_SlateBrush(struct FSlateBrush& A, struct FSlateBrush& B); // Offset: 0x104635140 // Return & Params: Num(3) Size(0x171)

	// Object Name: Function UMG.SlateBlueprintLibrary.AbsoluteToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void AbsoluteToViewport(struct UObject* WorldContextObject, struct FVector2D AbsoluteDesktopCoordinate, struct FVector2D& PixelPosition, struct FVector2D& ViewportPosition); // Offset: 0x104635004 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function UMG.SlateBlueprintLibrary.AbsoluteToLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D AbsoluteToLocal(struct FGeometry& Geometry, struct FVector2D AbsoluteCoordinate); // Offset: 0x104634f30 // Return & Params: Num(3) Size(0x48)
};

// Object Name: Class UMG.SlateDataSheet
// Size: 0x430 // Inherited bytes: 0x28
struct USlateDataSheet : UObject {
	// Fields
	struct UTexture2D* DataTexture; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x400]; // Offset: 0x30 // Size: 0x400
};

// Object Name: Class UMG.SlateVectorArtData
// Size: 0x60 // Inherited bytes: 0x28
struct USlateVectorArtData : UObject {
	// Fields
	struct TArray<struct FSlateMeshVertex> VertexData; // Offset: 0x28 // Size: 0x10
	struct TArray<uint32_t> IndexData; // Offset: 0x38 // Size: 0x10
	struct UMaterialInterface* Material; // Offset: 0x48 // Size: 0x08
	struct FVector2D ExtentMin; // Offset: 0x50 // Size: 0x08
	struct FVector2D ExtentMax; // Offset: 0x58 // Size: 0x08
};

// Object Name: Class UMG.Spacer
// Size: 0x118 // Inherited bytes: 0x100
struct USpacer : UWidget {
	// Fields
	struct FVector2D Size; // Offset: 0x100 // Size: 0x08
	char pad_0x108[0x10]; // Offset: 0x108 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Spacer.SetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSize(struct FVector2D InSize); // Offset: 0x104636ba8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.SpinBox
// Size: 0x5f8 // Inherited bytes: 0x100
struct USpinBox : UWidget {
	// Fields
	float Value; // Offset: 0x100 // Size: 0x04
	char pad_0x104[0x4]; // Offset: 0x104 // Size: 0x04
	DelegateProperty ValueDelegate; // Offset: 0x108 // Size: 0x10
	struct FSpinBoxStyle WidgetStyle; // Offset: 0x118 // Size: 0x3d8
	struct USlateWidgetStyleAsset* Style; // Offset: 0x4f0 // Size: 0x08
	float Delta; // Offset: 0x4f8 // Size: 0x04
	float SliderExponent; // Offset: 0x4fc // Size: 0x04
	struct FSlateFontInfo Font; // Offset: 0x500 // Size: 0x58
	enum class ETextJustify Justification; // Offset: 0x558 // Size: 0x01
	char pad_0x559[0x3]; // Offset: 0x559 // Size: 0x03
	float MinDesiredWidth; // Offset: 0x55c // Size: 0x04
	bool ClearKeyboardFocusOnCommit; // Offset: 0x560 // Size: 0x01
	bool SelectAllTextOnCommit; // Offset: 0x561 // Size: 0x01
	char pad_0x562[0x6]; // Offset: 0x562 // Size: 0x06
	struct FSlateColor ForegroundColor; // Offset: 0x568 // Size: 0x28
	struct FScriptMulticastDelegate OnValueChanged; // Offset: 0x590 // Size: 0x10
	struct FScriptMulticastDelegate OnValueCommitted; // Offset: 0x5a0 // Size: 0x10
	struct FScriptMulticastDelegate OnBeginSliderMovement; // Offset: 0x5b0 // Size: 0x10
	struct FScriptMulticastDelegate OnEndSliderMovement; // Offset: 0x5c0 // Size: 0x10
	char bOverride_MinValue : 1; // Offset: 0x5d0 // Size: 0x01
	char bOverride_MaxValue : 1; // Offset: 0x5d0 // Size: 0x01
	char bOverride_MinSliderValue : 1; // Offset: 0x5d0 // Size: 0x01
	char bOverride_MaxSliderValue : 1; // Offset: 0x5d0 // Size: 0x01
	char pad_0x5D0_4 : 4; // Offset: 0x5d0 // Size: 0x01
	char pad_0x5D1[0x3]; // Offset: 0x5d1 // Size: 0x03
	float MinValue; // Offset: 0x5d4 // Size: 0x04
	float MaxValue; // Offset: 0x5d8 // Size: 0x04
	float MinSliderValue; // Offset: 0x5dc // Size: 0x04
	float MaxSliderValue; // Offset: 0x5e0 // Size: 0x04
	char pad_0x5E4[0x14]; // Offset: 0x5e4 // Size: 0x14

	// Functions

	// Object Name: Function UMG.SpinBox.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetValue(float NewValue); // Offset: 0x1046372c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinValue(float NewValue); // Offset: 0x104637244 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinSliderValue(float NewValue); // Offset: 0x1046371c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxValue(float NewValue); // Offset: 0x10463714c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxSliderValue(float NewValue); // Offset: 0x1046370d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetForegroundColor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetForegroundColor(struct FSlateColor InForegroundColor); // Offset: 0x104636fcc // Return & Params: Num(1) Size(0x28)

	// Object Name: DelegateFunction UMG.SpinBox.OnSpinBoxValueCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSpinBoxValueCommittedEvent__DelegateSignature(float InValue, enum class ETextCommit CommitMethod); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x5)

	// Object Name: DelegateFunction UMG.SpinBox.OnSpinBoxValueChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSpinBoxValueChangedEvent__DelegateSignature(float InValue); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction UMG.SpinBox.OnSpinBoxBeginSliderMovement__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSpinBoxBeginSliderMovement__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SpinBox.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetValue(); // Offset: 0x104636f98 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMinValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMinValue(); // Offset: 0x104636f64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMinSliderValue(); // Offset: 0x104636f30 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxValue(); // Offset: 0x104636efc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxSliderValue(); // Offset: 0x104636ec8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.ClearMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinValue(); // Offset: 0x104636eb4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SpinBox.ClearMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinSliderValue(); // Offset: 0x104636ea0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SpinBox.ClearMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxValue(); // Offset: 0x104636e8c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SpinBox.ClearMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxSliderValue(); // Offset: 0x104636e78 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.StaticMeshWidget
// Size: 0x120 // Inherited bytes: 0x100
struct UStaticMeshWidget : UWidget {
	// Fields
	struct USlateVectorArtData* StaticMeshAsset; // Offset: 0x100 // Size: 0x08
	struct FVector2D MeshScale; // Offset: 0x108 // Size: 0x08
	char pad_0x110[0x10]; // Offset: 0x110 // Size: 0x10
};

// Object Name: Class UMG.TextBinding
// Size: 0x50 // Inherited bytes: 0x48
struct UTextBinding : UPropertyBinding {
	// Fields
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08

	// Functions

	// Object Name: Function UMG.TextBinding.GetTextValue
	// Flags: [Final|Native|Public|Const]
	struct FText GetTextValue(); // Offset: 0x104639258 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.TextBinding.GetStringValue
	// Flags: [Final|Native|Public|Const]
	struct FString GetStringValue(); // Offset: 0x1046391f4 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.TextBlock
// Size: 0x278 // Inherited bytes: 0x128
struct UTextBlock : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x128 // Size: 0x18
	DelegateProperty TextDelegate; // Offset: 0x140 // Size: 0x10
	struct FSlateColor ColorAndOpacity; // Offset: 0x150 // Size: 0x28
	DelegateProperty ColorAndOpacityDelegate; // Offset: 0x178 // Size: 0x10
	struct FSlateColor SelectColorAndOpacity; // Offset: 0x188 // Size: 0x28
	struct FSlateColor NoSelectColorAndOpacity; // Offset: 0x1b0 // Size: 0x28
	bool bHaveSelectColorAndOpacity; // Offset: 0x1d8 // Size: 0x01
	bool bIsSelected; // Offset: 0x1d9 // Size: 0x01
	char pad_0x1DA[0x6]; // Offset: 0x1da // Size: 0x06
	struct FSlateFontInfo Font; // Offset: 0x1e0 // Size: 0x58
	struct FVector2D ShadowOffset; // Offset: 0x238 // Size: 0x08
	struct FLinearColor ShadowColorAndOpacity; // Offset: 0x240 // Size: 0x10
	DelegateProperty ShadowColorAndOpacityDelegate; // Offset: 0x250 // Size: 0x10
	float MinDesiredWidth; // Offset: 0x260 // Size: 0x04
	bool AutoEllipsisText; // Offset: 0x264 // Size: 0x01
	bool bWrapWithInvalidationPanel; // Offset: 0x265 // Size: 0x01
	char pad_0x266[0x12]; // Offset: 0x266 // Size: 0x12

	// Functions

	// Object Name: Function UMG.TextBlock.SetVerticalJustification
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalJustification(enum class ETextVerticalJustify InJustification); // Offset: 0x104639afc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.TextBlock.SetText
	// Flags: [Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x104639a34 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.TextBlock.SetShadowOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetShadowOffset(struct FVector2D InShadowOffset); // Offset: 0x1046399bc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.TextBlock.SetShadowColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity); // Offset: 0x104639940 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.TextBlock.SetSelectColor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSelectColor(bool bIsSelect); // Offset: 0x1046398bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.TextBlock.SetOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOpacity(float InOpacity); // Offset: 0x104639840 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.TextBlock.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredWidth(float InMinDesiredWidth); // Offset: 0x1046397c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.TextBlock.SetJustification
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetJustification(enum class ETextJustify InJustification); // Offset: 0x104639748 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.TextBlock.SetFont
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFont(struct FSlateFontInfo InFontInfo); // Offset: 0x10463963c // Return & Params: Num(1) Size(0x58)

	// Object Name: Function UMG.TextBlock.SetColorAndOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColorAndOpacity(struct FSlateColor InColorAndOpacity); // Offset: 0x104639538 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.TextBlock.SetAutoEllipsisText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoEllipsisText(bool InAutoEllipsisText); // Offset: 0x1046394b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.TextBlock.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x104639450 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UMG.Throbber
// Size: 0x1d8 // Inherited bytes: 0x100
struct UThrobber : UWidget {
	// Fields
	int NumberOfPieces; // Offset: 0x100 // Size: 0x04
	bool bAnimateHorizontally; // Offset: 0x104 // Size: 0x01
	bool bAnimateVertically; // Offset: 0x105 // Size: 0x01
	bool bAnimateOpacity; // Offset: 0x106 // Size: 0x01
	char pad_0x107[0x1]; // Offset: 0x107 // Size: 0x01
	struct USlateBrushAsset* PieceImage; // Offset: 0x108 // Size: 0x08
	struct FSlateBrush Image; // Offset: 0x110 // Size: 0xb8
	char pad_0x1C8[0x10]; // Offset: 0x1c8 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Throbber.SetNumberOfPieces
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNumberOfPieces(int InNumberOfPieces); // Offset: 0x10463a344 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Throbber.SetAnimateVertically
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimateVertically(bool bInAnimateVertically); // Offset: 0x10463a2c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Throbber.SetAnimateOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimateOpacity(bool bInAnimateOpacity); // Offset: 0x10463a23c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Throbber.SetAnimateHorizontally
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimateHorizontally(bool bInAnimateHorizontally); // Offset: 0x10463a1b8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.TileView
// Size: 0x140 // Inherited bytes: 0x100
struct UTileView : UTableViewBase {
	// Fields
	float ItemWidth; // Offset: 0x100 // Size: 0x04
	float ItemHeight; // Offset: 0x104 // Size: 0x04
	struct TArray<struct UObject*> Items; // Offset: 0x108 // Size: 0x10
	enum class ESelectionMode SelectionMode; // Offset: 0x118 // Size: 0x01
	char pad_0x119[0x7]; // Offset: 0x119 // Size: 0x07
	DelegateProperty OnGenerateTileEvent; // Offset: 0x120 // Size: 0x10
	char pad_0x130[0x10]; // Offset: 0x130 // Size: 0x10

	// Functions

	// Object Name: Function UMG.TileView.SetItemWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetItemWidth(float Width); // Offset: 0x10463a6ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.TileView.SetItemHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetItemHeight(float Height); // Offset: 0x10463a630 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.TileView.RequestListRefresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RequestListRefresh(); // Offset: 0x10463a61c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.UMGSequencePlayer
// Size: 0x710 // Inherited bytes: 0x28
struct UUMGSequencePlayer : UObject {
	// Fields
	char pad_0x28[0x348]; // Offset: 0x28 // Size: 0x348
	struct UWidgetAnimation* Animation; // Offset: 0x370 // Size: 0x08
	char pad_0x378[0x398]; // Offset: 0x378 // Size: 0x398
};

// Object Name: Class UMG.UniformGridPanel
// Size: 0x140 // Inherited bytes: 0x118
struct UUniformGridPanel : UPanelWidget {
	// Fields
	struct FMargin SlotPadding; // Offset: 0x114 // Size: 0x10
	float MinDesiredSlotWidth; // Offset: 0x124 // Size: 0x04
	float MinDesiredSlotHeight; // Offset: 0x128 // Size: 0x04
	char pad_0x130[0x10]; // Offset: 0x130 // Size: 0x10

	// Functions

	// Object Name: Function UMG.UniformGridPanel.SetSlotPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSlotPadding(struct FMargin InSlotPadding); // Offset: 0x10463ac38 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UniformGridPanel.SetMinDesiredSlotWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredSlotWidth(float InMinDesiredSlotWidth); // Offset: 0x10463abbc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UniformGridPanel.SetMinDesiredSlotHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredSlotHeight(float InMinDesiredSlotHeight); // Offset: 0x10463ab40 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UniformGridPanel.AddChildToUniformGrid
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUniformGridSlot* AddChildToUniformGrid(struct UWidget* Content); // Offset: 0x10463aab4 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.UniformGridSlot
// Size: 0x50 // Inherited bytes: 0x38
struct UUniformGridSlot : UPanelSlot {
	// Fields
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x38 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x2]; // Offset: 0x3a // Size: 0x02
	int Row; // Offset: 0x3c // Size: 0x04
	int Column; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0xc]; // Offset: 0x44 // Size: 0x0c

	// Functions

	// Object Name: Function UMG.UniformGridSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10463b044 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UniformGridSlot.SetRow
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRow(int InRow); // Offset: 0x10463afc8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UniformGridSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10463af4c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UniformGridSlot.SetColumn
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColumn(int InColumn); // Offset: 0x10463aed0 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.VerticalBox
// Size: 0x128 // Inherited bytes: 0x118
struct UVerticalBox : UPanelWidget {
	// Fields
	bool bDontPaintWhenChildEmpty; // Offset: 0x111 // Size: 0x01
	char pad_0x119[0xf]; // Offset: 0x119 // Size: 0x0f

	// Functions

	// Object Name: Function UMG.VerticalBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x10463fbc0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.VerticalBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x10463fb8c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.VerticalBox.AddChildToVerticalBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UVerticalBoxSlot* AddChildToVerticalBox(struct UWidget* Content); // Offset: 0x10463fb00 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.VerticalBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UVerticalBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	struct FSlateChildSize Size; // Offset: 0x48 // Size: 0x08
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x50 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0xe]; // Offset: 0x52 // Size: 0x0e

	// Functions

	// Object Name: Function UMG.VerticalBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x104641ac0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.VerticalBoxSlot.SetSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSize(struct FSlateChildSize InSize); // Offset: 0x104641a28 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.VerticalBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1046419a8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.VerticalBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10464192c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.Viewport
// Size: 0x140 // Inherited bytes: 0x118
struct UViewport : UContentWidget {
	// Fields
	struct FLinearColor BackgroundColor; // Offset: 0x114 // Size: 0x10
	char pad_0x128[0x18]; // Offset: 0x128 // Size: 0x18

	// Functions

	// Object Name: Function UMG.Viewport.Spawn
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AActor* Spawn(struct AActor* ActorClass); // Offset: 0x104641ef0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.Viewport.SetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetViewRotation(struct FRotator Rotation); // Offset: 0x104641e74 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function UMG.Viewport.SetViewLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetViewLocation(struct FVector Location); // Offset: 0x104641df8 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function UMG.Viewport.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FRotator GetViewRotation(); // Offset: 0x104641dc0 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function UMG.Viewport.GetViewportWorld
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWorld* GetViewportWorld(); // Offset: 0x104641d8c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Viewport.GetViewLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetViewLocation(); // Offset: 0x104641d54 // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class UMG.VisibilityBinding
// Size: 0x48 // Inherited bytes: 0x48
struct UVisibilityBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.VisibilityBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	enum class ESlateVisibility GetValue(); // Offset: 0x104642210 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WeakRefImage
// Size: 0x268 // Inherited bytes: 0x248
struct UWeakRefImage : UImage {
	// Fields
	char pad_0x248[0x20]; // Offset: 0x248 // Size: 0x20

	// Functions

	// Object Name: Function UMG.WeakRefImage.UnloadTextureResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnloadTextureResource(); // Offset: 0x104642508 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WeakRefImage.LoadTextureResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LoadTextureResource(bool bAsync); // Offset: 0x104642484 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WidgetAnimation
// Size: 0x318 // Inherited bytes: 0x2e0
struct UWidgetAnimation : UMovieSceneSequence {
	// Fields
	struct FScriptMulticastDelegate OnAnimationStarted; // Offset: 0x2e0 // Size: 0x10
	struct FScriptMulticastDelegate OnAnimationFinished; // Offset: 0x2f0 // Size: 0x10
	struct UMovieScene* MovieScene; // Offset: 0x300 // Size: 0x08
	struct TArray<struct FWidgetAnimationBinding> AnimationBindings; // Offset: 0x308 // Size: 0x10

	// Functions

	// Object Name: Function UMG.WidgetAnimation.GetStartTime
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetStartTime(); // Offset: 0x10464468c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetAnimation.GetEndTime
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetEndTime(); // Offset: 0x104644658 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.WidgetBinding
// Size: 0x48 // Inherited bytes: 0x48
struct UWidgetBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.WidgetBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	struct UWidget* GetValue(); // Offset: 0x104644924 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.WidgetBlueprintGeneratedClass
// Size: 0x440 // Inherited bytes: 0x3d0
struct UWidgetBlueprintGeneratedClass : UBlueprintGeneratedClass {
	// Fields
	struct UWidgetTree* WidgetTree; // Offset: 0x3d0 // Size: 0x08
	char bAllowTemplate : 1; // Offset: 0x3d8 // Size: 0x01
	char bValidTemplate : 1; // Offset: 0x3d8 // Size: 0x01
	char bTemplateInitialized : 1; // Offset: 0x3d8 // Size: 0x01
	char bCookedTemplate : 1; // Offset: 0x3d8 // Size: 0x01
	char pad_0x3D8_4 : 4; // Offset: 0x3d8 // Size: 0x01
	char pad_0x3D9[0x7]; // Offset: 0x3d9 // Size: 0x07
	struct TArray<struct FDelegateRuntimeBinding> Bindings; // Offset: 0x3e0 // Size: 0x10
	struct TArray<struct UWidgetAnimation*> Animations; // Offset: 0x3f0 // Size: 0x10
	struct TArray<struct FName> NamedSlots; // Offset: 0x400 // Size: 0x10
	struct UUserWidget* TemplateAsset; // Offset: 0x410 // Size: 0x28
	struct UUserWidget* Template; // Offset: 0x438 // Size: 0x08
};

// Object Name: Class UMG.WidgetBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UWidgetBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UMG.WidgetBlueprintLibrary.UnlockMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply UnlockMouse(struct FEventReply& Reply); // Offset: 0x104647e2c // Return & Params: Num(2) Size(0x170)

	// Object Name: Function UMG.WidgetBlueprintLibrary.Unhandled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FEventReply Unhandled(); // Offset: 0x104647d9c // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetUserFocus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply SetUserFocus(struct FEventReply& Reply, struct UWidget* FocusWidget, bool bInAllUsers); // Offset: 0x104647c08 // Return & Params: Num(4) Size(0x180)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetMousePosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FEventReply SetMousePosition(struct FEventReply& Reply, struct FVector2D NewMousePosition); // Offset: 0x104647ac0 // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_UIOnlyEx
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_UIOnlyEx(struct APlayerController* Target, struct UWidget* InWidgetToFocus, enum class EMouseLockMode InMouseLockMode); // Offset: 0x1046479d8 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_UIOnly
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_UIOnly(struct APlayerController* Target, struct UWidget* InWidgetToFocus, bool bLockMouseToViewport); // Offset: 0x1046478e8 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameOnly
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_GameOnly(struct APlayerController* Target); // Offset: 0x104647874 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameAndUIEx
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_GameAndUIEx(struct APlayerController* Target, struct UWidget* InWidgetToFocus, enum class EMouseLockMode InMouseLockMode, bool bHideCursorDuringCapture); // Offset: 0x104647748 // Return & Params: Num(4) Size(0x12)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameAndUI
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_GameAndUI(struct APlayerController* Target, struct UWidget* InWidgetToFocus, bool bLockMouseToViewport, bool bHideCursorDuringCapture); // Offset: 0x104647614 // Return & Params: Num(4) Size(0x12)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetHardwareCursor
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	bool SetHardwareCursor(struct UObject* WorldContextObject, enum class EMouseCursor CursorShape, struct FName CursorName, struct FVector2D HotSpot); // Offset: 0x1046474e8 // Return & Params: Num(5) Size(0x21)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetFocusToGameViewport
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetFocusToGameViewport(); // Offset: 0x1046474d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetBrushResourceToTexture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetBrushResourceToTexture(struct FSlateBrush& Brush, struct UTexture2D* Texture); // Offset: 0x1046473ec // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetBrushResourceToMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetBrushResourceToMaterial(struct FSlateBrush& Brush, struct UMaterialInterface* Material); // Offset: 0x104647304 // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.ReleaseMouseCapture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply ReleaseMouseCapture(struct FEventReply& Reply); // Offset: 0x1046471fc // Return & Params: Num(2) Size(0x170)

	// Object Name: Function UMG.WidgetBlueprintLibrary.ReleaseJoystickCapture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply ReleaseJoystickCapture(struct FEventReply& Reply, bool bInAllJoysticks); // Offset: 0x1046470a8 // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.NoResourceBrush
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush NoResourceBrush(); // Offset: 0x104647044 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.MakeBrushFromTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush MakeBrushFromTexture(struct UTexture2D* Texture, int Width, int Height); // Offset: 0x104646f2c // Return & Params: Num(4) Size(0xc8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.MakeBrushFromMaterial
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush MakeBrushFromMaterial(struct UMaterialInterface* Material, int Width, int Height); // Offset: 0x104646e14 // Return & Params: Num(4) Size(0xc8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.MakeBrushFromAsset
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush MakeBrushFromAsset(struct USlateBrushAsset* BrushAsset); // Offset: 0x104646d70 // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.LockMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply LockMouse(struct FEventReply& Reply, struct UWidget* CapturingWidget); // Offset: 0x104646c24 // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.IsDragDropping
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsDragDropping(); // Offset: 0x104646bf0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetBlueprintLibrary.Handled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FEventReply Handled(); // Offset: 0x104646b60 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetSafeZonePadding
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetSafeZonePadding(struct UObject* WorldContextObject, struct FVector2D& SafePadding, struct FVector2D& SafePaddingScale, struct FVector2D& SpillOverPadding); // Offset: 0x104646a0c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetKeyEventFromAnalogInputEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FKeyEvent GetKeyEventFromAnalogInputEvent(struct FAnalogInputEvent& Event); // Offset: 0x104646938 // Return & Params: Num(2) Size(0x88)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetInputEventFromPointerEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputEvent GetInputEventFromPointerEvent(struct FPointerEvent& Event); // Offset: 0x104646834 // Return & Params: Num(2) Size(0x98)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetInputEventFromNavigationEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputEvent GetInputEventFromNavigationEvent(struct FNavigationEvent& Event); // Offset: 0x104646778 // Return & Params: Num(2) Size(0x48)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetInputEventFromKeyEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputEvent GetInputEventFromKeyEvent(struct FKeyEvent& Event); // Offset: 0x104646698 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetInputEventFromCharacterEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputEvent GetInputEventFromCharacterEvent(struct FCharacterEvent& Event); // Offset: 0x1046465dc // Return & Params: Num(2) Size(0x48)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetDynamicMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UMaterialInstanceDynamic* GetDynamicMaterial(struct FSlateBrush& Brush); // Offset: 0x104646530 // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetDragDroppingContent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UDragDropOperation* GetDragDroppingContent(); // Offset: 0x1046464fc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetBrushResourceAsTexture2D
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UTexture2D* GetBrushResourceAsTexture2D(struct FSlateBrush& Brush); // Offset: 0x104646450 // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetBrushResourceAsMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UMaterialInterface* GetBrushResourceAsMaterial(struct FSlateBrush& Brush); // Offset: 0x1046463a4 // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetBrushResource
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UObject* GetBrushResource(struct FSlateBrush& Brush); // Offset: 0x1046462f8 // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetAllWidgetsWithInterface
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetAllWidgetsWithInterface(struct UObject* WorldContextObject, struct UInterface* Interface, struct TArray<struct UUserWidget*>& FoundWidgets, bool TopLevelOnly); // Offset: 0x104646194 // Return & Params: Num(4) Size(0x21)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetAllWidgetsOfClass
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetAllWidgetsOfClass(struct UObject* WorldContextObject, struct TArray<struct UUserWidget*>& FoundWidgets, struct UUserWidget* WidgetClass, bool TopLevelOnly); // Offset: 0x10464602c // Return & Params: Num(4) Size(0x21)

	// Object Name: Function UMG.WidgetBlueprintLibrary.EndDragDrop
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply EndDragDrop(struct FEventReply& Reply); // Offset: 0x104645f24 // Return & Params: Num(2) Size(0x170)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawTextFormatted
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawTextFormatted(struct FPaintContext& Context, struct FText& Text, struct FVector2D Position, struct UFont* Font, int FontSize, struct FName FontTypeFace, struct FLinearColor Tint); // Offset: 0x104645ce4 // Return & Params: Num(7) Size(0x78)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawText
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawText(struct FPaintContext& Context, struct FString inString, struct FVector2D Position, struct FLinearColor Tint); // Offset: 0x104645b84 // Return & Params: Num(4) Size(0x58)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawLines
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawLines(struct FPaintContext& Context, struct TArray<struct FVector2D>& Points, struct FLinearColor Tint, bool bAntiAlias); // Offset: 0x1046459fc // Return & Params: Num(4) Size(0x51)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawLine
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawLine(struct FPaintContext& Context, struct FVector2D PositionA, struct FVector2D PositionB, struct FLinearColor Tint, bool bAntiAlias); // Offset: 0x104645884 // Return & Params: Num(5) Size(0x51)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawBox
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawBox(struct FPaintContext& Context, struct FVector2D Position, struct FVector2D Size, struct USlateBrushAsset* Brush, struct FLinearColor Tint); // Offset: 0x104645714 // Return & Params: Num(5) Size(0x58)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DismissAllMenus
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void DismissAllMenus(); // Offset: 0x104645700 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DetectDragIfPressed
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FEventReply DetectDragIfPressed(struct FPointerEvent& PointerEvent, struct UWidget* WidgetDetectingDrag, struct FKey DragKey); // Offset: 0x1046454cc // Return & Params: Num(4) Size(0x150)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DetectDrag
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply DetectDrag(struct FEventReply& Reply, struct UWidget* WidgetDetectingDrag, struct FKey DragKey); // Offset: 0x1046452e0 // Return & Params: Num(4) Size(0x190)

	// Object Name: Function UMG.WidgetBlueprintLibrary.CreateDragDropOperation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UDragDropOperation* CreateDragDropOperation(struct UDragDropOperation* OperationClass); // Offset: 0x104645264 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetBlueprintLibrary.Create
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	struct UUserWidget* Create(struct UObject* WorldContextObject, struct UUserWidget* WidgetType, struct APlayerController* OwningPlayer); // Offset: 0x104645174 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function UMG.WidgetBlueprintLibrary.ClearUserFocus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply ClearUserFocus(struct FEventReply& Reply, bool bInAllUsers); // Offset: 0x104645020 // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.CaptureMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply CaptureMouse(struct FEventReply& Reply, struct UWidget* CapturingWidget); // Offset: 0x104644ed4 // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.CaptureJoystick
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply CaptureJoystick(struct FEventReply& Reply, struct UWidget* CapturingWidget, bool bInAllJoysticks); // Offset: 0x104644d40 // Return & Params: Num(4) Size(0x180)

	// Object Name: Function UMG.WidgetBlueprintLibrary.CancelDragDrop
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CancelDragDrop(); // Offset: 0x104644d2c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.WidgetInteractionComponent
// Size: 0x4c0 // Inherited bytes: 0x2d0
struct UWidgetInteractionComponent : USceneComponent {
	// Fields
	struct FScriptMulticastDelegate OnHoveredWidgetChanged; // Offset: 0x2d0 // Size: 0x10
	char pad_0x2E0[0x10]; // Offset: 0x2e0 // Size: 0x10
	int VirtualUserIndex; // Offset: 0x2f0 // Size: 0x04
	float PointerIndex; // Offset: 0x2f4 // Size: 0x04
	enum class ECollisionChannel TraceChannel; // Offset: 0x2f8 // Size: 0x01
	char pad_0x2F9[0x3]; // Offset: 0x2f9 // Size: 0x03
	float InteractionDistance; // Offset: 0x2fc // Size: 0x04
	enum class EWidgetInteractionSource InteractionSource; // Offset: 0x300 // Size: 0x01
	bool bEnableHitTesting; // Offset: 0x301 // Size: 0x01
	bool bShowDebug; // Offset: 0x302 // Size: 0x01
	char pad_0x303[0x1]; // Offset: 0x303 // Size: 0x01
	struct FLinearColor DebugColor; // Offset: 0x304 // Size: 0x10
	char pad_0x314[0x7c]; // Offset: 0x314 // Size: 0x7c
	struct FHitResult CustomHitResult; // Offset: 0x390 // Size: 0x88
	struct FVector2D LocalHitLocation; // Offset: 0x418 // Size: 0x08
	struct FVector2D LastLocalHitLocation; // Offset: 0x420 // Size: 0x08
	struct UWidgetComponent* HoveredWidgetComponent; // Offset: 0x428 // Size: 0x08
	struct FHitResult LastHitResult; // Offset: 0x430 // Size: 0x88
	bool bIsHoveredWidgetInteractable; // Offset: 0x4b8 // Size: 0x01
	bool bIsHoveredWidgetFocusable; // Offset: 0x4b9 // Size: 0x01
	bool bIsHoveredWidgetHitTestVisible; // Offset: 0x4ba // Size: 0x01
	char pad_0x4BB[0x5]; // Offset: 0x4bb // Size: 0x05

	// Functions

	// Object Name: Function UMG.WidgetInteractionComponent.SetCustomHitResult
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetCustomHitResult(struct FHitResult& HitResult); // Offset: 0x10464af1c // Return & Params: Num(1) Size(0x88)

	// Object Name: Function UMG.WidgetInteractionComponent.SendKeyChar
	// Flags: [Native|Public|BlueprintCallable]
	bool SendKeyChar(struct FString Characters, bool bRepeat); // Offset: 0x10464ae00 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function UMG.WidgetInteractionComponent.ScrollWheel
	// Flags: [Native|Public|BlueprintCallable]
	void ScrollWheel(float ScrollDelta); // Offset: 0x10464ad7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetInteractionComponent.ReleasePointerKey
	// Flags: [Native|Public|BlueprintCallable]
	void ReleasePointerKey(struct FKey Key); // Offset: 0x10464ac8c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.WidgetInteractionComponent.ReleaseKey
	// Flags: [Native|Public|BlueprintCallable]
	bool ReleaseKey(struct FKey Key); // Offset: 0x10464ab8c // Return & Params: Num(2) Size(0x19)

	// Object Name: Function UMG.WidgetInteractionComponent.PressPointerKey
	// Flags: [Native|Public|BlueprintCallable]
	void PressPointerKey(struct FKey Key); // Offset: 0x10464aa9c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.WidgetInteractionComponent.PressKey
	// Flags: [Native|Public|BlueprintCallable]
	bool PressKey(struct FKey Key, bool bRepeat); // Offset: 0x10464a954 // Return & Params: Num(3) Size(0x1a)

	// Object Name: Function UMG.WidgetInteractionComponent.PressAndReleaseKey
	// Flags: [Native|Public|BlueprintCallable]
	bool PressAndReleaseKey(struct FKey Key); // Offset: 0x10464a854 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function UMG.WidgetInteractionComponent.IsOverInteractableWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOverInteractableWidget(); // Offset: 0x10464a820 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetInteractionComponent.IsOverHitTestVisibleWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOverHitTestVisibleWidget(); // Offset: 0x10464a7ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetInteractionComponent.IsOverFocusableWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOverFocusableWidget(); // Offset: 0x10464a7b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetInteractionComponent.GetLastHitResult
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FHitResult GetLastHitResult(); // Offset: 0x10464a780 // Return & Params: Num(1) Size(0x88)

	// Object Name: Function UMG.WidgetInteractionComponent.GetHoveredWidgetComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidgetComponent* GetHoveredWidgetComponent(); // Offset: 0x10464a74c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetInteractionComponent.Get2DHitLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D Get2DHitLocation(); // Offset: 0x10464a714 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.WidgetLayoutLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UWidgetLayoutLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsVerticalBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UVerticalBoxSlot* SlotAsVerticalBoxSlot(struct UWidget* Widget); // Offset: 0x10464bdec // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsUniformGridSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UUniformGridSlot* SlotAsUniformGridSlot(struct UWidget* Widget); // Offset: 0x10464bd70 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsOverlaySlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UOverlaySlot* SlotAsOverlaySlot(struct UWidget* Widget); // Offset: 0x10464bcf4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsHorizontalBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UHorizontalBoxSlot* SlotAsHorizontalBoxSlot(struct UWidget* Widget); // Offset: 0x10464bc78 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsGridSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UGridSlot* SlotAsGridSlot(struct UWidget* Widget); // Offset: 0x10464bbfc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsCanvasSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCanvasPanelSlot* SlotAsCanvasSlot(struct UWidget* Widget); // Offset: 0x10464bb80 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsBorderSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UBorderSlot* SlotAsBorderSlot(struct UWidget* Widget); // Offset: 0x10464bb04 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.RemoveAllWidgets
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void RemoveAllWidgets(struct UObject* WorldContextObject); // Offset: 0x10464ba90 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetLayoutLibrary.ProjectWorldLocationToWidgetPositionReturnValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D ProjectWorldLocationToWidgetPositionReturnValue(struct APlayerController* PlayerController, struct FVector WorldLocation); // Offset: 0x10464b9d8 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function UMG.WidgetLayoutLibrary.ProjectWorldLocationToWidgetPosition
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	bool ProjectWorldLocationToWidgetPosition(struct APlayerController* PlayerController, struct FVector WorldLocation, struct FVector2D& ScreenPosition); // Offset: 0x10464b8d8 // Return & Params: Num(4) Size(0x1d)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetViewportWidgetGeometry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGeometry GetViewportWidgetGeometry(struct UObject* WorldContextObject); // Offset: 0x10464b850 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetViewportSize
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetViewportSize(struct UObject* WorldContextObject); // Offset: 0x10464b7d0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetViewportScale
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float GetViewportScale(struct UObject* WorldContextObject); // Offset: 0x10464b754 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetPlayerScreenWidgetGeometry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGeometry GetPlayerScreenWidgetGeometry(struct APlayerController* PlayerController); // Offset: 0x10464b6cc // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetMousePositionScaledByDPI
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool GetMousePositionScaledByDPI(struct APlayerController* Player, float& LocationX, float& LocationY); // Offset: 0x10464b5b0 // Return & Params: Num(4) Size(0x11)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetMousePositionOnViewport
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct FVector2D GetMousePositionOnViewport(struct UObject* WorldContextObject); // Offset: 0x10464b530 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetMousePositionOnPlatform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct FVector2D GetMousePositionOnPlatform(); // Offset: 0x10464b4f8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.WidgetNavigation
// Size: 0xb8 // Inherited bytes: 0x28
struct UWidgetNavigation : UObject {
	// Fields
	struct FWidgetNavigationData Up; // Offset: 0x28 // Size: 0x18
	struct FWidgetNavigationData Down; // Offset: 0x40 // Size: 0x18
	struct FWidgetNavigationData Left; // Offset: 0x58 // Size: 0x18
	struct FWidgetNavigationData Right; // Offset: 0x70 // Size: 0x18
	struct FWidgetNavigationData Next; // Offset: 0x88 // Size: 0x18
	struct FWidgetNavigationData Previous; // Offset: 0xa0 // Size: 0x18
};

// Object Name: Class UMG.WidgetSwitcher
// Size: 0x130 // Inherited bytes: 0x118
struct UWidgetSwitcher : UPanelWidget {
	// Fields
	int ActiveWidgetIndex; // Offset: 0x114 // Size: 0x04
	bool bDontPaintWhenChildEmpty; // Offset: 0x118 // Size: 0x01
	char pad_0x11D[0x13]; // Offset: 0x11d // Size: 0x13

	// Functions

	// Object Name: Function UMG.WidgetSwitcher.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x10464c7ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetSwitcher.SetActiveWidgetIndex
	// Flags: [Native|Public|BlueprintCallable]
	void SetActiveWidgetIndex(int Index); // Offset: 0x10464c768 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetSwitcher.SetActiveWidget
	// Flags: [Native|Public|BlueprintCallable]
	void SetActiveWidget(struct UWidget* Widget); // Offset: 0x10464c6e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetSwitcher.GetWidgetAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetWidgetAtIndex(int Index); // Offset: 0x10464c658 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetSwitcher.GetNumWidgets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetNumWidgets(); // Offset: 0x10464c624 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetSwitcher.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x10464c5f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetSwitcher.GetActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetActiveWidgetIndex(); // Offset: 0x10464c5bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetSwitcher.GetActiveWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetActiveWidget(); // Offset: 0x10464c588 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.WidgetSwitcherSlot
// Size: 0x58 // Inherited bytes: 0x38
struct UWidgetSwitcherSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0xe]; // Offset: 0x4a // Size: 0x0e

	// Functions

	// Object Name: Function UMG.WidgetSwitcherSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10464cca8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetSwitcherSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x10464cc28 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WidgetSwitcherSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10464cbac // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WidgetTree
// Size: 0x40 // Inherited bytes: 0x28
struct UWidgetTree : UObject {
	// Fields
	struct UWidget* RootWidget; // Offset: 0x28 // Size: 0x08
	struct TArray<struct UWidget*> AllWidgets; // Offset: 0x30 // Size: 0x10
};

// Object Name: Class UMG.WindowTitleBarArea
// Size: 0x130 // Inherited bytes: 0x118
struct UWindowTitleBarArea : UContentWidget {
	// Fields
	bool bDoubleClickTogglesFullscreen; // Offset: 0x111 // Size: 0x01
	char pad_0x119[0x17]; // Offset: 0x119 // Size: 0x17

	// Functions

	// Object Name: Function UMG.WindowTitleBarArea.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10464d1a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WindowTitleBarArea.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x10464d128 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WindowTitleBarArea.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10464d0ac // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WindowTitleBarAreaSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UWindowTitleBarAreaSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.WindowTitleBarAreaSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10464d500 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WindowTitleBarAreaSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x10464d480 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WindowTitleBarAreaSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10464d404 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WrapBox
// Size: 0x138 // Inherited bytes: 0x118
struct UWrapBox : UPanelWidget {
	// Fields
	struct FVector2D InnerSlotPadding; // Offset: 0x114 // Size: 0x08
	float WrapWidth; // Offset: 0x11c // Size: 0x04
	bool bExplicitWrapWidth; // Offset: 0x120 // Size: 0x01
	char pad_0x125[0x13]; // Offset: 0x125 // Size: 0x13

	// Functions

	// Object Name: Function UMG.WrapBox.SetInnerSlotPadding
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetInnerSlotPadding(struct FVector2D InPadding); // Offset: 0x10464d7dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WrapBox.AddChildWrapBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UWrapBoxSlot* AddChildWrapBox(struct UWidget* Content); // Offset: 0x10464d750 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.WrapBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UWrapBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	bool bFillEmptySpace; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	float FillSpanWhenLessThan; // Offset: 0x4c // Size: 0x04
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x50 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0xe]; // Offset: 0x52 // Size: 0x0e

	// Functions

	// Object Name: Function UMG.WrapBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10464dbf8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WrapBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x10464db78 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WrapBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10464dafc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WrapBoxSlot.SetFillSpanWhenLessThan
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFillSpanWhenLessThan(float InFillSpanWhenLessThan); // Offset: 0x10464da80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WrapBoxSlot.SetFillEmptySpace
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFillEmptySpace(bool InbFillEmptySpace); // Offset: 0x10464d9fc // Return & Params: Num(1) Size(0x1)
};

