#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ItemUpgradeConfig_type.BP_STRUCT_ItemUpgradeConfig_type
// Size: 0x48 // Inherited bytes: 0x00
struct FBP_STRUCT_ItemUpgradeConfig_type {
	// Fields
	int ID_0_74823400740B386E7F557B4C095B0CF4; // Offset: 0x00 // Size: 0x04
	int GroupID_2_4E91F7403F208F5D7F4025C50C237414; // Offset: 0x04 // Size: 0x04
	int CostItemNum3_3_4805B380606054CE0B74DB5A068FB003; // Offset: 0x08 // Size: 0x04
	int ItemID_5_1A4F57C073BEACD924EAF6870D23FAD4; // Offset: 0x0c // Size: 0x04
	int CostItem2_6_407CA74002E8028108EC7D0C0F4068F2; // Offset: 0x10 // Size: 0x04
	int CostItemNum2_7_4804B340606054CD0B74DB59068FB002; // Offset: 0x14 // Size: 0x04
	int CostItem3_8_407DA78002E8028208EC7D0F0F4068F3; // Offset: 0x18 // Size: 0x04
	int ItemType_9_20217D006E9CA28C6D6121ED03F9CD45; // Offset: 0x1c // Size: 0x04
	int EffectID_10_326047402DFFF91D0718A47C0590A444; // Offset: 0x20 // Size: 0x04
	int CostItemNum1_11_4803B300606054CC0B74DB58068FB001; // Offset: 0x24 // Size: 0x04
	int CostItem1_12_407BA70002E8028008EC7D0D0F4068F1; // Offset: 0x28 // Size: 0x04
	int Level_13_0CD78EC02A3BEF5B5310207200D0590C; // Offset: 0x2c // Size: 0x04
	int FavourateItemID_14_7567630026AD12C45BA37EA604D70764; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString EffectBg_15_69612E407477C2010718A39C0590A417; // Offset: 0x38 // Size: 0x10
};

