#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_WeaponAttachments_type.BP_STRUCT_WeaponAttachments_type
// Size: 0x88 // Inherited bytes: 0x00
struct FBP_STRUCT_WeaponAttachments_type {
	// Fields
	int KeyID_12_DE29BA8D4D52E79C09ECD792B3E5AF59; // Offset: 0x00 // Size: 0x04
	int BulletID_16_836CF1DA41D9B5D6B2A048B65ABF9EA7; // Offset: 0x04 // Size: 0x04
	int ProposeBulletNum_17_776C3F00316F0B260271992A098E22ED; // Offset: 0x08 // Size: 0x04
	int AIMinAttackDist_29_2477C5804AB8968C0920F8790D819994; // Offset: 0x0c // Size: 0x04
	int AIMaxAttackDist_30_7148460032C6174A6AF00ED30DEF9994; // Offset: 0x10 // Size: 0x04
	int BornIslandBulletNum_38_313F40006E88965C3F9EC5D9017AF02D; // Offset: 0x14 // Size: 0x04
	struct TArray<int> Lowers_a_51_09824E0023E1D5C00B2140E803435431; // Offset: 0x18 // Size: 0x10
	struct TArray<int> Magazines_a_52_6C0D36C00DDFE4CD564FCEC60C50EDD1; // Offset: 0x28 // Size: 0x10
	struct TArray<int> Stocks_a_54_62740CC04A4BE64919BB407100C7E4B1; // Offset: 0x38 // Size: 0x10
	struct TArray<int> UpperSides_a_56_0CAAB0002CB0CF8444507E9802483CE1; // Offset: 0x48 // Size: 0x10
	struct TArray<int> Muzzles_a_57_7CDB4D804CD01C927C17EFF70A0E7CF1; // Offset: 0x58 // Size: 0x10
	struct TArray<int> Uppers_a_58_70690EC02BCBD1BF0079F65A02F354E1; // Offset: 0x68 // Size: 0x10
	struct TArray<int> Cores_a_59_5B8C8E0066BF188057B2D56F0F3135F1; // Offset: 0x78 // Size: 0x10
};

