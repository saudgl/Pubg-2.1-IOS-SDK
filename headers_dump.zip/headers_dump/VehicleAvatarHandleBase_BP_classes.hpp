#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass VehicleAvatarHandleBase_BP.VehicleAvatarHandleBase_BP_C
// Size: 0x490 // Inherited bytes: 0x490
struct UVehicleAvatarHandleBase_BP_C : UBackpackVehicleAvatarHandle {
};

