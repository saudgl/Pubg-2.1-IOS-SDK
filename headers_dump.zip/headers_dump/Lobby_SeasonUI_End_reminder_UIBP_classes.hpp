#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_SeasonUI_End_reminder_UIBP.Lobby_SeasonUI_End_reminder_UIBP_C
// Size: 0x3d8 // Inherited bytes: 0x248
struct ULobby_SeasonUI_End_reminder_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* zengzhang; // Offset: 0x248 // Size: 0x08
	struct UWidgetAnimation* Open; // Offset: 0x250 // Size: 0x08
	struct UButton* Button_Close; // Offset: 0x258 // Size: 0x08
	struct UCommon_BackgroundBlur_C* Common_BackgroundBlur; // Offset: 0x260 // Size: 0x08
	struct UCommon_RankIntegralLevel_Style_Small_UIBP_C* Common_RankIntegralLevel_Style_Small_UIBP; // Offset: 0x268 // Size: 0x08
	struct UCommon_UIPopupBG_C* Common_UIPopupBG; // Offset: 0x270 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x278 // Size: 0x08
	struct UImage* Image_3; // Offset: 0x280 // Size: 0x08
	struct UImage* Image_6; // Offset: 0x288 // Size: 0x08
	struct UImage* Image_8; // Offset: 0x290 // Size: 0x08
	struct UImage* Image_11; // Offset: 0x298 // Size: 0x08
	struct UImage* Image_13; // Offset: 0x2a0 // Size: 0x08
	struct UImage* Image_20; // Offset: 0x2a8 // Size: 0x08
	struct UImage* Image_21; // Offset: 0x2b0 // Size: 0x08
	struct UImage* Image_22; // Offset: 0x2b8 // Size: 0x08
	struct UImage* Image_23; // Offset: 0x2c0 // Size: 0x08
	struct UImage* Image_24; // Offset: 0x2c8 // Size: 0x08
	struct UImage* Image_27; // Offset: 0x2d0 // Size: 0x08
	struct UImage* Image_28; // Offset: 0x2d8 // Size: 0x08
	struct UImage* Image_29; // Offset: 0x2e0 // Size: 0x08
	struct UImage* Image_30; // Offset: 0x2e8 // Size: 0x08
	struct UImage* Image_31; // Offset: 0x2f0 // Size: 0x08
	struct UImage* Image_32; // Offset: 0x2f8 // Size: 0x08
	struct UImage* Image_33; // Offset: 0x300 // Size: 0x08
	struct UImage* Image_34; // Offset: 0x308 // Size: 0x08
	struct UImage* Image_35; // Offset: 0x310 // Size: 0x08
	struct UImage* Image_36; // Offset: 0x318 // Size: 0x08
	struct UImage* Image_67; // Offset: 0x320 // Size: 0x08
	struct UImage* Image_86; // Offset: 0x328 // Size: 0x08
	struct UImage* Image_87; // Offset: 0x330 // Size: 0x08
	struct UImage* Image_122; // Offset: 0x338 // Size: 0x08
	struct UImage* Image_269; // Offset: 0x340 // Size: 0x08
	struct UImage* Image_LeftDays; // Offset: 0x348 // Size: 0x08
	struct UImage* Image_NextSegmentIcon; // Offset: 0x350 // Size: 0x08
	struct UImage* Image_NextSegmentSubIcon; // Offset: 0x358 // Size: 0x08
	struct UImage* Image_SegmentBigIcon; // Offset: 0x360 // Size: 0x08
	struct UImage* Image_SegmentBigSubIcon; // Offset: 0x368 // Size: 0x08
	struct UImage* Image_SegmentIcon; // Offset: 0x370 // Size: 0x08
	struct UImage* Image_SegmentSubIcon; // Offset: 0x378 // Size: 0x08
	struct UImage* Number_2; // Offset: 0x380 // Size: 0x08
	struct UImage* Number_3; // Offset: 0x388 // Size: 0x08
	struct UProgressBar* ProgressBar_Credit; // Offset: 0x390 // Size: 0x08
	struct UTextBlock* TextBlock_3; // Offset: 0x398 // Size: 0x08
	struct UTextBlock* TextBlock_Credit; // Offset: 0x3a0 // Size: 0x08
	struct UTextBlock* TextBlock_LeftTime; // Offset: 0x3a8 // Size: 0x08
	struct UTextBlock* TextBlock_SeasonID; // Offset: 0x3b0 // Size: 0x08
	struct UTextBlock* TextBlock_SeasonIDLeft; // Offset: 0x3b8 // Size: 0x08
	struct UTextBlock* TextBlock_SeasonSprint; // Offset: 0x3c0 // Size: 0x08
	struct UTextBlock* TextBlock_SeasonTime; // Offset: 0x3c8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_1; // Offset: 0x3d0 // Size: 0x08
};

