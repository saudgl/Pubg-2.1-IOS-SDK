#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_VirtualItem.BattleItemHandle_VirtualItem_C
// Size: 0x140 // Inherited bytes: 0x140
struct UBattleItemHandle_VirtualItem_C : UBattleItemHandleBase {
};

