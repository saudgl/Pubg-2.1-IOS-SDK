#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass VideoPlayerSystem.VideoPlayerSystem_C
// Size: 0x480 // Inherited bytes: 0x400
struct UVideoPlayerSystem_C : UUAEUserWidget {
	// Fields
	struct UWidgetAnimation* shouqi; // Offset: 0x400 // Size: 0x08
	struct UButton* Button_all; // Offset: 0x408 // Size: 0x08
	struct UButton* Button_OK; // Offset: 0x410 // Size: 0x08
	struct UButton* Button_XMission; // Offset: 0x418 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_1; // Offset: 0x420 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x428 // Size: 0x08
	struct UImage* Image_2; // Offset: 0x430 // Size: 0x08
	struct UImage* Image_3; // Offset: 0x438 // Size: 0x08
	struct UImage* Image_4; // Offset: 0x440 // Size: 0x08
	struct UImage* Image_5; // Offset: 0x448 // Size: 0x08
	struct UImage* Image_6; // Offset: 0x450 // Size: 0x08
	struct UImage* Image_bg; // Offset: 0x458 // Size: 0x08
	struct UTextBlock* TextBlock_Time; // Offset: 0x460 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_1; // Offset: 0x468 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_2; // Offset: 0x470 // Size: 0x08
	struct UVideoPlayer_C* VideoPlayer; // Offset: 0x478 // Size: 0x08
};

