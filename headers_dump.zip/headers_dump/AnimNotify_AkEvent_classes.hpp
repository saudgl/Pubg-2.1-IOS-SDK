#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass AnimNotify_AkEvent.AnimNotify_AkEvent_C
// Size: 0x68 // Inherited bytes: 0x38
struct UAnimNotify_AkEvent_C : UAnimNotify {
	// Fields
	struct FString Attach Name; // Offset: 0x38 // Size: 0x10
	struct UAkAudioEvent* Event; // Offset: 0x48 // Size: 0x08
	bool Follow; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
	struct FString EventName; // Offset: 0x58 // Size: 0x10

	// Functions

	// Object Name: Function AnimNotify_AkEvent.AnimNotify_AkEvent_C.Received_Notify
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x11)
};

