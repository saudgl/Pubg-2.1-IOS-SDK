#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Rifle_SCAR.BP_Rifle_SCAR_C
// Size: 0x1279 // Inherited bytes: 0x126d
struct ABP_Rifle_SCAR_C : ABP_ShootWeaponBase_C {
	// Fields
	char pad_0x126D[0x3]; // Offset: 0x126d // Size: 0x03
	struct UWeaponAnimList_Rifle_SCAR_C* WeaponAnimList_Rifle_SCAR; // Offset: 0x1270 // Size: 0x08
	bool bUseIdleAnim_1; // Offset: 0x1278 // Size: 0x01

	// Functions

	// Object Name: Function BP_Rifle_SCAR.BP_Rifle_SCAR_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)
};

