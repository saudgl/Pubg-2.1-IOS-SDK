#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct slua_unreal.LuaNetSerialization
// Size: 0x50 // Inherited bytes: 0x00
struct FLuaNetSerialization {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

