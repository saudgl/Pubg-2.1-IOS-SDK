#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SceneCaptureWidgetPlugin.WidgetCaptureComponent2D
// Size: 0x970 // Inherited bytes: 0x950
struct UWidgetCaptureComponent2D : USceneCaptureComponent2D {
	// Fields
	char pad_0x950[0x20]; // Offset: 0x950 // Size: 0x20
};

// Object Name: Class SceneCaptureWidgetPlugin.SceneCaptureCameraActor
// Size: 0x980 // Inherited bytes: 0x970
struct ASceneCaptureCameraActor : ACameraActor {
	// Fields
	struct UWidgetCaptureComponent2D* SceneCaptureComponent; // Offset: 0x970 // Size: 0x08
	char pad_0x978[0x8]; // Offset: 0x978 // Size: 0x08
};

// Object Name: Class SceneCaptureWidgetPlugin.SceneCaptureWidget
// Size: 0x1e0 // Inherited bytes: 0x100
struct USceneCaptureWidget : UWidget {
	// Fields
	struct FSlateBrush Brush; // Offset: 0x100 // Size: 0xb8
	struct ASceneCaptureCameraActor* SceneCaptureCameraActor; // Offset: 0x1b8 // Size: 0x08
	char pad_0x1C0[0x20]; // Offset: 0x1c0 // Size: 0x20

	// Functions

	// Object Name: Function SceneCaptureWidgetPlugin.SceneCaptureWidget.SetSceneCaptureCameraActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSceneCaptureCameraActor(struct ASceneCaptureCameraActor* InSceneCaptureCameraActor); // Offset: 0x1021514bc // Return & Params: Num(1) Size(0x8)
};

