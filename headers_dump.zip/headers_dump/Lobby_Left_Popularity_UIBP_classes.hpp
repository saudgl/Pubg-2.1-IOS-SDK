#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Left_Popularity_UIBP.Lobby_Left_Popularity_UIBP_C
// Size: 0x2d0 // Inherited bytes: 0x248
struct ULobby_Left_Popularity_UIBP_C : UUserWidget {
	// Fields
	struct UCanvasPanel* Add_Friend; // Offset: 0x248 // Size: 0x08
	struct UButton* Button_Add; // Offset: 0x250 // Size: 0x08
	struct UButton* Button_Details; // Offset: 0x258 // Size: 0x08
	struct UButton* Button_Edit; // Offset: 0x260 // Size: 0x08
	struct UButton* Button_Gift; // Offset: 0x268 // Size: 0x08
	struct UButton* Button_Photo; // Offset: 0x270 // Size: 0x08
	struct UButton* Button_Popularity; // Offset: 0x278 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Popularity; // Offset: 0x280 // Size: 0x08
	struct UCanvasPanel* Give; // Offset: 0x288 // Size: 0x08
	struct UImage* Image_Popularity; // Offset: 0x290 // Size: 0x08
	struct UCanvasPanel* Photo; // Offset: 0x298 // Size: 0x08
	struct UImage* Photo_Reddot; // Offset: 0x2a0 // Size: 0x08
	struct UImage* popularity_reddot; // Offset: 0x2a8 // Size: 0x08
	struct UTextBlock* PopularityCount; // Offset: 0x2b0 // Size: 0x08
	struct UCanvasPanel* PopularityItem; // Offset: 0x2b8 // Size: 0x08
	struct UCanvasPanel* Show_Details; // Offset: 0x2c0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_GiftOrPhoto; // Offset: 0x2c8 // Size: 0x08
};

