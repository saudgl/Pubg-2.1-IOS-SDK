#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass LobbyModelShowActorBP.LobbyModelShowActorBP_C
// Size: 0x740 // Inherited bytes: 0x4a0
struct ALobbyModelShowActorBP_C : ALuaActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4a0 // Size: 0x08
	struct UStaticMeshComponent* Sphere; // Offset: 0x4a8 // Size: 0x08
	struct UCapsuleComponent* Capsule; // Offset: 0x4b0 // Size: 0x08
	struct USceneComponent* Scene; // Offset: 0x4b8 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x4c0 // Size: 0x08
	float WeaponMatTimeline_time_492B8511488AA34B66EFCEB09ACAE5EE; // Offset: 0x4c8 // Size: 0x04
	enum class ETimelineDirection WeaponMatTimeline__Direction_492B8511488AA34B66EFCEB09ACAE5EE; // Offset: 0x4cc // Size: 0x01
	char pad_0x4CD[0x3]; // Offset: 0x4cd // Size: 0x03
	struct UTimelineComponent* WeaponMatTimeline; // Offset: 0x4d0 // Size: 0x08
	struct ASTExtraWeapon* WeaponActor; // Offset: 0x4d8 // Size: 0x08
	struct UWeaponAvatarComponent* WeaponAvatarComponent; // Offset: 0x4e0 // Size: 0x08
	bool press; // Offset: 0x4e8 // Size: 0x01
	enum class ETouchIndex FingerIndex; // Offset: 0x4e9 // Size: 0x01
	char pad_0x4EA[0x2]; // Offset: 0x4ea // Size: 0x02
	float LocationX; // Offset: 0x4ec // Size: 0x04
	bool canAutoRotateZ; // Offset: 0x4f0 // Size: 0x01
	char pad_0x4F1[0x3]; // Offset: 0x4f1 // Size: 0x03
	float zRotateSpeed; // Offset: 0x4f4 // Size: 0x04
	float LocationY; // Offset: 0x4f8 // Size: 0x04
	bool canAutoRotateX; // Offset: 0x4fc // Size: 0x01
	char pad_0x4FD[0x3]; // Offset: 0x4fd // Size: 0x03
	float backTime; // Offset: 0x500 // Size: 0x04
	float curBackTime; // Offset: 0x504 // Size: 0x04
	float disinteractDis; // Offset: 0x508 // Size: 0x04
	float yIntensity; // Offset: 0x50c // Size: 0x04
	float yDisinteractRatio; // Offset: 0x510 // Size: 0x04
	float originX; // Offset: 0x514 // Size: 0x04
	float originY; // Offset: 0x518 // Size: 0x04
	bool alreadyRotate; // Offset: 0x51c // Size: 0x01
	bool alreadyRotateY; // Offset: 0x51d // Size: 0x01
	bool canRotateBack; // Offset: 0x51e // Size: 0x01
	char pad_0x51F[0x1]; // Offset: 0x51f // Size: 0x01
	int ShowType; // Offset: 0x520 // Size: 0x04
	bool needXRotation; // Offset: 0x524 // Size: 0x01
	char pad_0x525[0x3]; // Offset: 0x525 // Size: 0x03
	struct ACharacter* PlaneCharacter; // Offset: 0x528 // Size: 0x08
	float XRotateMin; // Offset: 0x530 // Size: 0x04
	float XRotateMax; // Offset: 0x534 // Size: 0x04
	float YRotateMin; // Offset: 0x538 // Size: 0x04
	float YRotateMax; // Offset: 0x53c // Size: 0x04
	int CurrentItemID; // Offset: 0x540 // Size: 0x04
	char pad_0x544[0x4]; // Offset: 0x544 // Size: 0x04
	struct ABP_Lobby_Grenade_C* grenadeActor; // Offset: 0x548 // Size: 0x08
	bool isTouching; // Offset: 0x550 // Size: 0x01
	char pad_0x551[0x7]; // Offset: 0x551 // Size: 0x07
	struct TArray<struct FVector> projectilePredictArray; // Offset: 0x558 // Size: 0x10
	int projectileTickIndex; // Offset: 0x568 // Size: 0x04
	float xRotateSpeed; // Offset: 0x56c // Size: 0x04
	struct FRotator AttachPointDefaultRotate; // Offset: 0x570 // Size: 0x0c
	char pad_0x57C[0x4]; // Offset: 0x57c // Size: 0x04
	struct ALobbyModelCommonActorBP_C* bagWidgetActor; // Offset: 0x580 // Size: 0x08
	char pad_0x588[0x8]; // Offset: 0x588 // Size: 0x08
	struct FTransform SpawnTransform; // Offset: 0x590 // Size: 0x30
	struct ABP_LobbyVehicle_C* VehicleActor; // Offset: 0x5c0 // Size: 0x08
	bool canRotate; // Offset: 0x5c8 // Size: 0x01
	char pad_0x5C9[0x3]; // Offset: 0x5c9 // Size: 0x03
	int curGrenadeIndex; // Offset: 0x5cc // Size: 0x04
	int spawnIndex; // Offset: 0x5d0 // Size: 0x04
	char pad_0x5D4[0x4]; // Offset: 0x5d4 // Size: 0x04
	struct TMap<int, struct FShowActorData> ShowActorDataArray; // Offset: 0x5d8 // Size: 0x50
	struct ABP_LobbyVehicle_C* refitVehicleActor; // Offset: 0x628 // Size: 0x08
	struct ALobbyModelCommonActorBP_C* parachuteActor; // Offset: 0x630 // Size: 0x08
	int curVehicleIndex; // Offset: 0x638 // Size: 0x04
	char pad_0x63C[0x4]; // Offset: 0x63c // Size: 0x04
	struct TArray<struct FString> ExtraData; // Offset: 0x640 // Size: 0x10
	bool EnableInput_2; // Offset: 0x650 // Size: 0x01
	bool RotateBackZ; // Offset: 0x651 // Size: 0x01
	char pad_0x652[0x6]; // Offset: 0x652 // Size: 0x06
	struct ALobbyModelShowActorBP_C* nextShowActor; // Offset: 0x658 // Size: 0x08
	bool isAsyncLoading; // Offset: 0x660 // Size: 0x01
	bool weaponDynMatChanged; // Offset: 0x661 // Size: 0x01
	char pad_0x662[0x6]; // Offset: 0x662 // Size: 0x06
	struct ALobbyModelCommonActorBP_C* icon3DActor; // Offset: 0x668 // Size: 0x08
	struct TSet<int> HasShakeEffectItem; // Offset: 0x670 // Size: 0x50
	struct ALobbyModelCommonActorBP_C* bagActor; // Offset: 0x6c0 // Size: 0x08
	struct FBP_STRUCT_WeaponMatParamCfg_type WeaponMatParam; // Offset: 0x6c8 // Size: 0x68
	float MatAlpha; // Offset: 0x730 // Size: 0x04
	char pad_0x734[0x4]; // Offset: 0x734 // Size: 0x04
	struct ABP_LobbyWingman_C* WingmanActor; // Offset: 0x738 // Size: 0x08

	// Functions

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnWingmanAyncReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnWingmanAyncReady(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowWingman
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowWingman(int resID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.DetachSuperCarAttachToAttachPoint
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void DetachSuperCarAttachToAttachPoint(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnAsyncReadyLua
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnAsyncReadyLua(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.DestroyContentsInLua
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void DestroyContentsInLua(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.GetLoadedClass
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetLoadedClass(int ID, struct UBattleItemHandleBase*& AsBattle Item Handle Base, bool& Success); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.TryShowModel
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void TryShowModel(int resID, int BPID, bool bIgnoreDownload); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.PreChangeWeaponAvatar
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PreChangeWeaponAvatar(int resID, int BPID); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.TriggerDownloadRes
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void TriggerDownloadRes(int ItemId, int BPID); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.CreaetAndSetWeaponDynamicMat
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CreaetAndSetWeaponDynamicMat(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowBag
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ShowBag(int commonActorResId); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.SetHolderBack
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetHolderBack(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.SetCastShadow
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCastShadow(bool CastShadow); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.MakeShowTypeCanRotateBack
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void MakeShowTypeCanRotateBack(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ProcessIcon3DAttachTexture
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ProcessIcon3DAttachTexture(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnIcon3dAsyncReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnIcon3dAsyncReady(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowIcon3D
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowIcon3D(int resID, bool isSync); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowIcon3dAsycOrSync
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowIcon3dAsycOrSync(int resID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.DestroyAllContent
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void DestroyAllContent(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.UpdateWeaponMatParam
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateWeaponMatParam(float Alpha); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.GetRotateSpeed
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetRotateSpeed(float DeltaX, float DeltaY, float& Speed); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.UpdateWeaponMat
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateWeaponMat(float RotateSpeed); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnParachuteAsyncReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnParachuteAsyncReady(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnBagWidgetAsyncReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnBagWidgetAsyncReady(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnWeaponAsyncReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnWeaponAsyncReady(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnPlaneAsyncReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnPlaneAsyncReady(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ProcessNextActor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ProcessNextActor(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnDIYWeaponDecalFinish
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnDIYWeaponDecalFinish(int RequestID, struct UTextureRenderTarget2D* RT); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.SetDIYDecalNumPerFrame
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDIYDecalNumPerFrame(bool isSync, int Num); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.SetRotateBackZ
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRotateBackZ(bool rotateZ); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.SetWeaponCollision
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetWeaponCollision(struct FString Asset); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.SetCanTouchRotate
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCanTouchRotate(bool canRotate); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.SetWeaponPendantSocketType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetWeaponPendantSocketType(enum class EWeaponPendantSocketType Type); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.GetSocketTransform
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetSocketTransform(int ShowType, struct FString SocketName, struct FTransform& Transform); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x50)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowBagWidgetAsycOrSync
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowBagWidgetAsycOrSync(int resID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowParachuteAsycOrSync
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowParachuteAsycOrSync(int resID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.GetComponentPosition
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetComponentPosition(int SlotID, struct FVector& Location); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnRefitVehicleAsyncReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnRefitVehicleAsyncReady(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.UpdateCapsuleSize
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdateCapsuleSize(float HalfHeight, float Radius); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.DestroyForType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void DestroyForType(int exceptType); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnVehicleAsyncReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnVehicleAsyncReady(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnGrenadeAsyncReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnGrenadeAsyncReady(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowModel
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowModel(int resID, int BPID); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowParachute
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ShowParachute(int resID, bool isSync); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowRefitVehicle
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ShowRefitVehicle(int VehicleID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.SetShowActorLocationRotation
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetShowActorLocationRotation(int resID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnAsyncReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnAsyncReady(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ModelSimulatePhysics
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ModelSimulatePhysics(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.TryRotate
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void TryRotate(float& DeltaX, float& DeltaY); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.MakeRotation
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void MakeRotation(float newLocationX, float newLocationY, float& RotationX, float& RotationY, float& RotationZ); // Offset: 0x103bcc798 // Return & Params: Num(5) Size(0x14)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.AttachModelCenter
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void AttachModelCenter(int CameraID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.GetShowTypeByItemType
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetShowTypeByItemType(int resID, int itemType, int ItemSubType, int& Type); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowVehicle
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ShowVehicle(int VehicleID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.RecordTmpVar
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RecordTmpVar(int resID, float ZSpeed, float backTime, float disinteractDis, float YdisRatio, float yIntensity, bool needXRotation, bool canAutoRotateZ, bool canRotateBack, bool canRotate, struct FString ExtraData); // Offset: 0x103bcc798 // Return & Params: Num(11) Size(0x30)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowWeapon
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ShowWeapon(int resID, int BPID); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowPlane
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowPlane(int resID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.MakeSpawnTransform
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FTransform MakeSpawnTransform(float ActorScale, struct FString ModelOffset); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x50)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowBagWidget
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ShowBagWidget(int resID, bool isSync); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowGrenade
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ShowGrenade(int resID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.GetAttachPoint
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetAttachPoint(struct AActor*& attachPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ResetAttachPointRotate
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ResetAttachPointRotate(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.DetachFromAttachPoint
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void DetachFromAttachPoint(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.AttachToAttachPoint
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void AttachToAttachPoint(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.OnParticleSystemFinish
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnParticleSystemFinish(struct UParticleSystemComponent* NewParam); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.XAutoRotate
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void XAutoRotate(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.TickProjectileEffect
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void TickProjectileEffect(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.PlayParticleEffect
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayParticleEffect(struct FVector Location); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.PlayProjectileEffect
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayProjectileEffect(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.IsModelValid
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsModelValid(bool& Valid); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.GetBaseItemHBClass
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetBaseItemHBClass(bool& NewParam, struct UBattleItemHandleBase*& AsBattle Item Handle Base); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.StopAkEvent
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void StopAkEvent(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.UpdateRotateLimit
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdateRotateLimit(struct FString XRotateLimit, struct FString YRotateLimit); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.UpdateShowType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdateShowType(int resID, int itemType, int ItemSubType); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.SetTouchStatus
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetTouchStatus(bool Can); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.SetRotateBackStatus
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRotateBackStatus(bool Can); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.NeedRotateY
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void NeedRotateY(float X, float Y, bool& need); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.NeedRotate
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void NeedRotate(float X, float Y, bool& need); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.RotateBack
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void RotateBack(float Delta); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ZAutoRotate
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ZAutoRotate(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.DestroyWeaponActor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void DestroyWeaponActor(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.GetItemSubType
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetItemSubType(int RowNum, int& SubType); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.GetBPID
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetBPID(int RowName, int& BPID, int& itemType, int& ItemSubType); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.PutOffEquipmentByResID
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PutOffEquipmentByResID(int resID); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.PutOnEquipmentByResID
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PutOnEquipmentByResID(int resID, bool& Ret); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ShowModelByResid
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ShowModelByResid(int resID, float XOffset, struct FRotator Rotator, float ZSpeed, float backTime, float disinteractDis, float YdisRatio, float yIntensity, bool needResetAutoRotation, bool needXRotation, float ActorScale, struct FString XRotateLimit, struct FString YRotateLimit, struct FString ModelOffset, bool canAutoRotate, bool canRotateBack, bool canRotate, struct FRotator InitRotate, struct FString ExtraData); // Offset: 0x103bcc798 // Return & Params: Num(19) Size(0x80)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.WeaponMatTimeline__FinishedFunc
	// Flags: [BlueprintEvent]
	void WeaponMatTimeline__FinishedFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.WeaponMatTimeline__UpdateFunc
	// Flags: [BlueprintEvent]
	void WeaponMatTimeline__UpdateFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveTick(float DeltaSeconds); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentOnInputTouchBeginSignature__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentOnInputTouchBeginSignature__DelegateSignature(enum class ETouchIndex FingerIndex, struct UPrimitiveComponent* TouchedComponent); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_1_ComponentOnInputTouchEndSignature__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Capsule_K2Node_ComponentBoundEvent_1_ComponentOnInputTouchEndSignature__DelegateSignature(enum class ETouchIndex FingerIndex, struct UPrimitiveComponent* TouchedComponent); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ReceiveDestroyed
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveDestroyed(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.Projectile
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Projectile(float X, float Y, float Z); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.TickWeaponMat
	// Flags: [BlueprintCallable|BlueprintEvent]
	void TickWeaponMat(float fromShake, float toShake); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyModelShowActorBP.LobbyModelShowActorBP_C.ExecuteUbergraph_LobbyModelShowActorBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_LobbyModelShowActorBP(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

