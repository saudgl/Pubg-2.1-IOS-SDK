#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct SimpleScatterPlugin.Bounds
// Size: 0x18 // Inherited bytes: 0x00
struct FBounds {
	// Fields
	struct FVector Origin; // Offset: 0x00 // Size: 0x0c
	struct FVector Extents; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct SimpleScatterPlugin.TracedPoint
// Size: 0x1c // Inherited bytes: 0x00
struct FTracedPoint {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FVector Normal; // Offset: 0x0c // Size: 0x0c
	struct FColor TextureColor; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct SimpleScatterPlugin.GeneratedPoint
// Size: 0x10 // Inherited bytes: 0x00
struct FGeneratedPoint {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	float Depth; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct SimpleScatterPlugin.HeightDistributionLimit
// Size: 0x10 // Inherited bytes: 0x00
struct FHeightDistributionLimit {
	// Fields
	bool bUseHeightLimit; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float HeightLimitMin; // Offset: 0x04 // Size: 0x04
	float HeightLimitMax; // Offset: 0x08 // Size: 0x04
	bool bHeightLimitInvert; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct SimpleScatterPlugin.SlopeDistributionLimit
// Size: 0x10 // Inherited bytes: 0x00
struct FSlopeDistributionLimit {
	// Fields
	bool bUseSlopeLimit; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float SlopeLimitOffset; // Offset: 0x04 // Size: 0x04
	float SlopeLimitContrast; // Offset: 0x08 // Size: 0x04
	bool bSlopeLimitInvert; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct SimpleScatterPlugin.SlopeScaleFalloff
// Size: 0x10 // Inherited bytes: 0x00
struct FSlopeScaleFalloff {
	// Fields
	float SlopeFalloffEffect; // Offset: 0x00 // Size: 0x04
	float SlopeFalloffOffset; // Offset: 0x04 // Size: 0x04
	float SlopeFalloffContrast; // Offset: 0x08 // Size: 0x04
	bool SlopeFalloffInvert; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct SimpleScatterPlugin.ScatterSurface
// Size: 0x30 // Inherited bytes: 0x00
struct FScatterSurface {
	// Fields
	struct AActor* Surface; // Offset: 0x00 // Size: 0x08
	struct UMaterial* DistributionMaterial; // Offset: 0x08 // Size: 0x08
	float LandscapeUV_Size; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FColor> DistributionTexture; // Offset: 0x18 // Size: 0x10
	int DistributionTextureSize; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct SimpleScatterPlugin.InstancedMesh
// Size: 0x20 // Inherited bytes: 0x00
struct FInstancedMesh {
	// Fields
	struct UStaticMesh* StaticMesh; // Offset: 0x00 // Size: 0x08
	float ScaleMultiplier; // Offset: 0x08 // Size: 0x04
	float Probability; // Offset: 0x0c // Size: 0x04
	enum class EComponentMobility Mobility; // Offset: 0x10 // Size: 0x01
	bool bEnableCollision; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x6]; // Offset: 0x12 // Size: 0x06
	struct UHierarchicalInstancedStaticMeshComponent* Instancer; // Offset: 0x18 // Size: 0x08
};

