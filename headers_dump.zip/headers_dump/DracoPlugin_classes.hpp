#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class DracoPlugin.Draco
// Size: 0x28 // Inherited bytes: 0x28
struct UDraco : UObject {
};

// Object Name: Class DracoPlugin.DracoSkeletal
// Size: 0x28 // Inherited bytes: 0x28
struct UDracoSkeletal : UObject {
};

