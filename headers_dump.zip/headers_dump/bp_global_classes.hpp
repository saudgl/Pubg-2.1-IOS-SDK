#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptBlueprintGeneratedClass bp_global.bp_global_C
// Size: 0x578 // Inherited bytes: 0x440
struct Abp_global_C : ALuaClassObj {
	// Fields
	struct UScriptContextComponent* Generated_ScriptContext; // Offset: 0x440 // Size: 0x08
	int BP_ChatBan; // Offset: 0x448 // Size: 0x04
	char pad_0x44C[0x4]; // Offset: 0x44c // Size: 0x04
	struct FString BP_Global_TouchTitleString; // Offset: 0x450 // Size: 0x10
	bool BP_IS_EXTERNAL_CHANNEL; // Offset: 0x460 // Size: 0x01
	bool BP_EUChatRestriction; // Offset: 0x461 // Size: 0x01
	char pad_0x462[0x2]; // Offset: 0x462 // Size: 0x02
	int BP_Platform; // Offset: 0x464 // Size: 0x04
	bool BP_IOS_CHECK; // Offset: 0x468 // Size: 0x01
	bool BP_Global_IsAnniversaryNeedShow; // Offset: 0x469 // Size: 0x01
	char pad_0x46A[0x2]; // Offset: 0x46a // Size: 0x02
	int BP_played_cg; // Offset: 0x46c // Size: 0x04
	bool BP_GlobalTips_ShowLimitIcon; // Offset: 0x470 // Size: 0x01
	char pad_0x471[0x3]; // Offset: 0x471 // Size: 0x03
	int BP_GameGender; // Offset: 0x474 // Size: 0x04
	bool BP_Global_AdvertiseNeedShowtask; // Offset: 0x478 // Size: 0x01
	bool BP_Global_IsChristmasNeedShow; // Offset: 0x479 // Size: 0x01
	char pad_0x47A[0x2]; // Offset: 0x47a // Size: 0x02
	int BP_Global_PreviewItemId; // Offset: 0x47c // Size: 0x04
	int BP_Global_BackpackAvatarPreviewID; // Offset: 0x480 // Size: 0x04
	bool BP_Global_AndroidKey_IsValid; // Offset: 0x484 // Size: 0x01
	char pad_0x485[0x3]; // Offset: 0x485 // Size: 0x03
	int BP_GlobalHelpTips_StringID; // Offset: 0x488 // Size: 0x04
	char pad_0x48C[0x4]; // Offset: 0x48c // Size: 0x04
	struct FString BP_Global_SelfUID; // Offset: 0x490 // Size: 0x10
	int BP_GlobalSwitchCameraIndex; // Offset: 0x4a0 // Size: 0x04
	char pad_0x4A4[0x4]; // Offset: 0x4a4 // Size: 0x04
	struct FString BP_GEM_REPORT_PARA1; // Offset: 0x4a8 // Size: 0x10
	int BP_Share_Platform; // Offset: 0x4b8 // Size: 0x04
	char pad_0x4BC[0x4]; // Offset: 0x4bc // Size: 0x04
	struct FString BP_GEM_REPORT_PARA2; // Offset: 0x4c0 // Size: 0x10
	struct FString BP_GEM_REPORT_SUBEVENT; // Offset: 0x4d0 // Size: 0x10
	struct FBP_STRUCT_GlobalTips_Pos BP_STRUCT_GlobalTips_Pos; // Offset: 0x4e0 // Size: 0x08
	int BP_BA_REASON; // Offset: 0x4e8 // Size: 0x04
	int BP_GlobalTips_PatternID; // Offset: 0x4ec // Size: 0x04
	int BP_CurSceneCameraIndex; // Offset: 0x4f0 // Size: 0x04
	int BP_CHECK_MENU_OPEN_ID; // Offset: 0x4f4 // Size: 0x04
	int BP_GlobalTips_ColorID; // Offset: 0x4f8 // Size: 0x04
	bool BP_Global_IsResidentEvilNeedShow; // Offset: 0x4fc // Size: 0x01
	char pad_0x4FD[0x3]; // Offset: 0x4fd // Size: 0x03
	struct FString BP_GLOBAL_USE_ITEM; // Offset: 0x500 // Size: 0x10
	bool BP_HadPlayAnimation; // Offset: 0x510 // Size: 0x01
	char pad_0x511[0x3]; // Offset: 0x511 // Size: 0x03
	int BP_Global_Cur_Lobby_Skin_Id; // Offset: 0x514 // Size: 0x04
	bool BP_GlobalTips_IsShowCloseBtn; // Offset: 0x518 // Size: 0x01
	char pad_0x519[0x3]; // Offset: 0x519 // Size: 0x03
	int BP_BA_BUTTON_TYPE; // Offset: 0x51c // Size: 0x04
	struct FBP_STRUCT_GlobalHelpTips_Pos BP_STRUCT_GlobalHelpTips_Pos; // Offset: 0x520 // Size: 0x08
	struct FBP_STRUCT_GlobalTips_TimeInfo BP_STRUCT_GlobalTips_TimeInfo; // Offset: 0x528 // Size: 0x18
	bool BP_ShouldRequestChatPrivacy; // Offset: 0x540 // Size: 0x01
	struct FBP_STRUCT_NATION_SWITCH BP_STRUCT_NATION_SWITCH; // Offset: 0x541 // Size: 0x04
	bool BP_IsAppleAudit; // Offset: 0x545 // Size: 0x01
	char pad_0x546[0x2]; // Offset: 0x546 // Size: 0x02
	struct FString BP_Global_Url; // Offset: 0x548 // Size: 0x10
	int BP_GlobalTips_ItemID; // Offset: 0x558 // Size: 0x04
	int BP_StartUpType; // Offset: 0x55c // Size: 0x04
	bool BP_CHECK_MENU_OPEN_RESULT; // Offset: 0x560 // Size: 0x01
	char pad_0x561[0x3]; // Offset: 0x561 // Size: 0x03
	int BP_GlobalTips_ItemCount; // Offset: 0x564 // Size: 0x04
	int BP_Global_AvatarPreviewTarget; // Offset: 0x568 // Size: 0x04
	char pad_0x56C[0x4]; // Offset: 0x56c // Size: 0x04
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x570 // Size: 0x08

	// Functions

	// Object Name: Function bp_global.bp_global_C.EventSetInfo_Push_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSetInfo_Push_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSetInfo_Push
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSetInfo_Push(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventCheckEUChatRestriction_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCheckEUChatRestriction_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventCheckEUChatRestriction
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCheckEUChatRestriction(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventShowPlatIconTips_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowPlatIconTips_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventShowPlatIconTips
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowPlatIconTips(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSendClickGemReport_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSendClickGemReport_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSendClickGemReport
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSendClickGemReport(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGlobalShowItemTips_Push_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGlobalShowItemTips_Push_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGlobalShowItemTips_Push
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGlobalShowItemTips_Push(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventShowPlatWXStartup_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowPlatWXStartup_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventShowPlatWXStartup
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowPlatWXStartup(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventShowPlatQQStartup_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowPlatQQStartup_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventShowPlatQQStartup
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowPlatQQStartup(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventCheckIfMenuOpen_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCheckIfMenuOpen_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventCheckIfMenuOpen
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCheckIfMenuOpen(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventAndroidQuitGame_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventAndroidQuitGame_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventAndroidQuitGame
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventAndroidQuitGame(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGlobalUseItem_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGlobalUseItem_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGlobalUseItem
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGlobalUseItem(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventClickLobbyEventGemReport_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventClickLobbyEventGemReport_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventClickLobbyEventGemReport
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventClickLobbyEventGemReport(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSwitchLobbySkinCompleted_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSwitchLobbySkinCompleted_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSwitchLobbySkinCompleted
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSwitchLobbySkinCompleted(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSendBAReport_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSendBAReport_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSendBAReport
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSendBAReport(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGlobalCloseItemTips_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGlobalCloseItemTips_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGlobalCloseItemTips
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGlobalCloseItemTips(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventJumpUrl_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventJumpUrl_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventJumpUrl
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventJumpUrl(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGotoItemPreviewClick_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGotoItemPreviewClick_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGotoItemPreviewClick
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGotoItemPreviewClick(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSlapJumpUrl_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSlapJumpUrl_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSlapJumpUrl
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSlapJumpUrl(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventFetchInfo_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventFetchInfo_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventFetchInfo
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventFetchInfo(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGotoItemPreviewPress_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGotoItemPreviewPress_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGotoItemPreviewPress
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGotoItemPreviewPress(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventFetchNationSwitch_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventFetchNationSwitch_NoFetch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventFetchNationSwitch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventFetchNationSwitch(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)
};

