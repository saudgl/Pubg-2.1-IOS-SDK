#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_AliasCfg_type.BP_STRUCT_AliasCfg_type
// Size: 0xf8 // Inherited bytes: 0x00
struct FBP_STRUCT_AliasCfg_type {
	// Fields
	int AliasQuality_0_52D618C06710B4516E54A5DD02AC5C99; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString AliasName_2_0717FEC012DC0CA124E0DCA506CEE7F5; // Offset: 0x08 // Size: 0x10
	struct FString AliasEndTime_3_1AF0C8006D3B07E2734D00920255C4E5; // Offset: 0x18 // Size: 0x10
	int AliasType_27_5DE467003EB70E1E24E47DFC06C221A5; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString AliasDesc_5_4D37FE40140AA53B240D9F7006CD0D53; // Offset: 0x30 // Size: 0x10
	int AliasID_6_353C41C06C5EB41765F74FFE01C6CD74; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString AliasGetDesc_7_6CA02640759BC685737AF47B07D4C043; // Offset: 0x48 // Size: 0x10
	int AliasJumpUrl_26_4BCF12400900E8A91D7221120BB8306C; // Offset: 0x58 // Size: 0x04
	int AliasIsShow_9_36BAB5C036E4D0695B3693210EA959A7; // Offset: 0x5c // Size: 0x04
	int AliasSortWeight_10_2EB1228029C7B6FE2B0FB3AC0F19BAA4; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct FString AliasIconPath_11_012C44007A15BA423E8DD5FC09A5A5F8; // Offset: 0x68 // Size: 0x10
	struct FString AliasValidTime_13_68567E40184F9DCB7CB207720E958A45; // Offset: 0x78 // Size: 0x10
	struct FString AliasIconPathBig_28_6A4EE880765FA71E4C643DAD0A5F52A7; // Offset: 0x88 // Size: 0x10
	int AliasSubType_29_5D0C918043E47B58622B5B1800ABEC45; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
	struct FString AliasIconPathSmall_30_72E7A2401449F42D7EA8179D0F446E7C; // Offset: 0xa0 // Size: 0x10
	int PopupImmediately_31_3378E600334574401D124023021D8169; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04
	struct FString Material_32_17C52FC053A16C272D8413870638243C; // Offset: 0xb8 // Size: 0x10
	struct FString Model_33_246F604059C608314535BD6D0AB5B3FC; // Offset: 0xc8 // Size: 0x10
	struct FString Texture_34_371C4040275E2709305AB3CA0D26F635; // Offset: 0xd8 // Size: 0x10
	int AliasBroadCastTextID_35_372CA7C00E3146D349D1223800B8B3D4; // Offset: 0xe8 // Size: 0x04
	int AliasIsBroadCast_36_124F0A407ABF176D28F9F4A90992FD54; // Offset: 0xec // Size: 0x04
	int AliasParamID_37_21F03E006336ED5E2352BE670C942DF4; // Offset: 0xf0 // Size: 0x04
	int WarZoneType_38_5343DE006B9A53A0537B209D00F0EF05; // Offset: 0xf4 // Size: 0x04
};

