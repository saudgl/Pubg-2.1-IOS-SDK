#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GeometryCache.GeometryCache
// Size: 0x68 // Inherited bytes: 0x28
struct UGeometryCache : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct TArray<struct UMaterialInterface*> Materials; // Offset: 0x30 // Size: 0x10
	struct TArray<struct UGeometryCacheTrack*> Tracks; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x18]; // Offset: 0x50 // Size: 0x18
};

// Object Name: Class GeometryCache.GeometryCacheActor
// Size: 0x3e0 // Inherited bytes: 0x3d8
struct AGeometryCacheActor : AActor {
	// Fields
	struct UGeometryCacheComponent* GeometryCacheComponent; // Offset: 0x3d8 // Size: 0x08

	// Functions

	// Object Name: Function GeometryCache.GeometryCacheActor.GetGeometryCacheComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGeometryCacheComponent* GetGeometryCacheComponent(); // Offset: 0x1047d6288 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class GeometryCache.GeometryCacheComponent
// Size: 0x7a0 // Inherited bytes: 0x730
struct UGeometryCacheComponent : UMeshComponent {
	// Fields
	struct UGeometryCache* GeometryCache; // Offset: 0x728 // Size: 0x08
	bool bRunning; // Offset: 0x730 // Size: 0x01
	bool bLooping; // Offset: 0x731 // Size: 0x01
	float StartTimeOffset; // Offset: 0x734 // Size: 0x04
	float PlaybackSpeed; // Offset: 0x738 // Size: 0x04
	int NumTracks; // Offset: 0x73c // Size: 0x04
	float ElapsedTime; // Offset: 0x740 // Size: 0x04
	char pad_0x74A[0x56]; // Offset: 0x74a // Size: 0x56

	// Functions

	// Object Name: Function GeometryCache.GeometryCacheComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x1047d684c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GeometryCache.GeometryCacheComponent.SetStartTimeOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStartTimeOffset(float NewStartTimeOffset); // Offset: 0x1047d67d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GeometryCache.GeometryCacheComponent.SetPlaybackSpeed
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackSpeed(float NewPlaybackSpeed); // Offset: 0x1047d6754 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GeometryCache.GeometryCacheComponent.SetLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLooping(bool bNewLooping); // Offset: 0x1047d66d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCache.GeometryCacheComponent.SetGeometryCache
	// Flags: [Native|Public|BlueprintCallable]
	bool SetGeometryCache(struct UGeometryCache* NewGeomCache); // Offset: 0x1047d663c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function GeometryCache.GeometryCacheComponent.PlayReversedFromEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayReversedFromEnd(); // Offset: 0x1047d6628 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GeometryCache.GeometryCacheComponent.PlayReversed
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayReversed(); // Offset: 0x1047d6614 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GeometryCache.GeometryCacheComponent.PlayFromStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayFromStart(); // Offset: 0x1047d6600 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GeometryCache.GeometryCacheComponent.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Play(); // Offset: 0x1047d65ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GeometryCache.GeometryCacheComponent.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Pause(); // Offset: 0x1047d65d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GeometryCache.GeometryCacheComponent.IsPlayingReversed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlayingReversed(); // Offset: 0x1047d65a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCache.GeometryCacheComponent.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlaying(); // Offset: 0x1047d6570 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCache.GeometryCacheComponent.IsLooping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLooping(); // Offset: 0x1047d653c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCache.GeometryCacheComponent.GetStartTimeOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetStartTimeOffset(); // Offset: 0x1047d6508 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GeometryCache.GeometryCacheComponent.GetPlaybackSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetPlaybackSpeed(); // Offset: 0x1047d64d4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class GeometryCache.GeometryCacheTrack
// Size: 0x50 // Inherited bytes: 0x28
struct UGeometryCacheTrack : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 // Size: 0x28
};

// Object Name: Class GeometryCache.GeometryCacheTrack_FlipbookAnimation
// Size: 0x70 // Inherited bytes: 0x50
struct UGeometryCacheTrack_FlipbookAnimation : UGeometryCacheTrack {
	// Fields
	uint32_t NumMeshSamples; // Offset: 0x4c // Size: 0x04
	char pad_0x54[0x1c]; // Offset: 0x54 // Size: 0x1c

	// Functions

	// Object Name: Function GeometryCache.GeometryCacheTrack_FlipbookAnimation.AddMeshSample
	// Flags: [Final|Native|Public|HasOutParms]
	void AddMeshSample(struct FGeometryCacheMeshData& MeshData, float SampleTime); // Offset: 0x1047d6ff8 // Return & Params: Num(2) Size(0x54)
};

// Object Name: Class GeometryCache.GeometryCacheTrack_TransformAnimation
// Size: 0xa0 // Inherited bytes: 0x50
struct UGeometryCacheTrack_TransformAnimation : UGeometryCacheTrack {
	// Fields
	char pad_0x50[0x50]; // Offset: 0x50 // Size: 0x50

	// Functions

	// Object Name: Function GeometryCache.GeometryCacheTrack_TransformAnimation.SetMesh
	// Flags: [Final|Native|Public|HasOutParms]
	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Offset: 0x1047d7248 // Return & Params: Num(1) Size(0x50)
};

// Object Name: Class GeometryCache.GeometryCacheTrack_TransformGroupAnimation
// Size: 0xa0 // Inherited bytes: 0x50
struct UGeometryCacheTrack_TransformGroupAnimation : UGeometryCacheTrack {
	// Fields
	char pad_0x50[0x50]; // Offset: 0x50 // Size: 0x50

	// Functions

	// Object Name: Function GeometryCache.GeometryCacheTrack_TransformGroupAnimation.SetMesh
	// Flags: [Final|Native|Public|HasOutParms]
	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Offset: 0x1047d744c // Return & Params: Num(1) Size(0x50)
};

