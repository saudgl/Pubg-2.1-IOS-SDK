#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_PlayerRifleBulletDamageType.BP_PlayerRifleBulletDamageType_C
// Size: 0x40 // Inherited bytes: 0x40
struct UBP_PlayerRifleBulletDamageType_C : UDamageType {
};

