#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Basic.OnlyActorComponent
// Size: 0x118 // Inherited bytes: 0x110
struct UOnlyActorComponent : UActorComponent {
	// Fields
	char bCanEverUpdate; // Offset: 0x110 // Size: 0x01
	char pad_0x111[0x7]; // Offset: 0x111 // Size: 0x07
};

// Object Name: Class Basic.UAENetActor
// Size: 0x4b0 // Inherited bytes: 0x4a0
struct AUAENetActor : ALuaActor {
	// Fields
	char pad_0x4A0[0x8]; // Offset: 0x4a0 // Size: 0x08
	int iRegionActor; // Offset: 0x4a8 // Size: 0x04
	char pad_0x4AC[0x2]; // Offset: 0x4ac // Size: 0x02
	bool bStaticAddNetworkActor; // Offset: 0x4ae // Size: 0x01
	char pad_0x4AF[0x1]; // Offset: 0x4af // Size: 0x01
};

// Object Name: Class Basic.UAEAnimListComponentBase
// Size: 0x208 // Inherited bytes: 0x110
struct UUAEAnimListComponentBase : UActorComponent {
	// Fields
	char pad_0x110[0x68]; // Offset: 0x110 // Size: 0x68
	struct TMap<int, struct FAnimListMapValueData> AnimListMap; // Offset: 0x178 // Size: 0x50
	struct TArray<struct UAnimationAsset*> AnimationCatcheList; // Offset: 0x1c8 // Size: 0x10
	char pad_0x1D8[0x28]; // Offset: 0x1d8 // Size: 0x28
	bool bDisableAnimListOnDS; // Offset: 0x200 // Size: 0x01
	char pad_0x201[0x7]; // Offset: 0x201 // Size: 0x07
};

// Object Name: Class Basic.ItemHandleBase
// Size: 0xa8 // Inherited bytes: 0x28
struct UItemHandleBase : UObject {
	// Fields
	int Count; // Offset: 0x28 // Size: 0x04
	int MaxCount; // Offset: 0x2c // Size: 0x04
	bool bUnique; // Offset: 0x30 // Size: 0x01
	bool bStackable; // Offset: 0x31 // Size: 0x01
	bool bSingle; // Offset: 0x32 // Size: 0x01
	char pad_0x33[0x5]; // Offset: 0x33 // Size: 0x05
	struct TMap<struct FName, struct FItemAssociation> AssociationMap; // Offset: 0x38 // Size: 0x50
	struct FItemDefineID DefineID; // Offset: 0x88 // Size: 0x18
	char pad_0xA0[0x8]; // Offset: 0xa0 // Size: 0x08

	// Functions

	// Object Name: Function Basic.ItemHandleBase.SetAssociation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAssociation(struct FName Name, struct FItemAssociation Association); // Offset: 0x1035d68b8 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function Basic.ItemHandleBase.RemoveAssociation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveAssociation(struct FName Name); // Offset: 0x1035d683c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.ItemHandleBase.Init
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void Init(struct FItemDefineID InDefineID); // Offset: 0x1035d67a8 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Basic.ItemHandleBase.GetDefineID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FItemDefineID GetDefineID(); // Offset: 0x1035d6758 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Basic.ItemHandleBase.GetAssociationMap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TMap<struct FName, struct FItemAssociation> GetAssociationMap(); // Offset: 0x1035d66f4 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Basic.ItemHandleBase.GetAssociationListByTargetType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FItemAssociation> GetAssociationListByTargetType(int Type); // Offset: 0x1035d6640 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.ItemHandleBase.GetAssociationByTargetDefineID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FItemAssociation GetAssociationByTargetDefineID(struct FItemDefineID TargetDefineID); // Offset: 0x1035d6594 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Basic.ItemHandleBase.GetAssociation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FItemAssociation GetAssociation(struct FName Name); // Offset: 0x1035d64f8 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function Basic.ItemHandleBase.Constuct
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void Constuct(struct FItemDefineID& InDefineID); // Offset: 0x1035d6460 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Basic.ItemHandleBase.AddAssociation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddAssociation(struct FName Name, struct FItemAssociation Association); // Offset: 0x1035d6394 // Return & Params: Num(2) Size(0x30)
};

// Object Name: Class Basic.BattleItemHandleBase
// Size: 0x140 // Inherited bytes: 0xa8
struct UBattleItemHandleBase : UItemHandleBase {
	// Fields
	char pad_0xA8[0x60]; // Offset: 0xa8 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x108 // Size: 0x10
	bool bEquipping; // Offset: 0x118 // Size: 0x01
	enum class EItemStoreArea ItemStoreArea; // Offset: 0x119 // Size: 0x01
	char pad_0x11A[0x6]; // Offset: 0x11a // Size: 0x06
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // Offset: 0x120 // Size: 0x10
	bool bDropOnDead; // Offset: 0x130 // Size: 0x01
	char pad_0x131[0x3]; // Offset: 0x131 // Size: 0x03
	float UnitWeight; // Offset: 0x134 // Size: 0x04
	bool bEquippable; // Offset: 0x138 // Size: 0x01
	bool bConsumable; // Offset: 0x139 // Size: 0x01
	bool bAutoEquipAndDrop; // Offset: 0x13a // Size: 0x01
	char pad_0x13B[0x1]; // Offset: 0x13b // Size: 0x01
	int ItemAttrsFlag; // Offset: 0x13c // Size: 0x04

	// Functions

	// Object Name: Function Basic.BattleItemHandleBase.UpdateAttributeModify
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void UpdateAttributeModify(bool bEnable); // Offset: 0x1035cf730 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.BattleItemHandleBase.UnEquip
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool UnEquip(); // Offset: 0x1035cf6fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.BattleItemHandleBase.HanldePickupAssociationData
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool HanldePickupAssociationData(struct TArray<struct FBattleItemAdditionalData>& PickupAdditionalData); // Offset: 0x1035cf63c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.BattleItemHandleBase.HanldeDropAssociationData
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HanldeDropAssociationData(); // Offset: 0x1035cf600 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.BattleItemHandleBase.HanldeCleared
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HanldeCleared(); // Offset: 0x1035cf5c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.BattleItemHandleBase.HandleUse
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HandleUse(struct FBattleItemUseTarget Target, enum class EBattleItemUseReason Reason); // Offset: 0x1035cf4e4 // Return & Params: Num(3) Size(0x2a)

	// Object Name: Function Basic.BattleItemHandleBase.HandlePickup
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool HandlePickup(struct TScriptInterface<Class>& ItemContainer, struct FBattleItemPickupInfo pickupInfo, enum class EBattleItemPickupReason Reason); // Offset: 0x1035cf368 // Return & Params: Num(4) Size(0x6a)

	// Object Name: Function Basic.BattleItemHandleBase.HandleEnable
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HandleEnable(bool bEnable); // Offset: 0x1035cf2cc // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Basic.BattleItemHandleBase.HandleDrop
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HandleDrop(int InCount, enum class EBattleItemDropReason Reason); // Offset: 0x1035cf1fc // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Basic.BattleItemHandleBase.HandleDisuse
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HandleDisuse(enum class EBattleItemDisuseReason Reason); // Offset: 0x1035cf168 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Basic.BattleItemHandleBase.HandleChangeItemStoreArea
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HandleChangeItemStoreArea(enum class EItemStoreArea InItemStoreArea); // Offset: 0x1035cf0d4 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Basic.BattleItemHandleBase.HandleBindToTargetItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HandleBindToTargetItem(); // Offset: 0x1035cf098 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.BattleItemHandleBase.GetWorldInternal
	// Flags: [Native|Event|Protected|BlueprintEvent|Const]
	struct UWorld* GetWorldInternal(); // Offset: 0x1035cf05c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.BattleItemHandleBase.GetCurrentWorld
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWorld* GetCurrentWorld(); // Offset: 0x1035cf028 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.BattleItemHandleBase.ExtractItemData
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FBattleItemData ExtractItemData(); // Offset: 0x1035cefbc // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function Basic.BattleItemHandleBase.ClearAdditionalData
	// Flags: [Final|Native|Public]
	void ClearAdditionalData(); // Offset: 0x1035cefa8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.BattleItemHandleBase.CheckCanUse
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool CheckCanUse(struct TScriptInterface<Class>& ItemContainer, struct FBattleItemUseTarget Target, enum class EBattleItemUseReason Reason); // Offset: 0x1035cee78 // Return & Params: Num(4) Size(0x3a)
};

// Object Name: Class Basic.UAENetPoolActor
// Size: 0x4f8 // Inherited bytes: 0x4b0
struct AUAENetPoolActor : AUAENetActor {
	// Fields
	char pad_0x4B0[0x48]; // Offset: 0x4b0 // Size: 0x48

	// Functions

	// Object Name: Function Basic.UAENetPoolActor.OnBPRespawned
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnBPRespawned(); // Offset: 0x1035eec44 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAENetPoolActor.OnBPRecycled
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnBPRecycled(); // Offset: 0x1035eec28 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Basic.UAEBaseSkillCondition
// Size: 0x70 // Inherited bytes: 0x60
struct UUAEBaseSkillCondition : UUTSkillCondition {
	// Fields
	char pad_0x60[0x8]; // Offset: 0x60 // Size: 0x08
	struct APawn* OwnerPawnForBuff; // Offset: 0x68 // Size: 0x08
};

// Object Name: Class Basic.DataProviderBase
// Size: 0x28 // Inherited bytes: 0x28
struct UDataProviderBase : UObject {
};

// Object Name: Class Basic.STBuffAction
// Size: 0x48 // Inherited bytes: 0x28
struct USTBuffAction : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	float ExecuteDelay; // Offset: 0x30 // Size: 0x04
	int ArrayIndex; // Offset: 0x34 // Size: 0x04
	struct TWeakObjectPtr<struct USTBuff> OwnerBuff; // Offset: 0x38 // Size: 0x08
	struct UActorComponent* CurOwnerActorComponent; // Offset: 0x40 // Size: 0x08

	// Functions

	// Object Name: Function Basic.STBuffAction.Tick
	// Flags: [Final|Native|Public]
	void Tick(struct UActorComponent* BuffSystemComponent, float DetalTime); // Offset: 0x1035e3bc4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuffAction.SetEnabled
	// Flags: [Final|Native|Public]
	void SetEnabled(struct UActorComponent* BuffSystemComponent, bool Enabled); // Offset: 0x1035e3b04 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Basic.STBuffAction.ResetExecute
	// Flags: [Final|Native|Public]
	void ResetExecute(struct UActorComponent* BuffSystemComponent, bool IgnoreEnd); // Offset: 0x1035e3a44 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Basic.STBuffAction.OnTick
	// Flags: [Native|Protected]
	void OnTick(float DetalTime); // Offset: 0x1035e39c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.STBuffAction.OnResetExecute
	// Flags: [Native|Protected]
	void OnResetExecute(bool IgnoreEnd); // Offset: 0x1035e3934 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.STBuffAction.OnInitialize
	// Flags: [Native|Protected]
	void OnInitialize(); // Offset: 0x1035e3918 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction.OnExecute
	// Flags: [Native|Protected]
	void OnExecute(); // Offset: 0x1035e38fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction.OnEnd
	// Flags: [Native|Protected]
	void OnEnd(); // Offset: 0x1035e38e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction.OnDestroy
	// Flags: [Native|Protected]
	void OnDestroy(); // Offset: 0x1035e38c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction.OnCheckLinkActionEnabled
	// Flags: [Native|Protected]
	void OnCheckLinkActionEnabled(); // Offset: 0x1035e38a8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction.OnChangeNotify
	// Flags: [Native|Protected]
	void OnChangeNotify(); // Offset: 0x1035e388c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction.Initialize
	// Flags: [Final|Native|Public]
	void Initialize(struct UActorComponent* BuffSystemComponent); // Offset: 0x1035e3810 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffAction.GetOwner
	// Flags: [Final|Native|Protected]
	struct AActor* GetOwner(); // Offset: 0x1035e37dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffAction.GetCauser
	// Flags: [Final|Native|Protected]
	struct AActor* GetCauser(); // Offset: 0x1035e37a8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffAction.End
	// Flags: [Final|Native|Public]
	void End(struct UActorComponent* BuffSystemComponent); // Offset: 0x1035e372c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffAction.Destroy
	// Flags: [Final|Native|Public]
	void Destroy(struct UActorComponent* BuffSystemComponent); // Offset: 0x1035e36b0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffAction.CopyAction
	// Flags: [Native|Public]
	struct USTBuffAction* CopyAction(struct UObject* Outer); // Offset: 0x1035e361c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBuffAction.CheckLinkActionEnabled
	// Flags: [Final|Native|Public]
	void CheckLinkActionEnabled(struct UActorComponent* BuffSystemComponent); // Offset: 0x1035e35a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffAction.ChangeNotify
	// Flags: [Final|Native|Public]
	void ChangeNotify(struct UActorComponent* BuffSystemComponent); // Offset: 0x1035e3524 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Basic.STBuffCondition
// Size: 0x40 // Inherited bytes: 0x28
struct USTBuffCondition : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	enum class EBuffConditionAndOr AndOrPrev; // Offset: 0x30 // Size: 0x01
	bool IsKeepResult; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
	struct USTBuffAction* OwnerAction; // Offset: 0x38 // Size: 0x08

	// Functions

	// Object Name: Function Basic.STBuffCondition.OnInitialize
	// Flags: [Native|Protected]
	void OnInitialize(); // Offset: 0x1035e4d6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffCondition.OnDestroy
	// Flags: [Native|Protected]
	void OnDestroy(); // Offset: 0x1035e4d50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffCondition.GetOwner
	// Flags: [Final|Native|Protected]
	struct AActor* GetOwner(); // Offset: 0x1035e4d1c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffCondition.GetCauser
	// Flags: [Final|Native|Protected]
	struct AActor* GetCauser(); // Offset: 0x1035e4ce8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffCondition.Copy
	// Flags: [Native|Public]
	struct USTBuffCondition* Copy(struct UObject* Outer); // Offset: 0x1035e4c54 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBuffCondition.CheckIsTrue
	// Flags: [Native|Protected]
	bool CheckIsTrue(); // Offset: 0x1035e4c18 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Basic.STBaseBuffManager
// Size: 0x188 // Inherited bytes: 0x28
struct USTBaseBuffManager : UObject {
	// Fields
	struct TArray<struct FSTBaseBuffTemplateItem> BuffList; // Offset: 0x28 // Size: 0x10
	struct TArray<struct USTBaseBuffList*> BuffListTemplates; // Offset: 0x38 // Size: 0x10
	struct TMap<int, struct USTBaseBuff*> BuffInstancedTemplateMap; // Offset: 0x48 // Size: 0x50
	char pad_0x98[0xf0]; // Offset: 0x98 // Size: 0xf0
};

// Object Name: Class Basic.STBaseBuffStatusType
// Size: 0x28 // Inherited bytes: 0x28
struct USTBaseBuffStatusType : UObject {
};

// Object Name: Class Basic.STBaseBuffSystemComponent
// Size: 0x288 // Inherited bytes: 0x110
struct USTBaseBuffSystemComponent : UActorComponent {
	// Fields
	char pad_0x110[0x50]; // Offset: 0x110 // Size: 0x50
	struct FScriptMulticastDelegate OnBuffAttached; // Offset: 0x160 // Size: 0x10
	struct FScriptMulticastDelegate OnBuffDetached; // Offset: 0x170 // Size: 0x10
	char pad_0x180[0x58]; // Offset: 0x180 // Size: 0x58
	struct TArray<struct FUTBuffSynData> BuffSyncList; // Offset: 0x1d8 // Size: 0x10
	struct FString ServerBuffString; // Offset: 0x1e8 // Size: 0x10
	float BuffSyncRemainingPeriod; // Offset: 0x1f8 // Size: 0x04
	char pad_0x1FC[0x4]; // Offset: 0x1fc // Size: 0x04
	struct TArray<struct FBuffInstancedItem> AllBuffs; // Offset: 0x200 // Size: 0x10
	char pad_0x210[0x8]; // Offset: 0x210 // Size: 0x08
	bool isNeedCheckValidation; // Offset: 0x218 // Size: 0x01
	char pad_0x219[0x6f]; // Offset: 0x219 // Size: 0x6f

	// Functions

	// Object Name: Function Basic.STBaseBuffSystemComponent.SetBuffExpiry
	// Flags: [Final|Native|Public]
	bool SetBuffExpiry(struct FName BuffName, float ExpirySeconds); // Offset: 0x1035e22cc // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ResetForDeath
	// Flags: [Final|Native|Public]
	void ResetForDeath(); // Offset: 0x1035e22b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBaseBuffSystemComponent.RepBuffSyncList
	// Flags: [Final|Native|Public]
	void RepBuffSyncList(); // Offset: 0x1035e22a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBaseBuffSystemComponent.RemoveBuffWithCauser
	// Flags: [Final|Native|Public]
	bool RemoveBuffWithCauser(struct FName BuffName, bool RemoveLayerOnly, struct AController* pCauser); // Offset: 0x1035e2198 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Basic.STBaseBuffSystemComponent.RemoveBuffByID
	// Flags: [Final|Native|Public]
	bool RemoveBuffByID(int BuffID, bool RemoveLayerOnly, struct AController* pCauser, struct AActor* BuffApplierActor); // Offset: 0x1035e2054 // Return & Params: Num(5) Size(0x19)

	// Object Name: Function Basic.STBaseBuffSystemComponent.RemoveBuff
	// Flags: [Final|Native|Public]
	bool RemoveBuff(struct FName BuffName, bool RemoveLayerOnly, struct AActor* BuffApplierActor); // Offset: 0x1035e1f48 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Basic.STBaseBuffSystemComponent.RefreshAllBuffs
	// Flags: [Native|Public]
	void RefreshAllBuffs(); // Offset: 0x1035e1f2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBaseBuffSystemComponent.IsBufferMutexed
	// Flags: [Final|Native|Public]
	bool IsBufferMutexed(struct FName NewBuffName); // Offset: 0x1035e1ea0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Basic.STBaseBuffSystemComponent.HasBuffID
	// Flags: [Final|Native|Public]
	bool HasBuffID(int BuffID); // Offset: 0x1035e1e14 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.STBaseBuffSystemComponent.HasBuff
	// Flags: [Final|Native|Public]
	bool HasBuff(struct FName BuffName); // Offset: 0x1035e1d88 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Basic.STBaseBuffSystemComponent.GetPawnOwner
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APawn* GetPawnOwner(); // Offset: 0x1035e1d54 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBaseBuffSystemComponent.GetBuffName
	// Flags: [Final|Native|Public]
	struct FName GetBuffName(int BuffID); // Offset: 0x1035e1cc8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBaseBuffSystemComponent.GetBuffID
	// Flags: [Final|Native|Public]
	int GetBuffID(struct FName BuffName); // Offset: 0x1035e1c3c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBaseBuffSystemComponent.GetBuffExpiry
	// Flags: [Final|Native|Public|HasOutParms]
	float GetBuffExpiry(struct FName& BuffName); // Offset: 0x1035e1ba0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBaseBuffSystemComponent.GetBuffByName
	// Flags: [Final|Native|Public]
	struct USTBaseBuff* GetBuffByName(struct FName BuffName); // Offset: 0x1035e1b14 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBaseBuffSystemComponent.GetActorOwner
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetActorOwner(); // Offset: 0x1035e1ae0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ClientSimulateRemoveBuff
	// Flags: [Final|Native|Public]
	void ClientSimulateRemoveBuff(struct FName BuffName, bool RemoveLayerOnly, struct AActor* BuffApplierActor); // Offset: 0x1035e19dc // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ClientSimulateAddBuff
	// Flags: [Final|Native|Public]
	void ClientSimulateAddBuff(struct FName BuffName, struct AController* BuffCauser, int LayerCount, struct AActor* BuffApplierActor); // Offset: 0x1035e18b0 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ClientMulticastSimulateRemoveBuff
	// Flags: [Final|Native|Public]
	void ClientMulticastSimulateRemoveBuff(struct FName BuffName, bool RemoveLayerOnly, struct AActor* BuffApplierActor); // Offset: 0x1035e17ac // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ClientMulticastSimulateAddBuff
	// Flags: [Final|Native|Public]
	void ClientMulticastSimulateAddBuff(struct FName BuffName, struct AController* BuffCauser, int LayerCount, struct AActor* BuffApplierActor); // Offset: 0x1035e1680 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ClientMulticastSetBuffExpiry
	// Flags: [Final|Native|Public]
	void ClientMulticastSetBuffExpiry(struct FName BuffName, float LeftSecondsAfterNow); // Offset: 0x1035e15c8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ClearBuff
	// Flags: [Final|Native|Public]
	void ClearBuff(bool bDebuff, bool bGainBuff); // Offset: 0x1035e14f8 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Basic.STBaseBuffSystemComponent.CheckBuffStatus
	// Flags: [Final|Native|Public|HasOutParms]
	bool CheckBuffStatus(struct USTBaseBuffStatusType* Status, bool& Value); // Offset: 0x1035e1420 // Return & Params: Num(3) Size(0xa)

	// Object Name: DelegateFunction Basic.STBaseBuffSystemComponent.BuffDetached__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void BuffDetached__DelegateSignature(struct FName& BuffName); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction Basic.STBaseBuffSystemComponent.BuffAttached__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void BuffAttached__DelegateSignature(struct FName& BuffName); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBaseBuffSystemComponent.AddBuffLayer
	// Flags: [Final|Native|Public]
	bool AddBuffLayer(struct FName BuffName, int layerNum); // Offset: 0x1035e1358 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBaseBuffSystemComponent.AddBuffExpiry
	// Flags: [Final|Native|Public]
	bool AddBuffExpiry(struct FName BuffName, float ExpirySeconds); // Offset: 0x1035e1290 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBaseBuffSystemComponent.AddBuffByID
	// Flags: [Native|Public]
	int AddBuffByID(int BuffID, struct AController* BuffCauser, int LayerCount, struct AActor* BuffApplierActor); // Offset: 0x1035e1148 // Return & Params: Num(5) Size(0x24)

	// Object Name: Function Basic.STBaseBuffSystemComponent.AddBuff
	// Flags: [Final|Native|Public]
	int AddBuff(struct FName BuffName, struct AController* BuffCauser, int LayerCount, struct AActor* BuffApplierActor, struct AActor* CauserActor); // Offset: 0x1035e0fd4 // Return & Params: Num(6) Size(0x2c)
};

// Object Name: Class Basic.STBaseBuffTriggerParam
// Size: 0x30 // Inherited bytes: 0x28
struct USTBaseBuffTriggerParam : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class Basic.UAEGameInstance
// Size: 0x490 // Inherited bytes: 0x2a0
struct UUAEGameInstance : UGameInstance {
	// Fields
	struct FClientBaseInfo ClientBaseInfo; // Offset: 0x2a0 // Size: 0x128
	struct FScriptMulticastDelegate EnginePreTick; // Offset: 0x3c8 // Size: 0x10
	char pad_0x3D8[0x50]; // Offset: 0x3d8 // Size: 0x50
	struct UFrontendHUD* AssociatedFrontendHUD; // Offset: 0x428 // Size: 0x08
	char pad_0x430[0x8]; // Offset: 0x430 // Size: 0x08
	struct ULuaStateWrapper* LuaStateWrapper; // Offset: 0x438 // Size: 0x08
	bool bStandAloneFromLobby; // Offset: 0x440 // Size: 0x01
	char pad_0x441[0x27]; // Offset: 0x441 // Size: 0x27
	struct FScriptMulticastDelegate OnPreBattleResult; // Offset: 0x468 // Size: 0x10
	struct TArray<struct FString> HighWeatherNames; // Offset: 0x478 // Size: 0x10
	int HighWeatherMinRenderQuality; // Offset: 0x488 // Size: 0x04
	int HighWeatherMaxRenderQuality; // Offset: 0x48c // Size: 0x04

	// Functions

	// Object Name: Function Basic.UAEGameInstance.SetLuaStateWrapper
	// Flags: [Final|Native|Public]
	void SetLuaStateWrapper(struct ULuaStateWrapper* TLuaStateWrapper); // Offset: 0x1035ebbc8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.UAEGameInstance.OpenAssetLoadLog
	// Flags: [Final|Exec|Native|Public]
	void OpenAssetLoadLog(); // Offset: 0x1035ebbb4 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Basic.UAEGameInstance.OnPreBattleResult__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnPreBattleResult__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAEGameInstance.LuaLeakDetect
	// Flags: [Final|Exec|Native|Public|Const]
	void LuaLeakDetect(); // Offset: 0x1035ebba0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAEGameInstance.LuaDoString
	// Flags: [Final|Exec|Native|Public|Const]
	void LuaDoString(struct FString LuaString); // Offset: 0x1035ebb08 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UAEGameInstance.GetWeatherTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetWeatherTime(); // Offset: 0x1035ebaec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.UAEGameInstance.GetWeatherLevelName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetWeatherLevelName(); // Offset: 0x1035eba84 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UAEGameInstance.GetWeatherID
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetWeatherID(); // Offset: 0x1035eba68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.UAEGameInstance.GetLuaStateWrapper
	// Flags: [Final|Native|Public]
	struct ULuaStateWrapper* GetLuaStateWrapper(); // Offset: 0x1035eba34 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.UAEGameInstance.GetLoadWeatherName
	// Flags: [Native|Public|BlueprintCallable]
	struct FString GetLoadWeatherName(struct FString InWeatherName); // Offset: 0x1035eb95c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Basic.UAEGameInstance.GetIsHighWeatherLevel
	// Flags: [Native|Public|BlueprintCallable]
	bool GetIsHighWeatherLevel(struct FString InWeatherLevelName); // Offset: 0x1035eb8ac // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.UAEGameInstance.GetGameId
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetGameId(); // Offset: 0x1035eb838 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UAEGameInstance.GetDeviceLevel
	// Flags: [Native|Public|BlueprintCallable]
	int GetDeviceLevel(); // Offset: 0x1035eb7fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.UAEGameInstance.GetDataTable_Mod
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEDataTable* GetDataTable_Mod(struct FString tableName); // Offset: 0x1035eb754 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAEGameInstance.GetDataTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEDataTable* GetDataTable(struct FString tableName); // Offset: 0x1035eb6ac // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAEGameInstance.GetAssociatedFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendHUD* GetAssociatedFrontendHUD(); // Offset: 0x1035eb678 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.UAEGameInstance.CloseAssetLoadLog
	// Flags: [Final|Exec|Native|Public]
	void CloseAssetLoadLog(); // Offset: 0x1035eb664 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Basic.AttrModifyComponent
// Size: 0x6c8 // Inherited bytes: 0x110
struct UAttrModifyComponent : UActorComponent {
	// Fields
	char pad_0x110[0x50]; // Offset: 0x110 // Size: 0x50
	struct FScriptMulticastDelegate OnAttrModified; // Offset: 0x160 // Size: 0x10
	uint32_t AttrModifyStateList; // Offset: 0x170 // Size: 0x04
	char pad_0x174[0x4]; // Offset: 0x174 // Size: 0x04
	struct FRepAttributeModify DynamicModifierRep; // Offset: 0x178 // Size: 0x18
	struct FRepAttributeModify DynamicModifierRepOnlyOwner; // Offset: 0x190 // Size: 0x18
	char pad_0x1A8[0x18]; // Offset: 0x1a8 // Size: 0x18
	struct TArray<struct FAttrModifyItem> ConfigAttrModifyList; // Offset: 0x1c0 // Size: 0x10
	char pad_0x1D0[0x1c8]; // Offset: 0x1d0 // Size: 0x1c8
	struct TArray<struct FAttributeExpand> AttributeExpands; // Offset: 0x398 // Size: 0x10
	struct FAttrDynamicModifier DynamicModifier; // Offset: 0x3a8 // Size: 0xa8
	struct TMap<struct FString, struct FRelateAttributeGroup> RelateAttributeGroup; // Offset: 0x450 // Size: 0x50
	enum class EActorRegAttrTableType ActorAttrType; // Offset: 0x4a0 // Size: 0x01
	char pad_0x4A1[0x10f]; // Offset: 0x4a1 // Size: 0x10f
	struct TArray<struct FModAttrSimulateSyncItem> ModSimulateSyncList; // Offset: 0x5b0 // Size: 0x10
	char pad_0x5C0[0x108]; // Offset: 0x5c0 // Size: 0x108

	// Functions

	// Object Name: Function Basic.AttrModifyComponent.SetValueToAttributeSafety
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetValueToAttributeSafety(struct FString AttrName, float Value); // Offset: 0x1035cc634 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.SetOrignalValueToAttribute
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOrignalValueToAttribute(struct FString AttrName, float Value); // Offset: 0x1035cc55c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.SetAttrModifyStateValue
	// Flags: [Final|Native|Public]
	void SetAttrModifyStateValue(int Index, bool Value); // Offset: 0x1035cc4a0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.AttrModifyComponent.SetAttributeMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAttributeMaxValue(struct FString AttrName, float MaxValue); // Offset: 0x1035cc3c8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.ResponeAttrValue
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	void ResponeAttrValue(struct FString AttrName, float FinalValue); // Offset: 0x1035cc2bc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.RequestAttrValue
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void RequestAttrValue(struct FString AttrName); // Offset: 0x1035cc1f4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.AttrModifyComponent.RemoveDynamicModifyItemForLua
	// Flags: [Final|Native|Public]
	void RemoveDynamicModifyItemForLua(uint32_t ModifyUID); // Offset: 0x1035cc178 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.AttrModifyComponent.RegisterModifyAbleAttr
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool RegisterModifyAbleAttr(struct TArray<struct FAttrRegisterItem>& AttrRegists, bool bSetAttrByOrigin); // Offset: 0x1035cc074 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Basic.AttrModifyComponent.OnRep_ModSimulateSyncList
	// Flags: [Final|Native|Public]
	void OnRep_ModSimulateSyncList(); // Offset: 0x1035cc060 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.AttrModifyComponent.OnRep_DynamicModifier
	// Flags: [Final|Native|Private]
	void OnRep_DynamicModifier(); // Offset: 0x1035cc04c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.AttrModifyComponent.OnRep_AttrModifyStateList
	// Flags: [Final|Native|Private]
	void OnRep_AttrModifyStateList(); // Offset: 0x1035cc038 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Basic.AttrModifyComponent.OnAttrModifiedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnAttrModifiedEvent__DelegateSignature(struct TArray<struct FAttrAffected>& AffectedAttrS); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.AttrModifyComponent.IsAttrModifyStateValidIndex
	// Flags: [Final|Native|Public]
	bool IsAttrModifyStateValidIndex(int Index); // Offset: 0x1035cbfac // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.AttrModifyComponent.HasDynamicModifier
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasDynamicModifier(struct FString AttrModifyId); // Offset: 0x1035cbf04 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.AttrModifyComponent.GetSubsystem
	// Flags: [Final|Native|Public]
	struct UAttrModifyModDataSubsystem* GetSubsystem(); // Offset: 0x1035cbed0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.AttrModifyComponent.GetMaxAttrName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetMaxAttrName(struct FString AttrName); // Offset: 0x1035cbe00 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Basic.AttrModifyComponent.GetAttrModifyStateValue
	// Flags: [Final|Native|Public]
	bool GetAttrModifyStateValue(int Index); // Offset: 0x1035cbd74 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.AttrModifyComponent.GetAttrModifyStateNum
	// Flags: [Final|Native|Public]
	int GetAttrModifyStateNum(); // Offset: 0x1035cbd58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.AttrModifyComponent.GetAttrModifyItemByItemName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FAttrModifyItem GetAttrModifyItemByItemName(struct FString ItemName); // Offset: 0x1035cbc64 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Basic.AttrModifyComponent.GetAttributeValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAttributeValue(struct FString AttrName); // Offset: 0x1035cbbbc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.GetAttributeOrignalValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAttributeOrignalValue(struct FString AttrName); // Offset: 0x1035cbb14 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.EnableAttrModifierByIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool EnableAttrModifierByIndex(int ModifyConfigIndex); // Offset: 0x1035cba88 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.AttrModifyComponent.EnableAttrModifier
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool EnableAttrModifier(struct FString AttrModifyItemName); // Offset: 0x1035cb9bc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.AttrModifyComponent.DisableAttrModifierByIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool DisableAttrModifierByIndex(int ModifyConfigIndex); // Offset: 0x1035cb930 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.AttrModifyComponent.DisableAttrModifier
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool DisableAttrModifier(struct FString AttrModifyItemName); // Offset: 0x1035cb864 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.AttrModifyComponent.DisableAllAttrModifier
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool DisableAllAttrModifier(); // Offset: 0x1035cb830 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.AttrModifyComponent.AddValueToAttribute
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddValueToAttribute(struct FString AttrName, float Value); // Offset: 0x1035cb758 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.AddDynamicModifyItemForLua
	// Flags: [Final|Native|Public]
	uint32_t AddDynamicModifyItemForLua(struct FString AttrName, char ModifyType, float Value, bool bEnable, struct UObject* Causer); // Offset: 0x1035cb5a8 // Return & Params: Num(6) Size(0x2c)

	// Object Name: Function Basic.AttrModifyComponent.AddDynamicModifyForLua
	// Flags: [Final|Native|Public]
	uint32_t AddDynamicModifyForLua(struct FString AttrName, char ModifyType, float Value); // Offset: 0x1035cb480 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function Basic.AttrModifyComponent.AddDynamicModifier
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AddDynamicModifier(struct FAttrModifyItem& AttrModifyItem, bool RepOnlyOwner); // Offset: 0x1035cb380 // Return & Params: Num(2) Size(0x49)
};

// Object Name: Class Basic.AttrModifyInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UAttrModifyInterface : UInterface {
	// Functions

	// Object Name: Function Basic.AttrModifyInterface.SetAttrValue
	// Flags: [Native|Public|BlueprintCallable]
	void SetAttrValue(struct FString AttrName, float NewVal, int Reason); // Offset: 0x1035cd3e4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Basic.AttrModifyInterface.RequestAttrValue
	// Flags: [Native|Public|BlueprintCallable]
	void RequestAttrValue(struct FString AttrName); // Offset: 0x1035cd344 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.AttrModifyInterface.RegisterModifiedAttributes
	// Flags: [Native|Public|BlueprintCallable]
	void RegisterModifiedAttributes(); // Offset: 0x1035cd328 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.AttrModifyInterface.GetAttrValue
	// Flags: [Native|Public|BlueprintCallable]
	float GetAttrValue(struct FString AttrName); // Offset: 0x1035cd278 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyInterface.GetAttrModifyRelevantActors
	// Flags: [Native|Public|BlueprintCallable]
	struct TArray<struct AActor*> GetAttrModifyRelevantActors(); // Offset: 0x1035cd20c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.AttrModifyInterface.GetAttrModifyComponent
	// Flags: [Native|Public|BlueprintCallable]
	struct UAttrModifyComponent* GetAttrModifyComponent(); // Offset: 0x1035cd1d0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.AttrModifyInterface.GetAttributeValue
	// Flags: [Native|Public|BlueprintCallable]
	float GetAttributeValue(struct FString AttrName); // Offset: 0x1035cd120 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyInterface.AddAttrValue
	// Flags: [Native|Public|BlueprintCallable]
	void AddAttrValue(struct FString AttrName, float AddVal, int Reason); // Offset: 0x1035cd000 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class Basic.AttrModifyModDataSubsystem
// Size: 0x188 // Inherited bytes: 0x30
struct UAttrModifyModDataSubsystem : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x158]; // Offset: 0x30 // Size: 0x158
};

// Object Name: Class Basic.BlueprintFunctionOverride
// Size: 0x98 // Inherited bytes: 0x28
struct UBlueprintFunctionOverride : UBlueprintFunctionLibrary {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x88 // Size: 0x10
};

// Object Name: Class Basic.BPClassManager
// Size: 0x190 // Inherited bytes: 0x30
struct UBPClassManager : UDataAsset {
	// Fields
	struct TArray<struct FBPClassItem> BPClassList; // Offset: 0x30 // Size: 0x10
	struct TMap<struct UObject*, struct UClass*> BPClassLookUp; // Offset: 0x40 // Size: 0x50
	struct TMap<struct UObject*, struct FBPClassItemMap> BPClassLookUpOverride; // Offset: 0x90 // Size: 0x50
	struct TMap<struct FString, struct UClass*> BPClassNameLookUp; // Offset: 0xe0 // Size: 0x50
	struct TMap<struct FString, struct FBPClassItemMap> BPClassNameLookUpOverride; // Offset: 0x130 // Size: 0x50
	struct FString BPClassManagerPath; // Offset: 0x180 // Size: 0x10

	// Functions

	// Object Name: Function Basic.BPClassManager.ModifyClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ModifyClass(struct UObject* InNativeClass, struct UClass* BPClass, struct FString ModTag); // Offset: 0x1035d53c8 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function Basic.BPClassManager.GetUClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetUClass(int KeyIndex); // Offset: 0x1035d533c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.BPClassManager.GetBPClassOverrideByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetBPClassOverrideByName(struct FString ClassTagName, struct FString ModTag); // Offset: 0x1035d51f8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Basic.BPClassManager.GetBPClassOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetBPClassOverride(struct UObject* InNativeClass, struct FString ModTag); // Offset: 0x1035d50ec // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Basic.BPClassManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UBPClassManager* Get(); // Offset: 0x1035d50b8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Basic.DataSearcherInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UDataSearcherInterface : UInterface {
};

// Object Name: Class Basic.DelayReplicationInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UDelayReplicationInterface : UInterface {
	// Functions

	// Object Name: Function Basic.DelayReplicationInterface.ReSendRPCAfterBeginPlay
	// Flags: [Native|Public|BlueprintCallable]
	void ReSendRPCAfterBeginPlay(); // Offset: 0x1035d5a6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.DelayReplicationInterface.ReCallRepAfterBeginPlay
	// Flags: [Native|Public|BlueprintCallable]
	void ReCallRepAfterBeginPlay(); // Offset: 0x1035d5a50 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Basic.FeatureSetDefine
// Size: 0x28 // Inherited bytes: 0x28
struct UFeatureSetDefine : UObject {
};

// Object Name: Class Basic.PathCompressionRef
// Size: 0x58 // Inherited bytes: 0x30
struct UPathCompressionRef : UDataAsset {
	// Fields
	struct FString Dict; // Offset: 0x30 // Size: 0x10
	struct FSoftObjectPath DataTableRef; // Offset: 0x40 // Size: 0x18
};

// Object Name: Class Basic.GameModeEnvInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UGameModeEnvInterface : UInterface {
};

// Object Name: Class Basic.ItemContainerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UItemContainerInterface : UInterface {
	// Functions

	// Object Name: Function Basic.ItemContainerInterface.GetOwningObject
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetOwningObject(); // Offset: 0x1035d70d0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.ItemContainerInterface.GetItemHandleListByDefineID
	// Flags: [Native|Public|BlueprintCallable]
	struct TArray<struct UItemHandleBase*> GetItemHandleListByDefineID(struct FItemDefineID DefineID); // Offset: 0x1035d7004 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function Basic.ItemContainerInterface.GetItemHandleByDefineID
	// Flags: [Native|Public|BlueprintCallable]
	struct UItemHandleBase* GetItemHandleByDefineID(struct FItemDefineID DefineID); // Offset: 0x1035d6f60 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Basic.ItemContainerInterface.GetItemDefineIDList
	// Flags: [Native|Public|BlueprintCallable]
	struct TArray<struct FItemDefineID> GetItemDefineIDList(); // Offset: 0x1035d6ef4 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Basic.ItemFactoryInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UItemFactoryInterface : UInterface {
};

// Object Name: Class Basic.LuaEventBridgeFunction
// Size: 0x28 // Inherited bytes: 0x28
struct ULuaEventBridgeFunction : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Basic.LuaEventBridgeFunction.UnRegisterEventByTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UnRegisterEventByTarget(struct UObject* ObjContext); // Offset: 0x1035d7b44 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.LuaEventBridgeFunction.UnRegisterEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UnRegisterEvent(struct FString FEventType, struct FString EventId, struct UObject* ObjContext); // Offset: 0x1035d7a20 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Basic.LuaEventBridgeFunction.RegistEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RegistEvent(struct FString EventType, struct FString EventId, struct UObject* ObjContext, struct FString FunctionName); // Offset: 0x1035d78a8 // Return & Params: Num(4) Size(0x38)
};

// Object Name: Class Basic.LuaEventBridge
// Size: 0x158 // Inherited bytes: 0x28
struct ULuaEventBridge : UObject {
	// Fields
	struct TWeakObjectPtr<struct ULuaStateWrapper> LuaStateWrapper; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x8]; // Offset: 0x30 // Size: 0x08
	struct TMap<struct FString, struct FEventTypeContainer> RegisterEventMap; // Offset: 0x38 // Size: 0x50
	struct TMap<struct FString, struct FLuaEventTypeContainer> LuaRegisterEventMap; // Offset: 0x88 // Size: 0x50
	struct TMap<uint32_t, struct FLuaEventTypeToIDSet> FilterKeyRegisterMap; // Offset: 0xd8 // Size: 0x50
	struct TArray<struct ULuaTemBPData*> CurrentParamArray; // Offset: 0x128 // Size: 0x10
	struct TArray<struct UProperty*> Params; // Offset: 0x138 // Size: 0x10
	char pad_0x148[0x10]; // Offset: 0x148 // Size: 0x10

	// Functions

	// Object Name: Function Basic.LuaEventBridge.SyncLuaRegisterEventNum
	// Flags: [Final|Native|Public]
	void SyncLuaRegisterEventNum(struct FString EventType, struct FString EventId, int Number); // Offset: 0x1035d8170 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Basic.LuaEventBridge.GetCurrentParam
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct ULuaTemBPData*> GetCurrentParam(); // Offset: 0x1035d8138 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.LuaEventBridge.DeactivateEventsByFilterKey
	// Flags: [Final|Native|Public|HasOutParms]
	void DeactivateEventsByFilterKey(uint32_t& FilterKey); // Offset: 0x1035d80ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.LuaEventBridge.CheckNeedPostEventWithFilterKey
	// Flags: [Final|Native|Public|HasOutParms]
	bool CheckNeedPostEventWithFilterKey(uint32_t& FilterKey, struct FString EventType, struct FString EventId, bool bCheckNeedPostLua); // Offset: 0x1035d7f18 // Return & Params: Num(5) Size(0x2a)

	// Object Name: Function Basic.LuaEventBridge.ActiveEventByFilterKey
	// Flags: [Final|Native|Public|HasOutParms]
	void ActiveEventByFilterKey(uint32_t& FilterKey, struct FString EventType, struct FString EventId, bool bActive); // Offset: 0x1035d7d8c // Return & Params: Num(4) Size(0x29)
};

// Object Name: Class Basic.ModTable
// Size: 0x120 // Inherited bytes: 0x28
struct UModTable : UObject {
	// Fields
	char pad_0x28[0xf8]; // Offset: 0x28 // Size: 0xf8
};

// Object Name: Class Basic.NetRelevancyGroup
// Size: 0x60 // Inherited bytes: 0x28
struct UNetRelevancyGroup : UObject {
	// Fields
	struct FNetRelevancyGroupID GroupID; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct UUAENetConnection*> Connections; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x20]; // Offset: 0x40 // Size: 0x20
};

// Object Name: Class Basic.OnlyActorCompManagerComponent
// Size: 0x170 // Inherited bytes: 0x110
struct UOnlyActorCompManagerComponent : UActorComponent {
	// Fields
	struct TMap<struct FString, struct UOnlyActorComponent*> CacheComponents; // Offset: 0x110 // Size: 0x50
	struct TArray<struct UOnlyActorComponent*> CacheUpdateComponents; // Offset: 0x160 // Size: 0x10
};

// Object Name: Class Basic.OnlyActorComponentManagerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UOnlyActorComponentManagerInterface : UInterface {
};

// Object Name: Class Basic.OwnerRelevancyDependencyInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UOwnerRelevancyDependencyInterface : UInterface {
};

// Object Name: Class Basic.RenderFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct URenderFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Basic.RenderFunctionLibrary.MarkComponentRenderStateDirty
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MarkComponentRenderStateDirty(struct UActorComponent* Comp); // Offset: 0x1035d8cec // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Basic.STBaseBuff
// Size: 0x198 // Inherited bytes: 0x28
struct USTBaseBuff : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
	struct FString BuffName; // Offset: 0x38 // Size: 0x10
	struct FString DisplayName; // Offset: 0x48 // Size: 0x10
	struct FString Message; // Offset: 0x58 // Size: 0x10
	struct UTexture2D* Icon; // Offset: 0x68 // Size: 0x08
	struct USoundBase* SoundData; // Offset: 0x70 // Size: 0x08
	bool IsDeBuff; // Offset: 0x78 // Size: 0x01
	bool IgnoreMagicalImmunity; // Offset: 0x79 // Size: 0x01
	bool bAllowOtherPawnRefreshBuff; // Offset: 0x7a // Size: 0x01
	bool Layerable; // Offset: 0x7b // Size: 0x01
	bool NeedDetachAndAttachForReplaceExit; // Offset: 0x7c // Size: 0x01
	bool NeedDetachAndAttachForAddLayer; // Offset: 0x7d // Size: 0x01
	bool ReplaceExsist; // Offset: 0x7e // Size: 0x01
	bool StaysOnDeath; // Offset: 0x7f // Size: 0x01
	int LayerMax; // Offset: 0x80 // Size: 0x04
	int InitialLayerCount; // Offset: 0x84 // Size: 0x04
	int LayerCount; // Offset: 0x88 // Size: 0x04
	float ValidityTime; // Offset: 0x8c // Size: 0x04
	float Internal; // Offset: 0x90 // Size: 0x04
	char pad_0x94[0x4]; // Offset: 0x94 // Size: 0x04
	struct TArray<struct UUTSkillCondition*> BuffConditions; // Offset: 0x98 // Size: 0x10
	float Expiry; // Offset: 0xa8 // Size: 0x04
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct TArray<struct FStatusChange> StatusChanges; // Offset: 0xb0 // Size: 0x10
	bool NeedSimulateToClientMulticast; // Offset: 0xc0 // Size: 0x01
	bool NeedSimulateToClient; // Offset: 0xc1 // Size: 0x01
	enum class ESimulateAddBuffRole SimulateAddBuffRole; // Offset: 0xc2 // Size: 0x01
	char pad_0xC3[0x5]; // Offset: 0xc3 // Size: 0x05
	struct TArray<struct FName> MutexBuffers; // Offset: 0xc8 // Size: 0x10
	struct TArray<struct FBuffActionItem> BuffActions; // Offset: 0xd8 // Size: 0x10
	struct TArray<struct FBuffEventActionItem> EventBuffActions; // Offset: 0xe8 // Size: 0x10
	float fADScale; // Offset: 0xf8 // Size: 0x04
	float fAPScale; // Offset: 0xfc // Size: 0x04
	bool IsAlwaysExists; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x7]; // Offset: 0x101 // Size: 0x07
	struct AController* CauserPawnController; // Offset: 0x108 // Size: 0x08
	struct AActor* CauserPawnActor; // Offset: 0x110 // Size: 0x08
	char pad_0x118[0x10]; // Offset: 0x118 // Size: 0x10
	struct TArray<struct FUAEBlackboardParameter> UAEBlackboardParamList; // Offset: 0x128 // Size: 0x10
	struct AActor* BuffApplier; // Offset: 0x138 // Size: 0x08
	struct TMap<struct UObject*, int> InstancedNodeNameToMemoryMap; // Offset: 0x140 // Size: 0x50
	int InstancedNodesTotalSize; // Offset: 0x190 // Size: 0x04
	char pad_0x194[0x4]; // Offset: 0x194 // Size: 0x04
};

// Object Name: Class Basic.STBaseBuffCarrierInterface
// Size: 0x28 // Inherited bytes: 0x28
struct USTBaseBuffCarrierInterface : UInterface {
	// Functions

	// Object Name: Function Basic.STBaseBuffCarrierInterface.SyncInvincibleData
	// Flags: [Native|Public]
	void SyncInvincibleData(float TotalTime); // Offset: 0x1035da080 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.SetBuffExpiry
	// Flags: [Native|Public]
	bool SetBuffExpiry(struct FName BuffName, float ExpirySecondsFromNow); // Offset: 0x1035d9fb0 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.RemoveBuffBySkill
	// Flags: [Native|Public]
	bool RemoveBuffBySkill(int SkillID, int LayerCount, struct AActor* Causer); // Offset: 0x1035d9ea8 // Return & Params: Num(4) Size(0x11)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.RemoveBuffByID
	// Flags: [Native|Public]
	bool RemoveBuffByID(int BuffID, struct AActor* Causer, int LayerCount, int CauseSkillID); // Offset: 0x1035d9d64 // Return & Params: Num(5) Size(0x19)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.RemoveBuff
	// Flags: [Native|Public]
	bool RemoveBuff(struct FName BuffName, bool RemoveLayerOnly, struct AActor* BuffApplierActor); // Offset: 0x1035d9c50 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.IsSameTeamWithFirstPC
	// Flags: [Native|Public]
	bool IsSameTeamWithFirstPC(); // Offset: 0x1035d9c14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.HasBuffID
	// Flags: [Native|Public]
	bool HasBuffID(int BuffID); // Offset: 0x1035d9b80 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.HasBuff
	// Flags: [Native|Public]
	bool HasBuff(struct FName BuffName); // Offset: 0x1035d9aec // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.GetBuffExpiry
	// Flags: [Native|Public]
	float GetBuffExpiry(struct FName BuffName); // Offset: 0x1035d9a58 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.GetBuffDuration
	// Flags: [Native|Public]
	float GetBuffDuration(int BuffID, int CauseSkillID); // Offset: 0x1035d998c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.GetBuffByName
	// Flags: [Native|Public]
	struct USTBaseBuff* GetBuffByName(struct FName BuffName); // Offset: 0x1035d98f8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.CheckBuffTarget
	// Flags: [Native|Public]
	bool CheckBuffTarget(struct USTBuff* Buff); // Offset: 0x1035d9864 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.AddBuffLayer
	// Flags: [Native|Public]
	bool AddBuffLayer(struct FName BuffName, int layerNum); // Offset: 0x1035d9794 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.AddBuffExpiry
	// Flags: [Native|Public]
	bool AddBuffExpiry(struct FName BuffName, float ExpirySeconds); // Offset: 0x1035d96c4 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.AddBuffBySkill
	// Flags: [Native|Public]
	bool AddBuffBySkill(int SkillID, int LayerCount, struct AActor* Causer); // Offset: 0x1035d95bc // Return & Params: Num(4) Size(0x11)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.AddBuffByID
	// Flags: [Native|Public]
	bool AddBuffByID(int BuffID, struct AActor* Causer, int LayerCount, int CauseSkillID); // Offset: 0x1035d9478 // Return & Params: Num(5) Size(0x19)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.AddBuff
	// Flags: [Native|Public]
	int AddBuff(struct FName BuffName, struct AController* SkillActor, int LayerCount, struct AActor* BuffApplierActor, struct AActor* CauserActor); // Offset: 0x1035d92fc // Return & Params: Num(6) Size(0x2c)
};

// Object Name: Class Basic.STBaseBuffConditionBase
// Size: 0x118 // Inherited bytes: 0x110
struct USTBaseBuffConditionBase : UActorComponent {
	// Fields
	struct TWeakObjectPtr<struct USTBaseBuff> OwnerBuff; // Offset: 0x110 // Size: 0x08
};

// Object Name: Class Basic.STBaseBuffEventType
// Size: 0x30 // Inherited bytes: 0x28
struct USTBaseBuffEventType : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class Basic.STBaseBuffEventType_LayerMax
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_LayerMax : USTBaseBuffEventType {
};

// Object Name: Class Basic.STBaseBuffEventType_LayerSpecific
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_LayerSpecific : USTBaseBuffEventType {
	// Fields
	int LayerCountParam; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class Basic.STBaseBuffEventType_Removed
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_Removed : USTBaseBuffEventType {
};

// Object Name: Class Basic.STBaseBuffEventType_TakeBuffDamage
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_TakeBuffDamage : USTBaseBuffEventType {
};

// Object Name: Class Basic.STBaseBuffEventType_OnAttach
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_OnAttach : USTBaseBuffEventType {
};

// Object Name: Class Basic.STBaseBuffEventType_ConditionNotMatch
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_ConditionNotMatch : USTBaseBuffEventType {
};

// Object Name: Class Basic.STBaseBuffEventType_Resurrection
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_Resurrection : USTBaseBuffEventType {
};

// Object Name: Class Basic.STBaseBuffEventType_WeaponAttack
// Size: 0x48 // Inherited bytes: 0x30
struct USTBaseBuffEventType_WeaponAttack : USTBaseBuffEventType {
	// Fields
	struct AActor* Attacter; // Offset: 0x30 // Size: 0x08
	struct AActor* Victim; // Offset: 0x38 // Size: 0x08
	int HitCount; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: Class Basic.STBaseBuffList
// Size: 0x48 // Inherited bytes: 0x28
struct USTBaseBuffList : UObject {
	// Fields
	struct FString BuffListName; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FSTBaseBuffTemplateItem> BuffList; // Offset: 0x38 // Size: 0x10
};

// Object Name: Class Basic.BuffManagerPathClass
// Size: 0x3f8 // Inherited bytes: 0x3d8
struct ABuffManagerPathClass : AActor {
	// Fields
	struct FString BuffManagerBlueprintPath; // Offset: 0x3d8 // Size: 0x10
	struct TArray<struct FBuffManagerModPath> BuffListPathMap; // Offset: 0x3e8 // Size: 0x10
};

// Object Name: Class Basic.STBaseBuffStatusType_ImmuneDebuff
// Size: 0x28 // Inherited bytes: 0x28
struct USTBaseBuffStatusType_ImmuneDebuff : USTBaseBuffStatusType {
};

// Object Name: Class Basic.STBuff
// Size: 0x158 // Inherited bytes: 0x28
struct USTBuff : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	int BuffID; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString BuffName; // Offset: 0x38 // Size: 0x10
	struct FString Desc; // Offset: 0x48 // Size: 0x10
	int LayerMax; // Offset: 0x58 // Size: 0x04
	int InitialLayerCount; // Offset: 0x5c // Size: 0x04
	float Duration; // Offset: 0x60 // Size: 0x04
	float ClientSyncInterval; // Offset: 0x64 // Size: 0x04
	enum class EBuffClientSyncType ClientSyncType; // Offset: 0x68 // Size: 0x01
	enum class EBuffTargetType TargetType; // Offset: 0x69 // Size: 0x01
	enum class EBuffRefreshType RefreshType; // Offset: 0x6a // Size: 0x01
	enum class EBuffReActionType ReActionType; // Offset: 0x6b // Size: 0x01
	enum class EMultiCauserHandleType MultiCauserHandleType; // Offset: 0x6c // Size: 0x01
	enum class EMultiSkillHandleType MultiSkillHandleType; // Offset: 0x6d // Size: 0x01
	bool IsExecuteOnece; // Offset: 0x6e // Size: 0x01
	bool RemoveAllLayer; // Offset: 0x6f // Size: 0x01
	struct TArray<struct USTBuffAction*> Actions; // Offset: 0x70 // Size: 0x10
	bool bNeedShowBuffInBuffList; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x3]; // Offset: 0x81 // Size: 0x03
	int LocalizeDescID; // Offset: 0x84 // Size: 0x04
	struct FString IconPath; // Offset: 0x88 // Size: 0x10
	bool IsClientOwnLife; // Offset: 0x98 // Size: 0x01
	bool ExistForever; // Offset: 0x99 // Size: 0x01
	char pad_0x9A[0x2]; // Offset: 0x9a // Size: 0x02
	int TipsOnAddBuff; // Offset: 0x9c // Size: 0x04
	struct TArray<struct UDataProviderBase*> DataProviders; // Offset: 0xa0 // Size: 0x10
	struct TMap<struct UObject*, int> InstancedNodeNameToMemoryMap; // Offset: 0xb0 // Size: 0x50
	int InstancedNodesTotalSize; // Offset: 0x100 // Size: 0x04
	char pad_0x104[0x54]; // Offset: 0x104 // Size: 0x54

	// Functions

	// Object Name: Function Basic.STBuff.Tick
	// Flags: [Final|Native|Public]
	void Tick(struct UActorComponent* BuffSystemComponent, float DetalTime, float TimeSeconds); // Offset: 0x1035e2f9c // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Basic.STBuff.ResetActionExecute
	// Flags: [Final|Native|Public]
	void ResetActionExecute(struct UActorComponent* BuffSystemComponent); // Offset: 0x1035e2f20 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuff.Initialize
	// Flags: [Final|Native|Public]
	void Initialize(struct UActorComponent* BuffSystemComponent); // Offset: 0x1035e2ea4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuff.End
	// Flags: [Final|Native|Public]
	void End(struct UActorComponent* BuffSystemComponent); // Offset: 0x1035e2e28 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuff.Destroy
	// Flags: [Final|Native|Public]
	void Destroy(struct UActorComponent* BuffSystemComponent); // Offset: 0x1035e2dac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuff.CopyActions
	// Flags: [Final|Native|Public]
	bool CopyActions(); // Offset: 0x1035e2d78 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.STBuff.ChangeNotify
	// Flags: [Final|Native|Public]
	void ChangeNotify(struct UActorComponent* BuffSystemComponent); // Offset: 0x1035e2cfc // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Basic.STBuffAction_Lua
// Size: 0x108 // Inherited bytes: 0x48
struct USTBuffAction_Lua : USTBuffAction {
	// Fields
	char pad_0x48[0x60]; // Offset: 0x48 // Size: 0x60
	struct TMap<struct FName, struct FString> ActionParams; // Offset: 0xa8 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0xf8 // Size: 0x10

	// Functions

	// Object Name: Function Basic.STBuffAction_Lua.OnTick
	// Flags: [Native|Public]
	void OnTick(float DetalTime); // Offset: 0x1035e4638 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.STBuffAction_Lua.OnInitialize
	// Flags: [Native|Public]
	void OnInitialize(); // Offset: 0x1035e461c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction_Lua.OnExecute
	// Flags: [Native|Public]
	void OnExecute(); // Offset: 0x1035e4600 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction_Lua.OnEnd
	// Flags: [Native|Public]
	void OnEnd(); // Offset: 0x1035e45e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction_Lua.OnDestroy
	// Flags: [Native|Public]
	void OnDestroy(); // Offset: 0x1035e45c8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction_Lua.OnChangeNotify
	// Flags: [Native|Public]
	void OnChangeNotify(); // Offset: 0x1035e45ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction_Lua.GetVectorValue
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|Const]
	struct FVector GetVectorValue(struct FName& Key); // Offset: 0x1035e4508 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.STBuffAction_Lua.GetStringValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	struct FString GetStringValue(struct FName& Key); // Offset: 0x1035e4444 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.STBuffAction_Lua.GetIntValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	int GetIntValue(struct FName& Key); // Offset: 0x1035e43a8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuffAction_Lua.GetFloatValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	float GetFloatValue(struct FName& Key); // Offset: 0x1035e430c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuffAction_Lua.GetBoolValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetBoolValue(struct FName& Key); // Offset: 0x1035e4270 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class Basic.STBuffConditionComplex
// Size: 0x50 // Inherited bytes: 0x40
struct USTBuffConditionComplex : USTBuffCondition {
	// Fields
	struct TArray<struct USTBuffCondition*> Conditions; // Offset: 0x40 // Size: 0x10

	// Functions

	// Object Name: Function Basic.STBuffConditionComplex.OnInitialize
	// Flags: [Native|Protected]
	void OnInitialize(); // Offset: 0x1035e5160 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionComplex.OnDestroy
	// Flags: [Native|Protected]
	void OnDestroy(); // Offset: 0x1035e5144 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionComplex.Copy
	// Flags: [Native|Public]
	struct USTBuffCondition* Copy(struct UObject* Outer); // Offset: 0x1035e50b0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBuffConditionComplex.CheckIsTrue
	// Flags: [Native|Protected]
	bool CheckIsTrue(); // Offset: 0x1035e5074 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Basic.STBuffConditionAction
// Size: 0x70 // Inherited bytes: 0x48
struct USTBuffConditionAction : USTBuffAction {
	// Fields
	struct USTBuffCondition* Condition; // Offset: 0x48 // Size: 0x08
	float ConditionTickInterval; // Offset: 0x50 // Size: 0x04
	float Probality; // Offset: 0x54 // Size: 0x04
	enum class EBuffConditionExecuteTimeType ExecuteTimeType; // Offset: 0x58 // Size: 0x01
	bool IsDoOnFalse; // Offset: 0x59 // Size: 0x01
	bool IsNeedTick; // Offset: 0x5a // Size: 0x01
	bool IsSetFalseWhenExecute; // Offset: 0x5b // Size: 0x01
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct TArray<struct FBuffConditionActionItem> LinkActions; // Offset: 0x60 // Size: 0x10

	// Functions

	// Object Name: Function Basic.STBuffConditionAction.OnTick
	// Flags: [Native|Protected]
	void OnTick(float DetalTime); // Offset: 0x1035e542c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.STBuffConditionAction.OnInitialize
	// Flags: [Native|Protected]
	void OnInitialize(); // Offset: 0x1035e5410 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionAction.OnDestroy
	// Flags: [Native|Protected]
	void OnDestroy(); // Offset: 0x1035e53f4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionAction.OnConditionTrue
	// Flags: [Final|Native|Protected]
	void OnConditionTrue(); // Offset: 0x1035e53e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionAction.OnConditionFalse
	// Flags: [Final|Native|Protected]
	void OnConditionFalse(); // Offset: 0x1035e53cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionAction.OnChangeNotify
	// Flags: [Native|Protected]
	void OnChangeNotify(); // Offset: 0x1035e53b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionAction.CheckCondition
	// Flags: [Final|Native|Protected]
	void CheckCondition(); // Offset: 0x1035e539c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Basic.STBuffSystemComponent
// Size: 0x4a8 // Inherited bytes: 0x110
struct USTBuffSystemComponent : UActorComponent {
	// Fields
	char pad_0x110[0x8]; // Offset: 0x110 // Size: 0x08
	float RPCSyncInterval; // Offset: 0x118 // Size: 0x04
	char pad_0x11C[0x4]; // Offset: 0x11c // Size: 0x04
	struct FScriptMulticastDelegate OnClientAddBuffEvent; // Offset: 0x120 // Size: 0x10
	struct FScriptMulticastDelegate OnClientRemoveBuffEvent; // Offset: 0x130 // Size: 0x10
	struct FScriptMulticastDelegate OnClientUpdateBuffEvent; // Offset: 0x140 // Size: 0x10
	struct TMap<int, struct UUAEBlackboard*> BuffBlackboardMap; // Offset: 0x150 // Size: 0x50
	int SyncBriefNum; // Offset: 0x1a0 // Size: 0x04
	char pad_0x1A4[0x4]; // Offset: 0x1a4 // Size: 0x04
	struct FClientSyncBrief SyncBriefs[0x6]; // Offset: 0x1a8 // Size: 0xf0
	struct FClientSyncBrief SyncRefBriefs[0x6]; // Offset: 0x298 // Size: 0xf0
	struct TSet<int> BriefRemoveInstIds; // Offset: 0x388 // Size: 0x50
	char pad_0x3D8[0xd0]; // Offset: 0x3d8 // Size: 0xd0

	// Functions

	// Object Name: Function Basic.STBuffSystemComponent.UpdateClientBuff
	// Flags: [Final|Native|Protected]
	void UpdateClientBuff(int InstID, int BuffID, int LayerCount, int CauseSkillID, struct AActor* CauseActor, float DSEndTime); // Offset: 0x1035e67a4 // Return & Params: Num(6) Size(0x1c)

	// Object Name: Function Basic.STBuffSystemComponent.UpdateBriefs
	// Flags: [Final|Native|Protected]
	void UpdateBriefs(); // Offset: 0x1035e6790 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffSystemComponent.RPC_Server_ReqBriefs
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void RPC_Server_ReqBriefs(); // Offset: 0x1035e6734 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffSystemComponent.RPC_Client_SyncBrief
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void RPC_Client_SyncBrief(struct FClientSyncBrief Brief); // Offset: 0x1035e6690 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Basic.STBuffSystemComponent.RPC_Client_RspBriefs
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void RPC_Client_RspBriefs(struct TArray<struct FClientSyncBrief> Briefs); // Offset: 0x1035e65f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.STBuffSystemComponent.RemoveClientBuff
	// Flags: [Final|Native|Protected]
	void RemoveClientBuff(int InstID); // Offset: 0x1035e6574 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.STBuffSystemComponent.RemoveBuff
	// Flags: [Final|Native|Public]
	void RemoveBuff(int BuffID, int LayerCount, struct AActor* Causer, int CauseSkillID); // Offset: 0x1035e6444 // Return & Params: Num(4) Size(0x14)

	// Object Name: Function Basic.STBuffSystemComponent.RemoveAllBuffs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveAllBuffs(); // Offset: 0x1035e6430 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffSystemComponent.OnRep_SyncBriefs
	// Flags: [Final|Native|Public]
	void OnRep_SyncBriefs(); // Offset: 0x1035e641c // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Basic.STBuffSystemComponent.OnClientUpdateBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnClientUpdateBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xc)

	// Object Name: DelegateFunction Basic.STBuffSystemComponent.OnClientRemoveBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnClientRemoveBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xc)

	// Object Name: DelegateFunction Basic.STBuffSystemComponent.OnClientAddBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnClientAddBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Basic.STBuffSystemComponent.HasSkillID
	// Flags: [Final|Native|Public]
	bool HasSkillID(int SkillID); // Offset: 0x1035e6390 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.STBuffSystemComponent.HasBuff
	// Flags: [Final|Native|Public]
	bool HasBuff(int BuffID); // Offset: 0x1035e6304 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.STBuffSystemComponent.GetSubsystem
	// Flags: [Final|Native|Public]
	struct UBuffConfigSubsystem* GetSubsystem(); // Offset: 0x1035e62d0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffSystemComponent.GetSTBuffByBuffID
	// Flags: [Final|Native|Public]
	struct USTBuff* GetSTBuffByBuffID(int BuffID); // Offset: 0x1035e6244 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBuffSystemComponent.GetBuffDuration
	// Flags: [Final|Native|Public]
	float GetBuffDuration(int BuffID, int CauseSkillID); // Offset: 0x1035e6180 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Basic.STBuffSystemComponent.GetBuffDSEndTime
	// Flags: [Final|Native|Public]
	float GetBuffDSEndTime(int BuffID, int CauseSkillID); // Offset: 0x1035e60bc // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Basic.STBuffSystemComponent.GetAllBuffInfo
	// Flags: [Final|Native|Public]
	struct TArray<struct FBuffInstInfo> GetAllBuffInfo(); // Offset: 0x1035e6058 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.STBuffSystemComponent.ClientGetBuffInfo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool ClientGetBuffInfo(int BuffID, struct FClientSyncBrief& OutBuff); // Offset: 0x1035e5f74 // Return & Params: Num(3) Size(0x31)

	// Object Name: Function Basic.STBuffSystemComponent.ClearBuffs
	// Flags: [Final|Native|Public]
	void ClearBuffs(bool IsClearAll); // Offset: 0x1035e5ef0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.STBuffSystemComponent.AddBuff
	// Flags: [Final|Native|Public]
	bool AddBuff(int BuffID, struct AActor* Causer, int LayerCount, int CauseSkillID); // Offset: 0x1035e5db4 // Return & Params: Num(5) Size(0x19)
};

// Object Name: Class Basic.BuffConfigSubsystem
// Size: 0x160 // Inherited bytes: 0x30
struct UBuffConfigSubsystem : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x30]; // Offset: 0x30 // Size: 0x30
	struct TMap<int, struct FBuffTableRow> Table; // Offset: 0x60 // Size: 0x50
	struct TMap<struct FString, struct UObject*> BuffClassMap; // Offset: 0xb0 // Size: 0x50
	char pad_0x100[0x60]; // Offset: 0x100 // Size: 0x60
};

// Object Name: Class Basic.UStringMap
// Size: 0x78 // Inherited bytes: 0x28
struct UUStringMap : UObject {
	// Fields
	struct FStringMap Map; // Offset: 0x28 // Size: 0x50
};

// Object Name: Class Basic.STExtraNetPriorityConfig
// Size: 0xe8 // Inherited bytes: 0x30
struct USTExtraNetPriorityConfig : UWorldSubsystem {
	// Fields
	bool ExtraNetPriorityEnabled; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct TMap<enum class ESTExtraNetPriorityFlags, float> ExtraNetPriorityFactor; // Offset: 0x38 // Size: 0x50
	bool EnemyExtraNetPriorityEnabled; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x3]; // Offset: 0x89 // Size: 0x03
	float EnemyExtraNetPriorityFactor; // Offset: 0x8c // Size: 0x04
	struct TMap<enum class ESTExtraNetPriorityIssueID, enum class ESTExtraNetPriorityFlags> NetPriorityIssue; // Offset: 0x90 // Size: 0x50
	float MoveExtraNetPriorityVelocitySquared; // Offset: 0xe0 // Size: 0x04
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
};

// Object Name: Class Basic.STExtraNetPriorityInterface
// Size: 0x28 // Inherited bytes: 0x28
struct USTExtraNetPriorityInterface : UInterface {
};

// Object Name: Class Basic.DataTableRowDesc
// Size: 0x98 // Inherited bytes: 0x28
struct UDataTableRowDesc : UObject {
	// Fields
	char pad_0x28[0x70]; // Offset: 0x28 // Size: 0x70
};

// Object Name: Class Basic.DataTableProxy
// Size: 0xe0 // Inherited bytes: 0x28
struct UDataTableProxy : UObject {
	// Fields
	struct UDataTable* ModDataTable; // Offset: 0x28 // Size: 0x08
	struct UDataTable* DataTable; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0xa0]; // Offset: 0x38 // Size: 0xa0
	struct UDataTableRowDesc* Desc; // Offset: 0xd8 // Size: 0x08
};

// Object Name: Class Basic.TableManagerSubsystem
// Size: 0xd0 // Inherited bytes: 0x30
struct UTableManagerSubsystem : UGameInstanceSubsystem {
	// Fields
	struct FString BaseTableRelativeDir; // Offset: 0x30 // Size: 0x10
	struct FString ModTableRelativeDir; // Offset: 0x40 // Size: 0x10
	struct FString TableRelativeDir; // Offset: 0x50 // Size: 0x10
	struct FString ManualTableDirectory; // Offset: 0x60 // Size: 0x10
	struct FString CurrentModName; // Offset: 0x70 // Size: 0x10
	struct TMap<struct FString, struct UDataTableProxy*> TableCache; // Offset: 0x80 // Size: 0x50

	// Functions

	// Object Name: Function Basic.TableManagerSubsystem.SetModName
	// Flags: [Final|Native|Public]
	void SetModName(struct FString ModName); // Offset: 0x1035ea784 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.TableManagerSubsystem.GetTableProxy
	// Flags: [Final|Native|Public]
	struct UDataTableProxy* GetTableProxy(struct FString tableName, bool bTempory); // Offset: 0x1035ea694 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Basic.TableManagerSubsystem.GetTableDataField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool GetTableDataField(struct FString tableName, struct FTableRowBase& Key, struct FString Field, struct FTableRowBase& Out); // Offset: 0x1035a6148 // Return & Params: Num(5) Size(0x31)

	// Object Name: Function Basic.TableManagerSubsystem.GetTableData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetTableData(struct FString tableName, struct FString Key, struct FTableRowBase& OutRow); // Offset: 0x1035ea528 // Return & Params: Num(4) Size(0x29)
};

// Object Name: Class Basic.UAEBPGameSubsystem
// Size: 0xa0 // Inherited bytes: 0x30
struct UUAEBPGameSubsystem : UWorldSubsystem {
	// Fields
	char pad_0x30[0x70]; // Offset: 0x30 // Size: 0x70
};

// Object Name: Class Basic.UAEBuffPoolSubsystem
// Size: 0x90 // Inherited bytes: 0x30
struct UUAEBuffPoolSubsystem : UWorldSubsystem {
	// Fields
	struct TArray<struct USTBuff*> BuffList; // Offset: 0x30 // Size: 0x10
	struct TMap<struct FString, struct USTBuff*> BuffInstancedTemplateMap; // Offset: 0x40 // Size: 0x50
};

// Object Name: Class Basic.UAEGameEngine
// Size: 0xe38 // Inherited bytes: 0xde8
struct UUAEGameEngine : UGameEngine {
	// Fields
	char pad_0xDE8[0x10]; // Offset: 0xde8 // Size: 0x10
	struct UBackendHUD* AssociatedBackendHUD; // Offset: 0xdf8 // Size: 0x08
	char pad_0xE00[0xc]; // Offset: 0xe00 // Size: 0x0c
	bool bEnableAutoStat; // Offset: 0xe0c // Size: 0x01
	bool bEnableAutoTickDeltaThreshold; // Offset: 0xe0d // Size: 0x01
	char pad_0xE0E[0x2]; // Offset: 0xe0e // Size: 0x02
	float AutoTickDeltaThresholdFactor; // Offset: 0xe10 // Size: 0x04
	float StatCollection_AvgTickDeltaThreshold; // Offset: 0xe14 // Size: 0x04
	float AutoStat_AvgTickDeltaThreshold; // Offset: 0xe18 // Size: 0x04
	float AutoStat_StartTime; // Offset: 0xe1c // Size: 0x04
	char pad_0xE20[0x4]; // Offset: 0xe20 // Size: 0x04
	float AutoStat_Duration_Engine; // Offset: 0xe24 // Size: 0x04
	float AutoStat_Duration_PhysX; // Offset: 0xe28 // Size: 0x04
	char pad_0xE2C[0xc]; // Offset: 0xe2c // Size: 0x0c
};

// Object Name: Class Basic.BPTable
// Size: 0xd8 // Inherited bytes: 0x28
struct UBPTable : UObject {
	// Fields
	struct FString BPTableName; // Offset: 0x28 // Size: 0x10
	struct TMap<int, struct FBPTableItem> BPTableItemMap; // Offset: 0x38 // Size: 0x50
	struct TMap<int, struct FBPTableItem> BPTableItemMap_Mod; // Offset: 0x88 // Size: 0x50

	// Functions

	// Object Name: Function Basic.BPTable.GetWrapperPath
	// Flags: [Final|Native|Public]
	struct FString GetWrapperPath(int ID); // Offset: 0x1035ecb40 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.BPTable.GetWrapperClass
	// Flags: [Final|Native|Public]
	struct UObject* GetWrapperClass(int ID); // Offset: 0x1035ecab4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.BPTable.GetPath
	// Flags: [Final|Native|Public]
	struct FString GetPath(int ID, bool IsLobby, bool bForceLobby); // Offset: 0x1035ec978 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function Basic.BPTable.GetObject
	// Flags: [Final|Native|Public]
	struct UObject* GetObject(int ID, struct UObject* Outer, bool IsLobby, bool IsLowDevice); // Offset: 0x1035ec828 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function Basic.BPTable.GetModObject
	// Flags: [Final|Native|Public]
	struct UObject* GetModObject(int ID, struct UObject* Outer, bool IsLobby); // Offset: 0x1035ec71c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Basic.BPTable.GetModClass
	// Flags: [Final|Native|Public]
	struct UObject* GetModClass(int ID, bool IsLobby); // Offset: 0x1035ec650 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Basic.BPTable.GetCustom1Class
	// Flags: [Final|Native|Public]
	struct UObject* GetCustom1Class(int ID); // Offset: 0x1035ec5c4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.BPTable.GetClass
	// Flags: [Final|Native|Public]
	struct UObject* GetClass(int ID, bool IsLobby, bool IsLowDevice); // Offset: 0x1035ec4b0 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Basic.BPTable.ConvertPath
	// Flags: [Final|Native|Public]
	void ConvertPath(int ID); // Offset: 0x1035ec434 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Basic.UAELoadedClassManager
// Size: 0x340 // Inherited bytes: 0x28
struct UUAELoadedClassManager : UObject {
	// Fields
	struct TMap<struct FString, struct UBPTable*> BPTableMap; // Offset: 0x28 // Size: 0x50
	struct TMap<struct FString, struct UBPTable*> BPTableMap_Mod; // Offset: 0x78 // Size: 0x50
	struct TMap<int, struct FString> BPTableNameMap; // Offset: 0xc8 // Size: 0x50
	struct FString LoadedClassManagerClassName; // Offset: 0x118 // Size: 0x10
	char pad_0x128[0x1c0]; // Offset: 0x128 // Size: 0x1c0
	struct TMap<struct UObject*, struct FSoftClassPath> AsyncLoadClassDict; // Offset: 0x2e8 // Size: 0x50
	char pad_0x338[0x8]; // Offset: 0x338 // Size: 0x08

	// Functions

	// Object Name: Function Basic.UAELoadedClassManager.InitTableData
	// Flags: [Native|Event|Public|BlueprintEvent]
	void InitTableData(); // Offset: 0x1035edcc0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.InitialModTableItemMap
	// Flags: [Native|Event|Public|BlueprintEvent]
	void InitialModTableItemMap(); // Offset: 0x1035edca4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.InitBPTableMap_Mod
	// Flags: [Event|Public|BlueprintEvent]
	void InitBPTableMap_Mod(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.InitBPTableMap
	// Flags: [Event|Public|BlueprintEvent]
	void InitBPTableMap(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.HandleTableModNameChanged
	// Flags: [Final|Native|Public]
	void HandleTableModNameChanged(struct FString InModName); // Offset: 0x1035edc0c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UAELoadedClassManager.GetWrapperPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetWrapperPath(struct FString BPTableName, int ID); // Offset: 0x1035edafc // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Basic.UAELoadedClassManager.GetWrapperClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetWrapperClass(struct FString BPTableName, int ID); // Offset: 0x1035eda14 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Basic.UAELoadedClassManager.GetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPath(struct FString BPTableName, int ID, bool IsLobby, bool bForceLobby); // Offset: 0x1035ed874 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function Basic.UAELoadedClassManager.GetObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetObject(struct FString BPTableName, int ID, struct UObject* Outer, bool IsLobby, bool IsLowDevice); // Offset: 0x1035ed6bc // Return & Params: Num(6) Size(0x30)

	// Object Name: Function Basic.UAELoadedClassManager.GetCustom1Class
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetCustom1Class(struct FString BPTableName, int ID); // Offset: 0x1035ed5d4 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Basic.UAELoadedClassManager.GetClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetClass(struct FString BPTableName, int ID, bool IsLobby, bool IsLowDevice); // Offset: 0x1035ed45c // Return & Params: Num(5) Size(0x20)

	// Object Name: Function Basic.UAELoadedClassManager.GetBPTableName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetBPTableName(int Type); // Offset: 0x1035ed3a8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAELoadedClassManager.GetAssetByAssetReferenceAsync
	// Flags: [Final|Native|Public|HasDefaults]
	void GetAssetByAssetReferenceAsync(struct FSoftObjectPath AssetReference, DelegateProperty AssetLoadSuccessDelegate); // Offset: 0x1035ed288 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function Basic.UAELoadedClassManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAELoadedClassManager* Get(); // Offset: 0x1035ed254 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.UAELoadedClassManager.CreateAndAddBPTable_Mod
	// Flags: [Final|Native|Protected|BlueprintCallable]
	struct UBPTable* CreateAndAddBPTable_Mod(struct FString BPTableName); // Offset: 0x1035ed1ac // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAELoadedClassManager.CreateAndAddBPTable
	// Flags: [Final|Native|Protected|BlueprintCallable]
	struct UBPTable* CreateAndAddBPTable(struct FString BPTableName); // Offset: 0x1035ed104 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAELoadedClassManager.ClearModTableItemMap
	// Flags: [Native|Event|Public|BlueprintEvent]
	void ClearModTableItemMap(); // Offset: 0x1035ed0e8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.ClearBPTable_Mod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearBPTable_Mod(); // Offset: 0x1035ed0d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.ClearBPTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearBPTable(); // Offset: 0x1035ed0c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.ClearAssetByAssetReferenceAsync
	// Flags: [Final|Native|Public]
	void ClearAssetByAssetReferenceAsync(DelegateProperty AssetLoadSuccessDelegate); // Offset: 0x1035ed030 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UAELoadedClassManager.ClearAllData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearAllData(); // Offset: 0x1035ed01c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Basic.UAEMeshComponent
// Size: 0xdc0 // Inherited bytes: 0xdc0
struct UUAEMeshComponent : USkeletalMeshComponent {
	// Fields
	bool bUseBoneRetargetLODFeature; // Offset: 0xdb4 // Size: 0x01
};

// Object Name: Class Basic.UAENetConnection
// Size: 0x33a10 // Inherited bytes: 0x33768
struct UUAENetConnection : UIpConnection {
	// Fields
	char pad_0x33768[0xbc]; // Offset: 0x33768 // Size: 0xbc
	int InitialHandshakeTimeoutNumThreshold; // Offset: 0x33824 // Size: 0x04
	char pad_0x33828[0x4]; // Offset: 0x33828 // Size: 0x04
	int ActorChannelProcessBunchErrorNumThreshold_Server_Global; // Offset: 0x3382c // Size: 0x04
	int ActorChannelProcessBunchErrorNumThreshold_Client_Global; // Offset: 0x33830 // Size: 0x04
	int ActorChannelProcessBunchErrorNumThreshold_Client_PerActor; // Offset: 0x33834 // Size: 0x04
	char pad_0x33838[0x50]; // Offset: 0x33838 // Size: 0x50
	bool bEnableHTTPDNS; // Offset: 0x33888 // Size: 0x01
	char pad_0x33889[0x7]; // Offset: 0x33889 // Size: 0x07
	struct FString HTTPDNSServerAddr; // Offset: 0x33890 // Size: 0x10
	float HTTPDNSResponseTimeout; // Offset: 0x338a0 // Size: 0x04
	char pad_0x338A4[0xc]; // Offset: 0x338a4 // Size: 0x0c
	struct UNetRelevancyGroup* RelevancyGroup; // Offset: 0x338b0 // Size: 0x08
	char pad_0x338B8[0xe0]; // Offset: 0x338b8 // Size: 0xe0
	struct TArray<struct FPendingRegionNetworkObject> PendingRegionNetworkObjects; // Offset: 0x33998 // Size: 0x10
	float MinRegionActorTickDelta; // Offset: 0x339a8 // Size: 0x04
	float MaxRegionActorTickDelta; // Offset: 0x339ac // Size: 0x04
	char pad_0x339B0[0xc]; // Offset: 0x339b0 // Size: 0x0c
	bool EnableWeakNetUpdate; // Offset: 0x339bc // Size: 0x01
	char pad_0x339BD[0x3]; // Offset: 0x339bd // Size: 0x03
	float MinWeakNetUpdateDelay; // Offset: 0x339c0 // Size: 0x04
	float MaxWeakNetUpdateDelay; // Offset: 0x339c4 // Size: 0x04
	float SquareSegmentSize; // Offset: 0x339c8 // Size: 0x04
	float MaxSegmentDistance; // Offset: 0x339cc // Size: 0x04
	int MaxObjectNumInSegments; // Offset: 0x339d0 // Size: 0x04
	char pad_0x339D4[0x15]; // Offset: 0x339d4 // Size: 0x15
	bool bRecreateSocketOnLost; // Offset: 0x339e9 // Size: 0x01
	char pad_0x339EA[0x12]; // Offset: 0x339ea // Size: 0x12
	float UpdateClientPingTimeThreshold; // Offset: 0x339fc // Size: 0x04
	char pad_0x33A00[0x10]; // Offset: 0x33a00 // Size: 0x10
};

// Object Name: Class Basic.UAENetDriver
// Size: 0x7c8 // Inherited bytes: 0x690
struct UUAENetDriver : UIpNetDriver {
	// Fields
	float NetCullChangeTime; // Offset: 0x690 // Size: 0x04
	bool bEnableCollectNetStats; // Offset: 0x694 // Size: 0x01
	bool bEnableResetNetStats; // Offset: 0x695 // Size: 0x01
	char pad_0x696[0x132]; // Offset: 0x696 // Size: 0x132
};

// Object Name: Class Basic.UAETableManager
// Size: 0x588 // Inherited bytes: 0x28
struct UUAETableManager : UObject {
	// Fields
	struct FString TableRelativeDir; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FName> TablesNeedReleasedInBattle; // Offset: 0x38 // Size: 0x10
	struct FString ManualTableDirectory; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x100]; // Offset: 0x58 // Size: 0x100
	bool AllowItemTable; // Offset: 0x158 // Size: 0x01
	char pad_0x159[0x7]; // Offset: 0x159 // Size: 0x07
	struct TArray<struct UUAEDataTable*> TableObjList; // Offset: 0x160 // Size: 0x10
	struct UWorld* CurWorld; // Offset: 0x170 // Size: 0x08
	struct TMap<struct FName, struct TWeakObjectPtr<struct UUAEDataTable>> TableObjMap; // Offset: 0x178 // Size: 0x50
	struct TMap<struct FName, struct TWeakObjectPtr<struct UUAEDataTable>> TableObjMap_Mod; // Offset: 0x1c8 // Size: 0x50
	struct FScriptMulticastDelegate OnTableCreateInFighting; // Offset: 0x218 // Size: 0x10
	char pad_0x228[0xf8]; // Offset: 0x228 // Size: 0xf8
	struct FString PathCompressionConfigsPath; // Offset: 0x320 // Size: 0x10
	bool bIsPathCompression; // Offset: 0x330 // Size: 0x01
	bool bIsPathCompressionCache; // Offset: 0x331 // Size: 0x01
	char pad_0x332[0x2]; // Offset: 0x332 // Size: 0x02
	int PathCompressionCacheMaxSize; // Offset: 0x334 // Size: 0x04
	bool bTranslationFallBackUnloadDuplicate; // Offset: 0x338 // Size: 0x01
	bool bShrinkTranslationMap; // Offset: 0x339 // Size: 0x01
	char pad_0x33A[0xe]; // Offset: 0x33a // Size: 0x0e
	struct FString BaseTableRelativeDir; // Offset: 0x348 // Size: 0x10
	struct FString ModTableRelativeDir; // Offset: 0x358 // Size: 0x10
	struct TMap<struct FName, struct UModTable*> ModTableMap; // Offset: 0x368 // Size: 0x50
	struct TMap<struct FName, struct TWeakObjectPtr<struct UUAEDataTable>> ModTableObjMap; // Offset: 0x3b8 // Size: 0x50
	struct TArray<struct UUAEDataTable*> InGameTableObjList; // Offset: 0x408 // Size: 0x10
	struct TMap<struct FName, bool> CheckNeedModMap; // Offset: 0x418 // Size: 0x50
	struct FString CurrentModName; // Offset: 0x468 // Size: 0x10
	struct FString EmptyModName; // Offset: 0x478 // Size: 0x10
	struct TMap<struct FString, struct UBaseTableResMap*> LoadedTableMap; // Offset: 0x488 // Size: 0x50
	struct TMap<struct FString, bool> CheckMapTable; // Offset: 0x4d8 // Size: 0x50
	char pad_0x528[0x10]; // Offset: 0x528 // Size: 0x10
	struct TMap<struct FString, struct UDataTableProxy*> TableCache; // Offset: 0x538 // Size: 0x50

	// Functions

	// Object Name: Function Basic.UAETableManager.SetPreLoadLanguageName
	// Flags: [Final|Native|Public]
	void SetPreLoadLanguageName(struct FString LanguageName); // Offset: 0x1035ef8fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UAETableManager.ReleaseTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReleaseTable(struct FName TableFName); // Offset: 0x1035ef880 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.UAETableManager.GetTablePtr_Mod
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEDataTable* GetTablePtr_Mod(struct FName tableName); // Offset: 0x1035ef7f4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.UAETableManager.GetTablePtr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEDataTable* GetTablePtr(struct FName tableName, bool bCheckModTable); // Offset: 0x1035ef724 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Basic.UAETableManager.GetTableMap
	// Flags: [Final|Native|Public]
	struct UBaseTableResMap* GetTableMap(struct FString tableName); // Offset: 0x1035ef67c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAETableManager.GetTableData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetTableData(struct FString tableName, struct FString Key, struct FTableRowBase& OutRow); // Offset: 0x1035ef270 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Basic.UAETableManager.GetPreLoadLanguageName
	// Flags: [Final|Native|Public]
	struct FString GetPreLoadLanguageName(); // Offset: 0x1035ef20c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UAETableManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAETableManager* GetInstance(); // Offset: 0x1035ef1d8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.UAETableManager.GetDataTableStatic_Mod
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAEDataTable* GetDataTableStatic_Mod(struct FString tableName); // Offset: 0x1035ef140 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAETableManager.GetDataTableStatic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAEDataTable* GetDataTableStatic(struct FString tableName); // Offset: 0x1035ef0a8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAETableManager.GetDataTableProxy
	// Flags: [Final|Native|Public]
	struct UDataTableProxy* GetDataTableProxy(struct FString tableName, bool bTempory); // Offset: 0x1035eefb8 // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class Basic.UEMathUtilityMethods
// Size: 0x28 // Inherited bytes: 0x28
struct UUEMathUtilityMethods : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Basic.UEMathUtilityMethods.VectorNormalizeMultiple
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void VectorNormalizeMultiple(struct FVector& Out, struct FVector& v1, float Multiple); // Offset: 0x1035f0670 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Basic.UEMathUtilityMethods.VectorMultiple
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void VectorMultiple(struct FVector& Out, struct FVector& v1, float Multiple); // Offset: 0x1035f0564 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Basic.UEMathUtilityMethods.VectorMinus
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void VectorMinus(struct FVector& Out, struct FVector& v1, struct FVector& v2); // Offset: 0x1035f044c // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Basic.UEMathUtilityMethods.VectorAdditive
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void VectorAdditive(struct FVector& Out, struct FVector& v1, struct FVector& v2); // Offset: 0x1035f0334 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Basic.UEMathUtilityMethods.FilterOKForCurrentMode
	// Flags: [Final|Native|Static|Public]
	bool FilterOKForCurrentMode(char ModeType, int ModeOpenFlag, struct FString ModeTypes); // Offset: 0x1035f01f0 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Basic.UEMathUtilityMethods.Conv_VectorToRotator
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void Conv_VectorToRotator(struct FRotator& Out, struct FVector& Vec); // Offset: 0x1035f0128 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UEMathUtilityMethods.CalculateAngleToTargetAngle
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float CalculateAngleToTargetAngle(float StartAngle, float targetAngle, float stepAngle, enum class EAngleRotationDirectionType Dir); // Offset: 0x1035efffc // Return & Params: Num(5) Size(0x14)

	// Object Name: Function Basic.UEMathUtilityMethods.BKDRHash
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BKDRHash(struct FString StrToHash, int Mod); // Offset: 0x1035eff24 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Basic.UEMathUtilityMethods.AngleDis
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float AngleDis(float angleA, float angleB); // Offset: 0x1035efe70 // Return & Params: Num(3) Size(0xc)
};

// Object Name: Class Basic.UEPathUtilityMethods
// Size: 0x28 // Inherited bytes: 0x28
struct UUEPathUtilityMethods : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Basic.UEPathUtilityMethods.IsPathExist
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsPathExist(struct FString HandlePath); // Offset: 0x1035f4ad0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.UEPathUtilityMethods.IsAvatarResPathExist
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsAvatarResPathExist(struct FString HandlePath); // Offset: 0x1035f4a38 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.UEPathUtilityMethods.GetModName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetModName(struct UObject* WorldContext); // Offset: 0x1035f4994 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UEPathUtilityMethods.FilterOKForCurrentModeString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool FilterOKForCurrentModeString(struct FString CurrentModeString, struct FString ModStringInfo, char ModeType, int ModeOpenFlag); // Offset: 0x1035f4804 // Return & Params: Num(5) Size(0x29)
};

