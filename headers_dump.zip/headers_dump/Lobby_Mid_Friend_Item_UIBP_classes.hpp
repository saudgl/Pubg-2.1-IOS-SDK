#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Mid_Friend_Item_UIBP.Lobby_Mid_Friend_Item_UIBP_C
// Size: 0x280 // Inherited bytes: 0x248
struct ULobby_Mid_Friend_Item_UIBP_C : UUserWidget {
	// Fields
	struct UButton* Button_Del; // Offset: 0x248 // Size: 0x08
	struct UCommon_Avatar_BP_C* Common_Avatar_BP_C_1; // Offset: 0x250 // Size: 0x08
	struct UImage* Image_5; // Offset: 0x258 // Size: 0x08
	struct UImage* Image_8; // Offset: 0x260 // Size: 0x08
	struct USizeBox* SizeBox_1; // Offset: 0x268 // Size: 0x08
	struct USizeBox* SizeBox_5; // Offset: 0x270 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_1; // Offset: 0x278 // Size: 0x08
};

