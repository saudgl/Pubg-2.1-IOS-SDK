#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass WeaponAnimList_Rifle_SCAR.WeaponAnimList_Rifle_SCAR_C
// Size: 0x2d8 // Inherited bytes: 0x2d8
struct UWeaponAnimList_Rifle_SCAR_C : UUAECharacterAnimListComponent {
};

