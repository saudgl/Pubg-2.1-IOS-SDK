#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class LightningComponent.LightningActor
// Size: 0x3e0 // Inherited bytes: 0x3d8
struct ALightningActor : AActor {
	// Fields
	struct ULightningComponent* LightningComponent; // Offset: 0x3d8 // Size: 0x08
};

// Object Name: Class LightningComponent.LightningComponent
// Size: 0x7e0 // Inherited bytes: 0x730
struct ULightningComponent : UMeshComponent {
	// Fields
	int MaxFractalTime; // Offset: 0x728 // Size: 0x04
	int PatternMask; // Offset: 0x72c // Size: 0x04
	float LightningWidth; // Offset: 0x730 // Size: 0x04
	float WidthDecay; // Offset: 0x734 // Size: 0x04
	float BrightnessDecay; // Offset: 0x738 // Size: 0x04
	bool bShrinkWidth; // Offset: 0x73c // Size: 0x01
	int AtlasNum; // Offset: 0x740 // Size: 0x04
	struct FVector SeedStart; // Offset: 0x744 // Size: 0x0c
	struct FVector SeedEnd; // Offset: 0x750 // Size: 0x0c
	struct FVector2D ZigZagFraction; // Offset: 0x75c // Size: 0x08
	struct FVector2D ZigZagDeviationRight; // Offset: 0x764 // Size: 0x08
	struct FVector2D ZigZagDeviationUp; // Offset: 0x76c // Size: 0x08
	float ZigZagDeviationDecay; // Offset: 0x774 // Size: 0x04
	struct FVector2D ForkFraction; // Offset: 0x778 // Size: 0x08
	struct FVector2D ForkZigZagDeviationRight; // Offset: 0x780 // Size: 0x08
	struct FVector2D ForkZigZagDeviationUp; // Offset: 0x788 // Size: 0x08
	float ForkZigZagDeviationDecay; // Offset: 0x790 // Size: 0x04
	struct FVector2D ForkDeviationRight; // Offset: 0x794 // Size: 0x08
	struct FVector2D ForkDeviationUp; // Offset: 0x79c // Size: 0x08
	struct FVector2D ForkDeviationForward; // Offset: 0x7a4 // Size: 0x08
	float ForkDeviationDecay; // Offset: 0x7ac // Size: 0x04
	struct FVector2D ForkLength; // Offset: 0x7b0 // Size: 0x08
	float ForkLengthDecay; // Offset: 0x7b8 // Size: 0x04
	char pad_0x7C1[0x1f]; // Offset: 0x7c1 // Size: 0x1f

	// Functions

	// Object Name: Function LightningComponent.LightningComponent.SetWidthDecay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWidthDecay(float InDecay); // Offset: 0x10246d194 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.SetShrinkWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetShrinkWidth(bool InBool); // Offset: 0x10246d110 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LightningComponent.LightningComponent.SetPatternMask
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPatternMask(int InPatternMask); // Offset: 0x10246d094 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.SetMaxFractalTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxFractalTime(int InMaxFractalTime); // Offset: 0x10246d018 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.SetLightningWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLightningWidth(float InWidth); // Offset: 0x10246cf9c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.SetBrightnessDecay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrightnessDecay(float InDecay); // Offset: 0x10246cf20 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.SetAtlasNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAtlasNum(int InVal); // Offset: 0x10246cea4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.RefreshLightningMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshLightningMesh(); // Offset: 0x10246ce90 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LightningComponent.LightningComponent.IsShrinkWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsShrinkWidth(); // Offset: 0x10246ce74 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LightningComponent.LightningComponent.GetWidthDecay
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetWidthDecay(); // Offset: 0x10246ce58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.GetPatternMask
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPatternMask(); // Offset: 0x10246ce3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.GetMaxFractalTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetMaxFractalTime(); // Offset: 0x10246ce20 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.GetLightningWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetLightningWidth(); // Offset: 0x10246ce04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.GetBrightnessDecay
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetBrightnessDecay(); // Offset: 0x10246cde8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.GetAtlasNum
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAtlasNum(); // Offset: 0x10246cdc8 // Return & Params: Num(1) Size(0x4)
};

