#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C
// Size: 0x310 // Inherited bytes: 0x248
struct UCommon_RankIntegralLevel_Style_Small_UIBP_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x248 // Size: 0x08
	struct UCanvasPanel* Root; // Offset: 0x250 // Size: 0x08
	enum class RankIntegralType RankIntegralType; // Offset: 0x258 // Size: 0x01
	char pad_0x259[0x7]; // Offset: 0x259 // Size: 0x07
	struct UUserWidget* RankIntegralUIBP; // Offset: 0x260 // Size: 0x08
	struct FSlateColor RankTextColor; // Offset: 0x268 // Size: 0x28
	struct FSlateColor RankTextShadowColor; // Offset: 0x290 // Size: 0x28
	struct FSlateFontInfo RankFontInfo; // Offset: 0x2b8 // Size: 0x58

	// Functions

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.SetArenaRankInteralWithCustomColor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetArenaRankInteralWithCustomColor(int RankInteral, struct UTextBlock* TextIntegralName, struct FSlateColor Color); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.SetRankInteralBySeason
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRankInteralBySeason(int rankIntegral, struct UTextBlock* TextIntegralName, int SeasonID); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.SetRankCustomColor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRankCustomColor(int rankIntegral, struct UTextBlock* TextIntegralName, struct FSlateColor Color, int SeasonID); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0x3c)

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.SetRankInteralJaguar
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetRankInteralJaguar(int rankIntegral, struct UTextBlock* TextIntegralName); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.SetRankInteral
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRankInteral(int rankIntegral, struct UTextBlock* TextIntegralName); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.SetRankInteralInXMission
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetRankInteralInXMission(int rankIntegral, struct UTextBlock* TextIntegralName); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.SetArenaRankInteral
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetArenaRankInteral(int rankIntegral, struct UTextBlock* TextIntegralName); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.SetRankInteralCommon
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetRankInteralCommon(int rankIntegral, struct UTextBlock* TextIntegralName, int SeasonID); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.ConstructItem
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ConstructItem(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Destruct(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_RankIntegralLevel_Style_Small_UIBP.Common_RankIntegralLevel_Style_Small_UIBP_C.ExecuteUbergraph_Common_RankIntegralLevel_Style_Small_UIBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Common_RankIntegralLevel_Style_Small_UIBP(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

