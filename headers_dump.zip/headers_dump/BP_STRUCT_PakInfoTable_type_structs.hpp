#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_PakInfoTable_type.BP_STRUCT_PakInfoTable_type
// Size: 0x60 // Inherited bytes: 0x00
struct FBP_STRUCT_PakInfoTable_type {
	// Fields
	struct FString PakDesc_0_6E91B0407A6E420F2F3B970B0B197D03; // Offset: 0x00 // Size: 0x10
	int PakID_1_2787F3C01109F2833D0E5F01019B1904; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString PakName_2_2871B0C036D9F5B52F2039E30B1A97A5; // Offset: 0x18 // Size: 0x10
	struct FString RewardDesc_4_599F8280689362F004DC89FD0591F623; // Offset: 0x28 // Size: 0x10
	struct FString IconPath_5_4AA40F004CDDD4F255A82072004E7098; // Offset: 0x38 // Size: 0x10
	int HaveReward_6_2F7F23C05893D46B3BEC13810794E624; // Offset: 0x48 // Size: 0x04
	int IsShow_7_72DD80C02601BBC33710FE7109DEF477; // Offset: 0x4c // Size: 0x04
	struct FString Videos_9_2559C4007F047F7C51C1B5670919C773; // Offset: 0x50 // Size: 0x10
};

