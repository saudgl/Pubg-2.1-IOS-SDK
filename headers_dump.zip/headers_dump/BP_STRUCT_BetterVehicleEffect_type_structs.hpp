#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_BetterVehicleEffect_type.BP_STRUCT_BetterVehicleEffect_type
// Size: 0x12c // Inherited bytes: 0x00
struct FBP_STRUCT_BetterVehicleEffect_type {
	// Fields
	int BornFall_0_699F66401857D3717272C3F90C031E0C; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString EnterTeamVideo_1_439821406CC04453172EAC6100F15A2F; // Offset: 0x08 // Size: 0x10
	int ID_2_6258A58050DEEC1C34CC36960D71DA44; // Offset: 0x18 // Size: 0x04
	int Parachute_3_58CF69800AF0CE4447FE852D0F6443F5; // Offset: 0x1c // Size: 0x04
	int VehicleMusic_4_0E3A12801F42C31E41988F0109D257A3; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString ParachuteVehicle_5_266D99802E2F69A84C03D52C0AFAC775; // Offset: 0x28 // Size: 0x10
	struct FString VehicleContainer_6_0FC11B00763F5CF0333D88620BFE3412; // Offset: 0x38 // Size: 0x10
	struct FString VehicleInBornIsland_7_536A1B00296E6F2C6F6CE5DA0FA35564; // Offset: 0x48 // Size: 0x10
	struct FString GiftPreview_14_558C5D4070F33535251D5E080A28E547; // Offset: 0x58 // Size: 0x10
	struct FString GetQualityImage_16_035D5D4050366A773BD94FF4054AD0C5; // Offset: 0x68 // Size: 0x10
	struct FString GetVehicleImage_17_062453006ABB76D04A9785020C4A7C45; // Offset: 0x78 // Size: 0x10
	struct FString GetShareGiveVersion_18_142EC3404FFEDF7558828BCC004D11DE; // Offset: 0x88 // Size: 0x10
	struct FString GiftPreviewShadow_19_1C8416C067541F557648D1C906B6A027; // Offset: 0x98 // Size: 0x10
	struct FString GetQualityImage2_20_1034C9C00A93CC5131F91D5B04AD0CD2; // Offset: 0xa8 // Size: 0x10
	struct FString VehicleInSocialIsland_21_2A6CAD80415C40A2077B867D0B8A25A4; // Offset: 0xb8 // Size: 0x10
	struct FString ShareQualityImage_22_107532001D3220D2428BC2110CE56945; // Offset: 0xc8 // Size: 0x10
	struct FString PropertyForParachute_23_5D8FAC8075FF989E5B7DDD4703989875; // Offset: 0xd8 // Size: 0x10
	struct FString TeamShowBGImage_24_70C0A7403E0824EB4EDF2BCB078C5205; // Offset: 0xe8 // Size: 0x10
	struct FString TeamShowLogoImage_25_3BAEC9400CFB3FCF5F60D4330A5BD3B5; // Offset: 0xf8 // Size: 0x10
	struct FString TeamShowNameImage_26_1AAAC54058596B673161407C07FBD285; // Offset: 0x108 // Size: 0x10
	struct FString GetVehicleImage2_27_135CDF8017A892822F0104B004A7C442; // Offset: 0x118 // Size: 0x10
	int MiniTVVehiclePhoto_28_7D9DC2802F47773069FB947102CE464F; // Offset: 0x128 // Size: 0x04
};

