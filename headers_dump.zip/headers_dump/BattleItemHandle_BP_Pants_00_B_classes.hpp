#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_BP_Pants_00_B.BattleItemHandle_BP_Pants_00_B_C
// Size: 0xb22 // Inherited bytes: 0xb22
struct UBattleItemHandle_BP_Pants_00_B_C : UBattleItemHandle_AvatarBP_C {
};

