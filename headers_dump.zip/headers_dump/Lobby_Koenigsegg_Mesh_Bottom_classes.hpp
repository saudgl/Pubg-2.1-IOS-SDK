#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C
// Size: 0x660 // Inherited bytes: 0x4a8
struct ALobby_Koenigsegg_Mesh_Bottom_C : ABP_ScriptBinder_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4a8 // Size: 0x08
	struct UActorSequenceComponent* Switch car; // Offset: 0x4b0 // Size: 0x08
	struct UStaticMeshComponent* SM_Lobby_Koenigsegg_Open_A; // Offset: 0x4b8 // Size: 0x08
	struct UStaticMeshComponent* SM_Lobby_Koenigsegg_Open_B; // Offset: 0x4c0 // Size: 0x08
	struct UStaticMeshComponent* SM_Lobby_Koenigsegg_Open_C; // Offset: 0x4c8 // Size: 0x08
	struct UStaticMeshComponent* SM_Lobby_Koenigsegg_Open_D; // Offset: 0x4d0 // Size: 0x08
	struct UStaticMeshComponent* StaticMesh; // Offset: 0x4d8 // Size: 0x08
	struct UStaticMeshComponent* SM_Lobby_Koenigsegg_Platform; // Offset: 0x4e0 // Size: 0x08
	struct UActorSequenceComponent* entrance; // Offset: 0x4e8 // Size: 0x08
	struct USceneComponent* Scene; // Offset: 0x4f0 // Size: 0x08
	struct UCapsuleComponent* Capsule; // Offset: 0x4f8 // Size: 0x08
	float Timeline_0_Alpha_ACB8AE614DFE050CA246E7B034D5967B; // Offset: 0x500 // Size: 0x04
	enum class ETimelineDirection Timeline_0__Direction_ACB8AE614DFE050CA246E7B034D5967B; // Offset: 0x504 // Size: 0x01
	char pad_0x505[0x3]; // Offset: 0x505 // Size: 0x03
	struct UTimelineComponent* Timeline_1; // Offset: 0x508 // Size: 0x08
	float LocationX; // Offset: 0x510 // Size: 0x04
	float LocationY; // Offset: 0x514 // Size: 0x04
	enum class ETouchIndex FingerIndex; // Offset: 0x518 // Size: 0x01
	bool RotateOnlyZ; // Offset: 0x519 // Size: 0x01
	bool Touching; // Offset: 0x51a // Size: 0x01
	char pad_0x51B[0x1]; // Offset: 0x51b // Size: 0x01
	float OriginTouchX; // Offset: 0x51c // Size: 0x04
	float OriginTouchY; // Offset: 0x520 // Size: 0x04
	struct FRotator CurRotator; // Offset: 0x524 // Size: 0x0c
	struct FSoftObjectPath Normal; // Offset: 0x530 // Size: 0x18
	struct FSoftObjectPath NormalSwitchCar; // Offset: 0x548 // Size: 0x18
	struct FSoftObjectPath NormalIdle; // Offset: 0x560 // Size: 0x18
	struct FSoftObjectPath NormalFullIdle; // Offset: 0x578 // Size: 0x18
	struct FSoftObjectPath TopIdle; // Offset: 0x590 // Size: 0x18
	struct FSoftObjectPath TopFullIdle; // Offset: 0x5a8 // Size: 0x18
	struct TMap<int, struct ALevelSequenceActor*> LevelSequenceActors; // Offset: 0x5c0 // Size: 0x50
	struct TMap<int, struct ULevelSequencePlayer*> LvelSequencePlayers; // Offset: 0x610 // Size: 0x50

	// Functions

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.RemoveCacheActor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RemoveCacheActor(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.ResetPlatform
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ResetPlatform(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.GetSeqByBind
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetSeqByBind(int Type, struct FMovieSceneObjectBindingID& NewParam); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.CreateLevelSequnceActor
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CreateLevelSequnceActor(struct UObject* SluaHUID, int sequenceType, struct ULevelSequencePlayer*& Player, struct ALevelSequenceActor*& sequenceActor); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.CreateSeq
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CreateSeq(int Type, struct UObject*& NewParam); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.TriggerRotate
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void TriggerRotate(float Delta); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.NeedRotate
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void NeedRotate(float X, float Y, bool& need); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.TickRotate
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void TickRotate(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.Timeline_0__FinishedFunc
	// Flags: [BlueprintEvent]
	void Timeline_0__FinishedFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.Timeline_0__UpdateFunc
	// Flags: [BlueprintEvent]
	void Timeline_0__UpdateFunc(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveTick(float DeltaSeconds); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentOnInputTouchBeginSignature__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentOnInputTouchBeginSignature__DelegateSignature(enum class ETouchIndex FingerIndex, struct UPrimitiveComponent* TouchedComponent); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_1_ComponentOnInputTouchEndSignature__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Capsule_K2Node_ComponentBoundEvent_1_ComponentOnInputTouchEndSignature__DelegateSignature(enum class ETouchIndex FingerIndex, struct UPrimitiveComponent* TouchedComponent); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.RotateSpecificAngle
	// Flags: [BlueprintCallable|BlueprintEvent]
	void RotateSpecificAngle(float Delta); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.StopRotate
	// Flags: [BlueprintCallable|BlueprintEvent]
	void StopRotate(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Koenigsegg_Mesh_Bottom.Lobby_Koenigsegg_Mesh_Bottom_C.ExecuteUbergraph_Lobby_Koenigsegg_Mesh_Bottom
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Lobby_Koenigsegg_Mesh_Bottom(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

