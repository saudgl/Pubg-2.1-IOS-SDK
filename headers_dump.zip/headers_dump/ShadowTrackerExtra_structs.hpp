#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ShadowTrackerExtra.SeekAndLockStageConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FSeekAndLockStageConfig {
	// Fields
	float LockTotalTime; // Offset: 0x00 // Size: 0x04
	float ShrinkSpeed; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.LaserTraceServerSyncData
// Size: 0x18 // Inherited bytes: 0x00
struct FLaserTraceServerSyncData {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
	struct FVector ClientTracePos; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.ExtraDamageInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FExtraDamageInfo {
	// Fields
	int DamageTypeId; // Offset: 0x00 // Size: 0x04
	enum class EAvatarDamagePosition DamagePosition; // Offset: 0x04 // Size: 0x01
	bool DamageToDying; // Offset: 0x05 // Size: 0x01
	bool DamageToDead; // Offset: 0x06 // Size: 0x01
	char pad_0x7[0x1]; // Offset: 0x07 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActivitySyncData
// Size: 0x1c // Inherited bytes: 0x00
struct FActivitySyncData {
	// Fields
	bool bIsDuringActivity; // Offset: 0x00 // Size: 0x01
	bool bIsAttachedToActor; // Offset: 0x01 // Size: 0x01
	bool bIsMovementDisabled; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	struct FVector AttachedOffsetLocation; // Offset: 0x04 // Size: 0x0c
	struct FRotator AttachedOffsetRotation; // Offset: 0x10 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterBodyOffset
// Size: 0x30 // Inherited bytes: 0x00
struct FCharacterBodyOffset {
	// Fields
	struct FVector HeadOffset; // Offset: 0x00 // Size: 0x0c
	struct FVector PitchOffset; // Offset: 0x0c // Size: 0x0c
	struct FVector FootOffset; // Offset: 0x18 // Size: 0x0c
	struct FVector TPPSpringArmOffset; // Offset: 0x24 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.PawnStateDisable
// Size: 0x02 // Inherited bytes: 0x00
struct FPawnStateDisable {
	// Fields
	enum class EPawnState PawnState; // Offset: 0x00 // Size: 0x01
	uint8_t Disabled; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.UnmannedVehicleSyncData
// Size: 0x10 // Inherited bytes: 0x00
struct FUnmannedVehicleSyncData {
	// Fields
	enum class EUAVUseType EUAVUseType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct ASTExtraVehicleBase* CurrentUnmannedVehicle; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.PickUpItemData
// Size: 0x38 // Inherited bytes: 0x00
struct FPickUpItemData {
	// Fields
	struct FItemDefineID ID; // Offset: 0x00 // Size: 0x18
	int Count; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FBattleItemAdditionalData> AdditionalDataList; // Offset: 0x20 // Size: 0x10
	int InstanceID; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DropGroundEffectInfo
// Size: 0x80 // Inherited bytes: 0x00
struct FDropGroundEffectInfo {
	// Fields
	float GroundEffectLifeSpan; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0xc]; // Offset: 0x04 // Size: 0x0c
	struct FTransform EffectTransform; // Offset: 0x10 // Size: 0x30
	struct UParticleSystem* GroundEffect; // Offset: 0x40 // Size: 0x28
	struct FString EffectPath; // Offset: 0x68 // Size: 0x10
	bool bShowGroundEffect; // Offset: 0x78 // Size: 0x01
	bool bUsePickUpSelfEffect; // Offset: 0x79 // Size: 0x01
	bool bEffectActive; // Offset: 0x7a // Size: 0x01
	char pad_0x7B[0x5]; // Offset: 0x7b // Size: 0x05
};

// Object Name: ScriptStruct ShadowTrackerExtra.STExtraVehicleSeat
// Size: 0xc0 // Inherited bytes: 0x00
struct FSTExtraVehicleSeat {
	// Fields
	enum class ESTExtraVehicleSeatType SeatType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FName AnimCompTagName; // Offset: 0x08 // Size: 0x08
	struct FName EnterVehicleSocket; // Offset: 0x10 // Size: 0x08
	struct FName LeaveVehicleSocket; // Offset: 0x18 // Size: 0x08
	enum class EMovementMode OccupyMovementMode; // Offset: 0x20 // Size: 0x01
	enum class EVHSeatWeaponHoldType HoldWeaponType; // Offset: 0x21 // Size: 0x01
	enum class EVHSeatSpecialType SeatSpecialType; // Offset: 0x22 // Size: 0x01
	bool IsCanLeanOut; // Offset: 0x23 // Size: 0x01
	bool NarrowSeatNeedUseCommomAimAnim; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
	int GUIDisplayIndex; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct UCurveFloat* MinViewPitchCurve; // Offset: 0x30 // Size: 0x08
	struct FRotator CharRotVsVehiRot; // Offset: 0x38 // Size: 0x0c
	enum class EVHSeatSideType SeatSideType; // Offset: 0x44 // Size: 0x01
	bool bEnableVehicleWeapon; // Offset: 0x45 // Size: 0x01
	bool bEnableUsedAsFreeFireSeat; // Offset: 0x46 // Size: 0x01
	bool bEnableChangeFreeFireSeat; // Offset: 0x47 // Size: 0x01
	struct TArray<struct FSTExtraVehicleWeaponConfig> VehicleWeaponConfig; // Offset: 0x48 // Size: 0x10
	bool bDefaultControlWeapon; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x7]; // Offset: 0x59 // Size: 0x07
	struct FName VehicleWeaponSeatSocket; // Offset: 0x60 // Size: 0x08
	bool bAddDynamicCapsuleCollision; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x3]; // Offset: 0x69 // Size: 0x03
	float Radius; // Offset: 0x6c // Size: 0x04
	float HalfHeight; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0xc]; // Offset: 0x74 // Size: 0x0c
	struct FTransform CollisionOffset; // Offset: 0x80 // Size: 0x30
	bool bDrawDebug; // Offset: 0xb0 // Size: 0x01
	char pad_0xB1[0x3]; // Offset: 0xb1 // Size: 0x03
	float OnSeatCameraSpringArmLength; // Offset: 0xb4 // Size: 0x04
	char pad_0xB8[0x8]; // Offset: 0xb8 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.STExtraVehicleWeaponConfig
// Size: 0x60 // Inherited bytes: 0x00
struct FSTExtraVehicleWeaponConfig {
	// Fields
	struct FName VehicleWeaponSocket; // Offset: 0x00 // Size: 0x08
	struct AVehicleShootWeapon* VehicleWeaponClass; // Offset: 0x08 // Size: 0x08
	struct FVector2D ViewYawLimit; // Offset: 0x10 // Size: 0x08
	struct FVector2D ViewPitchLimit; // Offset: 0x18 // Size: 0x08
	bool bVerifyMuzzleDirection; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	float MuzzleDirTor; // Offset: 0x24 // Size: 0x04
	bool bVerifyMuzzleLimit; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	float MuzzleVehicleTore; // Offset: 0x2c // Size: 0x04
	bool bVerifyMuzzleBoxRanges; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	struct FBox MuzzleRangeBox; // Offset: 0x34 // Size: 0x1c
	float DistTorSquared; // Offset: 0x50 // Size: 0x04
	bool UseByDriver; // Offset: 0x54 // Size: 0x01
	char pad_0x55[0x3]; // Offset: 0x55 // Size: 0x03
	int VehicleWeaponParentIndex; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.STExtraVehicleAttachment
// Size: 0x10 // Inherited bytes: 0x00
struct FSTExtraVehicleAttachment {
	// Fields
	struct FName AttachSocket; // Offset: 0x00 // Size: 0x08
	struct AVehicleAttachmentBase* VehicleAttachementClass; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.STExtraVehicleWeaponsOnSeat
// Size: 0x20 // Inherited bytes: 0x00
struct FSTExtraVehicleWeaponsOnSeat {
	// Fields
	struct TArray<struct AVehicleShootWeapon*> WeaponsOnSeat; // Offset: 0x00 // Size: 0x10
	struct TArray<int> BorrowedSeat; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponSystemDataOnSimulateClient
// Size: 0x38 // Inherited bytes: 0x00
struct FWeaponSystemDataOnSimulateClient {
	// Fields
	struct ASTExtraWeapon* TargetWeapon; // Offset: 0x00 // Size: 0x08
	struct FName LogicSocket; // Offset: 0x08 // Size: 0x08
	bool bAutoUse; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FItemDefineID ID; // Offset: 0x18 // Size: 0x18
	int OperationIndex; // Offset: 0x30 // Size: 0x04
	int BagLevel; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AutoTriggerWeaponEventParam
// Size: 0x38 // Inherited bytes: 0x00
struct FAutoTriggerWeaponEventParam {
	// Fields
	int TargetOwnerRole; // Offset: 0x00 // Size: 0x04
	enum class EWeaponTriggerEvent TargetEvent; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct FItemDefineID TargetWeaponID; // Offset: 0x08 // Size: 0x18
	bool bIgnoreItemIDInstance; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct TArray<enum class EPawnState> ForceExitPawnStateList; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpawnAndBackpackWeaponReplicatedData
// Size: 0x60 // Inherited bytes: 0x00
struct FSpawnAndBackpackWeaponReplicatedData {
	// Fields
	struct ASTExtraWeapon* TargetWeapon; // Offset: 0x00 // Size: 0x08
	struct FName LogicSocket; // Offset: 0x08 // Size: 0x08
	bool bAutoUse; // Offset: 0x10 // Size: 0x01
	bool bNeedSwitch; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x6]; // Offset: 0x12 // Size: 0x06
	struct FItemDefineID ID; // Offset: 0x18 // Size: 0x18
	bool bResetBulletNum; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	int ClientResetBulletNum; // Offset: 0x34 // Size: 0x04
	int OperationIndex; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct AActor* WeaponOwnerActor; // Offset: 0x40 // Size: 0x08
	struct FString OwnerCharacterName; // Offset: 0x48 // Size: 0x10
	bool bIsValid; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x3]; // Offset: 0x59 // Size: 0x03
	int SyncTicket; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponCreateInstance
// Size: 0x20 // Inherited bytes: 0x00
struct FWeaponCreateInstance {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x18
	int SyncTicket; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VolleyShootInfoCache
// Size: 0x18 // Inherited bytes: 0x00
struct FVolleyShootInfoCache {
	// Fields
	struct FVector StartLoc; // Offset: 0x00 // Size: 0x0c
	struct FVector ShootDir; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShootWeaponCustomDamageList
// Size: 0x50 // Inherited bytes: 0x00
struct FShootWeaponCustomDamageList {
	// Fields
	struct TMap<enum class EAvatarDamagePosition, struct FShootWeaponCustomDamage> Data; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShootWeaponCustomDamage
// Size: 0x30 // Inherited bytes: 0x00
struct FShootWeaponCustomDamage {
	// Fields
	struct UParticleSystem* ParticleSystem; // Offset: 0x00 // Size: 0x28
	float DamageRate; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.NormalProjectileVerifyConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FNormalProjectileVerifyConfig {
	// Fields
	float MaxShootPointTolerateDistanceOffset; // Offset: 0x00 // Size: 0x04
	float MaxShootPointTolerateDistanceOffsetVehicle; // Offset: 0x04 // Size: 0x04
	float MaxImpactPointTolerateDistanceOffset; // Offset: 0x08 // Size: 0x04
	float BlockVerifyImpactNormalOffset; // Offset: 0x0c // Size: 0x04
	bool bVerifyBulletScDiff; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	float MaxDiffServerClient; // Offset: 0x14 // Size: 0x04
	bool bVerifyShootDir2D; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	float ShortDirReverseDistance; // Offset: 0x1c // Size: 0x04
	float TolerateBulletDirOffsetSquared; // Offset: 0x20 // Size: 0x04
	float VerifyWeaponFireInfoTimeTorelate; // Offset: 0x24 // Size: 0x04
	bool bVerifyWeaponFireInfoTimeForcePunish; // Offset: 0x28 // Size: 0x01
	bool bVerifyClientFlySpeed; // Offset: 0x29 // Size: 0x01
	bool bVerifyLauchTimeWithServer; // Offset: 0x2a // Size: 0x01
	char pad_0x2B[0x1]; // Offset: 0x2b // Size: 0x01
	float ClientServerFlyTimeTorelate; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarActionBase
// Size: 0x18 // Inherited bytes: 0x00
struct FAvatarActionBase {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.MeshData
// Size: 0x80 // Inherited bytes: 0x00
struct FMeshData {
	// Fields
	struct UStaticMesh* stMesh; // Offset: 0x00 // Size: 0x08
	struct USkeletalMesh* skMesh; // Offset: 0x08 // Size: 0x08
	struct UMaterialInstance* matIns; // Offset: 0x10 // Size: 0x08
	struct TArray<struct UMaterialInstance*> additionalMats; // Offset: 0x18 // Size: 0x10
	enum class EMeshType meshType; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct TArray<int> hiddenSlots; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FReplacedSlotInfo> replacedSlots; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FHideBoneData> hideBoneSlots; // Offset: 0x50 // Size: 0x10
	struct FItemDefineID definedID; // Offset: 0x60 // Size: 0x18
	bool functionValid; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x7]; // Offset: 0x79 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.HideBoneData
// Size: 0x20 // Inherited bytes: 0x00
struct FHideBoneData {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct ShadowTrackerExtra.ReplacedSlotInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FReplacedSlotInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.MeshSynData
// Size: 0x28 // Inherited bytes: 0x00
struct FMeshSynData {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x18
	int gender; // Offset: 0x18 // Size: 0x04
	enum class ESyncOperation OperationType; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
	int AdditionalItemID; // Offset: 0x20 // Size: 0x04
	int DIYPlanID; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DIYEnableLevel
// Size: 0x08 // Inherited bytes: 0x00
struct FDIYEnableLevel {
	// Fields
	int DeviceLevel; // Offset: 0x00 // Size: 0x04
	int EnableLevel; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HandleMeshPack
// Size: 0x158 // Inherited bytes: 0x00
struct FHandleMeshPack {
	// Fields
	struct UBattleItemHandleBase* Handle; // Offset: 0x00 // Size: 0x08
	struct FWeaponMeshCfg MeshCfg; // Offset: 0x08 // Size: 0x150
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponMeshCfg
// Size: 0x150 // Inherited bytes: 0x00
struct FWeaponMeshCfg {
	// Fields
	struct UStaticMesh* stMesh; // Offset: 0x00 // Size: 0x28
	struct USkeletalMesh* skMesh; // Offset: 0x28 // Size: 0x28
	struct UStaticMesh* stMeshLod; // Offset: 0x50 // Size: 0x28
	struct USkeletalMesh* skMeshLod; // Offset: 0x78 // Size: 0x28
	struct UMaterialInterface* MeshMat; // Offset: 0xa0 // Size: 0x28
	struct FName MeshMatSlotName; // Offset: 0xc8 // Size: 0x08
	struct UMaterialInterface* OverrideMatByGameMode; // Offset: 0xd0 // Size: 0x28
	struct UMaterialInterface* baseMat; // Offset: 0xf8 // Size: 0x08
	struct UMaterialInterface* baseMatClass; // Offset: 0x100 // Size: 0x28
	struct TArray<struct FParticleRes> ParticleEffects; // Offset: 0x128 // Size: 0x10
	struct TArray<struct FUIWidgetRes> WidgetList; // Offset: 0x138 // Size: 0x10
	enum class EMeshType meshType; // Offset: 0x148 // Size: 0x01
	char pad_0x149[0x7]; // Offset: 0x149 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.UIWidgetRes
// Size: 0x50 // Inherited bytes: 0x00
struct FUIWidgetRes {
	// Fields
	struct UUserWidget* UserWidget; // Offset: 0x00 // Size: 0x08
	struct FName AttachSocket; // Offset: 0x08 // Size: 0x08
	struct FTransform Trans; // Offset: 0x10 // Size: 0x30
	struct FVector2D DrawSize; // Offset: 0x40 // Size: 0x08
	bool bShowDefault; // Offset: 0x48 // Size: 0x01
	bool bUseScreenSpace; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x6]; // Offset: 0x4a // Size: 0x06
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleRes
// Size: 0x10 // Inherited bytes: 0x00
struct FParticleRes {
	// Fields
	struct UParticleSystem* ParticleRes; // Offset: 0x00 // Size: 0x08
	struct FName AttachSocket; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemAvatarMatPath
// Size: 0x38 // Inherited bytes: 0x00
struct FItemAvatarMatPath {
	// Fields
	struct FName SlotID; // Offset: 0x00 // Size: 0x08
	struct FSoftObjectPath MatInstancePath; // Offset: 0x08 // Size: 0x18
	struct FSoftObjectPath MatBasePath; // Offset: 0x20 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.NetItemAvatarData
// Size: 0x20 // Inherited bytes: 0x00
struct FNetItemAvatarData {
	// Fields
	struct FItemDefineID ItemDefineID; // Offset: 0x00 // Size: 0x18
	int UpdateFlag; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponComponentItemData
// Size: 0x1d0 // Inherited bytes: 0x00
struct FWeaponComponentItemData {
	// Fields
	struct FPickUpGlobalDataTableRow PickUpGlobalDataTableRow; // Offset: 0x00 // Size: 0x1b0
	struct FWeaponComponentDataTableRow WeaponComponentDataTableRow; // Offset: 0x1b0 // Size: 0x20
};

// Object Name: ScriptStruct ShadowTrackerExtra.SurviveTableRowBase
// Size: 0x10 // Inherited bytes: 0x08
struct FSurviveTableRowBase : FTableRowBase {
	// Fields
	int ID; // Offset: 0x08 // Size: 0x04
	int PickUpSoundID; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponComponentDataTableRow
// Size: 0x20 // Inherited bytes: 0x10
struct FWeaponComponentDataTableRow : FSurviveTableRowBase {
	// Fields
	int WeaponComponentID; // Offset: 0x10 // Size: 0x04
	enum class EWeaponComponentType Type; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	struct UStaticMesh* ShowMesh; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.PickUpGlobalDataTableRow
// Size: 0x1b0 // Inherited bytes: 0x10
struct FPickUpGlobalDataTableRow : FSurviveTableRowBase {
	// Fields
	enum class ESurvivePickUpGlobalCategory SurvivePickUpGlobalCategory; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FSlateBrush SmallProfileImage; // Offset: 0x18 // Size: 0xb8
	struct FSlateBrush LargerProfileImage; // Offset: 0xd0 // Size: 0xb8
	struct FString Name; // Offset: 0x188 // Size: 0x10
	struct FString Description; // Offset: 0x198 // Size: 0x10
	int DisplayPriority; // Offset: 0x1a8 // Size: 0x04
	char pad_0x1AC[0x4]; // Offset: 0x1ac // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterCompOutOfVisionOptimizationItem
// Size: 0x06 // Inherited bytes: 0x00
struct FCharacterCompOutOfVisionOptimizationItem {
	// Fields
	bool bAbsoluteLocation; // Offset: 0x00 // Size: 0x01
	bool bAbsoluteRotation; // Offset: 0x01 // Size: 0x01
	bool bAbsoluteScale; // Offset: 0x02 // Size: 0x01
	bool bShouldUpdateOverLaps; // Offset: 0x03 // Size: 0x01
	bool bNoSkeletonUpdate; // Offset: 0x04 // Size: 0x01
	bool bVisible; // Offset: 0x05 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.SceneCompUpdateOptimizationItem
// Size: 0x05 // Inherited bytes: 0x00
struct FSceneCompUpdateOptimizationItem {
	// Fields
	char pad_0x0[0x5]; // Offset: 0x00 // Size: 0x05
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponReconnectReplicateData
// Size: 0x80 // Inherited bytes: 0x00
struct FWeaponReconnectReplicateData {
	// Fields
	struct ASTExtraPlayerController* OwnerPlayerController; // Offset: 0x00 // Size: 0x08
	struct AActor* WeaponOwner; // Offset: 0x08 // Size: 0x08
	bool UseNewReconnect; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FString OwnerPlayerName; // Offset: 0x18 // Size: 0x10
	struct FName WeaponInventoryLogicSocket; // Offset: 0x28 // Size: 0x08
	struct FBulletInClip WeaponBulletInClip; // Offset: 0x30 // Size: 0x18
	uint32_t WeaponShootID; // Offset: 0x48 // Size: 0x04
	uint32_t WeaponClipID; // Offset: 0x4c // Size: 0x04
	enum class EFreshWeaponStateType CurWeaponState; // Offset: 0x50 // Size: 0x01
	enum class ESTEWeaponShootType CurShootType; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0x2]; // Offset: 0x52 // Size: 0x02
	int CurShootTotalType; // Offset: 0x54 // Size: 0x04
	struct FItemDefineID DefineID; // Offset: 0x58 // Size: 0x18
	int BackpackPistolListIndex; // Offset: 0x70 // Size: 0x04
	bool bIsCurrentWeapon; // Offset: 0x74 // Size: 0x01
	char pad_0x75[0x3]; // Offset: 0x75 // Size: 0x03
	int OperationIndex; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BulletInClip
// Size: 0x18 // Inherited bytes: 0x00
struct FBulletInClip {
	// Fields
	int CurBulletNumInClip; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FBulletInWeapon> CurBulletIDList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.BulletInWeapon
// Size: 0x08 // Inherited bytes: 0x00
struct FBulletInWeapon {
	// Fields
	int BulletID; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MainWeaponTableStruct
// Size: 0x18 // Inherited bytes: 0x00
struct FMainWeaponTableStruct {
	// Fields
	int KeyID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> SkillIDList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponAttrModifyData
// Size: 0x18 // Inherited bytes: 0x00
struct FWeaponAttrModifyData {
	// Fields
	struct FString ModifyAttr; // Offset: 0x00 // Size: 0x10
	enum class EAttrOperator Op; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	float ModifyValue; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BulletHitInfoUploadDataInReplay
// Size: 0x250 // Inherited bytes: 0x00
struct FBulletHitInfoUploadDataInReplay {
	// Fields
	enum class EShootVertifyRes VertifyRes; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0xf]; // Offset: 0x01 // Size: 0x0f
	struct FBulletHitInfoUploadData UploadData; // Offset: 0x10 // Size: 0x110
	struct FCharacterHistoryData VictimHistoryData; // Offset: 0x120 // Size: 0x78
	char pad_0x198[0x8]; // Offset: 0x198 // Size: 0x08
	struct FShootTimeData ShootTimeData; // Offset: 0x1a0 // Size: 0xa0
	uint32_t CurrentUserCmdSequence; // Offset: 0x240 // Size: 0x04
	char pad_0x244[0xc]; // Offset: 0x244 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShootTimeData
// Size: 0xa0 // Inherited bytes: 0x00
struct FShootTimeData {
	// Fields
	struct FVector_NetQuantize ShootPos; // Offset: 0x00 // Size: 0x0c
	struct FVector_NetQuantize GunPos; // Offset: 0x0c // Size: 0x0c
	struct FVector_NetQuantizeNormalSv MuzzleDir; // Offset: 0x18 // Size: 0x0c
	uint32_t ShootID; // Offset: 0x24 // Size: 0x04
	uint64 CurrentStates; // Offset: 0x28 // Size: 0x08
	char CapsuleHalfHeight; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	float SkeletonLength; // Offset: 0x34 // Size: 0x04
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FShootTimeInfo_NetQuantize ShootInfo; // Offset: 0x40 // Size: 0x40
	uint32_t UserCmdSequence; // Offset: 0x80 // Size: 0x04
	char ShootTimeConDelta; // Offset: 0x84 // Size: 0x01
	char pad_0x85[0x3]; // Offset: 0x85 // Size: 0x03
	float ShootLevelTime; // Offset: 0x88 // Size: 0x04
	struct FVector_NetQuantize GunTailPos; // Offset: 0x8c // Size: 0x0c
	char ShotFlags; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x7]; // Offset: 0x99 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShootTimeInfo_NetQuantize
// Size: 0x40 // Inherited bytes: 0x00
struct FShootTimeInfo_NetQuantize {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x00 // Size: 0x40
};

// Object Name: ScriptStruct ShadowTrackerExtra.Vector_NetQuantizeNormalSv
// Size: 0x0c // Inherited bytes: 0x0c
struct FVector_NetQuantizeNormalSv : FVector {
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterHistoryData
// Size: 0x78 // Inherited bytes: 0x00
struct FCharacterHistoryData {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x0c // Size: 0x0c
	struct FBox BoundBox; // Offset: 0x18 // Size: 0x1c
	struct FBox HeadBoundBox; // Offset: 0x34 // Size: 0x1c
	bool IsInVehicle; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x3]; // Offset: 0x51 // Size: 0x03
	struct FVector VehicleLocation; // Offset: 0x54 // Size: 0x0c
	struct FVector Velocity; // Offset: 0x60 // Size: 0x0c
	uint32_t UserCmdSequenceNew; // Offset: 0x6c // Size: 0x04
	uint32_t UserCmdSequenceOld; // Offset: 0x70 // Size: 0x04
	enum class EMoveBaseSpeedType MoveBaseState; // Offset: 0x74 // Size: 0x01
	char pad_0x75[0x3]; // Offset: 0x75 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.BulletHitInfoUploadData
// Size: 0x110 // Inherited bytes: 0x00
struct FBulletHitInfoUploadData {
	// Fields
	struct FVector ImpactPoint; // Offset: 0x00 // Size: 0x0c
	struct FVector_NetQuantize RelativeImpactPoint; // Offset: 0x0c // Size: 0x0c
	struct FVector_NetQuantizeNormal ImpactNormal; // Offset: 0x18 // Size: 0x0c
	struct FVector_NetQuantize VictimLocation; // Offset: 0x24 // Size: 0x0c
	struct FVector_NetQuantize BulletPos; // Offset: 0x30 // Size: 0x0c
	struct FVector_NetQuantize ShootMomentMuzzlePos; // Offset: 0x3c // Size: 0x0c
	struct FVector2D ShootDir2D; // Offset: 0x48 // Size: 0x08
	char SurfaceType; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x3]; // Offset: 0x51 // Size: 0x03
	uint32_t ShootID; // Offset: 0x54 // Size: 0x04
	int BulletTypeSpecialID; // Offset: 0x58 // Size: 0x04
	uint16_t CompensationTime; // Offset: 0x5c // Size: 0x02
	char pad_0x5E[0x2]; // Offset: 0x5e // Size: 0x02
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x60 // Size: 0x08
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // Offset: 0x68 // Size: 0x08
	int TimeStamp; // Offset: 0x70 // Size: 0x04
	int ClientShootTime; // Offset: 0x74 // Size: 0x04
	char SpecialBulletID; // Offset: 0x78 // Size: 0x01
	char HitBodyType; // Offset: 0x79 // Size: 0x01
	char pad_0x7A[0x2]; // Offset: 0x7a // Size: 0x02
	uint32_t CharacterImpactOffsetSquared; // Offset: 0x7c // Size: 0x04
	float MuzzleFloorHeight; // Offset: 0x80 // Size: 0x04
	struct FVector_NetQuantize WeaponOwnerHeadPos; // Offset: 0x84 // Size: 0x0c
	float DamageRate; // Offset: 0x90 // Size: 0x04
	bool bIsFirstImpact; // Offset: 0x94 // Size: 0x01
	char pad_0x95[0x3]; // Offset: 0x95 // Size: 0x03
	struct FVector_NetQuantize GunTailPos; // Offset: 0x98 // Size: 0x0c
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
	struct FName BoneName; // Offset: 0xa8 // Size: 0x08
	struct FTransform BoneTrans; // Offset: 0xb0 // Size: 0x30
	char ImpactEffectMask; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0x2f]; // Offset: 0xe1 // Size: 0x2f
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponCrossHairPerformData
// Size: 0x18 // Inherited bytes: 0x00
struct FWeaponCrossHairPerformData {
	// Fields
	struct TArray<struct FWeaponCrossHairIconData> Crosshair; // Offset: 0x00 // Size: 0x10
	enum class ECrossHairSpreadType SpreadType; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponCrossHairIconData
// Size: 0x40 // Inherited bytes: 0x00
struct FWeaponCrossHairIconData {
	// Fields
	struct FCanvasIcon2D Icon; // Offset: 0x00 // Size: 0x18
	float Offset; // Offset: 0x18 // Size: 0x04
	struct FVector2D IconOffset; // Offset: 0x1c // Size: 0x08
	float Alpha; // Offset: 0x24 // Size: 0x04
	float Scale; // Offset: 0x28 // Size: 0x04
	float IconRotate; // Offset: 0x2c // Size: 0x04
	float LogicRotate; // Offset: 0x30 // Size: 0x04
	bool IsSpreadEnable; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	float BlendInOutRatePerSec; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CanvasIcon2D
// Size: 0x18 // Inherited bytes: 0x00
struct FCanvasIcon2D {
	// Fields
	struct UTexture2D* Texture; // Offset: 0x00 // Size: 0x08
	float U; // Offset: 0x08 // Size: 0x04
	float V; // Offset: 0x0c // Size: 0x04
	float UL; // Offset: 0x10 // Size: 0x04
	float VL; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponHitPartCoff
// Size: 0x14 // Inherited bytes: 0x00
struct FWeaponHitPartCoff {
	// Fields
	float Head; // Offset: 0x00 // Size: 0x04
	float Body; // Offset: 0x04 // Size: 0x04
	float Limbs; // Offset: 0x08 // Size: 0x04
	float Hand; // Offset: 0x0c // Size: 0x04
	float Foot; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SRangeAttenuateConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FSRangeAttenuateConfig {
	// Fields
	int rangeStart; // Offset: 0x00 // Size: 0x04
	int rangeEnd; // Offset: 0x04 // Size: 0x04
	float rangeAttenuateFactor; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponVisualBulletItemConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FWeaponVisualBulletItemConfig {
	// Fields
	bool bEnabled; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UParticleSystem* VisualBulletTrackFX; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SecurityLogHitTargetInfo
// Size: 0x24 // Inherited bytes: 0x00
struct FSecurityLogHitTargetInfo {
	// Fields
	char pad_0x0[0x24]; // Offset: 0x00 // Size: 0x24
};

// Object Name: ScriptStruct ShadowTrackerExtra.LocalShootHitData
// Size: 0x78 // Inherited bytes: 0x00
struct FLocalShootHitData {
	// Fields
	uint32_t ShootID; // Offset: 0x00 // Size: 0x04
	struct FVector_NetQuantize ShootingDeviation; // Offset: 0x04 // Size: 0x0c
	struct FVector_NetQuantize BulletsBornPosition; // Offset: 0x10 // Size: 0x0c
	int BulletFlyDistance; // Offset: 0x1c // Size: 0x04
	int BulletDown; // Offset: 0x20 // Size: 0x04
	uint8_t CurBullet; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
	int ShootInterval; // Offset: 0x28 // Size: 0x04
	int BulletFlyTime; // Offset: 0x2c // Size: 0x04
	int BulletShootTime; // Offset: 0x30 // Size: 0x04
	int BulletHitTime; // Offset: 0x34 // Size: 0x04
	int AimFov; // Offset: 0x38 // Size: 0x04
	char bulletDamageReduceRatio; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
	struct FVector_NetQuantize ShootingRecoil; // Offset: 0x40 // Size: 0x0c
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	int64_t ClientStartTime; // Offset: 0x50 // Size: 0x08
	struct TArray<int> MrpcsFlow; // Offset: 0x58 // Size: 0x10
	int AutoAimSpeed; // Offset: 0x68 // Size: 0x04
	int AutoAimSpeedRateMax; // Offset: 0x6c // Size: 0x04
	int AutoAimRangeMax; // Offset: 0x70 // Size: 0x04
	int AutoAimRangeRateMax; // Offset: 0x74 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.STPointDamageEvent
// Size: 0xb0 // Inherited bytes: 0xa8
struct FSTPointDamageEvent : FPointDamageEvent {
	// Fields
	int ItemId; // Offset: 0xa8 // Size: 0x04
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShootWeaponDamageEvent
// Size: 0xd0 // Inherited bytes: 0xb0
struct FShootWeaponDamageEvent : FSTPointDamageEvent {
	// Fields
	char AvatarDamagePosition; // Offset: 0xad // Size: 0x01
	char pad_0xB1[0x17]; // Offset: 0xb1 // Size: 0x17
	float DamageImpulse; // Offset: 0xc8 // Size: 0x04
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimulateBulletHitInfoData
// Size: 0x48 // Inherited bytes: 0x00
struct FSimulateBulletHitInfoData {
	// Fields
	struct FVector_NetQuantize10 ImpactPoint; // Offset: 0x00 // Size: 0x0c
	struct FVector_NetQuantize RelativeImpactPoint; // Offset: 0x0c // Size: 0x0c
	struct FVector_NetQuantizeNormal ImpactNormal; // Offset: 0x18 // Size: 0x0c
	struct FVector_NetQuantize10 ShootMomentMuzzlePos; // Offset: 0x24 // Size: 0x0c
	char SurfaceType; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x34 // Size: 0x08
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // Offset: 0x3c // Size: 0x08
	char HitBodyType; // Offset: 0x44 // Size: 0x01
	char ImpactEffectMask; // Offset: 0x45 // Size: 0x01
	char pad_0x46[0x2]; // Offset: 0x46 // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponAttrModifyConfig
// Size: 0x28 // Inherited bytes: 0x00
struct FWeaponAttrModifyConfig {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString ModifyConfigID; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FWeaponAttrModifyData> WeaponAttrModifiers; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponVerifyConfig
// Size: 0x40 // Inherited bytes: 0x00
struct FWeaponVerifyConfig {
	// Fields
	int VerifyIgnoreType; // Offset: 0x00 // Size: 0x04
	bool bVerifySooterSkeleton; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	float ShooterMuzzleOffsetAdditional; // Offset: 0x08 // Size: 0x04
	float ShooterMuzzleCircleAddit; // Offset: 0x0c // Size: 0x04
	bool bUseCompressDataUpload; // Offset: 0x10 // Size: 0x01
	bool bVerifyAttachDistance; // Offset: 0x11 // Size: 0x01
	bool bForceAttach; // Offset: 0x12 // Size: 0x01
	char pad_0x13[0x1]; // Offset: 0x13 // Size: 0x01
	float MaxAttachDistanceHorizon; // Offset: 0x14 // Size: 0x04
	float MaxAttachDistanceZ; // Offset: 0x18 // Size: 0x04
	float MinAttachDistanceZ; // Offset: 0x1c // Size: 0x04
	float MaxGunRoot; // Offset: 0x20 // Size: 0x04
	float MaxMuzzleGun; // Offset: 0x24 // Size: 0x04
	float DistMuzzleGun; // Offset: 0x28 // Size: 0x04
	float MuzzleHighCD; // Offset: 0x2c // Size: 0x04
	float AimFlyCD; // Offset: 0x30 // Size: 0x04
	bool bVerifyRpgController; // Offset: 0x34 // Size: 0x01
	bool bVerifyFakeTraceBock; // Offset: 0x35 // Size: 0x01
	char pad_0x36[0x2]; // Offset: 0x36 // Size: 0x02
	float MaxBackTraceSize; // Offset: 0x38 // Size: 0x04
	bool bVerifyRpgShootInterval; // Offset: 0x3c // Size: 0x01
	bool bVerifyRpgShootDir; // Offset: 0x3d // Size: 0x01
	char pad_0x3E[0x2]; // Offset: 0x3e // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarTableData
// Size: 0xa0 // Inherited bytes: 0x00
struct FAvatarTableData {
	// Fields
	int SlotID; // Offset: 0x00 // Size: 0x04
	int SubSlotID; // Offset: 0x04 // Size: 0x04
	struct TArray<int> HideFlags; // Offset: 0x08 // Size: 0x10
	struct TArray<int> ReplaceFlags; // Offset: 0x18 // Size: 0x10
	struct TArray<int> RecoverHideFlagsWhenSelfHidden; // Offset: 0x28 // Size: 0x10
	struct TArray<int> RecoverReplaceFlagsWhenSelfHidden; // Offset: 0x38 // Size: 0x10
	struct TArray<int> RecoverHideFlagsWhenSelfReplaced; // Offset: 0x48 // Size: 0x10
	struct TArray<int> RecoverReplaceFlagsWhenSelfReplaced; // Offset: 0x58 // Size: 0x10
	struct TArray<int> ConflictConfig; // Offset: 0x68 // Size: 0x10
	struct TArray<int> ConflictConfigWhenSelfReplaced; // Offset: 0x78 // Size: 0x10
	int HideBoneSlotID; // Offset: 0x88 // Size: 0x04
	int HideBoneType; // Offset: 0x8c // Size: 0x04
	struct TArray<struct FName> HideBoneNames; // Offset: 0x90 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarSyncData
// Size: 0x38 // Inherited bytes: 0x00
struct FAvatarSyncData {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int AdditionalItemID; // Offset: 0x04 // Size: 0x04
	int SlotID; // Offset: 0x08 // Size: 0x04
	int SubSlotID; // Offset: 0x0c // Size: 0x04
	int HideState; // Offset: 0x10 // Size: 0x04
	int ReplaceState; // Offset: 0x14 // Size: 0x04
	int FakeItemID; // Offset: 0x18 // Size: 0x04
	enum class ESlotDescDiff ForceDescDiff; // Offset: 0x1c // Size: 0x01
	enum class ESyncOperation OperationType; // Offset: 0x1d // Size: 0x01
	char pad_0x1E[0x2]; // Offset: 0x1e // Size: 0x02
	struct FAvatarCustom CustomInfo; // Offset: 0x20 // Size: 0x14
	enum class EForceHideState ForceHideState; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarCustom
// Size: 0x14 // Inherited bytes: 0x00
struct FAvatarCustom {
	// Fields
	enum class EAvatarCustomType CustomType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int ColorID; // Offset: 0x04 // Size: 0x04
	int PatternID; // Offset: 0x08 // Size: 0x04
	int NumID; // Offset: 0x0c // Size: 0x04
	int ParticleID; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarSlotDesc
// Size: 0x78 // Inherited bytes: 0x00
struct FAvatarSlotDesc {
	// Fields
	int SlotID; // Offset: 0x00 // Size: 0x04
	int SubSlotID; // Offset: 0x04 // Size: 0x04
	struct FItemDefineID ItemDefineID; // Offset: 0x08 // Size: 0x18
	struct FItemDefineID RealShowItemDefineID; // Offset: 0x20 // Size: 0x18
	int gender; // Offset: 0x38 // Size: 0x04
	int HideState; // Offset: 0x3c // Size: 0x04
	int ReplaceState; // Offset: 0x40 // Size: 0x04
	bool IsExist; // Offset: 0x44 // Size: 0x01
	char pad_0x45[0x3]; // Offset: 0x45 // Size: 0x03
	struct FAvatarCustom CustomInfo; // Offset: 0x48 // Size: 0x14
	bool bForceHideState; // Offset: 0x5c // Size: 0x01
	enum class ESlotDescDiff SlotDescDiff; // Offset: 0x5d // Size: 0x01
	char pad_0x5E[0x2]; // Offset: 0x5e // Size: 0x02
	struct FItemDefineID OldItemDefineID; // Offset: 0x60 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.ForceEquipSlotInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FForceEquipSlotInfo {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.NetAvatarSyncData
// Size: 0x20 // Inherited bytes: 0x00
struct FNetAvatarSyncData {
	// Fields
	struct TArray<struct FAvatarSyncData> SlotSyncData; // Offset: 0x00 // Size: 0x10
	int gender; // Offset: 0x10 // Size: 0x04
	int BaseID; // Offset: 0x14 // Size: 0x04
	int UpdateFlag; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SlotHandleDesc
// Size: 0x38 // Inherited bytes: 0x00
struct FSlotHandleDesc {
	// Fields
	int SlotID; // Offset: 0x00 // Size: 0x04
	struct TWeakObjectPtr<struct UItemHandleBase> EquipHandle; // Offset: 0x04 // Size: 0x08
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct UAvatarCustomBase*> CustomHandles; // Offset: 0x10 // Size: 0x10
	struct FSoftObjectPath EquipMeshAssetPath; // Offset: 0x20 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.SlotMeshDesc
// Size: 0x40 // Inherited bytes: 0x00
struct FSlotMeshDesc {
	// Fields
	int SlotID; // Offset: 0x00 // Size: 0x04
	struct TWeakObjectPtr<struct UMeshComponent> MeshComp; // Offset: 0x04 // Size: 0x08
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FParticleGroup ParticleGroup; // Offset: 0x10 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleGroup
// Size: 0x30 // Inherited bytes: 0x00
struct FParticleGroup {
	// Fields
	struct TArray<struct UParticleSystem*> ParticleSystemList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct UParticleSystemComponent*> ParticleCompList; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FParticleAsset> ParticleAssetList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleAsset
// Size: 0x80 // Inherited bytes: 0x00
struct FParticleAsset {
	// Fields
	struct FTransform Transform; // Offset: 0x00 // Size: 0x30
	struct UParticleSystem* ParticleSystem; // Offset: 0x30 // Size: 0x28
	struct FName AttachSocket; // Offset: 0x58 // Size: 0x08
	struct FName ComponentTag; // Offset: 0x60 // Size: 0x08
	struct TArray<struct FParticleSysParam> InstanceParameters; // Offset: 0x68 // Size: 0x10
	bool bLimitCount; // Offset: 0x78 // Size: 0x01
	bool bAutoDestroy; // Offset: 0x79 // Size: 0x01
	char pad_0x7A[0x6]; // Offset: 0x7a // Size: 0x06
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarReAttachConfigCollection
// Size: 0x10 // Inherited bytes: 0x00
struct FAvatarReAttachConfigCollection {
	// Fields
	struct TArray<struct FReAttachConfig> AvatarReAttachList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ReAttachConfig
// Size: 0xe0 // Inherited bytes: 0x00
struct FReAttachConfig {
	// Fields
	enum class EAvatarSlotType ReAttachSlot; // Offset: 0x00 // Size: 0x01
	enum class EAvatarSlotType TriggerSlot; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	int Priority; // Offset: 0x04 // Size: 0x04
	bool bForceRecreateAdaptSlotMesh; // Offset: 0x08 // Size: 0x01
	enum class ERetargetAvatarAdaptSpace SlotAdaptSpace; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
	struct FTransform AttachTransform; // Offset: 0x10 // Size: 0x30
	bool bForceRecreateAdaptAssociatedSlotMesh; // Offset: 0x40 // Size: 0x01
	enum class ERetargetAvatarAdaptSpace AssociatedSlotAdaptSpace; // Offset: 0x41 // Size: 0x01
	char pad_0x42[0xe]; // Offset: 0x42 // Size: 0x0e
	struct FTransform AssociatedSlotAdaptTransform; // Offset: 0x50 // Size: 0x30
	struct TArray<enum class EAvatarSlotType> AssociatedSlotList; // Offset: 0x80 // Size: 0x10
	struct TMap<struct FName, struct FTransform> WingClothScaleTransformMap; // Offset: 0x90 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.AssetPackage
// Size: 0x08 // Inherited bytes: 0x00
struct FAssetPackage {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAttachMeshData
// Size: 0x100 // Inherited bytes: 0x08
struct FAvatarAttachMeshData : FAssetPackage {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
	struct FTransform Transform; // Offset: 0x10 // Size: 0x30
	struct FName AttachSocket; // Offset: 0x40 // Size: 0x08
	struct FName SlotName; // Offset: 0x48 // Size: 0x08
	struct UStaticMesh* StaticMesh; // Offset: 0x50 // Size: 0x28
	struct USkeletalMesh* SkeletalMesh; // Offset: 0x78 // Size: 0x28
	struct USkeletalMesh* LODSkeletalMesh; // Offset: 0xa0 // Size: 0x28
	struct UMaterialInterface* MatInstance; // Offset: 0xc8 // Size: 0x28
	struct UAnimInstance* AttachAnimBP; // Offset: 0xf0 // Size: 0x08
	bool bUseScreenFactorOptimizeAnimRate; // Offset: 0xf8 // Size: 0x01
	char pad_0xF9[0x7]; // Offset: 0xf9 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.MeshPackage
// Size: 0x258 // Inherited bytes: 0x08
struct FMeshPackage : FAssetPackage {
	// Fields
	struct UStaticMesh* maleStMesh; // Offset: 0x08 // Size: 0x28
	struct UStaticMesh* femaleStMesh; // Offset: 0x30 // Size: 0x28
	struct UStaticMesh* maleLODStMesh; // Offset: 0x58 // Size: 0x28
	struct UStaticMesh* femaleLODStMesh; // Offset: 0x80 // Size: 0x28
	struct USkeletalMesh* maleSkMesh; // Offset: 0xa8 // Size: 0x28
	struct USkeletalMesh* femaleSkMesh; // Offset: 0xd0 // Size: 0x28
	struct USkeletalMesh* maleLODSkMesh; // Offset: 0xf8 // Size: 0x28
	struct USkeletalMesh* femaleLODSkMesh; // Offset: 0x120 // Size: 0x28
	struct UMaterialInterface* maleMat; // Offset: 0x148 // Size: 0x28
	struct UMaterialInterface* femaleMat; // Offset: 0x170 // Size: 0x28
	struct TArray<struct FMaterialSet> additionalMaleMats; // Offset: 0x198 // Size: 0x10
	struct TArray<struct FMaterialSet> additionalFemaleMats; // Offset: 0x1a8 // Size: 0x10
	struct UMaterialInterface* baseMat; // Offset: 0x1b8 // Size: 0x08
	struct UAnimInstance* animBP; // Offset: 0x1c0 // Size: 0x08
	struct UAnimSequence* LobbyIdleAnim; // Offset: 0x1c8 // Size: 0x28
	bool IsEffectOnly; // Offset: 0x1f0 // Size: 0x01
	enum class EEffectCreateType EffectCreateType; // Offset: 0x1f1 // Size: 0x01
	char pad_0x1F2[0x6]; // Offset: 0x1f2 // Size: 0x06
	struct TArray<struct FAvatarEffectData> EffectDataList; // Offset: 0x1f8 // Size: 0x10
	struct TArray<struct FAvatarAttachMeshData> AttachMeshDataList; // Offset: 0x208 // Size: 0x10
	struct UClass* animBPClass; // Offset: 0x218 // Size: 0x28
	char pad_0x240[0x18]; // Offset: 0x240 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarEffectData
// Size: 0x80 // Inherited bytes: 0x00
struct FAvatarEffectData {
	// Fields
	struct FTransform Transform; // Offset: 0x00 // Size: 0x30
	struct UParticleSystem* ParticleSystem; // Offset: 0x30 // Size: 0x28
	struct FName AttachSocket; // Offset: 0x58 // Size: 0x08
	struct FName ComponentTag; // Offset: 0x60 // Size: 0x08
	enum class EEffectValidTarget ValidMethod; // Offset: 0x68 // Size: 0x01
	enum class EEffectValidDevice ValidDevice; // Offset: 0x69 // Size: 0x01
	bool bIsActivate; // Offset: 0x6a // Size: 0x01
	bool bIsActivateWithMesh; // Offset: 0x6b // Size: 0x01
	bool IsLobbyActivate; // Offset: 0x6c // Size: 0x01
	char pad_0x6D[0x3]; // Offset: 0x6d // Size: 0x03
	struct TArray<struct FParticleSysParam> InstanceParameters; // Offset: 0x70 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MaterialSet
// Size: 0x58 // Inherited bytes: 0x00
struct FMaterialSet {
	// Fields
	struct UMaterialInterface* targetMat; // Offset: 0x00 // Size: 0x28
	enum class EAvatarSlotType targetSlot; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct UMaterialInterface* targetBaseMat; // Offset: 0x30 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.FakeHeadInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FFakeHeadInfo {
	// Fields
	bool bEnableFakeHead; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct USkeletalMesh* SoftFakeHeadMesh; // Offset: 0x08 // Size: 0x28
	struct UAnimInstance* FakeHeadAnimBPClass; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AdditonalAvatarStruct
// Size: 0x18 // Inherited bytes: 0x00
struct FAdditonalAvatarStruct {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> SlotIDList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAttachMeshFrameSkipMap
// Size: 0x08 // Inherited bytes: 0x00
struct FAvatarAttachMeshFrameSkipMap {
	// Fields
	int LODLevel; // Offset: 0x00 // Size: 0x04
	int SkipFrame; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAttachMeshGroup
// Size: 0x20 // Inherited bytes: 0x00
struct FAvatarAttachMeshGroup {
	// Fields
	struct TArray<struct UMeshComponent*> AttachMeshCompList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FAvatarAttachMeshData> AttachMeshDataList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarEffectGroup
// Size: 0x20 // Inherited bytes: 0x00
struct FAvatarEffectGroup {
	// Fields
	struct TArray<struct UParticleSystemComponent*> ParticleCompList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FAvatarEffectData> EffectDataList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarHideBonesDesc
// Size: 0x10 // Inherited bytes: 0x00
struct FAvatarHideBonesDesc {
	// Fields
	struct TArray<struct FHideBoneData> hideBoneSlots; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarSlotNameConfig
// Size: 0xa0 // Inherited bytes: 0x00
struct FAvatarSlotNameConfig {
	// Fields
	struct TMap<enum class EAvatarSlotType, struct FString> MaleSlotName; // Offset: 0x00 // Size: 0x50
	struct TMap<enum class EAvatarSlotType, struct FString> FemaleSlotName; // Offset: 0x50 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillReplaceCharAnimData
// Size: 0x28 // Inherited bytes: 0x00
struct FSkillReplaceCharAnimData {
	// Fields
	enum class ECharacterAnimType CharacterAnimType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct UAnimationAsset*> PoseAnimList; // Offset: 0x08 // Size: 0x10
	struct TArray<struct UAnimationAsset*> FPPPoseAnimList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayerPosMarkerParam
// Size: 0x10 // Inherited bytes: 0x00
struct FPlayerPosMarkerParam {
	// Fields
	struct ACharacter* Player; // Offset: 0x00 // Size: 0x08
	float MarkTimeLen; // Offset: 0x08 // Size: 0x04
	int MarkIcon; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.STAirAttackRadialDamageEvent
// Size: 0x40 // Inherited bytes: 0x40
struct FSTAirAttackRadialDamageEvent : FRadialDamageEvent {
};

// Object Name: ScriptStruct ShadowTrackerExtra.STBurningDamageEvent
// Size: 0xd0 // Inherited bytes: 0xb0
struct FSTBurningDamageEvent : FSTPointDamageEvent {
	// Fields
	char pad_0xB0[0x20]; // Offset: 0xb0 // Size: 0x20
};

// Object Name: ScriptStruct ShadowTrackerExtra.DotDamageEvent
// Size: 0xb8 // Inherited bytes: 0xb0
struct FDotDamageEvent : FSTPointDamageEvent {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.DrowningDamageEvent
// Size: 0xb0 // Inherited bytes: 0xb0
struct FDrowningDamageEvent : FSTPointDamageEvent {
};

// Object Name: ScriptStruct ShadowTrackerExtra.FallingDamageEvent
// Size: 0xb8 // Inherited bytes: 0xb0
struct FFallingDamageEvent : FSTPointDamageEvent {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.MeleeDamageEvent
// Size: 0xd0 // Inherited bytes: 0xb0
struct FMeleeDamageEvent : FSTPointDamageEvent {
	// Fields
	char pad_0xB0[0x20]; // Offset: 0xb0 // Size: 0x20
};

// Object Name: ScriptStruct ShadowTrackerExtra.PoisonDamageEvent
// Size: 0xb0 // Inherited bytes: 0xb0
struct FPoisonDamageEvent : FSTPointDamageEvent {
};

// Object Name: ScriptStruct ShadowTrackerExtra.STCustomRadialDamageEvent
// Size: 0xb8 // Inherited bytes: 0x40
struct FSTCustomRadialDamageEvent : FRadialDamageEvent {
	// Fields
	char pad_0x40[0x70]; // Offset: 0x40 // Size: 0x70
	bool bPlayHurtAnim; // Offset: 0xb0 // Size: 0x01
	char pad_0xB1[0x7]; // Offset: 0xb1 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.STRadialDamageEvent
// Size: 0xb8 // Inherited bytes: 0xb8
struct FSTRadialDamageEvent : FSTCustomRadialDamageEvent {
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleDamageEvent
// Size: 0xb8 // Inherited bytes: 0xb0
struct FVehicleDamageEvent : FSTPointDamageEvent {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ClientFatalDamageRecordData
// Size: 0x100 // Inherited bytes: 0x00
struct FClientFatalDamageRecordData {
	// Fields
	struct FString Causer; // Offset: 0x00 // Size: 0x10
	struct FString CauserNation; // Offset: 0x10 // Size: 0x10
	struct FString VictimName; // Offset: 0x20 // Size: 0x10
	struct FString VictimNation; // Offset: 0x30 // Size: 0x10
	struct FString FuzzyCauserName; // Offset: 0x40 // Size: 0x10
	struct FString FuzzyVictimName; // Offset: 0x50 // Size: 0x10
	int DamageType; // Offset: 0x60 // Size: 0x04
	int AdditionalParam; // Offset: 0x64 // Size: 0x04
	int CauserWeaponAvatarID; // Offset: 0x68 // Size: 0x04
	int CauserClothAvatarID; // Offset: 0x6c // Size: 0x04
	bool IsHeadShot; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x3]; // Offset: 0x71 // Size: 0x03
	int ResultHealthStatus; // Offset: 0x74 // Size: 0x04
	enum class EFatalDamageRelationShip RecordRelationShip; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x3]; // Offset: 0x79 // Size: 0x03
	int PreviousHealthStatus; // Offset: 0x7c // Size: 0x04
	int causerAnchorPlatformResID; // Offset: 0x80 // Size: 0x04
	int causerAnchorPlatformColorID; // Offset: 0x84 // Size: 0x04
	int realKillerAnchorPlatformResID; // Offset: 0x88 // Size: 0x04
	int realKillerAnchorPlatformColorID; // Offset: 0x8c // Size: 0x04
	int victimAnchorPlatformResID; // Offset: 0x90 // Size: 0x04
	int victimAnchorPlatformColorID; // Offset: 0x94 // Size: 0x04
	struct FString CauserPicURL; // Offset: 0x98 // Size: 0x10
	struct FString VictimPicURL; // Offset: 0xa8 // Size: 0x10
	struct FString RealKillerName; // Offset: 0xb8 // Size: 0x10
	int RealKillNum; // Offset: 0xc8 // Size: 0x04
	enum class EFatalDamageCharacterType CauserType; // Offset: 0xcc // Size: 0x01
	enum class EFatalDamageCharacterType VictimType; // Offset: 0xcd // Size: 0x01
	char pad_0xCE[0x2]; // Offset: 0xce // Size: 0x02
	int CauserTeamID; // Offset: 0xd0 // Size: 0x04
	int VictimTeamID; // Offset: 0xd4 // Size: 0x04
	bool IsUseColor; // Offset: 0xd8 // Size: 0x01
	char pad_0xD9[0x3]; // Offset: 0xd9 // Size: 0x03
	struct FLinearColor UseColor; // Offset: 0xdc // Size: 0x10
	char pad_0xEC[0x4]; // Offset: 0xec // Size: 0x04
	struct TArray<char> ExpandDataContent; // Offset: 0xf0 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DamageCauserRecordData
// Size: 0x28 // Inherited bytes: 0x00
struct FDamageCauserRecordData {
	// Fields
	struct AController* Causer; // Offset: 0x00 // Size: 0x08
	float Time; // Offset: 0x08 // Size: 0x04
	float Damage; // Offset: 0x0c // Size: 0x04
	int StatusChangeMargin; // Offset: 0x10 // Size: 0x04
	int DamageType; // Offset: 0x14 // Size: 0x04
	int AdditionalParam; // Offset: 0x18 // Size: 0x04
	bool bIsHeadshot; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
	int WeaponId; // Offset: 0x20 // Size: 0x04
	int FloorType; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SearchedPickUpItemResult
// Size: 0x40 // Inherited bytes: 0x00
struct FSearchedPickUpItemResult {
	// Fields
	struct APickUpWrapperActor* Wrapper; // Offset: 0x00 // Size: 0x08
	struct FPickUpItemData MainItemData; // Offset: 0x08 // Size: 0x38
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShootDamageTipsStr
// Size: 0x10 // Inherited bytes: 0x00
struct FShootDamageTipsStr {
	// Fields
	struct ASTExtraBaseCharacter* DamageTarget; // Offset: 0x00 // Size: 0x08
	float Damage; // Offset: 0x08 // Size: 0x04
	bool IsHeadShotDamage; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayerAnimList
// Size: 0x148 // Inherited bytes: 0x00
struct FPlayerAnimList {
	// Fields
	int FrameCounter; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FPlayerAnimData MovementAnim; // Offset: 0x08 // Size: 0x10
	struct FPlayerAnimData AimAnim; // Offset: 0x18 // Size: 0x10
	struct FPlayerAnimData ReloadAnim; // Offset: 0x28 // Size: 0x10
	struct FPlayerAnimData FillGasAnim; // Offset: 0x38 // Size: 0x10
	struct FPlayerAnimData EquipWeaponAnim; // Offset: 0x48 // Size: 0x10
	struct FPlayerAnimData ChangePoseAnim; // Offset: 0x58 // Size: 0x10
	struct FPlayerAnimData PickUpAnim; // Offset: 0x68 // Size: 0x10
	struct FPlayerAnimData FireAnim; // Offset: 0x78 // Size: 0x10
	struct FPlayerAnimData HurtAnim; // Offset: 0x88 // Size: 0x10
	struct FPlayerAnimData TurnAnim; // Offset: 0x98 // Size: 0x10
	struct FPlayerAnimData PullingPlugAnim; // Offset: 0xa8 // Size: 0x10
	struct FPlayerAnimData PutDownWeaponAnim; // Offset: 0xb8 // Size: 0x10
	struct FPlayerAnimData WeaponIdle; // Offset: 0xc8 // Size: 0x10
	struct FPlayerAnimData ForegripAnim; // Offset: 0xd8 // Size: 0x10
	struct FPlayerAnimData ShoudlerWeaponIdle; // Offset: 0xe8 // Size: 0x10
	struct FPlayerAnimData BeCarriedBackMoveAnim; // Offset: 0xf8 // Size: 0x10
	struct FPlayerAnimData BeCarriedBackPickUpAnim; // Offset: 0x108 // Size: 0x10
	struct TArray<struct FPlayerAnimData> JumpAnimList; // Offset: 0x118 // Size: 0x10
	struct TArray<struct FPlayerAnimData> ShovelAnimList; // Offset: 0x128 // Size: 0x10
	struct TArray<struct FPlayerAnimData> ExtraAnimList; // Offset: 0x138 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterEnergyData
// Size: 0x38 // Inherited bytes: 0x00
struct FCharacterEnergyData {
	// Fields
	struct TArray<struct FCharacterEnergyPhase> EnergyEffactPhase; // Offset: 0x00 // Size: 0x10
	float EnergyMax; // Offset: 0x10 // Size: 0x04
	float EnergyCurrent; // Offset: 0x14 // Size: 0x04
	float EnergyPredict; // Offset: 0x18 // Size: 0x04
	float AttenuationPeriod; // Offset: 0x1c // Size: 0x04
	float AttenuationAmount; // Offset: 0x20 // Size: 0x04
	float PassedDeltaTime; // Offset: 0x24 // Size: 0x04
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterEnergyPhase
// Size: 0x20 // Inherited bytes: 0x00
struct FCharacterEnergyPhase {
	// Fields
	float MakeEffectSection; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString BuffName; // Offset: 0x08 // Size: 0x10
	int BuffID; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimParamList
// Size: 0x138 // Inherited bytes: 0x00
struct FAnimParamList {
	// Fields
	int FrameCounter; // Offset: 0x00 // Size: 0x04
	struct FVector Velocity; // Offset: 0x04 // Size: 0x0c
	struct FVector movedir; // Offset: 0x10 // Size: 0x0c
	enum class EMovementMode MovementMode; // Offset: 0x1c // Size: 0x01
	enum class ECustomMovmentMode CustomMovementMode; // Offset: 0x1d // Size: 0x01
	enum class ECharacterPoseType PoseType; // Offset: 0x1e // Size: 0x01
	char pad_0x1F[0x1]; // Offset: 0x1f // Size: 0x01
	struct FRotator ViewRotation; // Offset: 0x20 // Size: 0x0c
	struct FRotator ControlRotation; // Offset: 0x2c // Size: 0x0c
	enum class EWeaponType WeaponType; // Offset: 0x38 // Size: 0x01
	enum class EWeaponHoldType WeaponHoldType; // Offset: 0x39 // Size: 0x01
	enum class EFreshWeaponStateType WeaponState; // Offset: 0x3a // Size: 0x01
	enum class EWeaponReloadMethod WeaponReloadMethod; // Offset: 0x3b // Size: 0x01
	bool bScopeInBoltActionEnable; // Offset: 0x3c // Size: 0x01
	enum class ESightType SightType; // Offset: 0x3d // Size: 0x01
	char pad_0x3E[0x2]; // Offset: 0x3e // Size: 0x02
	float RecoilKickADS; // Offset: 0x40 // Size: 0x04
	float ForegripParam; // Offset: 0x44 // Size: 0x04
	char pad_0x48[0x4]; // Offset: 0x48 // Size: 0x04
	struct FVector OffsetFPPLocation; // Offset: 0x4c // Size: 0x0c
	struct FRotator OffsetFPPRotation; // Offset: 0x58 // Size: 0x0c
	struct FVector OffsetFPPCrouchLocation; // Offset: 0x64 // Size: 0x0c
	struct FRotator OffsetFPPCrouchRotation; // Offset: 0x70 // Size: 0x0c
	struct FVector OffsetFPPProneLocation; // Offset: 0x7c // Size: 0x0c
	struct FRotator OffsetFPPProneRotation; // Offset: 0x88 // Size: 0x0c
	struct FVector OffsetAngledFPPLocation; // Offset: 0x94 // Size: 0x0c
	struct FRotator OffsetAngledFPPRotation; // Offset: 0xa0 // Size: 0x0c
	struct FVector OffsetAngledFPPCrouchLocation; // Offset: 0xac // Size: 0x0c
	struct FRotator OffsetAngledFPPCrouchRotation; // Offset: 0xb8 // Size: 0x0c
	struct FVector OffsetAngledFPPProneLocation; // Offset: 0xc4 // Size: 0x0c
	struct FRotator OffsetAngledFPPProneRotation; // Offset: 0xd0 // Size: 0x0c
	bool bIsAngledOpticalSight; // Offset: 0xdc // Size: 0x01
	bool IsHurting; // Offset: 0xdd // Size: 0x01
	bool IsNearDeathStatus; // Offset: 0xde // Size: 0x01
	bool IsRescueing; // Offset: 0xdf // Size: 0x01
	bool IsSprinting; // Offset: 0xe0 // Size: 0x01
	bool IsCastingGenerate; // Offset: 0xe1 // Size: 0x01
	char pad_0xE2[0x2]; // Offset: 0xe2 // Size: 0x02
	struct FVector HurtDir; // Offset: 0xe4 // Size: 0x0c
	bool IsDying; // Offset: 0xf0 // Size: 0x01
	bool IsJumping; // Offset: 0xf1 // Size: 0x01
	enum class ECharacterJumpType JumpType; // Offset: 0xf2 // Size: 0x01
	enum class EParachuteState ParachuteState; // Offset: 0xf3 // Size: 0x01
	bool bIsParachuteLanding; // Offset: 0xf4 // Size: 0x01
	bool bFreeFallingShake; // Offset: 0xf5 // Size: 0x01
	bool IsTurning; // Offset: 0xf6 // Size: 0x01
	bool IsOnVehicle; // Offset: 0xf7 // Size: 0x01
	bool IsDisableAim; // Offset: 0xf8 // Size: 0x01
	char pad_0xF9[0x3]; // Offset: 0xf9 // Size: 0x03
	float HandleFolderFactor; // Offset: 0xfc // Size: 0x04
	float CharacterYawRotateRate; // Offset: 0x100 // Size: 0x04
	bool ShouldPauseAnim; // Offset: 0x104 // Size: 0x01
	bool bCarryBack; // Offset: 0x105 // Size: 0x01
	bool bParachuteNearDeath; // Offset: 0x106 // Size: 0x01
	char pad_0x107[0x1]; // Offset: 0x107 // Size: 0x01
	float CarryBlendTimeAccumulator; // Offset: 0x108 // Size: 0x04
	float ParachuteNearDeathBlendTimeAccumulator; // Offset: 0x10c // Size: 0x04
	bool bHasTurnAnim; // Offset: 0x110 // Size: 0x01
	char pad_0x111[0x27]; // Offset: 0x111 // Size: 0x27
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimVehParamList
// Size: 0x30 // Inherited bytes: 0x00
struct FAnimVehParamList {
	// Fields
	int FrameCounter; // Offset: 0x00 // Size: 0x04
	bool IsLeanOut; // Offset: 0x04 // Size: 0x01
	bool IsDriver; // Offset: 0x05 // Size: 0x01
	bool IsSwitchingSeat; // Offset: 0x06 // Size: 0x01
	bool IsIdleAnimReplaced; // Offset: 0x07 // Size: 0x01
	float VacateHight; // Offset: 0x08 // Size: 0x04
	bool IsVehicleMotorbike; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	struct FRotator VehViewRotation; // Offset: 0x10 // Size: 0x0c
	struct FVector VehMoveVelocity; // Offset: 0x1c // Size: 0x0c
	enum class EVHSeatWeaponHoldType SeatWeaponHoldType; // Offset: 0x28 // Size: 0x01
	enum class EVHSeatSpecialType SeatSpecialType; // Offset: 0x29 // Size: 0x01
	enum class ESTExtraVehicleType VehicleType; // Offset: 0x2a // Size: 0x01
	char pad_0x2B[0x1]; // Offset: 0x2b // Size: 0x01
	float LeanOutPercentage; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MovementRecordData
// Size: 0x60 // Inherited bytes: 0x00
struct FMovementRecordData {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x0c // Size: 0x0c
	struct FVector Velocity; // Offset: 0x18 // Size: 0x0c
	struct FVector ControllerNormalRot; // Offset: 0x24 // Size: 0x0c
	float ServerTimeStamp; // Offset: 0x30 // Size: 0x04
	bool IsInVehicle; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	struct FVector VehicleLocation; // Offset: 0x38 // Size: 0x0c
	enum class ESTEPoseState PoseState; // Offset: 0x44 // Size: 0x01
	enum class EMoveBaseSpeedType MoveBaseState; // Offset: 0x45 // Size: 0x01
	char pad_0x46[0x2]; // Offset: 0x46 // Size: 0x02
	float PingMillisecond; // Offset: 0x48 // Size: 0x04
	bool IsCustomMove; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
	uint64 PawnStates; // Offset: 0x50 // Size: 0x08
	uint32_t UserCmdSequence; // Offset: 0x58 // Size: 0x04
	bool bHasWeapon; // Offset: 0x5c // Size: 0x01
	char pad_0x5D[0x3]; // Offset: 0x5d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeathReplayData
// Size: 0x108 // Inherited bytes: 0x00
struct FDeathReplayData {
	// Fields
	bool IsValidDeathReplay; // Offset: 0x00 // Size: 0x01
	bool IsForCE; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct FString SelfName; // Offset: 0x08 // Size: 0x10
	struct FString PlayerName; // Offset: 0x18 // Size: 0x10
	uint64 PlayerUID; // Offset: 0x28 // Size: 0x08
	uint64 MLAIUID; // Offset: 0x30 // Size: 0x08
	int DamageType; // Offset: 0x38 // Size: 0x04
	int SubType; // Offset: 0x3c // Size: 0x04
	struct FString CauseName; // Offset: 0x40 // Size: 0x10
	struct FString CauseActionName; // Offset: 0x50 // Size: 0x10
	bool IsBot; // Offset: 0x60 // Size: 0x01
	bool bIsMLAI; // Offset: 0x61 // Size: 0x01
	bool IsSuicide; // Offset: 0x62 // Size: 0x01
	char pad_0x63[0x1]; // Offset: 0x63 // Size: 0x01
	int AliasID; // Offset: 0x64 // Size: 0x04
	struct FString AliasTitle; // Offset: 0x68 // Size: 0x10
	struct FString AliasNation; // Offset: 0x78 // Size: 0x10
	int AliasRank; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
	struct FString AliasPartnerName; // Offset: 0x90 // Size: 0x10
	int AliasPartnerRelation; // Offset: 0xa0 // Size: 0x04
	int AliasRankID; // Offset: 0xa4 // Size: 0x04
	int SegmentLevel; // Offset: 0xa8 // Size: 0x04
	float KDNum; // Offset: 0xac // Size: 0x04
	int GameCount; // Offset: 0xb0 // Size: 0x04
	int WinCount; // Offset: 0xb4 // Size: 0x04
	int TopTenCount; // Offset: 0xb8 // Size: 0x04
	int KillNum; // Offset: 0xbc // Size: 0x04
	float Distance; // Offset: 0xc0 // Size: 0x04
	struct FDeathReplayHitInfo OtherHitInfo; // Offset: 0xc4 // Size: 0x20
	struct FDeathReplayHitInfo SelfHitInfo; // Offset: 0xe4 // Size: 0x20
	char pad_0x104[0x4]; // Offset: 0x104 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeathReplayHitInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FDeathReplayHitInfo {
	// Fields
	float Damage; // Offset: 0x00 // Size: 0x04
	int HitCount; // Offset: 0x04 // Size: 0x04
	int HeadShoot; // Offset: 0x08 // Size: 0x04
	int LimbsShoot; // Offset: 0x0c // Size: 0x04
	int BodyShoot; // Offset: 0x10 // Size: 0x04
	int HandShoot; // Offset: 0x14 // Size: 0x04
	int FootShoot; // Offset: 0x18 // Size: 0x04
	float GunHitRate; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SearchedTombBoxAndWrapperListResult
// Size: 0x18 // Inherited bytes: 0x00
struct FSearchedTombBoxAndWrapperListResult {
	// Fields
	struct APlayerTombBox* Box; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FSearchedPickUpItemResult> SearchedPickUpItemResultList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayerDecalData
// Size: 0x60 // Inherited bytes: 0x00
struct FPlayerDecalData {
	// Fields
	int DecalId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0xc]; // Offset: 0x04 // Size: 0x0c
	struct FTransform DecalTransform; // Offset: 0x10 // Size: 0x30
	int DecalInstanceId; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct TArray<struct FIdeaDecalInfo> DecalInfos; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x8]; // Offset: 0x58 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.IdeaDecalInfo
// Size: 0x80 // Inherited bytes: 0x00
struct FIdeaDecalInfo {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0xc]; // Offset: 0x04 // Size: 0x0c
	struct FTransform Transform; // Offset: 0x10 // Size: 0x30
	char pad_0x40[0x1d]; // Offset: 0x40 // Size: 0x1d
	enum class EIdeaDecalParentType ParentType; // Offset: 0x5d // Size: 0x01
	char pad_0x5E[0x2]; // Offset: 0x5e // Size: 0x02
	struct TWeakObjectPtr<struct UPrimitiveComponent> Parent; // Offset: 0x60 // Size: 0x08
	char pad_0x68[0x18]; // Offset: 0x68 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.NetCarryBackState
// Size: 0x18 // Inherited bytes: 0x00
struct FNetCarryBackState {
	// Fields
	enum class ECarryBackState State; // Offset: 0x00 // Size: 0x01
	enum class EPutDownDetachMethod DetachMethod; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct ASTExtraBaseCharacter* CarryBackCharacter; // Offset: 0x08 // Size: 0x08
	struct ASTExtraBaseCharacter* BeCarriedBackCharacter; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.InjuryParticleAttachOffset
// Size: 0x50 // Inherited bytes: 0x00
struct FInjuryParticleAttachOffset {
	// Fields
	enum class EMovementMode MovementMode; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0xf]; // Offset: 0x01 // Size: 0x0f
	struct FTransform AttachTransform; // Offset: 0x10 // Size: 0x30
	enum class EAttachLocation AttachLocationType; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0xf]; // Offset: 0x41 // Size: 0x0f
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterHide
// Size: 0x03 // Inherited bytes: 0x00
struct FCharacterHide {
	// Fields
	bool bCharacterHideIngame; // Offset: 0x00 // Size: 0x01
	char nRepFlag; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x1]; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayerRespawnData
// Size: 0x20 // Inherited bytes: 0x00
struct FPlayerRespawnData {
	// Fields
	char RespawnCount; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector Location; // Offset: 0x04 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x10 // Size: 0x0c
	bool bCanRespawn; // Offset: 0x1c // Size: 0x01
	bool bIsDead; // Offset: 0x1d // Size: 0x01
	char pad_0x1E[0x2]; // Offset: 0x1e // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.AutoAimingConfig
// Size: 0x110 // Inherited bytes: 0x00
struct FAutoAimingConfig {
	// Fields
	struct FAutoAimingRangeConfig OuterRange; // Offset: 0x00 // Size: 0x4c
	struct FAutoAimingRangeConfig InnerRange; // Offset: 0x4c // Size: 0x4c
	struct FAutoAimingRangeConfig ScopeRange; // Offset: 0x98 // Size: 0x4c
	float followTimeMax; // Offset: 0xe4 // Size: 0x04
	bool TriggerBeforeFire; // Offset: 0xe8 // Size: 0x01
	char pad_0xE9[0x7]; // Offset: 0xe9 // Size: 0x07
	struct UCurveFloat* SpeedCurve; // Offset: 0xf0 // Size: 0x08
	struct UCurveFloat* DistanceSpeedCurve; // Offset: 0xf8 // Size: 0x08
	struct UCurveFloat* SensitiveSpeedCurve; // Offset: 0x100 // Size: 0x08
	float MaxAngle; // Offset: 0x108 // Size: 0x04
	char pad_0x10C[0x4]; // Offset: 0x10c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AutoAimingRangeConfig
// Size: 0x4c // Inherited bytes: 0x00
struct FAutoAimingRangeConfig {
	// Fields
	float Speed; // Offset: 0x00 // Size: 0x04
	float CenterSpeedRate; // Offset: 0x04 // Size: 0x04
	float RangeRate; // Offset: 0x08 // Size: 0x04
	float SpeedRate; // Offset: 0x0c // Size: 0x04
	float RangeRateSight; // Offset: 0x10 // Size: 0x04
	float SpeedRateSight; // Offset: 0x14 // Size: 0x04
	float CrouchRate; // Offset: 0x18 // Size: 0x04
	float ProneRate; // Offset: 0x1c // Size: 0x04
	float DyingRate; // Offset: 0x20 // Size: 0x04
	float DriveVehicleRate; // Offset: 0x24 // Size: 0x04
	float InVehicleRate; // Offset: 0x28 // Size: 0x04
	float FreeFallRate; // Offset: 0x2c // Size: 0x04
	float OpeningRate; // Offset: 0x30 // Size: 0x04
	float LandingRate; // Offset: 0x34 // Size: 0x04
	float adsorbMaxRange; // Offset: 0x38 // Size: 0x04
	float adsorbMinRange; // Offset: 0x3c // Size: 0x04
	float adsorbMinAttenuationDis; // Offset: 0x40 // Size: 0x04
	float adsorbMaxAttenuationDis; // Offset: 0x44 // Size: 0x04
	float adsorbActiveMinRange; // Offset: 0x48 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InteractionEmoteConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FInteractionEmoteConfig {
	// Fields
	int SelfEmoteId; // Offset: 0x00 // Size: 0x04
	int OtherEmoteId; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterOverrideAttrs
// Size: 0x10 // Inherited bytes: 0x00
struct FCharacterOverrideAttrs {
	// Fields
	float GameModeOverride_SpeedScaleModifier; // Offset: 0x00 // Size: 0x04
	float GameModeOverride_SwimSpeedScaleModifier; // Offset: 0x04 // Size: 0x04
	float GameModeOverride_EnergySpeedScaleModifier; // Offset: 0x08 // Size: 0x04
	float GameModeOverride_LastBreathSpeedScaleModifier; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponOverrideAttrs
// Size: 0x18 // Inherited bytes: 0x00
struct FWeaponOverrideAttrs {
	// Fields
	float GameModeOverride_DeviationMoveModifier; // Offset: 0x00 // Size: 0x04
	float GameModeOverride_DeviationStanceJumpModifier; // Offset: 0x04 // Size: 0x04
	float GameModeOverride_MeleeDamageAmountModifier; // Offset: 0x08 // Size: 0x04
	float GameModeOverride_GrenadeDamageRadiusModifier; // Offset: 0x0c // Size: 0x04
	float GameModeOverride_GrenadeDamageAmountModifier; // Offset: 0x10 // Size: 0x04
	float GameModeOverride_GunsDamageAmountModifier; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.LastEmoteInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FLastEmoteInfo {
	// Fields
	int EmoteId; // Offset: 0x00 // Size: 0x04
	int AreaID; // Offset: 0x04 // Size: 0x04
	float EmoteTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParachuteFollowState
// Size: 0x08 // Inherited bytes: 0x00
struct FParachuteFollowState {
	// Fields
	enum class EFollowState FollowState; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int LeaderIdx; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.STReplicatedMoveState
// Size: 0x20 // Inherited bytes: 0x00
struct FSTReplicatedMoveState {
	// Fields
	struct FVector_NetQuantize Location; // Offset: 0x00 // Size: 0x0c
	char Roll; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	uint32_t View; // Offset: 0x10 // Size: 0x04
	struct FVector_NetQuantize Velocity; // Offset: 0x14 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.STParachuteState
// Size: 0x18 // Inherited bytes: 0x00
struct FSTParachuteState {
	// Fields
	float ThrottleInput; // Offset: 0x00 // Size: 0x04
	float SteerInput; // Offset: 0x04 // Size: 0x04
	uint8_t State; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	struct FRotator CameraRotation; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.RepVehicleAttachment
// Size: 0x10 // Inherited bytes: 0x00
struct FRepVehicleAttachment {
	// Fields
	struct ASTExtraVehicleBase* Vehicle; // Offset: 0x00 // Size: 0x08
	struct FName AttachSocket; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.HealthPredictShowData
// Size: 0x20 // Inherited bytes: 0x00
struct FHealthPredictShowData {
	// Fields
	struct FString ShowDataKey; // Offset: 0x00 // Size: 0x10
	enum class EHealthPredictShowType ShowType; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	float Value; // Offset: 0x14 // Size: 0x04
	float LimitValue; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BodyPartCfg
// Size: 0x40 // Inherited bytes: 0x00
struct FBodyPartCfg {
	// Fields
	float DamageScale; // Offset: 0x00 // Size: 0x04
	float Durability; // Offset: 0x04 // Size: 0x04
	float DamageReduceScale; // Offset: 0x08 // Size: 0x04
	float DamageReduceScaleExtra; // Offset: 0x0c // Size: 0x04
	float DamageReduceScaleIgnoreDurability; // Offset: 0x10 // Size: 0x04
	float BrokenArmorDamageReduceScale; // Offset: 0x14 // Size: 0x04
	float DurabilityReduceScale; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString BodyDurabilityIndexName; // Offset: 0x20 // Size: 0x10
	float MomentumResistance; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct ASTEShootWeaponBulletImpactEffect* ImpactEffectOverride; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimStatusKeyList
// Size: 0x28 // Inherited bytes: 0x00
struct FAnimStatusKeyList {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
	struct ASTExtraWeapon* EquipWeapon; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.PoseChangeTime
// Size: 0x10 // Inherited bytes: 0x00
struct FPoseChangeTime {
	// Fields
	float PoseChange_Prone_Stand; // Offset: 0x00 // Size: 0x04
	float PoseChange_Prone_Move; // Offset: 0x04 // Size: 0x04
	float PoseChange_UnProne_Stand; // Offset: 0x08 // Size: 0x04
	float PoseChange_UnProne_Move; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponRecordDataForReplay
// Size: 0x0c // Inherited bytes: 0x00
struct FWeaponRecordDataForReplay {
	// Fields
	int WeaponId; // Offset: 0x00 // Size: 0x04
	char HeadShoot; // Offset: 0x04 // Size: 0x01
	char LimbsShoot; // Offset: 0x05 // Size: 0x01
	char BodyShoot; // Offset: 0x06 // Size: 0x01
	char HandShoot; // Offset: 0x07 // Size: 0x01
	char FootShoot; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimViewData
// Size: 0x06 // Inherited bytes: 0x00
struct FSimViewData {
	// Fields
	uint16_t ViewPitch; // Offset: 0x00 // Size: 0x02
	uint16_t ViewYaw; // Offset: 0x02 // Size: 0x02
	char ViewRoll; // Offset: 0x04 // Size: 0x01
	bool FreeCamera; // Offset: 0x05 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimLocalViewData
// Size: 0x10 // Inherited bytes: 0x00
struct FSimLocalViewData {
	// Fields
	float ViewPitch; // Offset: 0x00 // Size: 0x04
	float ViewYaw; // Offset: 0x04 // Size: 0x04
	float ViewRoll; // Offset: 0x08 // Size: 0x04
	bool FreeCamera; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.SyncAKEvent
// Size: 0x10 // Inherited bytes: 0x00
struct FSyncAKEvent {
	// Fields
	int AkEventID; // Offset: 0x00 // Size: 0x04
	struct FVector AkLocation; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.BodyTypeDef
// Size: 0x08 // Inherited bytes: 0x00
struct FBodyTypeDef {
	// Fields
	int UpThreshold; // Offset: 0x00 // Size: 0x04
	int DownThreshold; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpecialAmbientData
// Size: 0x28 // Inherited bytes: 0x00
struct FSpecialAmbientData {
	// Fields
	struct UAkAudioEvent* Sound; // Offset: 0x00 // Size: 0x08
	struct FString SwitchGroupName; // Offset: 0x08 // Size: 0x10
	struct FString SwitchValue; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponSlotSwitchTimeData
// Size: 0x0c // Inherited bytes: 0x00
struct FWeaponSlotSwitchTimeData {
	// Fields
	enum class ESurviveWeaponPropSlot EquipSlot; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float TotalTime; // Offset: 0x04 // Size: 0x04
	float AttachWeaponTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayerRoleCacheFrameData
// Size: 0x10 // Inherited bytes: 0x00
struct FPlayerRoleCacheFrameData {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActicityDisallowedData
// Size: 0x18 // Inherited bytes: 0x00
struct FActicityDisallowedData {
	// Fields
	struct TArray<enum class EPawnState> DisallowedStates; // Offset: 0x00 // Size: 0x10
	int ActivityID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AngledSightRepData
// Size: 0x02 // Inherited bytes: 0x00
struct FAngledSightRepData {
	// Fields
	enum class EAngledSightType AngledSightType; // Offset: 0x00 // Size: 0x01
	bool IsOnlyTurn; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActivityAnimationRepData
// Size: 0x08 // Inherited bytes: 0x00
struct FActivityAnimationRepData {
	// Fields
	struct UAnimMontage* AnimMontage; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.FanPickerConfigData
// Size: 0x50 // Inherited bytes: 0x00
struct FFanPickerConfigData {
	// Fields
	float Radius; // Offset: 0x00 // Size: 0x04
	float Angle; // Offset: 0x04 // Size: 0x04
	float CapsuleRadius; // Offset: 0x08 // Size: 0x04
	struct FVector Offset; // Offset: 0x0c // Size: 0x0c
	bool Random; // Offset: 0x18 // Size: 0x01
	bool IsCheckHeadshot; // Offset: 0x19 // Size: 0x01
	bool IsShowDebugFan; // Offset: 0x1a // Size: 0x01
	bool IsHeadJudgeWithoutOwner; // Offset: 0x1b // Size: 0x01
	bool bPickUpMonsters; // Offset: 0x1c // Size: 0x01
	bool bIgnoreAimCheck; // Offset: 0x1d // Size: 0x01
	char pad_0x1E[0x2]; // Offset: 0x1e // Size: 0x02
	struct TArray<struct AActor*> IgnoredActors; // Offset: 0x20 // Size: 0x10
	bool bForwardHitAim; // Offset: 0x30 // Size: 0x01
	enum class UTSkillPickerType PickerType; // Offset: 0x31 // Size: 0x01
	enum class UTPickerTargetType PickerTargetType; // Offset: 0x32 // Size: 0x01
	char pad_0x33[0x1]; // Offset: 0x33 // Size: 0x01
	int PickerMaxCount; // Offset: 0x34 // Size: 0x04
	bool bIncludeOwner; // Offset: 0x38 // Size: 0x01
	bool bOnlyHero; // Offset: 0x39 // Size: 0x01
	bool bEnableTrace; // Offset: 0x3a // Size: 0x01
	bool bIsUsingViewRotation; // Offset: 0x3b // Size: 0x01
	bool bUseNewOffset; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
	struct TArray<struct TWeakObjectPtr<struct AActor>> IgnoreTargets; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpringArmParams
// Size: 0x50 // Inherited bytes: 0x00
struct FSpringArmParams {
	// Fields
	struct FCameraParams CameraParam; // Offset: 0x00 // Size: 0x08
	struct USceneComponent* ParentComp; // Offset: 0x08 // Size: 0x08
	struct FName ParentSocketName; // Offset: 0x10 // Size: 0x08
	float TargetArmALength; // Offset: 0x18 // Size: 0x04
	struct FVector SocketOffset; // Offset: 0x1c // Size: 0x0c
	struct FVector TargetOffset; // Offset: 0x28 // Size: 0x0c
	struct FVector RelativeLocation; // Offset: 0x34 // Size: 0x0c
	float ProbeSize; // Offset: 0x40 // Size: 0x04
	enum class ECollisionChannel ProbeChannel; // Offset: 0x44 // Size: 0x01
	bool bDoCollisionTest; // Offset: 0x45 // Size: 0x01
	bool bUsePawnControlRotation; // Offset: 0x46 // Size: 0x01
	bool bEnableCameraLag; // Offset: 0x47 // Size: 0x01
	float CameraLagSpeed; // Offset: 0x48 // Size: 0x04
	bool bEnableCustomSpringArm; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.CameraParams
// Size: 0x08 // Inherited bytes: 0x00
struct FCameraParams {
	// Fields
	float FieldOfView; // Offset: 0x00 // Size: 0x04
	bool bLocktoHmd; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.AsyncLoadAnimParams
// Size: 0x20 // Inherited bytes: 0x00
struct FAsyncLoadAnimParams {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIShootingPoseOffsetInfo
// Size: 0x70 // Inherited bytes: 0x00
struct FAIShootingPoseOffsetInfo {
	// Fields
	struct TArray<struct FAIShootingPoseOffsetDetailInfo> ShootingPoseShootPointOffsetArray; // Offset: 0x00 // Size: 0x10
	float CrouchToStandHeightOffset; // Offset: 0x10 // Size: 0x04
	float ProneToStandHeightOffset; // Offset: 0x14 // Size: 0x04
	char pad_0x18[0x8]; // Offset: 0x18 // Size: 0x08
	struct TMap<enum class EAIShootingPose, struct FVector> ShootingPoseShootPointOffsetMap; // Offset: 0x20 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIShootingPoseOffsetDetailInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FAIShootingPoseOffsetDetailInfo {
	// Fields
	enum class EAIShootingPose shootingPose; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector offsetInfo; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.AITargetInViewOffset
// Size: 0x38 // Inherited bytes: 0x00
struct FAITargetInViewOffset {
	// Fields
	struct TArray<struct FVector> Offset; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FVector> CrouchOffset; // Offset: 0x10 // Size: 0x10
	struct FVector TargetLoc; // Offset: 0x20 // Size: 0x0c
	int CurrentOffsetIndex; // Offset: 0x2c // Size: 0x04
	bool bTargetInViewDueToOffset; // Offset: 0x30 // Size: 0x01
	enum class EPawnState TargetPawnState; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIEquipSpawnItem
// Size: 0x18 // Inherited bytes: 0x00
struct FAIEquipSpawnItem {
	// Fields
	enum class EAIEquipSpawnItemType itemType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int ItemSpecificID; // Offset: 0x04 // Size: 0x04
	int Count; // Offset: 0x08 // Size: 0x04
	int MaxCount; // Offset: 0x0c // Size: 0x04
	struct FVector2D ExtraConfigValue; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIFeatureInfo
// Size: 0x140 // Inherited bytes: 0x00
struct FAIFeatureInfo {
	// Fields
	float HP; // Offset: 0x00 // Size: 0x04
	float DamageScale; // Offset: 0x04 // Size: 0x04
	float TakeDamageScale; // Offset: 0x08 // Size: 0x04
	int DropID; // Offset: 0x0c // Size: 0x04
	struct TArray<float> HitRates; // Offset: 0x10 // Size: 0x10
	struct TMap<int, float> ThrownUsingProbability; // Offset: 0x20 // Size: 0x50
	struct TMap<float, float> EnemyHpHitRateMap; // Offset: 0x70 // Size: 0x50
	struct TMap<float, float> EnemyHpDamageRateMap; // Offset: 0xc0 // Size: 0x50
	bool bNeedNearDeath; // Offset: 0x110 // Size: 0x01
	bool bHasDeadBox; // Offset: 0x111 // Size: 0x01
	char pad_0x112[0x2]; // Offset: 0x112 // Size: 0x02
	struct FVector2D MissOnPurposeTimeRange; // Offset: 0x114 // Size: 0x08
	struct FVector2D OutViewMissOnPurposeTimeRange; // Offset: 0x11c // Size: 0x08
	float MissOnPurposeCD; // Offset: 0x124 // Size: 0x04
	float MissOnPurposeResetTime; // Offset: 0x128 // Size: 0x04
	float MissOnPurposeHitRate; // Offset: 0x12c // Size: 0x04
	float NearDeathTargetStopFireTime; // Offset: 0x130 // Size: 0x04
	float NearDeathTargetFixedHitRate; // Offset: 0x134 // Size: 0x04
	bool bDoMissOnPurposeWhenNearDeathToNormal; // Offset: 0x138 // Size: 0x01
	char pad_0x139[0x3]; // Offset: 0x139 // Size: 0x03
	float NearDeathTargetFixedDamageRate; // Offset: 0x13c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIShootMissInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FAIShootMissInfo {
	// Fields
	float MissMaxRangeTime; // Offset: 0x00 // Size: 0x04
	float MissMinRangeTime; // Offset: 0x04 // Size: 0x04
	float MissCDTime; // Offset: 0x08 // Size: 0x04
	float MissResetTime; // Offset: 0x0c // Size: 0x04
	float MissResetConfig; // Offset: 0x10 // Size: 0x04
	bool bCanMissShoot; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIControllerCachedData
// Size: 0x38 // Inherited bytes: 0x00
struct FAIControllerCachedData {
	// Fields
	struct ASTExtraBaseCharacter* ControlledPawn; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x28]; // Offset: 0x08 // Size: 0x28
	struct ASTExtraPlayerController* CacheNearPlayerController; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.MarkSyncData
// Size: 0x70 // Inherited bytes: 0x00
struct FMarkSyncData {
	// Fields
	enum class EMarkStatus Status; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int TypeId; // Offset: 0x04 // Size: 0x04
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x14 // Size: 0x0c
	int InstanceID; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FCustomMarkEventData CustomMarkEvent; // Offset: 0x28 // Size: 0x20
	enum class EAddMarkFlag MapAdded; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	int ActorUniqueID; // Offset: 0x4c // Size: 0x04
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x50 // Size: 0x08
	bool bIsLuaConfig; // Offset: 0x58 // Size: 0x01
	bool bLocalData; // Offset: 0x59 // Size: 0x01
	char pad_0x5A[0x6]; // Offset: 0x5a // Size: 0x06
	struct TArray<struct TWeakObjectPtr<struct UProperty>> DeltaProperties; // Offset: 0x60 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomMarkEventData
// Size: 0x20 // Inherited bytes: 0x00
struct FCustomMarkEventData {
	// Fields
	float CreateTime; // Offset: 0x00 // Size: 0x04
	int CustomState; // Offset: 0x04 // Size: 0x04
	struct FString CustomString; // Offset: 0x08 // Size: 0x10
	enum class EAddMarkFlag InWhichMap; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int CustomCanvasTag; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.GameModePlayerAliasShowInfo
// Size: 0x60 // Inherited bytes: 0x00
struct FGameModePlayerAliasShowInfo {
	// Fields
	struct FGameModePlayerAliasInfo AliasInfo; // Offset: 0x00 // Size: 0x48
	struct FString PlayerName; // Offset: 0x48 // Size: 0x10
	struct ASTExtraBaseCharacter* Character; // Offset: 0x58 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterBuffRecord
// Size: 0x14 // Inherited bytes: 0x00
struct FCharacterBuffRecord {
	// Fields
	int BuffID; // Offset: 0x00 // Size: 0x04
	int CauseSkillID; // Offset: 0x04 // Size: 0x04
	int LayerCount; // Offset: 0x08 // Size: 0x04
	struct TWeakObjectPtr<struct AActor> Causer; // Offset: 0x0c // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.DriveCarNotify
// Size: 0x18 // Inherited bytes: 0x00
struct FDriveCarNotify {
	// Fields
	enum class EDriveCar DriveCar; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct ASTExtraBaseCharacter* Character; // Offset: 0x08 // Size: 0x08
	struct ASTExtraWheeledVehicle* Vehicle; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.VisualFieldInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FVisualFieldInfo {
	// Fields
	int ViewerLayerID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FVisualFieldMetaInfo> VisualFieldMetaInfoList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VisualFieldMetaInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FVisualFieldMetaInfo {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	int LayerID; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HistoricalTeammateInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FHistoricalTeammateInfo {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct FString UId; // Offset: 0x10 // Size: 0x10
	struct FString OpenID; // Offset: 0x20 // Size: 0x10
	bool bIsAI; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	int InTeamIndex; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RescueTime
// Size: 0x0c // Inherited bytes: 0x00
struct FRescueTime {
	// Fields
	bool bBeingRescued; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float RescueStartTime; // Offset: 0x04 // Size: 0x04
	float RescueExpectedEndTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterLocAndRot
// Size: 0x18 // Inherited bytes: 0x00
struct FCharacterLocAndRot {
	// Fields
	struct FVector Loc; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rot; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterAutoFollowStruct
// Size: 0x10 // Inherited bytes: 0x00
struct FCharacterAutoFollowStruct {
	// Fields
	bool IsFollowing; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct ASTExtraBaseCharacter* Target; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.DrawTextToTextureRenderTarget2DParams
// Size: 0x88 // Inherited bytes: 0x00
struct FDrawTextToTextureRenderTarget2DParams {
	// Fields
	struct FText Text; // Offset: 0x00 // Size: 0x18
	struct FName WidgetName; // Offset: 0x18 // Size: 0x08
	int DrawWidth; // Offset: 0x20 // Size: 0x04
	int DrawHeight; // Offset: 0x24 // Size: 0x04
	struct UTextureRenderTarget2D* OptionalInOutTextureRenderTarget2D; // Offset: 0x28 // Size: 0x08
	bool bMaterialInstanceDynamicCreated; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct UMaterialInterface* ParentMaterial; // Offset: 0x38 // Size: 0x28
	struct FName TextureParameterName; // Offset: 0x60 // Size: 0x08
	struct UMaterialInstanceDynamic* OptionalInOutMaterialInstanceDynamic; // Offset: 0x68 // Size: 0x08
	struct FString Payload; // Offset: 0x70 // Size: 0x10
	bool bParamsCached; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x7]; // Offset: 0x81 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirAttackOrder
// Size: 0x48 // Inherited bytes: 0x00
struct FAirAttackOrder {
	// Fields
	int waveIndex; // Offset: 0x00 // Size: 0x04
	float FlightHeight; // Offset: 0x04 // Size: 0x04
	float SeaLevelHeight; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<uint16_t> bombsInterval; // Offset: 0x10 // Size: 0x10
	uint16_t BombBaseDamage; // Offset: 0x20 // Size: 0x02
	uint16_t BombMinDamage; // Offset: 0x22 // Size: 0x02
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct TArray<struct FVector2D> bombsPosition2D; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ReConnectGameStateInfo
// Size: 0x68 // Inherited bytes: 0x00
struct FReConnectGameStateInfo {
	// Fields
	bool bIsLessning; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float CircleStateStartServerWorldSecond; // Offset: 0x04 // Size: 0x04
	float CircleStatusLastTime; // Offset: 0x08 // Size: 0x04
	float CircleStatusElapsedTime; // Offset: 0x0c // Size: 0x04
	enum class ECircleInfo CircleStatus; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	struct FVector BlueCircle; // Offset: 0x14 // Size: 0x0c
	struct FVector OriginalBlueCircle; // Offset: 0x20 // Size: 0x0c
	struct FVector WhiteCircle; // Offset: 0x2c // Size: 0x0c
	bool bActiveScreenSize; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	float ScreenSizeFactor; // Offset: 0x3c // Size: 0x04
	float ExtraRadius; // Offset: 0x40 // Size: 0x04
	enum class EAirAttackInfo AirAttackStatus; // Offset: 0x44 // Size: 0x01
	char pad_0x45[0x3]; // Offset: 0x45 // Size: 0x03
	struct FVector AirAttackArea; // Offset: 0x48 // Size: 0x0c
	int AirAttackWave; // Offset: 0x54 // Size: 0x04
	int BossCountDown; // Offset: 0x58 // Size: 0x04
	struct FVector BossBornPos; // Offset: 0x5c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherChangeEvent
// Size: 0x02 // Inherited bytes: 0x00
struct FWeatherChangeEvent {
	// Fields
	enum class EWeatherStatusType WeaterType; // Offset: 0x00 // Size: 0x01
	enum class EWeatherChangeEvent WeaterChangeEvent; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirDropPathData3D
// Size: 0x48 // Inherited bytes: 0x00
struct FAirDropPathData3D {
	// Fields
	int AirDropIndex; // Offset: 0x00 // Size: 0x04
	struct FVector StartLoc3D; // Offset: 0x04 // Size: 0x0c
	struct FVector TargetLoc3D; // Offset: 0x10 // Size: 0x0c
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FVector> AirDropLocs3D; // Offset: 0x20 // Size: 0x10
	bool bIsDrawAirDropFlightPath; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	struct FVector MapCenter; // Offset: 0x34 // Size: 0x0c
	float Radius; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.GetCircleInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FGetCircleInfo {
	// Fields
	bool bIsLessning; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float CircleStateStartServerWorldSecond; // Offset: 0x04 // Size: 0x04
	float CircleStatusLastTime; // Offset: 0x08 // Size: 0x04
	float CircleStatusElapsedTime; // Offset: 0x0c // Size: 0x04
	enum class ECircleInfo CircleStatus; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	struct FVector BlueCircle; // Offset: 0x14 // Size: 0x0c
	struct FVector OriginalBlueCircle; // Offset: 0x20 // Size: 0x0c
	struct FVector WhiteCircle; // Offset: 0x2c // Size: 0x0c
	bool bActiveScreenSize; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	float ScreenSizeFactor; // Offset: 0x3c // Size: 0x04
	float ExtraRadius; // Offset: 0x40 // Size: 0x04
	int CurrentCircleIndex; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.GameStateWeaponRule
// Size: 0x28 // Inherited bytes: 0x00
struct FGameStateWeaponRule {
	// Fields
	bool bForbidShootTarget; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float CheckForbidShootTime; // Offset: 0x04 // Size: 0x04
	struct TArray<struct AActor*> ForbidShootClassArray; // Offset: 0x08 // Size: 0x10
	struct TArray<struct AActor*> SwallowBulletClassArray; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.GameModeCVarConfigItem
// Size: 0x20 // Inherited bytes: 0x00
struct FGameModeCVarConfigItem {
	// Fields
	struct FString Key; // Offset: 0x00 // Size: 0x10
	struct FString Value; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActorExtraComponents
// Size: 0x10 // Inherited bytes: 0x00
struct FActorExtraComponents {
	// Fields
	struct TArray<struct UClass*> BPComponents; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.GameModeFeatureSetData
// Size: 0x04 // Inherited bytes: 0x00
struct FGameModeFeatureSetData {
	// Fields
	uint32_t GameModeFeatureSet_A; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VisualFieldFeatureParam
// Size: 0x40 // Inherited bytes: 0x00
struct FVisualFieldFeatureParam {
	// Fields
	float VisualFieldUpdateInterval; // Offset: 0x00 // Size: 0x04
	float MaxVisualFieldDistanceSquared; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FName> VisualCheckBoneList; // Offset: 0x08 // Size: 0x10
	float DefaultFOVAngle; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<enum class ECollisionChannel> VisualCheckChanelList; // Offset: 0x20 // Size: 0x10
	struct TArray<struct ACharacter*> ExcludeCheckCharacterClass; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherControllerRepData
// Size: 0x1c // Inherited bytes: 0x00
struct FWeatherControllerRepData {
	// Fields
	enum class EWeatherStatusType WeatherType; // Offset: 0x00 // Size: 0x01
	bool bStarted; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float ElapsedTime; // Offset: 0x04 // Size: 0x04
	float BlendInTime; // Offset: 0x08 // Size: 0x04
	float BlendOutTime; // Offset: 0x0c // Size: 0x04
	float SaturateTime; // Offset: 0x10 // Size: 0x04
	float TimeMultiplier; // Offset: 0x14 // Size: 0x04
	bool BlendInStarted; // Offset: 0x18 // Size: 0x01
	bool BlendSaturated; // Offset: 0x19 // Size: 0x01
	bool BlendOutStarted; // Offset: 0x1a // Size: 0x01
	bool BlendOutEnded; // Offset: 0x1b // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherDetailStatus
// Size: 0x0c // Inherited bytes: 0x00
struct FWeatherDetailStatus {
	// Fields
	enum class EWeatherStatusType CurrentWeather; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float CurrentElapsedTime; // Offset: 0x04 // Size: 0x04
	float TotalTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherChangeSequenceItem
// Size: 0x0c // Inherited bytes: 0x00
struct FWeatherChangeSequenceItem {
	// Fields
	enum class EWeatherStatusType WeatherStatus; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float StartTime; // Offset: 0x04 // Size: 0x04
	float TotalDurationTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherChangeControl
// Size: 0x1c // Inherited bytes: 0x00
struct FWeatherChangeControl {
	// Fields
	bool WeatherChangeStarted; // Offset: 0x00 // Size: 0x01
	bool WeatherChangeFinished; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float WeatherChangeStartTime; // Offset: 0x04 // Size: 0x04
	float ElapsedTime; // Offset: 0x08 // Size: 0x04
	enum class EWeatherStatusType NextWeather; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float NextDuration; // Offset: 0x10 // Size: 0x04
	float WeatherTotalWeight; // Offset: 0x14 // Size: 0x04
	float TimelineOffset; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherChangeConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FWeatherChangeConfig {
	// Fields
	float StartTimeMin; // Offset: 0x00 // Size: 0x04
	float StartTimeMax; // Offset: 0x04 // Size: 0x04
	float BlendInTime; // Offset: 0x08 // Size: 0x04
	float BlendOutTime; // Offset: 0x0c // Size: 0x04
	float DurationTimeMin; // Offset: 0x10 // Size: 0x04
	float DurationTimeMax; // Offset: 0x14 // Size: 0x04
	enum class EWeatherStatusType LastWeatherStatus; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	float LastWeatherAppearTime; // Offset: 0x1c // Size: 0x04
	bool bUseFixWeatherChangeSequence; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct TArray<struct FWeatherChangeWeight> WeatherChangeWeights; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FWeatherChangeSequenceItem> WeatherChangeSequence; // Offset: 0x38 // Size: 0x10
	float TimeMultiplier; // Offset: 0x48 // Size: 0x04
	bool bUseReadyGameStateEnetrAsOriginalTime; // Offset: 0x4c // Size: 0x01
	bool bDisableReadyGameStateWeatherTick; // Offset: 0x4d // Size: 0x01
	char pad_0x4E[0x2]; // Offset: 0x4e // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherChangeWeight
// Size: 0x08 // Inherited bytes: 0x00
struct FWeatherChangeWeight {
	// Fields
	enum class EWeatherStatusType NewWeatherStatus; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Weight; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DropPropData
// Size: 0x10 // Inherited bytes: 0x00
struct FDropPropData {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int ItemCount; // Offset: 0x04 // Size: 0x04
	int DropMode; // Offset: 0x08 // Size: 0x04
	bool bDropOnDead; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.FatalDamageParameter
// Size: 0xd0 // Inherited bytes: 0x00
struct FFatalDamageParameter {
	// Fields
	struct FFatalDamageStringParameter String; // Offset: 0x00 // Size: 0x70
	int DamageType; // Offset: 0x70 // Size: 0x04
	int AdditionalParam; // Offset: 0x74 // Size: 0x04
	bool IsHeadShot; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x3]; // Offset: 0x79 // Size: 0x03
	int ResultHealthStatus; // Offset: 0x7c // Size: 0x04
	int Relationship; // Offset: 0x80 // Size: 0x04
	int PreviousHealthStatus; // Offset: 0x84 // Size: 0x04
	int realKillerNewKillNum; // Offset: 0x88 // Size: 0x04
	uint32_t causerKey; // Offset: 0x8c // Size: 0x04
	uint32_t victimKey; // Offset: 0x90 // Size: 0x04
	int causerAnchorPlatformResID; // Offset: 0x94 // Size: 0x04
	int causerAnchorPlatformColorID; // Offset: 0x98 // Size: 0x04
	int victimAnchorPlatformResID; // Offset: 0x9c // Size: 0x04
	int victimAnchorPlatformColorID; // Offset: 0xa0 // Size: 0x04
	int realKillerAnchorPlatformResID; // Offset: 0xa4 // Size: 0x04
	int realKillerAnchorPlatformColorID; // Offset: 0xa8 // Size: 0x04
	int CauserWeaponAvatarID; // Offset: 0xac // Size: 0x04
	int CauserClothAvatarID; // Offset: 0xb0 // Size: 0x04
	int CauserType; // Offset: 0xb4 // Size: 0x04
	int VictimType; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct TArray<char> ExpandDataContent; // Offset: 0xc0 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.FatalDamageStringParameter
// Size: 0x70 // Inherited bytes: 0x00
struct FFatalDamageStringParameter {
	// Fields
	struct FString CauserName; // Offset: 0x00 // Size: 0x10
	struct FString VictimName; // Offset: 0x10 // Size: 0x10
	struct FString FuzzyCauserName; // Offset: 0x20 // Size: 0x10
	struct FString FuzzyVictimName; // Offset: 0x30 // Size: 0x10
	struct FString RealKillerName; // Offset: 0x40 // Size: 0x10
	struct FString CauserNation; // Offset: 0x50 // Size: 0x10
	struct FString VictimNation; // Offset: 0x60 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.TeamMateStateInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FTeamMateStateInfo {
	// Fields
	char DirtyFlags; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct ASTExtraPlayerState* PlayerState; // Offset: 0x08 // Size: 0x08
	struct FVector_NetQuantize10 Location; // Offset: 0x10 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x1c // Size: 0x0c
	float PlayerHealth; // Offset: 0x28 // Size: 0x04
	float PlayerHealthMax; // Offset: 0x2c // Size: 0x04
	int MemberIdInVoiceRoom; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0xc]; // Offset: 0x34 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.SACData
// Size: 0x78 // Inherited bytes: 0x00
struct FSACData {
	// Fields
	struct TArray<struct FBulletHitInfoUploadData> HitDataArray; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FBulletHitInfoUploadBinaray> HitBinarayArray; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FBulletHitInfoWithoutDamage> HitInfoWithoutDamageArray; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FLocalShootHitData> ShootHitDataArray; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FShootTimeData> ShootTimeDatas; // Offset: 0x40 // Size: 0x10
	int ShootTimes; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct TArray<char> TssSdkAntiData; // Offset: 0x58 // Size: 0x10
	int TssSdkAntiDataLen; // Offset: 0x68 // Size: 0x04
	int NetworkStatus; // Offset: 0x6c // Size: 0x04
	int Sequence; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BulletHitInfoWithoutDamage
// Size: 0x4c // Inherited bytes: 0x00
struct FBulletHitInfoWithoutDamage {
	// Fields
	struct FVector ImpactPoint; // Offset: 0x00 // Size: 0x0c
	struct FVector_NetQuantize RelativeImpactPoint; // Offset: 0x0c // Size: 0x0c
	struct FVector_NetQuantizeNormal ImpactNormal; // Offset: 0x18 // Size: 0x0c
	struct FVector_NetQuantize ShootMomentMuzzlePos; // Offset: 0x24 // Size: 0x0c
	char SurfaceType; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	uint32_t ShootID; // Offset: 0x34 // Size: 0x04
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x38 // Size: 0x08
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // Offset: 0x40 // Size: 0x08
	char HitBodyType; // Offset: 0x48 // Size: 0x01
	bool bIsFirstImpact; // Offset: 0x49 // Size: 0x01
	char ImpactEffectMask; // Offset: 0x4a // Size: 0x01
	char pad_0x4B[0x1]; // Offset: 0x4b // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.BulletHitInfoUploadBinaray
// Size: 0x28 // Inherited bytes: 0x00
struct FBulletHitInfoUploadBinaray {
	// Fields
	struct TArray<char> Data; // Offset: 0x00 // Size: 0x10
	uint16_t CompensationTime; // Offset: 0x10 // Size: 0x02
	char pad_0x12[0x2]; // Offset: 0x12 // Size: 0x02
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x14 // Size: 0x08
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // Offset: 0x1c // Size: 0x08
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BattleSceneAvatarDisplayInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FBattleSceneAvatarDisplayInfo {
	// Fields
	struct FString PlayerName; // Offset: 0x00 // Size: 0x10
	struct FString PlayerUIDStr; // Offset: 0x10 // Size: 0x10
	int PlayerGender; // Offset: 0x20 // Size: 0x04
	bool bIsMVP; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
	struct TArray<int> EquipedAvatarList; // Offset: 0x28 // Size: 0x10
	struct TArray<int> EquipedWeaponList; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponHitDetailInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FWeaponHitDetailInfo {
	// Fields
	int TotalShootNum; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> HitNumEveryBodys; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.LastGameRemainItemData
// Size: 0x38 // Inherited bytes: 0x00
struct FLastGameRemainItemData {
	// Fields
	struct FName TombName; // Offset: 0x00 // Size: 0x08
	struct FVector DropGroundPoint; // Offset: 0x08 // Size: 0x0c
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString TargetPlayerUID; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FRemainItemData> RemainItemDataList; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RemainItemData
// Size: 0x20 // Inherited bytes: 0x00
struct FRemainItemData {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FBattleItemAdditionalData> AdditionalDataList; // Offset: 0x08 // Size: 0x10
	int SlotID; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponHitDisanceSectionArray
// Size: 0x18 // Inherited bytes: 0x00
struct FWeaponHitDisanceSectionArray {
	// Fields
	struct TArray<int> SectionArray; // Offset: 0x00 // Size: 0x10
	enum class EWeaponDistanceType CaculateType; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.BattleOpenSequencerInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FBattleOpenSequencerInfo {
	// Fields
	struct FTransform StartPosition; // Offset: 0x00 // Size: 0x30
	struct TArray<struct FVehicleWarStartVehicleInfo> VehicleInfoList; // Offset: 0x30 // Size: 0x10
	float Time; // Offset: 0x40 // Size: 0x04
	float ServerStartTimestamp; // Offset: 0x44 // Size: 0x04
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarStartVehicleInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FVehicleWarStartVehicleInfo {
	// Fields
	struct FVector Position; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x0c // Size: 0x0c
	struct ASTExtraVehicleBase* Vehicle; // Offset: 0x18 // Size: 0x08
	struct FVehicleWarStartVehiclePlayerInfo DriverInfo; // Offset: 0x20 // Size: 0x10
	struct FVehicleWarStartVehiclePlayerInfo PassengerInfo; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarStartVehiclePlayerInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FVehicleWarStartVehiclePlayerInfo {
	// Fields
	int upassLevel; // Offset: 0x00 // Size: 0x04
	int upassScore; // Offset: 0x04 // Size: 0x04
	struct ASTExtraBaseCharacter* BasePlayer; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.WarPlayerStateScore
// Size: 0x18 // Inherited bytes: 0x00
struct FWarPlayerStateScore {
	// Fields
	int Rank; // Offset: 0x00 // Size: 0x04
	int Score; // Offset: 0x04 // Size: 0x04
	enum class EWarScoreChangeReason ScoreChangeReason; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int ScoreChangeCauserPlayerID; // Offset: 0x0c // Size: 0x04
	int HighestScore; // Offset: 0x10 // Size: 0x04
	int FollowScore; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ExplosionProjectileHitInfo
// Size: 0x24 // Inherited bytes: 0x00
struct FExplosionProjectileHitInfo {
	// Fields
	struct FVector ImpactPoint; // Offset: 0x00 // Size: 0x0c
	struct FVector ImpactNormal; // Offset: 0x0c // Size: 0x0c
	float BulletHitTime; // Offset: 0x18 // Size: 0x04
	float BulletLaunchTime; // Offset: 0x1c // Size: 0x04
	float BulletMovedDistance; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SeekAndLockRPGBulletUploadData
// Size: 0x10 // Inherited bytes: 0x00
struct FSeekAndLockRPGBulletUploadData {
	// Fields
	char SeekAndLockStageType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct AActor* SeekAndLockTarget; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeviceInfo
// Size: 0x80 // Inherited bytes: 0x00
struct FDeviceInfo {
	// Fields
	struct FString GPUFamily; // Offset: 0x00 // Size: 0x10
	struct FString GLVersion; // Offset: 0x10 // Size: 0x10
	struct FString OSVersion; // Offset: 0x20 // Size: 0x10
	struct FString DeviceMake; // Offset: 0x30 // Size: 0x10
	struct FString DeviceModel; // Offset: 0x40 // Size: 0x10
	struct FString VulkanVersion; // Offset: 0x50 // Size: 0x10
	struct FString MemorySizeInGB; // Offset: 0x60 // Size: 0x10
	struct FString OpenID; // Offset: 0x70 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.HitTargetExtraData
// Size: 0x24 // Inherited bytes: 0x00
struct FHitTargetExtraData {
	// Fields
	char PlatForm; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int CharacterReplicatID; // Offset: 0x04 // Size: 0x04
	int CharacterMovementReplicatID; // Offset: 0x08 // Size: 0x04
	float LastReplicatedServerLastTransformUpdateTimeStamp; // Offset: 0x0c // Size: 0x04
	float LastReplicatedTimePass; // Offset: 0x10 // Size: 0x04
	float CapsulePreMoveDistance; // Offset: 0x14 // Size: 0x04
	float MeshOffsetDistance; // Offset: 0x18 // Size: 0x04
	float AverageFPS; // Offset: 0x1c // Size: 0x04
	float ImpactFrameDeltaTime; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.StartFireInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FStartFireInfo {
	// Fields
	uint32_t CurShootID; // Offset: 0x00 // Size: 0x04
	uint32_t CurClipID; // Offset: 0x04 // Size: 0x04
	int CurBulletNumInClip; // Offset: 0x08 // Size: 0x04
	enum class EShootWeaponShootMode ShootMode; // Offset: 0x0c // Size: 0x01
	enum class ESTEWeaponShootType ShootType; // Offset: 0x0d // Size: 0x01
	char pad_0xE[0x2]; // Offset: 0x0e // Size: 0x02
	float StartFireTime; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	double StartFireSysTime; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.TeamateStateUAVChangedCompressData
// Size: 0x14 // Inherited bytes: 0x00
struct FTeamateStateUAVChangedCompressData {
	// Fields
	struct FVector_NetQuantize100 Location; // Offset: 0x00 // Size: 0x0c
	uint32_t View; // Offset: 0x0c // Size: 0x04
	char Roll; // Offset: 0x10 // Size: 0x01
	char uavType; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x2]; // Offset: 0x12 // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParachuteAnimAssetData
// Size: 0x58 // Inherited bytes: 0x00
struct FParachuteAnimAssetData {
	// Fields
	struct TMap<enum class ECharacterParachuteAnimType, struct UAnimationAsset*> AnimAssetCache; // Offset: 0x00 // Size: 0x50
	bool IsAnimCached; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.TrailMarkActorBlock
// Size: 0x20 // Inherited bytes: 0x00
struct FTrailMarkActorBlock {
	// Fields
	struct TArray<struct ATrailMarkActor*> WorkingList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct ATrailMarkActor*> AssignableList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.FootprintActorBlock
// Size: 0x58 // Inherited bytes: 0x00
struct FFootprintActorBlock {
	// Fields
	struct TMap<uint32_t, struct AFootprintInstanceActor*> TeamFootprintInstanceActorMap; // Offset: 0x00 // Size: 0x50
	struct AFootprintInstanceActor* OthersFootprintInstanceActor; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.FootprintActorInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FFootprintActorInfo {
	// Fields
	enum class EPhysicalSurfaceDescription PhysicalSurface; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UClass* FootprintClass; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.ClientSettingBaseOnGameMode
// Size: 0x50 // Inherited bytes: 0x00
struct FClientSettingBaseOnGameMode {
	// Fields
	bool bEnableBulletImpactFXTargetCullingByQualityLevel; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FBulletImpactFXTargetCullingByQualityLeveConfigItem> BulletImpactFXTargetCullingByQualityLeveConfigList; // Offset: 0x08 // Size: 0x10
	bool bBulletImpactFXAttachToTarget; // Offset: 0x18 // Size: 0x01
	bool bSimulateClientEnableOBBulletTrackEffect; // Offset: 0x19 // Size: 0x01
	bool bAutonomousClientEnableOBBulletTrackEffect; // Offset: 0x1a // Size: 0x01
	char pad_0x1B[0x5]; // Offset: 0x1b // Size: 0x05
	struct TArray<int> DisableBulletTrackDeviceQualityLevelConfigList; // Offset: 0x20 // Size: 0x10
	struct TArray<int> DisableSimulateClientBulletImpactFXDeviceQualityLevelConfigList; // Offset: 0x30 // Size: 0x10
	struct TArray<int> DisableSimulateClientMuzzleFXDeviceQualityLevelConfigList; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.BulletImpactFXTargetCullingByQualityLeveConfigItem
// Size: 0x28 // Inherited bytes: 0x00
struct FBulletImpactFXTargetCullingByQualityLeveConfigItem {
	// Fields
	enum class ERenderQuality QualityLevel; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct UClass*> TargetClassConfigList; // Offset: 0x08 // Size: 0x10
	struct TArray<struct UObject*> CachedClassList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ImpactMapValueData
// Size: 0x10 // Inherited bytes: 0x00
struct FImpactMapValueData {
	// Fields
	struct TArray<struct ASTEShootWeaponBulletImpactEffect*> ImpactEffectList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponMgrInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FWeaponMgrInfo {
	// Fields
	struct TArray<struct FItemDefineID> ItemList; // Offset: 0x00 // Size: 0x10
	struct UWeaponManagerComponent* WeaponMgr; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.OwnerClientCreateWeaponCache
// Size: 0x18 // Inherited bytes: 0x00
struct FOwnerClientCreateWeaponCache {
	// Fields
	struct TArray<struct FItemDefineID> IDList; // Offset: 0x00 // Size: 0x10
	uint32_t CharacterGUID; // Offset: 0x10 // Size: 0x04
	int SyncTicket; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ObservedData
// Size: 0x50 // Inherited bytes: 0x00
struct FObservedData {
	// Fields
	struct FString PlayerName; // Offset: 0x00 // Size: 0x10
	struct FString PicUrl; // Offset: 0x10 // Size: 0x10
	bool ShowPicUrl; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	int TeamID; // Offset: 0x24 // Size: 0x04
	uint64 UId; // Offset: 0x28 // Size: 0x08
	struct TArray<struct FVector> PosList; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x10]; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponSystemReconnectReplicateData
// Size: 0x30 // Inherited bytes: 0x00
struct FWeaponSystemReconnectReplicateData {
	// Fields
	struct FName LastUseNoneGrenadeLogicSlot; // Offset: 0x00 // Size: 0x08
	struct FName LastUseLogicSlot; // Offset: 0x08 // Size: 0x08
	struct TArray<struct FName> GrenadeLogicSlotList; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FItemDefineID> GrenadeDefineIDList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ServerHitEnemyReplicatedData
// Size: 0x10 // Inherited bytes: 0x00
struct FServerHitEnemyReplicatedData {
	// Fields
	struct ASTExtraBaseCharacter* HitTargetPawn; // Offset: 0x00 // Size: 0x08
	uint32_t EventId; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CameraViewPitchLimitData
// Size: 0x08 // Inherited bytes: 0x00
struct FCameraViewPitchLimitData {
	// Fields
	float ViewPitchMin; // Offset: 0x00 // Size: 0x04
	float ViewPitchMax; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CommonCameraModeData
// Size: 0x24 // Inherited bytes: 0x00
struct FCommonCameraModeData {
	// Fields
	struct FSwitchCameraData SwitchCameraData; // Offset: 0x00 // Size: 0x24
};

// Object Name: ScriptStruct ShadowTrackerExtra.CameraData
// Size: 0x14 // Inherited bytes: 0x00
struct FCameraData {
	// Fields
	float CameraFOV; // Offset: 0x00 // Size: 0x04
	struct FVector SpringArmSocketOffset; // Offset: 0x04 // Size: 0x0c
	float SpringArmLength; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SwitchCameraData
// Size: 0x24 // Inherited bytes: 0x14
struct FSwitchCameraData : FCameraData {
	// Fields
	float StartCameraSwitchDelayTimeFrom_Normal; // Offset: 0x14 // Size: 0x04
	float StartCameraSwitchDelayTimeFrom_Near; // Offset: 0x18 // Size: 0x04
	float StartCameraSwitchDelayTimeFrom_Aim; // Offset: 0x1c // Size: 0x04
	float CameraSwitchTime; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AimCameraModeData
// Size: 0x24 // Inherited bytes: 0x00
struct FAimCameraModeData {
	// Fields
	struct FSwitchCameraData SwitchCameraData; // Offset: 0x00 // Size: 0x24
};

// Object Name: ScriptStruct ShadowTrackerExtra.KillOrPutDownMessage
// Size: 0xa8 // Inherited bytes: 0x00
struct FKillOrPutDownMessage {
	// Fields
	enum class EKillOrPutDownMessageType MsgType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString AttackActionName; // Offset: 0x08 // Size: 0x10
	struct FString AttackName; // Offset: 0x18 // Size: 0x10
	bool bIsHeadshot; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int KillNum; // Offset: 0x2c // Size: 0x04
	bool bShowKillNum; // Offset: 0x30 // Size: 0x01
	bool bHideKillIcon; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
	struct FString FullMsg; // Offset: 0x38 // Size: 0x10
	int victimAnchorPlatformResID; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FString VictimPlayerName; // Offset: 0x50 // Size: 0x10
	struct FString CauserPlayerName; // Offset: 0x60 // Size: 0x10
	struct FString CauserRealPlayerName; // Offset: 0x70 // Size: 0x10
	bool bIsCauserTeammate; // Offset: 0x80 // Size: 0x01
	bool bIsVictimTeammate; // Offset: 0x81 // Size: 0x01
	bool bIamCauser; // Offset: 0x82 // Size: 0x01
	bool bIamVictim; // Offset: 0x83 // Size: 0x01
	int ResultHealthStatus; // Offset: 0x84 // Size: 0x04
	int CauserType; // Offset: 0x88 // Size: 0x04
	int DamageType; // Offset: 0x8c // Size: 0x04
	int AdditionalParam; // Offset: 0x90 // Size: 0x04
	int PreviousHealthStatus; // Offset: 0x94 // Size: 0x04
	struct TArray<char> ExpandDataContent; // Offset: 0x98 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SensibilityConfig
// Size: 0x100 // Inherited bytes: 0x00
struct FSensibilityConfig {
	// Fields
	struct FSensibilityMode NormalMode; // Offset: 0x00 // Size: 0x28
	struct FSensibilityMode FireMode; // Offset: 0x28 // Size: 0x28
	struct FSensibilityMode MotionMode; // Offset: 0x50 // Size: 0x28
	struct FSensibilityMode MotionFireMode; // Offset: 0x78 // Size: 0x28
	float VehicleEye; // Offset: 0xa0 // Size: 0x04
	float ParachuteEye; // Offset: 0xa4 // Size: 0x04
	float FPPEye; // Offset: 0xa8 // Size: 0x04
	int SideMirrorModeC; // Offset: 0xac // Size: 0x04
	struct TMap<int, struct FSightMaterialConfig> MaterialConfigs; // Offset: 0xb0 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.SightMaterialConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FSightMaterialConfig {
	// Fields
	int Color; // Offset: 0x00 // Size: 0x04
	int Type; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SensibilityMode
// Size: 0x28 // Inherited bytes: 0x00
struct FSensibilityMode {
	// Fields
	float NoAim; // Offset: 0x00 // Size: 0x04
	float Sight1X; // Offset: 0x04 // Size: 0x04
	float Sight2X; // Offset: 0x08 // Size: 0x04
	float Sight3X; // Offset: 0x0c // Size: 0x04
	float Sight4X; // Offset: 0x10 // Size: 0x04
	float Sight6X; // Offset: 0x14 // Size: 0x04
	float Sight8X; // Offset: 0x18 // Size: 0x04
	float FPPNoAim; // Offset: 0x1c // Size: 0x04
	float Shoulder; // Offset: 0x20 // Size: 0x04
	float ShoulderFPP; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ValidTouchMoveFrameConfig
// Size: 0x20 // Inherited bytes: 0x00
struct FValidTouchMoveFrameConfig {
	// Fields
	struct FString DeviceName; // Offset: 0x00 // Size: 0x10
	int Enable; // Offset: 0x10 // Size: 0x04
	int Frame; // Offset: 0x14 // Size: 0x04
	bool IsInit; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterAsyncloadAnimParams
// Size: 0x01 // Inherited bytes: 0x00
struct FMonsterAsyncloadAnimParams {
	// Fields
	enum class EMonsterPoseType PosType; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleStyleData
// Size: 0x18 // Inherited bytes: 0x00
struct FVehicleStyleData {
	// Fields
	int StyleID; // Offset: 0x00 // Size: 0x04
	enum class EVehicleSlotType SlotType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct TArray<struct FVehicleStyle> MutilStyles; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleStyle
// Size: 0x08 // Inherited bytes: 0x00
struct FVehicleStyle {
	// Fields
	enum class EVehicleStyleType StyleType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int StyleValue; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.LoadGuideConfig
// Size: 0x28 // Inherited bytes: 0x00
struct FLoadGuideConfig {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.LoadGuideUIFinishRet
// Size: 0x08 // Inherited bytes: 0x00
struct FLoadGuideUIFinishRet {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.NewbieGuideItem
// Size: 0x90 // Inherited bytes: 0x00
struct FNewbieGuideItem {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Name; // Offset: 0x08 // Size: 0x10
	enum class ENewbieGuideType Type; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int MaxGuideCounts; // Offset: 0x1c // Size: 0x04
	int MaxGuideLevel; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct TArray<enum class ENewbieGuidePlayerCategory> SubjectPlayerTypes; // Offset: 0x28 // Size: 0x10
	int Priority; // Offset: 0x38 // Size: 0x04
	int MuteFlag; // Offset: 0x3c // Size: 0x04
	int PreconditionID; // Offset: 0x40 // Size: 0x04
	float PreconditionTipTimeGap; // Offset: 0x44 // Size: 0x04
	struct TArray<struct USTNewbieGuideConditionBase*> Conditions; // Offset: 0x48 // Size: 0x10
	struct USTNewbieGuideSuccessListenerBase* QuickFinishedListener; // Offset: 0x58 // Size: 0x08
	struct TArray<struct USTNewbieGuideSuccessListenerBase*> QuickFinishedListenerList; // Offset: 0x60 // Size: 0x10
	float Duration; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct TArray<struct FNewbieGuideUIInfo> UIInfos; // Offset: 0x78 // Size: 0x10
	bool UseNewEdition; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x7]; // Offset: 0x89 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.NewbieGuideUIInfo
// Size: 0xa0 // Inherited bytes: 0x00
struct FNewbieGuideUIInfo {
	// Fields
	struct UClass* WidgetClassPath; // Offset: 0x00 // Size: 0x28
	bool isMountUIDynamic; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FString MountName; // Offset: 0x30 // Size: 0x10
	struct FString MountOuterName; // Offset: 0x40 // Size: 0x10
	struct FAnchorData LayoutData; // Offset: 0x50 // Size: 0x28
	struct FString LogicManagerNames; // Offset: 0x78 // Size: 0x10
	bool bAutoSize; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x3]; // Offset: 0x89 // Size: 0x03
	int ZOrder; // Offset: 0x8c // Size: 0x04
	struct UWidget* UIWidget; // Offset: 0x90 // Size: 0x08
	struct UObject* UIWidgetClass; // Offset: 0x98 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.QuickSignMark
// Size: 0xc8 // Inherited bytes: 0x00
struct FQuickSignMark {
	// Fields
	struct FString MsgID; // Offset: 0x00 // Size: 0x10
	struct FString MarkType; // Offset: 0x10 // Size: 0x10
	struct FString IconPath; // Offset: 0x20 // Size: 0x10
	struct FString IconBGPath; // Offset: 0x30 // Size: 0x10
	struct FString IconOuterPath; // Offset: 0x40 // Size: 0x10
	struct FString IconOuterBGPath; // Offset: 0x50 // Size: 0x10
	struct FString IconOutScreenIconPath; // Offset: 0x60 // Size: 0x10
	struct FString IconOutScreenBGPath; // Offset: 0x70 // Size: 0x10
	struct FString IconOutScreenArrowPath; // Offset: 0x80 // Size: 0x10
	struct FString ReplyID; // Offset: 0x90 // Size: 0x10
	struct FVector Loc; // Offset: 0xa0 // Size: 0x0c
	int MaxNum; // Offset: 0xac // Size: 0x04
	int LifeSpan; // Offset: 0xb0 // Size: 0x04
	bool IsSelfMark; // Offset: 0xb4 // Size: 0x01
	char pad_0xB5[0x3]; // Offset: 0xb5 // Size: 0x03
	struct FString SenderPlayerKey; // Offset: 0xb8 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ConveyorCarryData
// Size: 0x30 // Inherited bytes: 0x00
struct FConveyorCarryData {
	// Fields
	struct AActor* Actor; // Offset: 0x00 // Size: 0x08
	float StartTime; // Offset: 0x08 // Size: 0x04
	int StartStep; // Offset: 0x0c // Size: 0x04
	struct FVector RelativeLocation; // Offset: 0x10 // Size: 0x0c
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FQuat RelativeQuat; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CheckGroundSlopData
// Size: 0x0c // Inherited bytes: 0x00
struct FCheckGroundSlopData {
	// Fields
	float MaxSlopAngle; // Offset: 0x00 // Size: 0x04
	int MaxSlopAngleLastFrames; // Offset: 0x04 // Size: 0x04
	int CurUpHeavySlopFrames; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InterpToMovementComponent2ReplicatedData
// Size: 0x10 // Inherited bytes: 0x00
struct FInterpToMovementComponent2ReplicatedData {
	// Fields
	enum class EInterpToBehaviourType ReplicatedBehaviourType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float ReplicatedCurrentTime; // Offset: 0x04 // Size: 0x04
	float ReplicatedTimeMultiplier; // Offset: 0x08 // Size: 0x04
	float ReplicatedCurrentDirection; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.FPSMonitorConfigSwitch
// Size: 0x14 // Inherited bytes: 0x00
struct FFPSMonitorConfigSwitch {
	// Fields
	bool bFPSMonitor; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float FPSCollectInternal; // Offset: 0x04 // Size: 0x04
	int FPSCollectCountForGroup; // Offset: 0x08 // Size: 0x04
	float FPSThreshold; // Offset: 0x0c // Size: 0x04
	int FPSLowActionType; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.TargetTrainData
// Size: 0x28 // Inherited bytes: 0x00
struct FTargetTrainData {
	// Fields
	struct FString UId; // Offset: 0x00 // Size: 0x10
	int TimeStamp; // Offset: 0x10 // Size: 0x04
	int Score; // Offset: 0x14 // Size: 0x04
	int Duration; // Offset: 0x18 // Size: 0x04
	int IslandID; // Offset: 0x1c // Size: 0x04
	int ShootType; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ThrowableConfig
// Size: 0x78 // Inherited bytes: 0x00
struct FThrowableConfig {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct AEliteProjectile* ProjectileClass; // Offset: 0x08 // Size: 0x08
	char bShowTrajectory : 1; // Offset: 0x10 // Size: 0x01
	char pad_0x10_1 : 7; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct UClass* Ring; // Offset: 0x18 // Size: 0x28
	struct FName RingAttachSocket; // Offset: 0x40 // Size: 0x08
	float ExplosionDelayOverride; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct UCurveFloat* SpeedCurve; // Offset: 0x50 // Size: 0x08
	struct UCurveFloat* PitchCurve; // Offset: 0x58 // Size: 0x08
	float FireDelay; // Offset: 0x60 // Size: 0x04
	float ProjectileSpawnDelay; // Offset: 0x64 // Size: 0x04
	float ThrowCooldownDuration; // Offset: 0x68 // Size: 0x04
	struct FVector PawnMotionContributionMultiplier; // Offset: 0x6c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.RenderQualitySettings
// Size: 0x08 // Inherited bytes: 0x00
struct FRenderQualitySettings {
	// Fields
	enum class ERenderQuality RenderQualitySetting; // Offset: 0x00 // Size: 0x01
	enum class ERenderStyle RenderStyleSetting; // Offset: 0x01 // Size: 0x01
	bool RenderMSAASetting; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	int RenderMSAAValue; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.FadeDynamicStyleInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FFadeDynamicStyleInfo {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.MaterialParametersStyle
// Size: 0x38 // Inherited bytes: 0x00
struct FMaterialParametersStyle {
	// Fields
	struct FString StyleName; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FMaterialParameterFloat> Floats; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FMaterialParameterVector> Vectors; // Offset: 0x20 // Size: 0x10
	char pad_0x30[0x8]; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.MaterialParameterVector
// Size: 0x18 // Inherited bytes: 0x00
struct FMaterialParameterVector {
	// Fields
	struct FName Name; // Offset: 0x00 // Size: 0x08
	struct FVector Vector; // Offset: 0x08 // Size: 0x0c
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MaterialParameterFloat
// Size: 0x10 // Inherited bytes: 0x00
struct FMaterialParameterFloat {
	// Fields
	struct FName Name; // Offset: 0x00 // Size: 0x08
	float Value; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RenderStyleParameterInMaps
// Size: 0x40 // Inherited bytes: 0x00
struct FRenderStyleParameterInMaps {
	// Fields
	enum class ERenderDynamicStyle DynamicStyleName; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FString> PostProcessParams; // Offset: 0x08 // Size: 0x10
	struct FACESParameter ACESParams; // Offset: 0x18 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.RenderItem
// Size: 0x18 // Inherited bytes: 0x00
struct FRenderItem {
	// Fields
	struct FString RenderKey; // Offset: 0x00 // Size: 0x10
	float RenderValue; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SwitchesInMaps
// Size: 0x20 // Inherited bytes: 0x00
struct FSwitchesInMaps {
	// Fields
	struct FString MapName; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FSwitchesItem> Switches; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SwitchesItem
// Size: 0x30 // Inherited bytes: 0x00
struct FSwitchesItem {
	// Fields
	struct FString Key; // Offset: 0x00 // Size: 0x10
	float Value; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString DependKey; // Offset: 0x18 // Size: 0x10
	float DependValue; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionContinuousKillInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FInfectionContinuousKillInfo {
	// Fields
	enum class ECharacterMainType PawnType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int KillNumber; // Offset: 0x04 // Size: 0x04
	struct FString KillerName; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionRoundTlogCountData
// Size: 0x140 // Inherited bytes: 0x00
struct FInfectionRoundTlogCountData {
	// Fields
	float RoundStartTime; // Offset: 0x00 // Size: 0x04
	float RoundEndTime; // Offset: 0x04 // Size: 0x04
	int WinCamp; // Offset: 0x08 // Size: 0x04
	bool bSpawnRevenger; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float RevengerSpawmTime; // Offset: 0x10 // Size: 0x04
	int RevengerDoSkillCount; // Offset: 0x14 // Size: 0x04
	int ZombieReviveCount; // Offset: 0x18 // Size: 0x04
	int NormalZombieDoSkillCount; // Offset: 0x1c // Size: 0x04
	int InvisibleZombieDoSkillCount; // Offset: 0x20 // Size: 0x04
	int ThrowerZombieDoSkillCount; // Offset: 0x24 // Size: 0x04
	int MotherZombieDoSkillCount; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TMap<int, struct FInfectionRoundTlogGuidData> GuidCount; // Offset: 0x30 // Size: 0x50
	struct TArray<struct FInfectionPlayerDeadTlogData> DeadList; // Offset: 0x80 // Size: 0x10
	struct TMap<int, int> ZombieLevelNumMap; // Offset: 0x90 // Size: 0x50
	struct TArray<int> EnhancerUserList; // Offset: 0xe0 // Size: 0x10
	struct TMap<int, struct FInfectionSpringUseData> SpringUseMap; // Offset: 0xf0 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionRoleTableRow
// Size: 0xc8 // Inherited bytes: 0x00
struct FInfectionRoleTableRow {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString RoleName; // Offset: 0x08 // Size: 0x10
	int DieExchange; // Offset: 0x18 // Size: 0x04
	int MatrixEffect; // Offset: 0x1c // Size: 0x04
	int BornChoose; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString WeIcon; // Offset: 0x28 // Size: 0x10
	struct FString EnemyIcon; // Offset: 0x38 // Size: 0x10
	struct TArray<enum class ECharacterSubType> VisibleRange; // Offset: 0x48 // Size: 0x10
	int MainSkillId; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct TArray<int> BornSkillList; // Offset: 0x60 // Size: 0x10
	struct FString SkillIcon; // Offset: 0x70 // Size: 0x10
	struct FString SkillCDIcon; // Offset: 0x80 // Size: 0x10
	struct FString SkillName; // Offset: 0x90 // Size: 0x10
	struct FString SkillDetail; // Offset: 0xa0 // Size: 0x10
	float SkillCD; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04
	struct FString HeroIcon; // Offset: 0xb8 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionRoundScoreData
// Size: 0x7c // Inherited bytes: 0x00
struct FInfectionRoundScoreData {
	// Fields
	int RoundNo; // Offset: 0x00 // Size: 0x04
	float MonsterScore; // Offset: 0x04 // Size: 0x04
	float PersonScore; // Offset: 0x08 // Size: 0x04
	int KillMonsters; // Offset: 0x0c // Size: 0x04
	int KillPersons; // Offset: 0x10 // Size: 0x04
	float RoundDamage; // Offset: 0x14 // Size: 0x04
	int BeMatrixMonsterTimes; // Offset: 0x18 // Size: 0x04
	int BeRevengerPlayerTimes; // Offset: 0x1c // Size: 0x04
	uint32_t Headshot4Avenger; // Offset: 0x20 // Size: 0x04
	int RevengerPlayerKillWinTimes; // Offset: 0x24 // Size: 0x04
	int BeMonsterWinTimes; // Offset: 0x28 // Size: 0x04
	int BePersonWinTimes; // Offset: 0x2c // Size: 0x04
	int UseSpringJumpTimes; // Offset: 0x30 // Size: 0x04
	int UseEnhancerTimes; // Offset: 0x34 // Size: 0x04
	int DamageToMonster; // Offset: 0x38 // Size: 0x04
	int DamageToRevengerPlayer; // Offset: 0x3c // Size: 0x04
	int ChooseZombieFirstTimes; // Offset: 0x40 // Size: 0x04
	int ChooseZombieSecondTimes; // Offset: 0x44 // Size: 0x04
	int ChooseZombieThirdTimes; // Offset: 0x48 // Size: 0x04
	uint32_t PlayerKilled; // Offset: 0x4c // Size: 0x04
	uint32_t PlayerHurtCount; // Offset: 0x50 // Size: 0x04
	uint32_t PlayerDamageCount; // Offset: 0x54 // Size: 0x04
	uint32_t HeadshotCounts; // Offset: 0x58 // Size: 0x04
	uint32_t GunKillingTimes; // Offset: 0x5c // Size: 0x04
	uint8_t RoleType; // Offset: 0x60 // Size: 0x01
	uint8_t RoleTypeEnd; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x2]; // Offset: 0x62 // Size: 0x02
	uint32_t RoleTypeSwitchTime; // Offset: 0x64 // Size: 0x04
	int PlayerJumpHeightMax; // Offset: 0x68 // Size: 0x04
	int PlayerJumpSpeedMax; // Offset: 0x6c // Size: 0x04
	uint32_t PlayerMoveDistance; // Offset: 0x70 // Size: 0x04
	uint32_t PlayerMoveTime; // Offset: 0x74 // Size: 0x04
	int PlayerMoveSpeedAvg; // Offset: 0x78 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionPlayerScoreData
// Size: 0xb8 // Inherited bytes: 0x00
struct FInfectionPlayerScoreData {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString PlayerName; // Offset: 0x08 // Size: 0x10
	int TeamID; // Offset: 0x18 // Size: 0x04
	float PlayerEnterGameTime; // Offset: 0x1c // Size: 0x04
	struct FInfectionPlayerInfo InfectionPlayerInfo; // Offset: 0x20 // Size: 0x48
	struct TMap<int, struct FInfectionRoundScoreData> RoundScoreData; // Offset: 0x68 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionPlayerInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FInfectionPlayerInfo {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	struct FString UIDString; // Offset: 0x08 // Size: 0x10
	struct FString PlayerName; // Offset: 0x18 // Size: 0x10
	struct FString iconUrl; // Offset: 0x28 // Size: 0x10
	char gender; // Offset: 0x38 // Size: 0x01
	char PlatformGender; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x2]; // Offset: 0x3a // Size: 0x02
	int PlayerLevel; // Offset: 0x3c // Size: 0x04
	int SegmentLevel; // Offset: 0x40 // Size: 0x04
	int AvatarBoxId; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionRoundResultPlayerShowData
// Size: 0x80 // Inherited bytes: 0x00
struct FInfectionRoundResultPlayerShowData {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString PlayerName; // Offset: 0x08 // Size: 0x10
	int TeamID; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FInfectionPlayerInfo InfectionPlayerInfo; // Offset: 0x20 // Size: 0x48
	struct FInfectionShowRoundScoreData RoundScoreData; // Offset: 0x68 // Size: 0x14
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionShowRoundScoreData
// Size: 0x14 // Inherited bytes: 0x00
struct FInfectionShowRoundScoreData {
	// Fields
	int RoundNo; // Offset: 0x00 // Size: 0x04
	int MonsterScore; // Offset: 0x04 // Size: 0x04
	int PersonScore; // Offset: 0x08 // Size: 0x04
	int KillMonsters; // Offset: 0x0c // Size: 0x04
	int KillPersons; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionRoundResultData
// Size: 0x118 // Inherited bytes: 0x00
struct FInfectionRoundResultData {
	// Fields
	int RoundNum; // Offset: 0x00 // Size: 0x04
	enum class ECharacterMainType WinType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct FInfectionRoundResultPlayerShowData BestPerson; // Offset: 0x08 // Size: 0x80
	struct FInfectionRoundResultPlayerShowData BestMonster; // Offset: 0x88 // Size: 0x80
	struct TArray<struct FInfectionRoundResultPlayerShowData> AllDataArray; // Offset: 0x108 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionScoreTableRow
// Size: 0x20 // Inherited bytes: 0x00
struct FInfectionScoreTableRow {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	int Identity; // Offset: 0x04 // Size: 0x04
	struct FString Action; // Offset: 0x08 // Size: 0x10
	int Param1; // Offset: 0x18 // Size: 0x04
	int Score; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionRoleLevelMap
// Size: 0x58 // Inherited bytes: 0x00
struct FInfectionRoleLevelMap {
	// Fields
	struct TMap<int, struct FInfectionRoleLevelInfo> LevelMap; // Offset: 0x00 // Size: 0x50
	int MaxLevel; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionRoleLevelInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FInfectionRoleLevelInfo {
	// Fields
	int Exp; // Offset: 0x00 // Size: 0x04
	int BuffID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionGainExpInfo
// Size: 0x1c // Inherited bytes: 0x00
struct FInfectionGainExpInfo {
	// Fields
	int KillExp; // Offset: 0x00 // Size: 0x04
	int AssistExp; // Offset: 0x04 // Size: 0x04
	float AssistExpAcceptRange; // Offset: 0x08 // Size: 0x04
	float DamageExpRate; // Offset: 0x0c // Size: 0x04
	float HealthExpRate; // Offset: 0x10 // Size: 0x04
	float SecondExp; // Offset: 0x14 // Size: 0x04
	float GainExpInterval; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.IslandRoomData
// Size: 0x30 // Inherited bytes: 0x00
struct FIslandRoomData {
	// Fields
	int LandId; // Offset: 0x00 // Size: 0x04
	int EndStateTime; // Offset: 0x04 // Size: 0x04
	int PlayerNum; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct TWeakObjectPtr<struct APlayerController>> Players; // Offset: 0x10 // Size: 0x10
	bool IsEnd; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	int FirstPlayerEnterTime; // Offset: 0x24 // Size: 0x04
	bool bArenaOccupied; // Offset: 0x28 // Size: 0x01
	bool bForceCheck; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x6]; // Offset: 0x2a // Size: 0x06
};

// Object Name: ScriptStruct ShadowTrackerExtra.SIslandAIPlayerMarkInfo
// Size: 0x68 // Inherited bytes: 0x00
struct FSIslandAIPlayerMarkInfo {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString PlayerName; // Offset: 0x08 // Size: 0x10
	struct FGameModePlayerAliasInfo PlayerAliasInfo; // Offset: 0x18 // Size: 0x48
	struct ASTExtraBaseCharacter* AIPlayer; // Offset: 0x60 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarTeamKillData
// Size: 0x0c // Inherited bytes: 0x00
struct FVehicleWarTeamKillData {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	int ContinueKillNum; // Offset: 0x04 // Size: 0x04
	int TotalKillNum; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarRankData
// Size: 0x14 // Inherited bytes: 0x00
struct FVehicleWarRankData {
	// Fields
	int RoundNo; // Offset: 0x00 // Size: 0x04
	int TeamID; // Offset: 0x04 // Size: 0x04
	int Distance; // Offset: 0x08 // Size: 0x04
	int Score; // Offset: 0x0c // Size: 0x04
	int GemStoneNum; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarCampGroup
// Size: 0x18 // Inherited bytes: 0x00
struct FVehicleWarCampGroup {
	// Fields
	int CampID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FVehicleWarTeamGroupInfo> CampGroups; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarTeamGroupInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FVehicleWarTeamGroupInfo {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct AVehicleWarPlayerState*> TeamPlayers; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarGemMatchState
// Size: 0x0c // Inherited bytes: 0x00
struct FVehicleWarGemMatchState {
	// Fields
	enum class EVehicleWarGemMatchState GemMatchState; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int CampID; // Offset: 0x04 // Size: 0x04
	float CampWinServerTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarKillInfoData
// Size: 0x78 // Inherited bytes: 0x00
struct FVehicleWarKillInfoData {
	// Fields
	int DamageType; // Offset: 0x00 // Size: 0x04
	int AdditionalParam; // Offset: 0x04 // Size: 0x04
	struct FString CauserName; // Offset: 0x08 // Size: 0x10
	struct FString CauserNation; // Offset: 0x18 // Size: 0x10
	struct FString VictimName; // Offset: 0x28 // Size: 0x10
	struct FString VictimNation; // Offset: 0x38 // Size: 0x10
	struct FString KillerIconURL; // Offset: 0x48 // Size: 0x10
	int KillerPlayerLevel; // Offset: 0x58 // Size: 0x04
	int KillerAvatarBoxId; // Offset: 0x5c // Size: 0x04
	float TotalDamage; // Offset: 0x60 // Size: 0x04
	bool IsCooperationKill; // Offset: 0x64 // Size: 0x01
	char pad_0x65[0x3]; // Offset: 0x65 // Size: 0x03
	int KillerTeamId; // Offset: 0x68 // Size: 0x04
	int VictimTeamID; // Offset: 0x6c // Size: 0x04
	float ThisDamage; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.EmoteAnimCharacterConfig
// Size: 0x70 // Inherited bytes: 0x00
struct FEmoteAnimCharacterConfig {
	// Fields
	struct UClass* Character; // Offset: 0x00 // Size: 0x28
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FTransform Transform; // Offset: 0x30 // Size: 0x30
	bool NeedAttach; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0xf]; // Offset: 0x61 // Size: 0x0f
};

// Object Name: ScriptStruct ShadowTrackerExtra.EmoteAnimConfig
// Size: 0xe0 // Inherited bytes: 0x00
struct FEmoteAnimConfig {
	// Fields
	struct FName GenderStr; // Offset: 0x00 // Size: 0x08
	struct UClass* MainCharacter; // Offset: 0x08 // Size: 0x28
	struct UAnimationAsset* MainCharacterAnimAsset; // Offset: 0x30 // Size: 0x28
	bool CanRotateMainCharacter; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x7]; // Offset: 0x59 // Size: 0x07
	struct FTransform MainCharacterTransform; // Offset: 0x60 // Size: 0x30
	bool RotateBackToZero; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
	struct ULevelSequence* EmoteLevelSequence; // Offset: 0x98 // Size: 0x08
	struct TArray<struct FEmoteAnimCharacterConfig> MultiFollowerCharacters; // Offset: 0xa0 // Size: 0x10
	struct UClass* FollowerCharacter; // Offset: 0xb0 // Size: 0x28
	bool NeedAttach; // Offset: 0xd8 // Size: 0x01
	char pad_0xD9[0x7]; // Offset: 0xd9 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.GenderMapping
// Size: 0x10 // Inherited bytes: 0x00
struct FGenderMapping {
	// Fields
	struct FName GenderStr; // Offset: 0x00 // Size: 0x08
	enum class ELobbyCharacterAnimType GenderType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.PetMontageData
// Size: 0x08 // Inherited bytes: 0x00
struct FPetMontageData {
	// Fields
	int AnimationAssetId; // Offset: 0x00 // Size: 0x04
	float MontageStartTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionMeshAsyncloadParams
// Size: 0x02 // Inherited bytes: 0x00
struct FInfectionMeshAsyncloadParams {
	// Fields
	char pad_0x0[0x2]; // Offset: 0x00 // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.ChachePlayMontageData
// Size: 0x18 // Inherited bytes: 0x00
struct FChachePlayMontageData {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeathMatchPlayerStateData
// Size: 0x88 // Inherited bytes: 0x00
struct FDeathMatchPlayerStateData {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FDeathMatchPlayerInfo DeathMatchPlayerInfo; // Offset: 0x08 // Size: 0x58
	int TeamID; // Offset: 0x60 // Size: 0x04
	int TeamIndex; // Offset: 0x64 // Size: 0x04
	int Score; // Offset: 0x68 // Size: 0x04
	int Rank; // Offset: 0x6c // Size: 0x04
	int Kills; // Offset: 0x70 // Size: 0x04
	int Assists; // Offset: 0x74 // Size: 0x04
	int Deaths; // Offset: 0x78 // Size: 0x04
	int ContinuouKills; // Offset: 0x7c // Size: 0x04
	int rescueTimes; // Offset: 0x80 // Size: 0x04
	bool IsAIPlayer; // Offset: 0x84 // Size: 0x01
	char pad_0x85[0x3]; // Offset: 0x85 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeathMatchPlayerInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FDeathMatchPlayerInfo {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	struct FString UIDString; // Offset: 0x08 // Size: 0x10
	struct FString PlayerName; // Offset: 0x18 // Size: 0x10
	struct FString iconUrl; // Offset: 0x28 // Size: 0x10
	char gender; // Offset: 0x38 // Size: 0x01
	char PlatformGender; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x2]; // Offset: 0x3a // Size: 0x02
	int PlayerLevel; // Offset: 0x3c // Size: 0x04
	int SegmentLevel; // Offset: 0x40 // Size: 0x04
	int AvatarBoxId; // Offset: 0x44 // Size: 0x04
	struct FAchievementPrize EquippedAchievementPrize; // Offset: 0x48 // Size: 0x0c
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeathMatchPlayerDieData
// Size: 0xb8 // Inherited bytes: 0x00
struct FDeathMatchPlayerDieData {
	// Fields
	struct TArray<struct FDeathMatchDamageCauserRecordData> KillerCauserRecords; // Offset: 0x00 // Size: 0x10
	struct FDeathMatchPlayerStateData KillerStateData; // Offset: 0x10 // Size: 0x88
	struct TArray<struct FDeathMatchPlayerStateData> AssisterStateDatas; // Offset: 0x98 // Size: 0x10
	struct TArray<struct FDeathMatchDamageRecordData> VictimDamageRecords; // Offset: 0xa8 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeathMatchDamageRecordData
// Size: 0x20 // Inherited bytes: 0x00
struct FDeathMatchDamageRecordData {
	// Fields
	struct FString VictimName; // Offset: 0x00 // Size: 0x10
	float Damage; // Offset: 0x10 // Size: 0x04
	enum class EDeathMatchDamageResult DamageResult; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	float LastTime; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeathMatchDamageCauserRecordData
// Size: 0x0c // Inherited bytes: 0x00
struct FDeathMatchDamageCauserRecordData {
	// Fields
	int DamageType; // Offset: 0x00 // Size: 0x04
	int MurderWeaponID; // Offset: 0x04 // Size: 0x04
	float Damage; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DestructInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FDestructInfo {
	// Fields
	struct AController* LastHitBy; // Offset: 0x00 // Size: 0x08
	struct AActor* LastHitCauser; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ReplayStreamInfo
// Size: 0x60 // Inherited bytes: 0x00
struct FReplayStreamInfo {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct FString FriendlyName; // Offset: 0x10 // Size: 0x10
	struct FDateTime TimeStamp; // Offset: 0x20 // Size: 0x08
	int TimestampInt; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x10]; // Offset: 0x2c // Size: 0x10
	int NumViewers; // Offset: 0x3c // Size: 0x04
	bool bIsLive; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0xf]; // Offset: 0x41 // Size: 0x0f
	struct FString ReplayURL; // Offset: 0x50 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.KillInfoRecordData
// Size: 0x58 // Inherited bytes: 0x00
struct FKillInfoRecordData {
	// Fields
	struct FString Killer; // Offset: 0x00 // Size: 0x10
	struct FString Victim; // Offset: 0x10 // Size: 0x10
	bool bKillDown; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	uint64 KillTimeStampDemoTime; // Offset: 0x28 // Size: 0x08
	uint64 KillTimeStampGameTime; // Offset: 0x30 // Size: 0x08
	struct FString SafeLabel; // Offset: 0x38 // Size: 0x10
	int SafeParam1; // Offset: 0x48 // Size: 0x04
	int SafeParam2; // Offset: 0x4c // Size: 0x04
	float RecordTimestamp; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.UIBPAsyncParams
// Size: 0xd8 // Inherited bytes: 0x00
struct FUIBPAsyncParams {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FMarkSyncData MarkData; // Offset: 0x08 // Size: 0x70
	char pad_0x78[0x8]; // Offset: 0x78 // Size: 0x08
	struct UClass* UIIconSoftPtr; // Offset: 0x80 // Size: 0x28
	struct UClass* UIBPSoftPtr; // Offset: 0xa8 // Size: 0x28
	struct UObject* UIClass; // Offset: 0xd0 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.MapMarkConfig
// Size: 0x48 // Inherited bytes: 0x00
struct FMapMarkConfig {
	// Fields
	int ConfigId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString UIPath; // Offset: 0x08 // Size: 0x10
	bool bIsIcon; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	struct FVector2D Size; // Offset: 0x1c // Size: 0x08
	bool bIsUpdateSize; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
	struct FVector2D MaxSize; // Offset: 0x28 // Size: 0x08
	int ZOrder; // Offset: 0x30 // Size: 0x04
	bool bIsControlByLegend; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	struct FString LegendTags; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MarkActorInstInfo
// Size: 0x04 // Inherited bytes: 0x00
struct FMarkActorInstInfo {
	// Fields
	int UIBPInstID; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MarkPathSetting
// Size: 0x28 // Inherited bytes: 0x00
struct FMarkPathSetting {
	// Fields
	int UIBPSrcID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString UIBPSoftPtr; // Offset: 0x08 // Size: 0x10
	struct FString UIDescription; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.TypeWidgetPair
// Size: 0x28 // Inherited bytes: 0x00
struct FTypeWidgetPair {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct TArray<struct UWidget*> Widgets; // Offset: 0x08 // Size: 0x10
	char pad_0x18[0x10]; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemLayoutInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FItemLayoutInfo {
	// Fields
	struct UWidget* itemType; // Offset: 0x00 // Size: 0x08
	struct FVector2D ItemSize; // Offset: 0x08 // Size: 0x08
	struct FVector2D ItemPadding; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.KilledTipsBlock
// Size: 0x38 // Inherited bytes: 0x00
struct FKilledTipsBlock {
	// Fields
	enum class EDamageType DamageType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString attackerName; // Offset: 0x08 // Size: 0x10
	struct FString WeaponName; // Offset: 0x18 // Size: 0x10
	struct FString DeadName; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.TurretRotation
// Size: 0x08 // Inherited bytes: 0x00
struct FTurretRotation {
	// Fields
	float TurretYaw; // Offset: 0x00 // Size: 0x04
	float MainGunPitch; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ESTAINoiseEventParams
// Size: 0x10 // Inherited bytes: 0x00
struct FESTAINoiseEventParams {
	// Fields
	enum class ESTAINoiseType NoiseType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Loudness; // Offset: 0x04 // Size: 0x04
	float StartAttenuationDist; // Offset: 0x08 // Size: 0x04
	float MaxRange; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleSimViewData
// Size: 0x04 // Inherited bytes: 0x00
struct FVehicleSimViewData {
	// Fields
	char ViewPitch; // Offset: 0x00 // Size: 0x01
	char ViewYaw; // Offset: 0x01 // Size: 0x01
	char ViewRoll; // Offset: 0x02 // Size: 0x01
	bool FreeCamera; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.STExtraVehicleSfxLoopBase
// Size: 0x58 // Inherited bytes: 0x00
struct FSTExtraVehicleSfxLoopBase {
	// Fields
	struct UAkComponent* AkComp; // Offset: 0x00 // Size: 0x08
	struct TMap<uint32_t, float> MapRTPC; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.STExtraVehicleSfxLoop
// Size: 0x78 // Inherited bytes: 0x58
struct FSTExtraVehicleSfxLoop : FSTExtraVehicleSfxLoopBase {
	// Fields
	struct UAkAudioEvent* AkEvent; // Offset: 0x58 // Size: 0x08
	char pad_0x60[0x18]; // Offset: 0x60 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehBackpackItem
// Size: 0x08 // Inherited bytes: 0x00
struct FVehBackpackItem {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int ItemCount; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleRuntimeDataArray
// Size: 0x18 // Inherited bytes: 0x00
struct FParticleRuntimeDataArray {
	// Fields
	struct TArray<struct FParticleRuntimeData> DataArray; // Offset: 0x00 // Size: 0x10
	char pad_0x10[0x8]; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleRuntimeData
// Size: 0x10 // Inherited bytes: 0x00
struct FParticleRuntimeData {
	// Fields
	struct UParticleSystemComponent* SpawnedComponent; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleSoftWrapperArray
// Size: 0x10 // Inherited bytes: 0x00
struct FParticleSoftWrapperArray {
	// Fields
	struct TArray<struct FParticleSoftWrapper> WrapperArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleSoftWrapper
// Size: 0x60 // Inherited bytes: 0x00
struct FParticleSoftWrapper {
	// Fields
	struct UParticleSystem* Template; // Offset: 0x00 // Size: 0x28
	struct FVector Location; // Offset: 0x28 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x34 // Size: 0x0c
	struct FVector Scale; // Offset: 0x40 // Size: 0x0c
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FName AttachSocketName; // Offset: 0x50 // Size: 0x08
	bool bAutoLoad; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x3]; // Offset: 0x59 // Size: 0x03
	int ValidDeviceLevel; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.TankScopingSyncData
// Size: 0x10 // Inherited bytes: 0x00
struct FTankScopingSyncData {
	// Fields
	bool IsScoping; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct ASTExtraPlayerCharacter* ScopingCharacter; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.TankMovementInputState
// Size: 0x04 // Inherited bytes: 0x00
struct FTankMovementInputState {
	// Fields
	uint8_t SteeringInput; // Offset: 0x00 // Size: 0x01
	uint8_t ThrottleInput; // Offset: 0x01 // Size: 0x01
	uint8_t BrakeInput; // Offset: 0x02 // Size: 0x01
	uint8_t CurrentGear; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleHitImpulse
// Size: 0xc8 // Inherited bytes: 0x00
struct FVehicleHitImpulse {
	// Fields
	char pad_0x0[0xc8]; // Offset: 0x00 // Size: 0xc8
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponSyncData
// Size: 0x08 // Inherited bytes: 0x00
struct FWeaponSyncData {
	// Fields
	uint32_t ShootID; // Offset: 0x00 // Size: 0x04
	uint32_t ClipID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CameraOffsetData
// Size: 0x1c // Inherited bytes: 0x00
struct FCameraOffsetData {
	// Fields
	struct FVector SocketOffset; // Offset: 0x00 // Size: 0x0c
	struct FVector TargetOffset; // Offset: 0x0c // Size: 0x0c
	float SpringArmLength; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.LuaSongInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FLuaSongInfo {
	// Fields
	int SongID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString SongName; // Offset: 0x08 // Size: 0x10
	float SongDuration; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString SongEvent; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SongInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FSongInfo {
	// Fields
	int SongID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString SongName; // Offset: 0x08 // Size: 0x10
	float SongDuration; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FSoftObjectPath SongEvent; // Offset: 0x20 // Size: 0x18
	struct UAkAudioEvent* SongEventPtr; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.STReplicatedVehicleState
// Size: 0x0c // Inherited bytes: 0x00
struct FSTReplicatedVehicleState {
	// Fields
	uint8_t SteeringInput; // Offset: 0x00 // Size: 0x01
	uint8_t ThrottleInput; // Offset: 0x01 // Size: 0x01
	uint8_t BrakeInput; // Offset: 0x02 // Size: 0x01
	uint8_t HandbrakeInput; // Offset: 0x03 // Size: 0x01
	uint8_t CurrentGear; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int Flag; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.STExtraVehicleWheelSfxOnSurface
// Size: 0x70 // Inherited bytes: 0x58
struct FSTExtraVehicleWheelSfxOnSurface : FSTExtraVehicleSfxLoopBase {
	// Fields
	struct UPhysicalMaterial* LastSurfaceMaterial; // Offset: 0x58 // Size: 0x08
	struct UWheelSfxConfig* WheelSfxConfig; // Offset: 0x60 // Size: 0x08
	char pad_0x68[0x8]; // Offset: 0x68 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarVehicleReceiveDamageRecord
// Size: 0x08 // Inherited bytes: 0x00
struct FVehicleWarVehicleReceiveDamageRecord {
	// Fields
	int DamageFromTeamID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarLockData
// Size: 0x10 // Inherited bytes: 0x00
struct FVehicleWarLockData {
	// Fields
	enum class EAutoAimLockState LockState; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct AActor* LockTarget; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ProjectileBulletLaunchParams
// Size: 0x60 // Inherited bytes: 0x00
struct FProjectileBulletLaunchParams {
	// Fields
	float Speed; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0xc]; // Offset: 0x04 // Size: 0x0c
	struct FTransform Trans; // Offset: 0x10 // Size: 0x30
	struct AActor* OwningWeapon; // Offset: 0x40 // Size: 0x08
	struct AActor* Instigator; // Offset: 0x48 // Size: 0x08
	uint32_t ShootID; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0xc]; // Offset: 0x54 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.ApplyRadialDamageParams
// Size: 0x110 // Inherited bytes: 0x00
struct FApplyRadialDamageParams {
	// Fields
	float BaseDamage; // Offset: 0x00 // Size: 0x04
	float MinimumDamage; // Offset: 0x04 // Size: 0x04
	float BaseMomentumMag; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FApplyRadialDamageMomentum Momentum; // Offset: 0x10 // Size: 0x70
	struct FVector Origin; // Offset: 0x80 // Size: 0x0c
	float DamageInnerRadius; // Offset: 0x8c // Size: 0x04
	float DamageOuterRadius; // Offset: 0x90 // Size: 0x04
	float DamageFalloff; // Offset: 0x94 // Size: 0x04
	bool bTraceComplex; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x17]; // Offset: 0x99 // Size: 0x17
	bool CanPenetrationdamage; // Offset: 0xb0 // Size: 0x01
	char pad_0xB1[0x7]; // Offset: 0xb1 // Size: 0x07
	struct UDamageType* DamageTypeClass; // Offset: 0xb8 // Size: 0x08
	struct TArray<struct AActor*> IgnoreActors; // Offset: 0xc0 // Size: 0x10
	struct TArray<struct AActor*> IgnoreClasses; // Offset: 0xd0 // Size: 0x10
	struct AActor* DamageCauser; // Offset: 0xe0 // Size: 0x08
	struct AController* InstigatedBy; // Offset: 0xe8 // Size: 0x08
	float CollisionFreeRadius; // Offset: 0xf0 // Size: 0x04
	enum class ECollisionChannel DamageChannel; // Offset: 0xf4 // Size: 0x01
	char pad_0xF5[0x3]; // Offset: 0xf5 // Size: 0x03
	float AddtionalDamage; // Offset: 0xf8 // Size: 0x04
	enum class EDamageType DamageEventType; // Offset: 0xfc // Size: 0x01
	char pad_0xFD[0x3]; // Offset: 0xfd // Size: 0x03
	float HorizontalCoverRatio; // Offset: 0x100 // Size: 0x04
	float VerticalCoverRatio; // Offset: 0x104 // Size: 0x04
	bool bDrawVisibilityTraceLine; // Offset: 0x108 // Size: 0x01
	bool bExplosionTestOnly; // Offset: 0x109 // Size: 0x01
	bool bPlayHurtAnim; // Offset: 0x10a // Size: 0x01
	char pad_0x10B[0x1]; // Offset: 0x10b // Size: 0x01
	float SphereOverlapRadius; // Offset: 0x10c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ApplyRadialDamageMomentum
// Size: 0x70 // Inherited bytes: 0x00
struct FApplyRadialDamageMomentum {
	// Fields
	bool bEnable; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector LinerScaleForEnemy; // Offset: 0x04 // Size: 0x0c
	struct FVector LinerScaleForTeam; // Offset: 0x10 // Size: 0x0c
	struct FVector ConstScaleForEnemy; // Offset: 0x1c // Size: 0x0c
	struct FVector ConstScaleForTeam; // Offset: 0x28 // Size: 0x0c
	struct FVector ExtraImpulseForEnemy; // Offset: 0x34 // Size: 0x0c
	struct FVector ExtraImpulseForTeam; // Offset: 0x40 // Size: 0x0c
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct TArray<int> BuffForEnemy; // Offset: 0x50 // Size: 0x10
	struct TArray<int> BuffForTeam; // Offset: 0x60 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActivitySoundGroup
// Size: 0x20 // Inherited bytes: 0x00
struct FActivitySoundGroup {
	// Fields
	struct TArray<struct UAkAudioEvent*> AudioEventList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FActivitySoundAsset> SoundAssetList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActivitySoundAsset
// Size: 0x38 // Inherited bytes: 0x00
struct FActivitySoundAsset {
	// Fields
	struct FString BankName; // Offset: 0x00 // Size: 0x10
	struct UAkAudioEvent* AudioEvent; // Offset: 0x10 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActivityParticleGroup
// Size: 0x30 // Inherited bytes: 0x00
struct FActivityParticleGroup {
	// Fields
	struct TArray<struct UParticleSystem*> ParticleSystemList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct UParticleSystemComponent*> ParticleCompList; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FActivityParticleAsset> ParticleAssetList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActivityParticleAsset
// Size: 0x80 // Inherited bytes: 0x00
struct FActivityParticleAsset {
	// Fields
	struct FTransform Transform; // Offset: 0x00 // Size: 0x30
	struct UParticleSystem* ParticleSystem; // Offset: 0x30 // Size: 0x28
	struct FName AttachSocket; // Offset: 0x58 // Size: 0x08
	struct TArray<struct FParticleSysParam> InstanceParameters; // Offset: 0x60 // Size: 0x10
	bool bLimitCount; // Offset: 0x70 // Size: 0x01
	bool bAutoDestroy; // Offset: 0x71 // Size: 0x01
	char pad_0x72[0xe]; // Offset: 0x72 // Size: 0x0e
};

// Object Name: ScriptStruct ShadowTrackerExtra.SequenceInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FSequenceInfo {
	// Fields
	struct FTransform TransfromOrigin; // Offset: 0x00 // Size: 0x30
	struct AActor* TransfromOriginActor; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SequenceBindingInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FSequenceBindingInfo {
	// Fields
	struct FMovieSceneObjectBindingID Binding; // Offset: 0x00 // Size: 0x18
	struct AActor* Actor; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SequencePlayerInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FSequencePlayerInfo {
	// Fields
	struct ASTExtraBaseCharacter* PlayerPawn; // Offset: 0x00 // Size: 0x08
	float CurrentPlayingTime; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeliveryPolygonPoints
// Size: 0x10 // Inherited bytes: 0x00
struct FDeliveryPolygonPoints {
	// Fields
	struct TArray<struct FVector> DeliveryPolygonPoint; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIDynamicDamageBasedHP
// Size: 0x10 // Inherited bytes: 0x00
struct FAIDynamicDamageBasedHP {
	// Fields
	float HealthPercentLeft; // Offset: 0x00 // Size: 0x04
	float HealthPercentRight; // Offset: 0x04 // Size: 0x04
	float FireHitRate; // Offset: 0x08 // Size: 0x04
	float DamageScale; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeliveryPlayerConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FDeliveryPlayerConfig {
	// Fields
	struct TArray<struct FDeliveryItem> DeliveryItem; // Offset: 0x00 // Size: 0x10
	float RightRatingSection; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeliveryItem
// Size: 0x08 // Inherited bytes: 0x00
struct FDeliveryItem {
	// Fields
	int percent; // Offset: 0x00 // Size: 0x04
	int DeliveryNum; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpecialAIDeliveryNumContainer
// Size: 0x18 // Inherited bytes: 0x00
struct FSpecialAIDeliveryNumContainer {
	// Fields
	int TeammateNum; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FSpecialAIDeliveryNum> DeliverNumCfg; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpecialAIDeliveryNum
// Size: 0x08 // Inherited bytes: 0x00
struct FSpecialAIDeliveryNum {
	// Fields
	int DeliveryNum; // Offset: 0x00 // Size: 0x04
	int Weight; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HotValueScale
// Size: 0x0c // Inherited bytes: 0x00
struct FHotValueScale {
	// Fields
	float Corner; // Offset: 0x00 // Size: 0x04
	float Center; // Offset: 0x04 // Size: 0x04
	float UpDown; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HotValueAttenuation
// Size: 0x0c // Inherited bytes: 0x00
struct FHotValueAttenuation {
	// Fields
	float Corner; // Offset: 0x00 // Size: 0x04
	float Center; // Offset: 0x04 // Size: 0x04
	float UpDown; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeliveryRatingConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FDeliveryRatingConfig {
	// Fields
	float DeliveryInterval; // Offset: 0x00 // Size: 0x04
	float RightRatingSection; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIBeginAttackEachOther
// Size: 0x08 // Inherited bytes: 0x00
struct FAIBeginAttackEachOther {
	// Fields
	float BeginAttackEachOtherTime; // Offset: 0x00 // Size: 0x04
	float RightRatingSection; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIDeliveryAreaLimit
// Size: 0x18 // Inherited bytes: 0x00
struct FAIDeliveryAreaLimit {
	// Fields
	struct FVector TopLeftVec; // Offset: 0x00 // Size: 0x0c
	struct FVector BottomRightVec; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIAttackAnimalRatingDamage
// Size: 0x0c // Inherited bytes: 0x00
struct FAIAttackAnimalRatingDamage {
	// Fields
	float RatingDamageScale; // Offset: 0x00 // Size: 0x04
	float FiringAccuracyRadius; // Offset: 0x04 // Size: 0x04
	float SectionRightValue; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIAttackBuildingRatingDamage
// Size: 0x0c // Inherited bytes: 0x00
struct FAIAttackBuildingRatingDamage {
	// Fields
	float RatingDamageScale; // Offset: 0x00 // Size: 0x04
	float FiringAccuracyRadius; // Offset: 0x04 // Size: 0x04
	float SectionRightValue; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIAttackMORatingDamage
// Size: 0x0c // Inherited bytes: 0x00
struct FAIAttackMORatingDamage {
	// Fields
	float RatingDamageScale; // Offset: 0x00 // Size: 0x04
	float FiringAccuracyRadius; // Offset: 0x04 // Size: 0x04
	float SectionRightValue; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIAttackAIRatingFireHitRate
// Size: 0x08 // Inherited bytes: 0x00
struct FAIAttackAIRatingFireHitRate {
	// Fields
	float FireHitRate; // Offset: 0x00 // Size: 0x04
	float SectionRightValue; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIAttackAIRatingDamage
// Size: 0x0c // Inherited bytes: 0x00
struct FAIAttackAIRatingDamage {
	// Fields
	float RatingDamageScale; // Offset: 0x00 // Size: 0x04
	float FiringAccuracyRadius; // Offset: 0x04 // Size: 0x04
	float SectionRightValue; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIRatingFireHitRate
// Size: 0x08 // Inherited bytes: 0x00
struct FAIRatingFireHitRate {
	// Fields
	float FireHitRate; // Offset: 0x00 // Size: 0x04
	float SectionRightValue; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIRatingDamage
// Size: 0x18 // Inherited bytes: 0x00
struct FAIRatingDamage {
	// Fields
	float RatingDamageScale; // Offset: 0x00 // Size: 0x04
	float SpecialRatingDamageScale; // Offset: 0x04 // Size: 0x04
	float FiringAccuracyRadius; // Offset: 0x08 // Size: 0x04
	float SpecialFiringAccuracyRadius; // Offset: 0x0c // Size: 0x04
	int AIFeedLimit; // Offset: 0x10 // Size: 0x04
	float SectionRightValue; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIActingItem
// Size: 0x30 // Inherited bytes: 0x00
struct FAIActingItem {
	// Fields
	float StartSeconds; // Offset: 0x00 // Size: 0x04
	float EndSeconds; // Offset: 0x04 // Size: 0x04
	float DeadPercent; // Offset: 0x08 // Size: 0x04
	int PlayerNumScale; // Offset: 0x0c // Size: 0x04
	bool IsFinished; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct TArray<int> WeaponIdList; // Offset: 0x18 // Size: 0x10
	int FinalRestBotNum; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIActingCandidateData
// Size: 0x30 // Inherited bytes: 0x00
struct FAIActingCandidateData {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
	struct AFakePlayerAIController* FakePlayerAIController; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIAttributeTableRow
// Size: 0x0c // Inherited bytes: 0x00
struct FAIAttributeTableRow {
	// Fields
	int AttributeID; // Offset: 0x00 // Size: 0x04
	float DamageRate; // Offset: 0x04 // Size: 0x04
	int HP; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.EnemyInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FEnemyInfo {
	// Fields
	enum class EEnemyType EnemyType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FName Tag; // Offset: 0x08 // Size: 0x08
	float MemoryTime; // Offset: 0x10 // Size: 0x04
	int16_t RevengeValue_Sight; // Offset: 0x14 // Size: 0x02
	int16_t RevengeValue_Memory; // Offset: 0x16 // Size: 0x02
	int16_t RevengeValue_NearDeath; // Offset: 0x18 // Size: 0x02
	char pad_0x1A[0x2]; // Offset: 0x1a // Size: 0x02
	float RevengeValue_PerMetre; // Offset: 0x1c // Size: 0x04
	struct FVector TraceStartOffset; // Offset: 0x20 // Size: 0x0c
	struct FVector TraceEndOffset; // Offset: 0x2c // Size: 0x0c
	char Belonging; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	float HitProtectTime; // Offset: 0x3c // Size: 0x04
	bool IsBlockTrace; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.FanInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FFanInfo {
	// Fields
	float Radius; // Offset: 0x00 // Size: 0x04
	float Angle; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.UpdateItemInterval
// Size: 0x08 // Inherited bytes: 0x00
struct FUpdateItemInterval {
	// Fields
	int Distance; // Offset: 0x00 // Size: 0x04
	float interval; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffStateInfoBase
// Size: 0x10 // Inherited bytes: 0x00
struct FDiffStateInfoBase {
	// Fields
	struct TArray<struct FString> IgnoreNames; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffAIStateInfo
// Size: 0x2c8 // Inherited bytes: 0x10
struct FDiffAIStateInfo : FDiffStateInfoBase {
	// Fields
	struct FDiffAIPlayerState State; // Offset: 0x10 // Size: 0x80
	struct FAIHeardSound Sound; // Offset: 0x90 // Size: 0x10
	struct FDiffCameraState Camera; // Offset: 0xa0 // Size: 0x28
	struct FDiffAIPlayerWeapon Weapon; // Offset: 0xc8 // Size: 0x30
	struct FDiffPlayerBackpack backpack; // Offset: 0xf8 // Size: 0x30
	struct FDiffAIPlayerEquipment equipment; // Offset: 0x128 // Size: 0x30
	struct FDiffProgressBarState progress_bar; // Offset: 0x158 // Size: 0x18
	struct FDiffAINearbyPlayers nearby_player; // Offset: 0x170 // Size: 0x30
	struct FDiffItemStateDatas nearby_item; // Offset: 0x1a0 // Size: 0x30
	struct TArray<struct FObstacleState> nearby_obstacle; // Offset: 0x1d0 // Size: 0x10
	struct TArray<struct FAINearbyThrown> nearby_thrown; // Offset: 0x1e0 // Size: 0x10
	struct FDiffSafetyAreaState safety_area; // Offset: 0x1f0 // Size: 0x40
	struct FDiffAIGameState Game; // Offset: 0x230 // Size: 0x18
	struct TArray<struct FDoorState> nearby_door; // Offset: 0x248 // Size: 0x10
	struct FDiffRedZoneState red_zone; // Offset: 0x258 // Size: 0x28
	struct FAIDamageSources damage_sources; // Offset: 0x280 // Size: 0x30
	uint32_t Key; // Offset: 0x2b0 // Size: 0x04
	char pad_0x2B4[0x4]; // Offset: 0x2b4 // Size: 0x04
	struct TArray<struct FItemStateData> nearby_box_item; // Offset: 0x2b8 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemStateData
// Size: 0x20 // Inherited bytes: 0x00
struct FItemStateData {
	// Fields
	int Type; // Offset: 0x00 // Size: 0x04
	int Category; // Offset: 0x04 // Size: 0x04
	int ID; // Offset: 0x08 // Size: 0x04
	int UId; // Offset: 0x0c // Size: 0x04
	float Durability; // Offset: 0x10 // Size: 0x04
	struct FAIStateXYZ Position; // Offset: 0x14 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIStateXYZ
// Size: 0x0c // Inherited bytes: 0x00
struct FAIStateXYZ {
	// Fields
	float X; // Offset: 0x00 // Size: 0x04
	float Y; // Offset: 0x04 // Size: 0x04
	float Z; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIDamageSources
// Size: 0x30 // Inherited bytes: 0x00
struct FAIDamageSources {
	// Fields
	struct TArray<struct FAIStateXYZ> damage_source; // Offset: 0x00 // Size: 0x10
	struct TArray<int> damage_type; // Offset: 0x10 // Size: 0x10
	struct TArray<int> damage_weapon_type; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffRedZoneState
// Size: 0x28 // Inherited bytes: 0x10
struct FDiffRedZoneState : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoVector Center; // Offset: 0x10 // Size: 0x0c
	struct FDiffStateInfoFloat Radius; // Offset: 0x1c // Size: 0x04
	struct FDiffStateInfoFloat remain_time; // Offset: 0x20 // Size: 0x04
	struct FDiffStateInfoFloat start_time; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffStateInfoFloat
// Size: 0x04 // Inherited bytes: 0x00
struct FDiffStateInfoFloat {
	// Fields
	float Value; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffStateInfoVector
// Size: 0x0c // Inherited bytes: 0x00
struct FDiffStateInfoVector {
	// Fields
	struct FDiffStateInfoFloat X; // Offset: 0x00 // Size: 0x04
	struct FDiffStateInfoFloat Y; // Offset: 0x04 // Size: 0x04
	struct FDiffStateInfoFloat Z; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DoorState
// Size: 0x10 // Inherited bytes: 0x00
struct FDoorState {
	// Fields
	struct FAIStateXYZ Position; // Offset: 0x00 // Size: 0x0c
	int State; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffAIGameState
// Size: 0x18 // Inherited bytes: 0x10
struct FDiffAIGameState : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoBool is_over; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	struct FDiffStateInfoInt32 alive_player_count; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffStateInfoInt32
// Size: 0x04 // Inherited bytes: 0x00
struct FDiffStateInfoInt32 {
	// Fields
	int Value; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffStateInfoBool
// Size: 0x01 // Inherited bytes: 0x00
struct FDiffStateInfoBool {
	// Fields
	bool Value; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffSafetyAreaState
// Size: 0x40 // Inherited bytes: 0x10
struct FDiffSafetyAreaState : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoInt32 State; // Offset: 0x10 // Size: 0x04
	struct FDiffStateInfoVector Center; // Offset: 0x14 // Size: 0x0c
	struct FDiffStateInfoFloat Radius; // Offset: 0x20 // Size: 0x04
	struct FDiffStateInfoVector next_center; // Offset: 0x24 // Size: 0x0c
	struct FDiffStateInfoFloat next_radius; // Offset: 0x30 // Size: 0x04
	struct FDiffStateInfoInt32 Time; // Offset: 0x34 // Size: 0x04
	struct FDiffStateInfoInt32 total_time; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AINearbyThrown
// Size: 0x30 // Inherited bytes: 0x10
struct FAINearbyThrown : FDiffStateInfoBase {
	// Fields
	int Type; // Offset: 0x10 // Size: 0x04
	struct FAIStateXYZ Position; // Offset: 0x14 // Size: 0x0c
	float remain_time; // Offset: 0x20 // Size: 0x04
	float explode_time; // Offset: 0x24 // Size: 0x04
	bool is_own; // Offset: 0x28 // Size: 0x01
	bool is_held; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x6]; // Offset: 0x2a // Size: 0x06
};

// Object Name: ScriptStruct ShadowTrackerExtra.ObstacleState
// Size: 0x28 // Inherited bytes: 0x00
struct FObstacleState {
	// Fields
	int Type; // Offset: 0x00 // Size: 0x04
	int Category; // Offset: 0x04 // Size: 0x04
	float HP; // Offset: 0x08 // Size: 0x04
	float max_hp; // Offset: 0x0c // Size: 0x04
	struct FAIStateXYZ Position; // Offset: 0x10 // Size: 0x0c
	struct FAIStateXYZ Rotation; // Offset: 0x1c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffItemStateDatas
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffItemStateDatas : FDiffStateInfoBase {
	// Fields
	struct TArray<struct FDiffItemStateData> Items; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> item_state; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffItemStateData
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffItemStateData : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoInt32 Type; // Offset: 0x10 // Size: 0x04
	struct FDiffStateInfoInt32 Category; // Offset: 0x14 // Size: 0x04
	struct FDiffStateInfoUInt32 ID; // Offset: 0x18 // Size: 0x04
	int UId; // Offset: 0x1c // Size: 0x04
	struct FDiffStateInfoVector Position; // Offset: 0x20 // Size: 0x0c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffStateInfoUInt32
// Size: 0x04 // Inherited bytes: 0x00
struct FDiffStateInfoUInt32 {
	// Fields
	uint32_t Value; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffAINearbyPlayers
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffAINearbyPlayers : FDiffStateInfoBase {
	// Fields
	struct TArray<struct FDiffAINearbyPlayer> Players; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> item_state; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffAINearbyPlayer
// Size: 0xf0 // Inherited bytes: 0x10
struct FDiffAINearbyPlayer : FDiffStateInfoBase {
	// Fields
	struct FDiffAIPlayerState State; // Offset: 0x10 // Size: 0x80
	struct FDiffAIPlayerWeapon Weapon; // Offset: 0x90 // Size: 0x30
	struct FDiffAIPlayerEquipment equipment; // Offset: 0xc0 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffAIPlayerEquipment
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffAIPlayerEquipment : FDiffStateInfoBase {
	// Fields
	struct TArray<struct FDiffAIEquipmentInfo> equipment_item; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> item_state; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffAIEquipmentInfo
// Size: 0x20 // Inherited bytes: 0x10
struct FDiffAIEquipmentInfo : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoInt32 Category; // Offset: 0x10 // Size: 0x04
	uint32_t ID; // Offset: 0x14 // Size: 0x04
	struct FDiffStateInfoFloat Durability; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffAIPlayerWeapon
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffAIPlayerWeapon : FDiffStateInfoBase {
	// Fields
	struct TArray<struct FDiffAIWeaponStateInfo> player_weapon; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> item_state; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffAIWeaponStateInfo
// Size: 0x38 // Inherited bytes: 0x10
struct FDiffAIWeaponStateInfo : FDiffStateInfoBase {
	// Fields
	uint32_t slot_id; // Offset: 0x10 // Size: 0x04
	struct FDiffStateInfoInt32 Category; // Offset: 0x14 // Size: 0x04
	struct FDiffStateInfoInt32 Type; // Offset: 0x18 // Size: 0x04
	struct FDiffStateInfoInt32 Bullet; // Offset: 0x1c // Size: 0x04
	struct FDiffStateInfoFloat remain_reloading; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct TArray<int> attachments; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffAIPlayerState
// Size: 0x80 // Inherited bytes: 0x10
struct FDiffAIPlayerState : FDiffStateInfoBase {
	// Fields
	uint32_t ID; // Offset: 0x10 // Size: 0x04
	struct FDiffStateInfoInt32 actor_id; // Offset: 0x14 // Size: 0x04
	struct FDiffStateInfoInt32 team_id; // Offset: 0x18 // Size: 0x04
	struct FDiffStateInfoVector Position; // Offset: 0x1c // Size: 0x0c
	struct FDiffStateInfoVector Rotation; // Offset: 0x28 // Size: 0x0c
	struct FDiffStateInfoVector Speed; // Offset: 0x34 // Size: 0x0c
	struct FDiffStateInfoFloat HP; // Offset: 0x40 // Size: 0x04
	struct FDiffStateInfoFloat Energy; // Offset: 0x44 // Size: 0x04
	struct FDiffStateInfoFloat dying_hp; // Offset: 0x48 // Size: 0x04
	struct FDiffStateInfoFloat oxygen; // Offset: 0x4c // Size: 0x04
	struct FDiffStateInfoInt32 active_weapon_slot; // Offset: 0x50 // Size: 0x04
	struct FDiffStateInfoInt32 weapon_status; // Offset: 0x54 // Size: 0x04
	struct FDiffStateInfoBool is_switching; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x3]; // Offset: 0x59 // Size: 0x03
	struct FDiffStateInfoInt32 alive_state; // Offset: 0x5c // Size: 0x04
	struct FDiffStateInfoInt32 kill_count; // Offset: 0x60 // Size: 0x04
	struct FDiffStateInfoInt32 Damages; // Offset: 0x64 // Size: 0x04
	struct FDiffStateInfoBool is_running; // Offset: 0x68 // Size: 0x01
	struct FDiffStateInfoBool is_aiming; // Offset: 0x69 // Size: 0x01
	struct FDiffStateInfoBool is_left_probe; // Offset: 0x6a // Size: 0x01
	struct FDiffStateInfoBool is_right_probe; // Offset: 0x6b // Size: 0x01
	struct FDiffStateInfoBool is_floating; // Offset: 0x6c // Size: 0x01
	struct FDiffStateInfoBool is_diving; // Offset: 0x6d // Size: 0x01
	struct FDiffStateInfoBool is_vehicle_probe; // Offset: 0x6e // Size: 0x01
	struct FDiffStateInfoBool is_in_vehicle; // Offset: 0x6f // Size: 0x01
	struct FDiffStateInfoBool is_firing; // Offset: 0x70 // Size: 0x01
	struct FDiffStateInfoBool is_holding; // Offset: 0x71 // Size: 0x01
	struct FDiffStateInfoBool is_pose_acting; // Offset: 0x72 // Size: 0x01
	struct FDiffStateInfoBool is_picking; // Offset: 0x73 // Size: 0x01
	struct FDiffStateInfoInt32 body_state; // Offset: 0x74 // Size: 0x04
	struct FDiffStateInfoInt32 location_state; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffProgressBarState
// Size: 0x18 // Inherited bytes: 0x10
struct FDiffProgressBarState : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoInt32 Type; // Offset: 0x10 // Size: 0x04
	struct FDiffStateInfoFloat remain_time; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffPlayerBackpack
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffPlayerBackpack : FDiffStateInfoBase {
	// Fields
	struct TArray<struct FDiffAIBackpackItem> backpack_item; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> item_state; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffAIBackpackItem
// Size: 0x20 // Inherited bytes: 0x10
struct FDiffAIBackpackItem : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoInt32 Category; // Offset: 0x10 // Size: 0x04
	uint32_t ID; // Offset: 0x14 // Size: 0x04
	struct FDiffStateInfoUInt32 Count; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DiffCameraState
// Size: 0x28 // Inherited bytes: 0x10
struct FDiffCameraState : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoVector Position; // Offset: 0x10 // Size: 0x0c
	struct FDiffStateInfoVector Rotation; // Offset: 0x1c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIHeardSound
// Size: 0x10 // Inherited bytes: 0x00
struct FAIHeardSound {
	// Fields
	struct TArray<struct FSoundState> heard_sound; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SoundState
// Size: 0x10 // Inherited bytes: 0x00
struct FSoundState {
	// Fields
	int Type; // Offset: 0x00 // Size: 0x04
	struct FAIStateXYZ Location; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIStateInfo
// Size: 0x1b8 // Inherited bytes: 0x00
struct FAIStateInfo {
	// Fields
	struct FAIPlayerState State; // Offset: 0x00 // Size: 0x6c
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FAIHeardSound Sound; // Offset: 0x70 // Size: 0x10
	struct FAIDamageSources damage_sources; // Offset: 0x80 // Size: 0x30
	struct FCameraState Camera; // Offset: 0xb0 // Size: 0x18
	struct FAIPlayerWeapon Weapon; // Offset: 0xc8 // Size: 0x10
	struct FAIPlayerBackpack backpack; // Offset: 0xd8 // Size: 0x10
	struct FAIPlayerEquipment equipment; // Offset: 0xe8 // Size: 0x10
	struct FProgressBarState progress_bar; // Offset: 0xf8 // Size: 0x08
	struct TArray<struct FAINearbyPlayer> nearby_player; // Offset: 0x100 // Size: 0x10
	struct TArray<struct FItemStateData> nearby_item; // Offset: 0x110 // Size: 0x10
	struct TArray<struct FObstacleState> nearby_obstacle; // Offset: 0x120 // Size: 0x10
	struct TArray<struct FAINearbyThrown> nearby_thrown; // Offset: 0x130 // Size: 0x10
	struct TArray<struct FDoorState> nearby_door; // Offset: 0x140 // Size: 0x10
	struct FAIPlayerHitInfo player_hit_info; // Offset: 0x150 // Size: 0x14
	struct FSafetyAreaState safety_area; // Offset: 0x164 // Size: 0x2c
	struct FRedZoneState red_zone; // Offset: 0x190 // Size: 0x18
	struct FAIGameState Game; // Offset: 0x1a8 // Size: 0x08
	uint32_t Key; // Offset: 0x1b0 // Size: 0x04
	char pad_0x1B4[0x4]; // Offset: 0x1b4 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIGameState
// Size: 0x08 // Inherited bytes: 0x00
struct FAIGameState {
	// Fields
	bool is_over; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int alive_player_count; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RedZoneState
// Size: 0x18 // Inherited bytes: 0x00
struct FRedZoneState {
	// Fields
	struct FAIStateXYZ Center; // Offset: 0x00 // Size: 0x0c
	float Radius; // Offset: 0x0c // Size: 0x04
	float remain_time; // Offset: 0x10 // Size: 0x04
	float start_time; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SafetyAreaState
// Size: 0x2c // Inherited bytes: 0x00
struct FSafetyAreaState {
	// Fields
	int State; // Offset: 0x00 // Size: 0x04
	struct FAIStateXYZ Center; // Offset: 0x04 // Size: 0x0c
	float Radius; // Offset: 0x10 // Size: 0x04
	struct FAIStateXYZ next_center; // Offset: 0x14 // Size: 0x0c
	float next_radius; // Offset: 0x20 // Size: 0x04
	int Time; // Offset: 0x24 // Size: 0x04
	int total_time; // Offset: 0x28 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIPlayerHitInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FAIPlayerHitInfo {
	// Fields
	int fire_count; // Offset: 0x00 // Size: 0x04
	int hit_count; // Offset: 0x04 // Size: 0x04
	int hit_head_count; // Offset: 0x08 // Size: 0x04
	int hit_count_filter; // Offset: 0x0c // Size: 0x04
	int hit_head_filter; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AINearbyPlayer
// Size: 0x90 // Inherited bytes: 0x00
struct FAINearbyPlayer {
	// Fields
	struct FAIPlayerState State; // Offset: 0x00 // Size: 0x6c
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FAIPlayerWeapon Weapon; // Offset: 0x70 // Size: 0x10
	struct FAIPlayerEquipment equipment; // Offset: 0x80 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIPlayerEquipment
// Size: 0x10 // Inherited bytes: 0x00
struct FAIPlayerEquipment {
	// Fields
	struct TArray<struct FAIEquipmentInfo> equipment_item; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIEquipmentInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FAIEquipmentInfo {
	// Fields
	int Category; // Offset: 0x00 // Size: 0x04
	int ID; // Offset: 0x04 // Size: 0x04
	float Durability; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIPlayerWeapon
// Size: 0x10 // Inherited bytes: 0x00
struct FAIPlayerWeapon {
	// Fields
	struct TArray<struct FAIWeaponStateInfo> player_weapon; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIWeaponStateInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FAIWeaponStateInfo {
	// Fields
	int slot_id; // Offset: 0x00 // Size: 0x04
	int Category; // Offset: 0x04 // Size: 0x04
	int Type; // Offset: 0x08 // Size: 0x04
	int Bullet; // Offset: 0x0c // Size: 0x04
	float remain_reloading; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<int> attachments; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIPlayerState
// Size: 0x6c // Inherited bytes: 0x00
struct FAIPlayerState {
	// Fields
	uint32_t ID; // Offset: 0x00 // Size: 0x04
	uint32_t actor_id; // Offset: 0x04 // Size: 0x04
	int team_id; // Offset: 0x08 // Size: 0x04
	struct FAIStateXYZ Position; // Offset: 0x0c // Size: 0x0c
	struct FAIStateXYZ Rotation; // Offset: 0x18 // Size: 0x0c
	struct FAIStateXYZ Speed; // Offset: 0x24 // Size: 0x0c
	float HP; // Offset: 0x30 // Size: 0x04
	float Energy; // Offset: 0x34 // Size: 0x04
	float dying_hp; // Offset: 0x38 // Size: 0x04
	float oxygen; // Offset: 0x3c // Size: 0x04
	int active_weapon_slot; // Offset: 0x40 // Size: 0x04
	int weapon_status; // Offset: 0x44 // Size: 0x04
	bool is_switching; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	int alive_state; // Offset: 0x4c // Size: 0x04
	int kill_count; // Offset: 0x50 // Size: 0x04
	int Damages; // Offset: 0x54 // Size: 0x04
	bool is_running; // Offset: 0x58 // Size: 0x01
	bool is_aiming; // Offset: 0x59 // Size: 0x01
	bool is_left_probe; // Offset: 0x5a // Size: 0x01
	bool is_right_probe; // Offset: 0x5b // Size: 0x01
	bool is_floating; // Offset: 0x5c // Size: 0x01
	bool is_diving; // Offset: 0x5d // Size: 0x01
	bool is_vehicle_probe; // Offset: 0x5e // Size: 0x01
	bool is_in_vehicle; // Offset: 0x5f // Size: 0x01
	bool is_firing; // Offset: 0x60 // Size: 0x01
	bool is_holding; // Offset: 0x61 // Size: 0x01
	bool is_pose_acting; // Offset: 0x62 // Size: 0x01
	bool is_picking; // Offset: 0x63 // Size: 0x01
	int body_state; // Offset: 0x64 // Size: 0x04
	int location_state; // Offset: 0x68 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ProgressBarState
// Size: 0x08 // Inherited bytes: 0x00
struct FProgressBarState {
	// Fields
	int Type; // Offset: 0x00 // Size: 0x04
	float remain_time; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIPlayerBackpack
// Size: 0x10 // Inherited bytes: 0x00
struct FAIPlayerBackpack {
	// Fields
	struct TArray<struct FAIBackpackItem> backpack_item; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIBackpackItem
// Size: 0x0c // Inherited bytes: 0x00
struct FAIBackpackItem {
	// Fields
	int Category; // Offset: 0x00 // Size: 0x04
	int ID; // Offset: 0x04 // Size: 0x04
	int Count; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CameraState
// Size: 0x18 // Inherited bytes: 0x00
struct FCameraState {
	// Fields
	struct FAIStateXYZ Position; // Offset: 0x00 // Size: 0x0c
	struct FAIStateXYZ Rotation; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIWinnerState
// Size: 0x18 // Inherited bytes: 0x10
struct FAIWinnerState : FDiffStateInfoBase {
	// Fields
	int team_id; // Offset: 0x10 // Size: 0x04
	int player_id; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIEquipSpawnGroupDataBase
// Size: 0x28 // Inherited bytes: 0x00
struct FAIEquipSpawnGroupDataBase {
	// Fields
	float RightTime; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FAIEquipSpawnGroup> AIEquipSpawnGroupList; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FAIEquipSpawnItem> AIMustPickUpItemList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIEquipSpawnGroup
// Size: 0x10 // Inherited bytes: 0x00
struct FAIEquipSpawnGroup {
	// Fields
	struct TArray<struct FAIEquipSpawnItem> Item; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIAttrObserver
// Size: 0x08 // Inherited bytes: 0x00
struct FAIAttrObserver {
	// Fields
	enum class EAITriggerAttrType AttrType; // Offset: 0x00 // Size: 0x01
	enum class EAIAttrCompareType CompareType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	int ComparePercentValue; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AITriggerTupple
// Size: 0x38 // Inherited bytes: 0x00
struct FAITriggerTupple {
	// Fields
	int Probability; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FBlackboardKeySelector TriggerTarget; // Offset: 0x08 // Size: 0x28
	int TriggerSetValue; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WayPointEvents
// Size: 0x10 // Inherited bytes: 0x00
struct FWayPointEvents {
	// Fields
	struct TArray<struct FWayPointRandomEvent> EventsList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WayPointRandomEvent
// Size: 0x10 // Inherited bytes: 0x00
struct FWayPointRandomEvent {
	// Fields
	struct TArray<struct FWayPointEvent> RandomEvents; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WayPointEvent
// Size: 0x20 // Inherited bytes: 0x00
struct FWayPointEvent {
	// Fields
	struct FName LuaEventType; // Offset: 0x00 // Size: 0x08
	struct FName EventId; // Offset: 0x08 // Size: 0x08
	struct UAIWayPointEventBase* EventInfo; // Offset: 0x10 // Size: 0x08
	int Weight; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimalGroupRespawnConfig
// Size: 0x70 // Inherited bytes: 0x00
struct FAnimalGroupRespawnConfig {
	// Fields
	enum class EAnimalType AnimalType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FAnimalGroupRespawnNumProbability> AnimalGroupRespawnNumProbability; // Offset: 0x08 // Size: 0x10
	float NoBlueCircleRadius; // Offset: 0x18 // Size: 0x04
	float CheckPlayerRadius; // Offset: 0x1c // Size: 0x04
	float EndRespawnTime; // Offset: 0x20 // Size: 0x04
	int TryFindSpawnLocNum; // Offset: 0x24 // Size: 0x04
	struct TArray<struct FString> ValidTraceActorIncludeName; // Offset: 0x28 // Size: 0x10
	struct FVector AnimalGenerateOffset; // Offset: 0x38 // Size: 0x0c
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct UClass* AnimalCharacterClass; // Offset: 0x48 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimalGroupRespawnNumProbability
// Size: 0x08 // Inherited bytes: 0x00
struct FAnimalGroupRespawnNumProbability {
	// Fields
	uint32_t AnimalNum; // Offset: 0x00 // Size: 0x04
	int Weight; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIGroupData
// Size: 0x20 // Inherited bytes: 0x00
struct FAIGroupData {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirAttackOuterConfig
// Size: 0x60 // Inherited bytes: 0x00
struct FAirAttackOuterConfig {
	// Fields
	struct FVector MapOriginal; // Offset: 0x00 // Size: 0x0c
	float MapRadius; // Offset: 0x0c // Size: 0x04
	float FlightHeight; // Offset: 0x10 // Size: 0x04
	float SeaLevelHeight; // Offset: 0x14 // Size: 0x04
	float DelayTime; // Offset: 0x18 // Size: 0x04
	int WaveCount; // Offset: 0x1c // Size: 0x04
	enum class EAirAttackGenerateType DefaultAirAttackGenerateType; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct TArray<enum class EAirAttackGenerateType> AirAttackGenerateTypeList; // Offset: 0x28 // Size: 0x10
	int WaveInternal; // Offset: 0x38 // Size: 0x04
	float EscapeTime; // Offset: 0x3c // Size: 0x04
	float AttackLastingTime; // Offset: 0x40 // Size: 0x04
	float AttackAreaRadius; // Offset: 0x44 // Size: 0x04
	float OuterRadius; // Offset: 0x48 // Size: 0x04
	int TotalBombs; // Offset: 0x4c // Size: 0x04
	int BombsRadius; // Offset: 0x50 // Size: 0x04
	float BombBaseDamage; // Offset: 0x54 // Size: 0x04
	float BombMinDamage; // Offset: 0x58 // Size: 0x04
	float BroadcastClientDistance; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirAttackCfg
// Size: 0x18 // Inherited bytes: 0x00
struct FAirAttackCfg {
	// Fields
	float EscapeTime; // Offset: 0x00 // Size: 0x04
	float AttackLastingTime; // Offset: 0x04 // Size: 0x04
	float AttackAreaRadius; // Offset: 0x08 // Size: 0x04
	float OuterRadius; // Offset: 0x0c // Size: 0x04
	int TotalBombs; // Offset: 0x10 // Size: 0x04
	int BombsRadius; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirDropBoxGenerateWrapperItemData
// Size: 0x10 // Inherited bytes: 0x00
struct FAirDropBoxGenerateWrapperItemData {
	// Fields
	struct AActor* WrapperClass; // Offset: 0x00 // Size: 0x08
	int Count; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirDropResource
// Size: 0xc0 // Inherited bytes: 0x00
struct FAirDropResource {
	// Fields
	struct UStaticMesh* AirdropBoxMesh; // Offset: 0x00 // Size: 0x08
	struct UStaticMesh* AirDropParachuteMesh; // Offset: 0x08 // Size: 0x08
	struct UParticleSystem* AirdropSmoke; // Offset: 0x10 // Size: 0x08
	struct UParticleSystem* AirdropFlash; // Offset: 0x18 // Size: 0x08
	struct UStaticMesh* SoftAirdropBoxMesh; // Offset: 0x20 // Size: 0x28
	struct UStaticMesh* SoftAirdropParachuteMesh; // Offset: 0x48 // Size: 0x28
	struct UParticleSystem* SoftAirdropSmoke; // Offset: 0x70 // Size: 0x28
	struct UParticleSystem* SoftAirdropFlash; // Offset: 0x98 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.FlareGunAirDropRandomParams
// Size: 0x0c // Inherited bytes: 0x00
struct FFlareGunAirDropRandomParams {
	// Fields
	float SuperAirDropRandomRadius; // Offset: 0x00 // Size: 0x04
	float SuperAirDropRouteRandomRadiusMin; // Offset: 0x04 // Size: 0x04
	float SuperAirDropRouteRandomRadiusMax; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MapRealTimeInfo
// Size: 0x108 // Inherited bytes: 0x00
struct FMapRealTimeInfo {
	// Fields
	struct FVector2D MapCenterToPlayer; // Offset: 0x00 // Size: 0x08
	struct FVector MapCenterToBlueCircle; // Offset: 0x08 // Size: 0x0c
	struct FVector MapCenterToWhiteCircle; // Offset: 0x14 // Size: 0x0c
	struct FVector2D PlayerCoord; // Offset: 0x20 // Size: 0x08
	struct FVector2D SpectatedPlayerCoord; // Offset: 0x28 // Size: 0x08
	struct FVector2D WhiteCircleCoord; // Offset: 0x30 // Size: 0x08
	struct FVector2D BlueCircleCoord; // Offset: 0x38 // Size: 0x08
	float WhiteCircleRadius; // Offset: 0x40 // Size: 0x04
	float BlueCircleRadius; // Offset: 0x44 // Size: 0x04
	struct FVector2D LastDriveVehicleCoord; // Offset: 0x48 // Size: 0x08
	bool bCanPlayerSeeLastVehicle; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
	struct FAirplaneRouteData PlaneRouteData; // Offset: 0x58 // Size: 0x68
	struct FAirDropPathData AirDropPathData; // Offset: 0xc0 // Size: 0x48
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirDropPathData
// Size: 0x48 // Inherited bytes: 0x00
struct FAirDropPathData {
	// Fields
	int AirDropIndex; // Offset: 0x00 // Size: 0x04
	struct FVector2D StartLoc; // Offset: 0x04 // Size: 0x08
	struct FVector2D TargetLoc; // Offset: 0x0c // Size: 0x08
	float RouteWidgetRotateAngle; // Offset: 0x14 // Size: 0x04
	float RouteLengthInMap; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FVector2D> AirDropLocs; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FVector> AirDropLocs3D; // Offset: 0x30 // Size: 0x10
	bool bIsDrawAirDropFlightPath; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirplaneRouteData
// Size: 0x68 // Inherited bytes: 0x00
struct FAirplaneRouteData {
	// Fields
	float PlaneFlyingProcess; // Offset: 0x00 // Size: 0x04
	struct FVector2D CanJumpLocInMap; // Offset: 0x04 // Size: 0x08
	struct FVector2D ForceJumpLocInMap; // Offset: 0x0c // Size: 0x08
	float RouteWidgetRotateAngle; // Offset: 0x14 // Size: 0x04
	float RouteLengthInMap; // Offset: 0x18 // Size: 0x04
	struct FVector2D PlaneLocInMap; // Offset: 0x1c // Size: 0x08
	float PlaneRotation; // Offset: 0x24 // Size: 0x04
	struct TArray<struct FAirDropPathData> AirDropPaths; // Offset: 0x28 // Size: 0x10
	struct FVector2D CanJumpLocInMapForCamp; // Offset: 0x38 // Size: 0x08
	struct FVector2D ForceJumpLocInMapForCamp; // Offset: 0x40 // Size: 0x08
	float CampRouteLengthInMap; // Offset: 0x48 // Size: 0x04
	float CampRouteWidgetRotateAngle; // Offset: 0x4c // Size: 0x04
	struct FVector2D LastValidCanJumpLocInMap; // Offset: 0x50 // Size: 0x08
	struct FVector2D LastValidForceJumpLocInMap; // Offset: 0x58 // Size: 0x08
	float LastValidRouteWidgetRotateAngle; // Offset: 0x60 // Size: 0x04
	float LastValidRouteLengthInMap; // Offset: 0x64 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BackupEnterAirDropPlaneParams
// Size: 0x40 // Inherited bytes: 0x00
struct FBackupEnterAirDropPlaneParams {
	// Fields
	float FlyingHeight; // Offset: 0x00 // Size: 0x04
	float FlyingSpeed; // Offset: 0x04 // Size: 0x04
	float AirDropFallingSpeed; // Offset: 0x08 // Size: 0x04
	struct FVector DroppingLocationOffset; // Offset: 0x0c // Size: 0x0c
	struct TArray<struct FVector> PlaneSpawnOffset; // Offset: 0x18 // Size: 0x10
	struct TArray<float> DropTimeOffset; // Offset: 0x28 // Size: 0x10
	int MaxPlaneNum; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirDropOrder
// Size: 0xa0 // Inherited bytes: 0x00
struct FAirDropOrder {
	// Fields
	struct FVector AirDropPlaneSpawnPosition; // Offset: 0x00 // Size: 0x0c
	struct FVector AirDropPlaneFlyingDirection; // Offset: 0x0c // Size: 0x0c
	float AirDropPlaneFlyingSpeed; // Offset: 0x18 // Size: 0x04
	struct FVector AirDropStuffFallingPosition; // Offset: 0x1c // Size: 0x0c
	struct TArray<struct FVector> BoxFallingPositionArray; // Offset: 0x28 // Size: 0x10
	int AirDropIndex; // Offset: 0x38 // Size: 0x04
	bool bIsDrawAirDropFlightPath; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
	struct FVector AirDropPlaneEndPosition; // Offset: 0x40 // Size: 0x0c
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct TArray<struct FAirDropBoxParams> AirDropBoxParamsArray; // Offset: 0x50 // Size: 0x10
	struct UObject* AirdropBoxClass; // Offset: 0x60 // Size: 0x08
	float AirDropStuffFallingSpeed; // Offset: 0x68 // Size: 0x04
	bool bIsSpecialAirdrop; // Offset: 0x6c // Size: 0x01
	char pad_0x6D[0x3]; // Offset: 0x6d // Size: 0x03
	int DropType; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct FString DropCategory; // Offset: 0x78 // Size: 0x10
	uint32_t AirDropSummoner; // Offset: 0x88 // Size: 0x04
	int ZombieID; // Offset: 0x8c // Size: 0x04
	int FlowId; // Offset: 0x90 // Size: 0x04
	bool bIsEmptyAirdrop; // Offset: 0x94 // Size: 0x01
	char pad_0x95[0x3]; // Offset: 0x95 // Size: 0x03
	int DropID; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirDropBoxParams
// Size: 0x18 // Inherited bytes: 0x00
struct FAirDropBoxParams {
	// Fields
	struct FVector AirdropBoxFallingPosition; // Offset: 0x00 // Size: 0x0c
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct UObject* AirdropBoxClass; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirDropConfig
// Size: 0x60 // Inherited bytes: 0x00
struct FAirDropConfig {
	// Fields
	float AirDropTime; // Offset: 0x00 // Size: 0x04
	float RandomDroppingRange; // Offset: 0x04 // Size: 0x04
	float DoubleCircleRandomDroppingRange; // Offset: 0x08 // Size: 0x04
	float DropStuffChance; // Offset: 0x0c // Size: 0x04
	float NoLandscapeDelayTime; // Offset: 0x10 // Size: 0x04
	bool bCanMakeExtraAirdrop; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	struct TArray<struct FExtraAirDropRandomParams> ExtraAirDropRandParamsArray; // Offset: 0x18 // Size: 0x10
	float ExtraAirDropRandLowerLimit; // Offset: 0x28 // Size: 0x04
	float ExtraAirDropRandUpperLimit; // Offset: 0x2c // Size: 0x04
	bool ExtraAirDropUseEvenlyDistributed; // Offset: 0x30 // Size: 0x01
	bool bCanMakeContinuousAirdrop; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x2]; // Offset: 0x32 // Size: 0x02
	float ContinuousAirDropInterval; // Offset: 0x34 // Size: 0x04
	struct TArray<struct UClass*> AirDropBoxBlueprintList; // Offset: 0x38 // Size: 0x10
	bool bIsDrawAirDropFlightPath; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	float AirdropWhiteCircleProportionMin; // Offset: 0x4c // Size: 0x04
	float AirdropWhiteCircleProportionMax; // Offset: 0x50 // Size: 0x04
	float AirdropIntervalProportionMin; // Offset: 0x54 // Size: 0x04
	float AirdropIntervalProportionMax; // Offset: 0x58 // Size: 0x04
	bool bUseCustomStrategy; // Offset: 0x5c // Size: 0x01
	char pad_0x5D[0x3]; // Offset: 0x5d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.ExtraAirDropRandomParams
// Size: 0x08 // Inherited bytes: 0x00
struct FExtraAirDropRandomParams {
	// Fields
	int TotalDropCount; // Offset: 0x00 // Size: 0x04
	int TermWeight; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirDropPlaneParams
// Size: 0x1c // Inherited bytes: 0x00
struct FAirDropPlaneParams {
	// Fields
	float FlyingHeight; // Offset: 0x00 // Size: 0x04
	float FlyingSpeed; // Offset: 0x04 // Size: 0x04
	float AirDropFallingSpeed; // Offset: 0x08 // Size: 0x04
	bool bIsUseDebugLocation; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	struct FVector DebugDroppingLocation; // Offset: 0x10 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.FlyingParam
// Size: 0x14 // Inherited bytes: 0x00
struct FFlyingParam {
	// Fields
	float FlyingSpeed; // Offset: 0x00 // Size: 0x04
	struct FVector FlyingDirection; // Offset: 0x04 // Size: 0x0c
	float AirPlaneSpawnServerTime; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirDropUAVSpawnInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FAirDropUAVSpawnInfo {
	// Fields
	struct TArray<int> SpawnGroupIndexRandomArray; // Offset: 0x00 // Size: 0x10
	int SpawnGroupCount; // Offset: 0x10 // Size: 0x04
	float SpawnTime; // Offset: 0x14 // Size: 0x04
	bool bShowNoticeTips; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct FString NoticeTipsFunctionName; // Offset: 0x20 // Size: 0x10
	int NoticeTipsID; // Offset: 0x30 // Size: 0x04
	struct FVector NoticeCenterLoc; // Offset: 0x34 // Size: 0x0c
	float NoticeRadius; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirDropUAVSpawnGroupInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FAirDropUAVSpawnGroupInfo {
	// Fields
	struct TArray<struct FTransform> SpawnLocRandomArray; // Offset: 0x00 // Size: 0x10
	int SpawnCount; // Offset: 0x10 // Size: 0x04
	bool bShowUAVMapMarker; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	struct FVector UAVMapMarkerLoc; // Offset: 0x18 // Size: 0x0c
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirplaneData
// Size: 0x78 // Inherited bytes: 0x00
struct FAirplaneData {
	// Fields
	float PlaneHeight; // Offset: 0x00 // Size: 0x04
	float CanOpenParachuteHeight; // Offset: 0x04 // Size: 0x04
	float ForceOpenParachuteHeight; // Offset: 0x08 // Size: 0x04
	float CloseParachuteHeight; // Offset: 0x0c // Size: 0x04
	struct FVector DestinationCenter; // Offset: 0x10 // Size: 0x0c
	struct FVector PlaneVelocity; // Offset: 0x1c // Size: 0x0c
	struct FVector PlaneStartLoc; // Offset: 0x28 // Size: 0x0c
	struct FVector PlaneEndLoc; // Offset: 0x34 // Size: 0x0c
	struct FVector2D CanJumpLoc; // Offset: 0x40 // Size: 0x08
	struct FVector2D ForceJumpLoc; // Offset: 0x48 // Size: 0x08
	int TotalPlayerNum; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct TArray<struct APlayerController*> TotalPlayers; // Offset: 0x58 // Size: 0x10
	struct TArray<struct APlayerController*> CurPlayers; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CacheNearbyItemState
// Size: 0x20 // Inherited bytes: 0x00
struct FCacheNearbyItemState {
	// Fields
	struct TArray<struct FItemStateData> States; // Offset: 0x00 // Size: 0x10
	struct FVector Position; // Offset: 0x10 // Size: 0x0c
	bool IsDirty; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.TeamWayPointLink
// Size: 0x18 // Inherited bytes: 0x00
struct FTeamWayPointLink {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FWayPointLink> Links; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WayPointLink
// Size: 0x08 // Inherited bytes: 0x00
struct FWayPointLink {
	// Fields
	int NextPointID; // Offset: 0x00 // Size: 0x04
	int Weight; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIWayPointPathInfo
// Size: 0x60 // Inherited bytes: 0x00
struct FAIWayPointPathInfo {
	// Fields
	bool bEnable; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct AAIWayPointActor* StartWayPointActor; // Offset: 0x08 // Size: 0x08
	struct TArray<struct FName> LevelsToBeLoaded; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FTransform> ApexCampInfos; // Offset: 0x20 // Size: 0x10
	struct AActor* ApexCampActorClass; // Offset: 0x30 // Size: 0x08
	struct TArray<struct FTransform> BalloonInfos; // Offset: 0x38 // Size: 0x10
	struct AActor* BalloonActorClass; // Offset: 0x48 // Size: 0x08
	struct TArray<struct FActorPointWithWeight> PathOutlinePoints; // Offset: 0x50 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActorPointWithWeight
// Size: 0x10 // Inherited bytes: 0x00
struct FActorPointWithWeight {
	// Fields
	struct AActor* ActorPoint; // Offset: 0x00 // Size: 0x08
	float Weight; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SoundConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FSoundConfig {
	// Fields
	float TransDist; // Offset: 0x00 // Size: 0x04
	bool bSetBlackboardValue; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct TArray<struct FName> BlackboardNameList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SingleSplineData
// Size: 0x20 // Inherited bytes: 0x00
struct FSingleSplineData {
	// Fields
	struct FName SocketName; // Offset: 0x00 // Size: 0x08
	struct FVector StartLocationOffest; // Offset: 0x08 // Size: 0x0c
	float LengthPerPiece; // Offset: 0x14 // Size: 0x04
	float FinishedTime; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimalAIStateData
// Size: 0x1c // Inherited bytes: 0x00
struct FAnimalAIStateData {
	// Fields
	char pad_0x0[0x1c]; // Offset: 0x00 // Size: 0x1c
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimalAnimData
// Size: 0x30 // Inherited bytes: 0x00
struct FAnimalAnimData {
	// Fields
	enum class AnimalAnimListType PoseType; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UAnimationAsset* AnimSoftPtr; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimalMoveAnimSpeed
// Size: 0x08 // Inherited bytes: 0x00
struct FAnimalMoveAnimSpeed {
	// Fields
	enum class AnimalAnimListType PoseType; // Offset: 0x00 // Size: 0x04
	float Speed; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimalDeliverRatingConfig
// Size: 0x70 // Inherited bytes: 0x00
struct FAnimalDeliverRatingConfig {
	// Fields
	float RightRatingSection; // Offset: 0x00 // Size: 0x04
	uint32_t DeliverGroupNumPerWave; // Offset: 0x04 // Size: 0x04
	float DeliverBeginTime; // Offset: 0x08 // Size: 0x04
	float DeliveryWaveInterval; // Offset: 0x0c // Size: 0x04
	float DeliverEndTime; // Offset: 0x10 // Size: 0x04
	uint32_t FullFeedLimit; // Offset: 0x14 // Size: 0x04
	float DeliverFreqInterval; // Offset: 0x18 // Size: 0x04
	int DeliverNumEachFreq; // Offset: 0x1c // Size: 0x04
	struct TMap<int, int> DeliverCountByPlayerNum; // Offset: 0x20 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimalDeliverAreaLimit
// Size: 0x18 // Inherited bytes: 0x00
struct FAnimalDeliverAreaLimit {
	// Fields
	struct FVector TopLeft; // Offset: 0x00 // Size: 0x0c
	struct FVector BottomRight; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimationCurveData
// Size: 0x10 // Inherited bytes: 0x00
struct FAnimationCurveData {
	// Fields
	struct FString CurveName; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimationFloatCurveData
// Size: 0x18 // Inherited bytes: 0x10
struct FAnimationFloatCurveData : FAnimationCurveData {
	// Fields
	struct UCurveFloat* FloatCurve; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimLODInstance
// Size: 0x10 // Inherited bytes: 0x00
struct FAnimLODInstance {
	// Fields
	struct ASTExtraPlayerCharacter* Character; // Offset: 0x00 // Size: 0x08
	int LODLevel; // Offset: 0x08 // Size: 0x04
	float MaxDistanceFactor; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterComplexParamBase
// Size: 0x20 // Inherited bytes: 0x00
struct FCharacterComplexParamBase {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct UAnimParamsComponent* OwnerComponent; // Offset: 0x08 // Size: 0x08
	struct ASTExtraBaseCharacter* OwnerCharacter; // Offset: 0x10 // Size: 0x08
	char pad_0x18[0x8]; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimVehicleParam
// Size: 0x20 // Inherited bytes: 0x20
struct FAnimVehicleParam : FCharacterComplexParamBase {
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterVectorParam
// Size: 0x28 // Inherited bytes: 0x20
struct FCharacterVectorParam : FCharacterComplexParamBase {
	// Fields
	char pad_0x20[0x8]; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterParamMoveDirector
// Size: 0x28 // Inherited bytes: 0x28
struct FCharacterParamMoveDirector : FCharacterVectorParam {
};

// Object Name: ScriptStruct ShadowTrackerExtra.FloatNet
// Size: 0x04 // Inherited bytes: 0x00
struct FFloatNet {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.Float_NetQuantize8
// Size: 0x04 // Inherited bytes: 0x04
struct FFloat_NetQuantize8 : FFloatNet {
};

// Object Name: ScriptStruct ShadowTrackerExtra.PoolPreloadTableConfigItem
// Size: 0x18 // Inherited bytes: 0x00
struct FPoolPreloadTableConfigItem {
	// Fields
	int LoadPriority; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString CSVFilePath; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PoolPreloadAysncLoadParams
// Size: 0x01 // Inherited bytes: 0x00
struct FPoolPreloadAysncLoadParams {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.PoolPreloadClassItem
// Size: 0x30 // Inherited bytes: 0x00
struct FPoolPreloadClassItem {
	// Fields
	struct UClass* Object; // Offset: 0x00 // Size: 0x28
	bool IsSpawnToPool; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int PreloadNum; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PoolPreloadObjectItem
// Size: 0x30 // Inherited bytes: 0x00
struct FPoolPreloadObjectItem {
	// Fields
	struct UObject* Object; // Offset: 0x00 // Size: 0x28
	bool IsSpawnToPool; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int PreloadNum; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ArmsRaceWeaponGroupWeightConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FArmsRaceWeaponGroupWeightConfig {
	// Fields
	int GroupID; // Offset: 0x00 // Size: 0x04
	int Weight; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ArmsRaceWeaponConfig
// Size: 0x20 // Inherited bytes: 0x00
struct FArmsRaceWeaponConfig {
	// Fields
	int WeaponItemID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> AttachmentItemIDs_a; // Offset: 0x08 // Size: 0x10
	int BulletItemID; // Offset: 0x18 // Size: 0x04
	int BulletCount; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PropSkillNoiseRangeParam
// Size: 0x24 // Inherited bytes: 0x00
struct FPropSkillNoiseRangeParam {
	// Fields
	float GenProbility; // Offset: 0x00 // Size: 0x04
	int PropSkillLevel; // Offset: 0x04 // Size: 0x04
	float RangeLifeSpan; // Offset: 0x08 // Size: 0x04
	float MarkerLifeSpan; // Offset: 0x0c // Size: 0x04
	float RangeRadius; // Offset: 0x10 // Size: 0x04
	int HumanBuffID; // Offset: 0x14 // Size: 0x04
	int ZombieBuffID; // Offset: 0x18 // Size: 0x04
	int ZombieWeakSpeakBuffID; // Offset: 0x1c // Size: 0x04
	int MarkerIconID; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RangeCheckRetParam
// Size: 0x90 // Inherited bytes: 0x00
struct FRangeCheckRetParam {
	// Fields
	struct FHitResult HitResult; // Offset: 0x00 // Size: 0x88
	bool IsBlockedBySomething; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x7]; // Offset: 0x89 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.PropSkillSmokeDamageParam
// Size: 0x34 // Inherited bytes: 0x00
struct FPropSkillSmokeDamageParam {
	// Fields
	float GenProbility; // Offset: 0x00 // Size: 0x04
	int PropSkillLevel; // Offset: 0x04 // Size: 0x04
	float PlayerInnerDamageHealth; // Offset: 0x08 // Size: 0x04
	float PlayerOuterDamageHealth; // Offset: 0x0c // Size: 0x04
	float ZombieInnerDamageHealth; // Offset: 0x10 // Size: 0x04
	float ZombieOuterDamageHealth; // Offset: 0x14 // Size: 0x04
	float WallWeakenDamageRatio; // Offset: 0x18 // Size: 0x04
	float InnerDamageRadius; // Offset: 0x1c // Size: 0x04
	float OuterDamageRadius; // Offset: 0x20 // Size: 0x04
	float SomkeLifeSpan; // Offset: 0x24 // Size: 0x04
	float CheckPeriod; // Offset: 0x28 // Size: 0x04
	int HumanBuffID; // Offset: 0x2c // Size: 0x04
	int ZombieBuffID; // Offset: 0x30 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AutoAimInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FAutoAimInfo {
	// Fields
	struct AActor* AimClass; // Offset: 0x00 // Size: 0x08
	struct FVector AimOffset; // Offset: 0x08 // Size: 0x0c
	float MaxAimDistance; // Offset: 0x14 // Size: 0x04
	float MaxAimScreenDis; // Offset: 0x18 // Size: 0x04
	struct FVector2D ScreenAimRect; // Offset: 0x1c // Size: 0x08
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	float DefaultLockDelay; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FName LockSocketName; // Offset: 0x30 // Size: 0x08
	float DotValue; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAction_ApplyMatConfig
// Size: 0x50 // Inherited bytes: 0x18
struct FAvatarAction_ApplyMatConfig : FAvatarActionBase {
	// Fields
	struct FCustomMatConfig CacheMatConfig; // Offset: 0x18 // Size: 0x38
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomMatConfig
// Size: 0x38 // Inherited bytes: 0x00
struct FCustomMatConfig {
	// Fields
	struct FName SlotName; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FCustomMatScalar> ScalarConfig; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FCustomMatColor> ColorConfig; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FCustomMatTextrue> TextrueConfig; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomMatTextrue
// Size: 0x48 // Inherited bytes: 0x00
struct FCustomMatTextrue {
	// Fields
	struct FName ParamName; // Offset: 0x00 // Size: 0x08
	struct FName Tips; // Offset: 0x08 // Size: 0x08
	struct UTexture* Textrue; // Offset: 0x10 // Size: 0x28
	struct FString TextruePath; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomMatColor
// Size: 0x20 // Inherited bytes: 0x00
struct FCustomMatColor {
	// Fields
	struct FName ParamName; // Offset: 0x00 // Size: 0x08
	struct FName Tips; // Offset: 0x08 // Size: 0x08
	struct FLinearColor Color; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomMatScalar
// Size: 0x18 // Inherited bytes: 0x00
struct FCustomMatScalar {
	// Fields
	struct FName ParamName; // Offset: 0x00 // Size: 0x08
	struct FName Tips; // Offset: 0x08 // Size: 0x08
	float Scalar; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAction_ApplyDIYMatParam
// Size: 0x60 // Inherited bytes: 0x50
struct FAvatarAction_ApplyDIYMatParam : FAvatarAction_ApplyMatConfig {
	// Fields
	struct TArray<int> MatID; // Offset: 0x50 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAction_ApplyDIYMirroParam
// Size: 0x60 // Inherited bytes: 0x50
struct FAvatarAction_ApplyDIYMirroParam : FAvatarAction_ApplyMatConfig {
	// Fields
	struct TArray<int> MirroParam; // Offset: 0x50 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAction_ApplyDIYPattern
// Size: 0x30 // Inherited bytes: 0x18
struct FAvatarAction_ApplyDIYPattern : FAvatarActionBase {
	// Fields
	struct TArray<struct FDIYMergedTexData> DIYTextureParam; // Offset: 0x18 // Size: 0x10
	int UVIndex; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAction_ApplyItemHandle
// Size: 0x30 // Inherited bytes: 0x18
struct FAvatarAction_ApplyItemHandle : FAvatarActionBase {
	// Fields
	struct FItemDefineID ItemDefineID; // Offset: 0x18 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAction_ApplyMaterial
// Size: 0x48 // Inherited bytes: 0x18
struct FAvatarAction_ApplyMaterial : FAvatarActionBase {
	// Fields
	int MaterialBPID; // Offset: 0x14 // Size: 0x04
	struct FMaterialGroup CacheMatGroup; // Offset: 0x18 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.MaterialGroup
// Size: 0x30 // Inherited bytes: 0x00
struct FMaterialGroup {
	// Fields
	struct TArray<struct FMaterialAsset> MatList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct UMaterialInterface*> NewMatObjectList; // Offset: 0x10 // Size: 0x10
	struct TArray<struct UMaterialInterface*> OriMatObjectList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MaterialAsset
// Size: 0x68 // Inherited bytes: 0x00
struct FMaterialAsset {
	// Fields
	struct FName SlotName; // Offset: 0x00 // Size: 0x08
	struct UMaterialInterface* MatInst; // Offset: 0x08 // Size: 0x28
	struct UMaterialInterface* MatBase; // Offset: 0x30 // Size: 0x28
	struct UMaterialInterface* MatBaseObject; // Offset: 0x58 // Size: 0x08
	bool bDynamicMat; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x7]; // Offset: 0x61 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAction_ApplyMatParamModify
// Size: 0xa8 // Inherited bytes: 0x18
struct FAvatarAction_ApplyMatParamModify : FAvatarActionBase {
	// Fields
	char pad_0x18[0x90]; // Offset: 0x18 // Size: 0x90
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAction_ApplyMesh
// Size: 0xf0 // Inherited bytes: 0x18
struct FAvatarAction_ApplyMesh : FAvatarActionBase {
	// Fields
	int MeshBPID; // Offset: 0x14 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FMeshAsset CachedMeshAsset; // Offset: 0x20 // Size: 0xd0
};

// Object Name: ScriptStruct ShadowTrackerExtra.MeshAsset
// Size: 0xd0 // Inherited bytes: 0x00
struct FMeshAsset {
	// Fields
	struct FTransform Transform; // Offset: 0x00 // Size: 0x30
	struct USkeletalMesh* SkeletalMesh; // Offset: 0x30 // Size: 0x28
	struct UStaticMesh* StaticMesh; // Offset: 0x58 // Size: 0x28
	struct FName AttachSocket; // Offset: 0x80 // Size: 0x08
	enum class EMeshAssetType meshType; // Offset: 0x88 // Size: 0x01
	bool bKeepRelative; // Offset: 0x89 // Size: 0x01
	char pad_0x8A[0x6]; // Offset: 0x8a // Size: 0x06
	struct UAnimInstance* animBP; // Offset: 0x90 // Size: 0x08
	struct UClass* animBPClass; // Offset: 0x98 // Size: 0x28
	bool bAnimInit; // Offset: 0xc0 // Size: 0x01
	bool bUpdateTransform; // Offset: 0xc1 // Size: 0x01
	char pad_0xC2[0xe]; // Offset: 0xc2 // Size: 0x0e
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAction_ApplyParticle
// Size: 0x50 // Inherited bytes: 0x18
struct FAvatarAction_ApplyParticle : FAvatarActionBase {
	// Fields
	int ParticleBPID; // Offset: 0x14 // Size: 0x04
	struct FName ParticleName; // Offset: 0x18 // Size: 0x08
	struct FParticleGroup ParticleGroup; // Offset: 0x20 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAction_ApplyWeaponHandle
// Size: 0x150 // Inherited bytes: 0x30
struct FAvatarAction_ApplyWeaponHandle : FAvatarAction_ApplyItemHandle {
	// Fields
	struct FMeshAsset CachedMeshAsset; // Offset: 0x30 // Size: 0xd0
	struct TArray<struct FMaterialAsset> CachedMatAsset; // Offset: 0x100 // Size: 0x10
	struct UParticleSystem* CachedLightAsset; // Offset: 0x110 // Size: 0x28
	struct TArray<struct FSoftObjectPath> CachedAnimAsset; // Offset: 0x138 // Size: 0x10
	char pad_0x148[0x8]; // Offset: 0x148 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.MatParamModifyCfg
// Size: 0x78 // Inherited bytes: 0x00
struct FMatParamModifyCfg {
	// Fields
	struct FSoftObjectPath CurveAsset; // Offset: 0x00 // Size: 0x18
	struct FName ParamName; // Offset: 0x18 // Size: 0x08
	struct FName ParticleTag; // Offset: 0x20 // Size: 0x08
	struct TArray<int> RelatedSlots; // Offset: 0x28 // Size: 0x10
	struct UCurveFloat* CachedCurve; // Offset: 0x38 // Size: 0x08
	struct FName ReplaceMatSlotName; // Offset: 0x40 // Size: 0x08
	struct FSoftObjectPath NormalMat; // Offset: 0x48 // Size: 0x18
	struct FSoftObjectPath ReplaceMat; // Offset: 0x60 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.MaterialConfig
// Size: 0x68 // Inherited bytes: 0x00
struct FMaterialConfig {
	// Fields
	struct FName MatSlotName; // Offset: 0x00 // Size: 0x08
	struct UMaterialInterface* Mat; // Offset: 0x08 // Size: 0x28
	struct UMaterialInterface* MatBase; // Offset: 0x30 // Size: 0x28
	struct TArray<struct FMaterialAsset> additionalMats; // Offset: 0x58 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MeshGroup
// Size: 0x30 // Inherited bytes: 0x00
struct FMeshGroup {
	// Fields
	struct TArray<struct FMeshAsset> MeshAssetList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct UObject*> MeshObjectList; // Offset: 0x10 // Size: 0x10
	struct TArray<struct UMeshComponent*> MeshCompList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.LoadParticleAssetRequest
// Size: 0x58 // Inherited bytes: 0x00
struct FLoadParticleAssetRequest {
	// Fields
	struct TArray<struct FParticleAsset> ParticleAsset; // Offset: 0x00 // Size: 0x10
	struct FParticleGroup ParticleGroup; // Offset: 0x10 // Size: 0x30
	struct UMeshComponent* Outer; // Offset: 0x40 // Size: 0x08
	DelegateProperty Callback; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.LoadMeshAssetRequest
// Size: 0x58 // Inherited bytes: 0x00
struct FLoadMeshAssetRequest {
	// Fields
	struct TArray<struct FMeshAsset> MeshAsset; // Offset: 0x00 // Size: 0x10
	struct FMeshGroup MeshGroup; // Offset: 0x10 // Size: 0x30
	struct UMeshComponent* Outer; // Offset: 0x40 // Size: 0x08
	DelegateProperty Callback; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CaptureMeshDesc
// Size: 0x30 // Inherited bytes: 0x00
struct FCaptureMeshDesc {
	// Fields
	struct FName SocketName; // Offset: 0x00 // Size: 0x08
	struct UMeshComponent* MeshComp; // Offset: 0x08 // Size: 0x08
	enum class EMeshType meshType; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct UAnimInstance* AnimClass; // Offset: 0x18 // Size: 0x08
	struct TArray<struct FCaptureMeshBase> AttachMeshDesc; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CaptureMeshBase
// Size: 0x18 // Inherited bytes: 0x00
struct FCaptureMeshBase {
	// Fields
	struct FName SocketName; // Offset: 0x00 // Size: 0x08
	struct UMeshComponent* MeshComp; // Offset: 0x08 // Size: 0x08
	struct UAnimInstance* AnimClass; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponAnimAsset
// Size: 0x80 // Inherited bytes: 0x00
struct FWeaponAnimAsset {
	// Fields
	struct FName WeaponName; // Offset: 0x00 // Size: 0x08
	struct UAnimSequenceBase* AnimPose; // Offset: 0x08 // Size: 0x28
	struct UAnimSequenceBase* AnimAdd; // Offset: 0x30 // Size: 0x28
	struct UAnimSequenceBase* WeaponAnimBP; // Offset: 0x58 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.DIYUVInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FDIYUVInfo {
	// Fields
	float UVCorrdX; // Offset: 0x00 // Size: 0x04
	float UVCorrdY; // Offset: 0x04 // Size: 0x04
	float UVSizeX; // Offset: 0x08 // Size: 0x04
	float UVSizeY; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DIYMatParam
// Size: 0x20 // Inherited bytes: 0x00
struct FDIYMatParam {
	// Fields
	struct FString MatTexPath; // Offset: 0x00 // Size: 0x10
	struct FLinearColor MatTexColor; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DIYData
// Size: 0x50 // Inherited bytes: 0x00
struct FDIYData {
	// Fields
	struct UTexture2D* Texture; // Offset: 0x00 // Size: 0x08
	struct FLinearColor Color; // Offset: 0x08 // Size: 0x10
	struct FVector2D Scale; // Offset: 0x18 // Size: 0x08
	struct FVector2D Offset; // Offset: 0x20 // Size: 0x08
	float Rotation; // Offset: 0x28 // Size: 0x04
	enum class EDIYProjectDirection Direction; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
	struct FLinearColor UVClip; // Offset: 0x30 // Size: 0x10
	struct FLinearColor UVInfo; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarExceptStruct
// Size: 0xa0 // Inherited bytes: 0x00
struct FAvatarExceptStruct {
	// Fields
	char pad_0x0[0xa0]; // Offset: 0x00 // Size: 0xa0
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarExceptCount
// Size: 0x50 // Inherited bytes: 0x00
struct FAvatarExceptCount {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.CreateAvatarHandleListAsyncRequest
// Size: 0x38 // Inherited bytes: 0x00
struct FCreateAvatarHandleListAsyncRequest {
	// Fields
	struct TArray<struct FItemDefineID> DefineIDList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> PathList; // Offset: 0x10 // Size: 0x10
	struct UObject* Outer; // Offset: 0x20 // Size: 0x08
	DelegateProperty Callback; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CreateAvatarHandleAsyncRequest
// Size: 0x40 // Inherited bytes: 0x00
struct FCreateAvatarHandleAsyncRequest {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x18
	struct UObject* Outer; // Offset: 0x18 // Size: 0x08
	struct FString Path; // Offset: 0x20 // Size: 0x10
	DelegateProperty Callback; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponReuseCfgDataRow
// Size: 0x50 // Inherited bytes: 0x00
struct FWeaponReuseCfgDataRow {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.ModTableByMode
// Size: 0x50 // Inherited bytes: 0x00
struct FModTableByMode {
	// Fields
	struct FString UpWeaponTableName; // Offset: 0x00 // Size: 0x10
	struct FString UpWeaponAttachmentTableName; // Offset: 0x10 // Size: 0x10
	struct FString UpBulletTableName; // Offset: 0x20 // Size: 0x10
	struct FString ChipTableName; // Offset: 0x30 // Size: 0x10
	struct FString ChipSupportTableName; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponAttachmentsDataRow
// Size: 0x88 // Inherited bytes: 0x00
struct FWeaponAttachmentsDataRow {
	// Fields
	int WeaponId; // Offset: 0x00 // Size: 0x04
	int BulletID; // Offset: 0x04 // Size: 0x04
	int ProposeBulletNum; // Offset: 0x08 // Size: 0x04
	int AIMinAttackDist; // Offset: 0x0c // Size: 0x04
	int AIMaxAttackDist; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<int> MuzzleIDList; // Offset: 0x18 // Size: 0x10
	struct TArray<int> UpperIDList; // Offset: 0x28 // Size: 0x10
	struct TArray<int> StockIDList; // Offset: 0x38 // Size: 0x10
	struct TArray<int> MagazineIDList; // Offset: 0x48 // Size: 0x10
	struct TArray<int> LowerIDList; // Offset: 0x58 // Size: 0x10
	struct TArray<int> UpperSideIDList; // Offset: 0x68 // Size: 0x10
	struct TArray<int> CoreIDList; // Offset: 0x78 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SupportUpBullets
// Size: 0x10 // Inherited bytes: 0x00
struct FSupportUpBullets {
	// Fields
	struct TArray<struct FSupportUpBullet> SupportUpBulletList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SupportUpBullet
// Size: 0x08 // Inherited bytes: 0x00
struct FSupportUpBullet {
	// Fields
	int UpBulletID; // Offset: 0x00 // Size: 0x04
	int DefaultPriority; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ChipSupportItem
// Size: 0x58 // Inherited bytes: 0x00
struct FChipSupportItem {
	// Fields
	int ChipSubType; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TMap<int, bool> SupportItemDic; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.ChipDataRow
// Size: 0x18 // Inherited bytes: 0x00
struct FChipDataRow {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FAttrModifyData> AttrModifyList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AttrModifyData
// Size: 0x18 // Inherited bytes: 0x00
struct FAttrModifyData {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.ChipSupportDataRow
// Size: 0x20 // Inherited bytes: 0x00
struct FChipSupportDataRow {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> SupportChipSupTypeList; // Offset: 0x08 // Size: 0x10
	int SupportChipNum; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.UpBulletTableDataRow
// Size: 0x30 // Inherited bytes: 0x00
struct FUpBulletTableDataRow {
	// Fields
	int MiltiBulletID; // Offset: 0x00 // Size: 0x04
	int ParentBulletID; // Offset: 0x04 // Size: 0x04
	float BulletImpactDamagePerc; // Offset: 0x08 // Size: 0x04
	int BulletImpactDamageAddVal; // Offset: 0x0c // Size: 0x04
	float BulletMomentumPerc; // Offset: 0x10 // Size: 0x04
	int BulletMomentumAddVal; // Offset: 0x14 // Size: 0x04
	int DefaultPriority; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<int> BulletHitBuffIdList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.UpWeaponAttachmentDataRow
// Size: 0x18 // Inherited bytes: 0x00
struct FUpWeaponAttachmentDataRow {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.UpWeaponDataRow
// Size: 0x18 // Inherited bytes: 0x00
struct FUpWeaponDataRow {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponAvatarAttrRow
// Size: 0x88 // Inherited bytes: 0x00
struct FWeaponAvatarAttrRow {
	// Fields
	char pad_0x0[0x88]; // Offset: 0x00 // Size: 0x88
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarAnimOverrideData
// Size: 0x18 // Inherited bytes: 0x00
struct FAvatarAnimOverrideData {
	// Fields
	enum class EAnimLayerType Layer; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UUAECharAnimListCompBase* AnimListCompClass; // Offset: 0x08 // Size: 0x08
	struct UUAECharAnimListCompBase* AnimListCompInstance; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarPostOperation
// Size: 0x03 // Inherited bytes: 0x00
struct FAvatarPostOperation {
	// Fields
	enum class EAvatarSlotType SlotID; // Offset: 0x00 // Size: 0x01
	enum class EPostOperationType operationWhenReplaced; // Offset: 0x01 // Size: 0x01
	enum class EPostOperationType operationWhenHidden; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarPendantConfig
// Size: 0x60 // Inherited bytes: 0x00
struct FAvatarPendantConfig {
	// Fields
	struct FString ConfigName; // Offset: 0x00 // Size: 0x10
	struct FTransform SocketRelativeTransform; // Offset: 0x10 // Size: 0x30
	struct FVector AngularLimitsMin; // Offset: 0x40 // Size: 0x0c
	struct FVector AngularLimitsMax; // Offset: 0x4c // Size: 0x0c
	char pad_0x58[0x8]; // Offset: 0x58 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.BodyAttachmentConfig
// Size: 0x38 // Inherited bytes: 0x00
struct FBodyAttachmentConfig {
	// Fields
	struct FText AttachmentID; // Offset: 0x00 // Size: 0x18
	struct TArray<struct FBodyAttachmentAttrModify> BodyAttachmentAttrModifiers; // Offset: 0x18 // Size: 0x10
	struct FString BodyDurabilityIndexName; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.BodyAttachmentAttrModify
// Size: 0x18 // Inherited bytes: 0x00
struct FBodyAttachmentAttrModify {
	// Fields
	struct FString ModifyAttr; // Offset: 0x00 // Size: 0x10
	enum class EAttrOperator Op; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	float ModifyValue; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarItemData
// Size: 0xd8 // Inherited bytes: 0xb8
struct FAvatarItemData : FBattleItemData {
	// Fields
	struct USkeletalMesh* SkeletalMesh; // Offset: 0xb8 // Size: 0x08
	struct UStaticMesh* StaticMesh; // Offset: 0xc0 // Size: 0x08
	struct UMaterialInstance* MatInst; // Offset: 0xc8 // Size: 0x08
	int meshType; // Offset: 0xd0 // Size: 0x04
	char pad_0xD4[0x4]; // Offset: 0xd4 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarPendantConfig_SpecialParam
// Size: 0x40 // Inherited bytes: 0x00
struct FAvatarPendantConfig_SpecialParam {
	// Fields
	struct FName SpecialUseExplanation; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
	struct FTransform AdditionalTransform2SocketRelativeTransform; // Offset: 0x10 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.SlotToMatPattern
// Size: 0x78 // Inherited bytes: 0x00
struct FSlotToMatPattern {
	// Fields
	enum class EAvatarSlotType SlotID; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UTexture* PatternTexture_2; // Offset: 0x08 // Size: 0x28
	float IconScale_2; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct UTexture* PatternTexture_3; // Offset: 0x38 // Size: 0x28
	float IconScale_3; // Offset: 0x60 // Size: 0x04
	struct FLinearColor IconOffset; // Offset: 0x64 // Size: 0x10
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SlotToMatColor
// Size: 0x48 // Inherited bytes: 0x00
struct FSlotToMatColor {
	// Fields
	enum class EAvatarSlotType SlotID; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FLinearColor> MaskColor; // Offset: 0x08 // Size: 0x10
	float GrayScale; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct UTexture* MaskGrayTexture; // Offset: 0x20 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemAvatarData
// Size: 0x58 // Inherited bytes: 0x00
struct FItemAvatarData {
	// Fields
	struct FName SlotID; // Offset: 0x00 // Size: 0x08
	struct UMaterialInterface* MatInstance; // Offset: 0x08 // Size: 0x28
	struct UMaterialInterface* LobbyMatInstance; // Offset: 0x30 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.GenderMultiAnimConfig
// Size: 0x38 // Inherited bytes: 0x00
struct FGenderMultiAnimConfig {
	// Fields
	struct FName GenderStr; // Offset: 0x00 // Size: 0x08
	struct ACharacter* Character; // Offset: 0x08 // Size: 0x08
	struct UAnimationAsset* Anim; // Offset: 0x10 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.LobbyGenderAnimData
// Size: 0x50 // Inherited bytes: 0x00
struct FLobbyGenderAnimData {
	// Fields
	struct UAnimationAsset* BoyAnim; // Offset: 0x00 // Size: 0x28
	struct UAnimationAsset* GirlAnim; // Offset: 0x28 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.GrenadeParticleSystemAsset
// Size: 0x40 // Inherited bytes: 0x00
struct FGrenadeParticleSystemAsset {
	// Fields
	struct UParticleSystem* GrenadeParticleSystem; // Offset: 0x00 // Size: 0x28
	struct FName Name; // Offset: 0x28 // Size: 0x08
	struct FString Key; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.GrenadeSoundAsset
// Size: 0x40 // Inherited bytes: 0x00
struct FGrenadeSoundAsset {
	// Fields
	struct UAkAudioEvent* GrenadeSound; // Offset: 0x00 // Size: 0x28
	struct FName Name; // Offset: 0x28 // Size: 0x08
	struct FString Key; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlaneEffectData
// Size: 0x70 // Inherited bytes: 0x00
struct FPlaneEffectData {
	// Fields
	struct FTransform Transform; // Offset: 0x00 // Size: 0x30
	struct UParticleSystem* ParticleSystem; // Offset: 0x30 // Size: 0x28
	struct FName AttachSocket; // Offset: 0x58 // Size: 0x08
	struct TArray<struct FParticleSysParam> InstanceParameters; // Offset: 0x60 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlaneAvatarData
// Size: 0x30 // Inherited bytes: 0x00
struct FPlaneAvatarData {
	// Fields
	struct FName SlotID; // Offset: 0x00 // Size: 0x08
	struct UMaterialInterface* MatInstance; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.TouchInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FTouchInfo {
	// Fields
	char pad_0x0[0x14]; // Offset: 0x00 // Size: 0x14
};

// Object Name: ScriptStruct ShadowTrackerExtra.ResultItemData
// Size: 0x08 // Inherited bytes: 0x00
struct FResultItemData {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int Durability; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponAttachItemUnit
// Size: 0x20 // Inherited bytes: 0x00
struct FWeaponAttachItemUnit {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x18
	enum class EWeaponAttachmentSocketType socket; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.EquipmentBrief
// Size: 0x0c // Inherited bytes: 0x00
struct FEquipmentBrief {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int ItemSubType; // Offset: 0x04 // Size: 0x04
	int BPID; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CreateBattleItemHandleListAsyncRequest
// Size: 0x38 // Inherited bytes: 0x00
struct FCreateBattleItemHandleListAsyncRequest {
	// Fields
	struct TArray<struct FItemDefineID> DefineIDList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> PathList; // Offset: 0x10 // Size: 0x10
	struct UObject* Outer; // Offset: 0x20 // Size: 0x08
	DelegateProperty Callback; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CreateBattleItemHandleAsyncRequest
// Size: 0x40 // Inherited bytes: 0x00
struct FCreateBattleItemHandleAsyncRequest {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x18
	struct UObject* Outer; // Offset: 0x18 // Size: 0x08
	struct FString Path; // Offset: 0x20 // Size: 0x10
	DelegateProperty Callback; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemDefineSortingInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FItemDefineSortingInfo {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x18
	bool bUsed; // Offset: 0x18 // Size: 0x01
	bool bMainHand; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x2]; // Offset: 0x1a // Size: 0x02
	int Count; // Offset: 0x1c // Size: 0x04
	char pad_0x20[0x8]; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.PickupItemDataSortingInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FPickupItemDataSortingInfo {
	// Fields
	struct FPickUpItemData Data; // Offset: 0x00 // Size: 0x38
	bool bHighPriority; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.BattleSearchBoxSortingInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FBattleSearchBoxSortingInfo {
	// Fields
	struct FSearchedPickUpItemResult pickUpItemResult; // Offset: 0x00 // Size: 0x40
	bool bHighPriority; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x3]; // Offset: 0x41 // Size: 0x03
	int pickCount; // Offset: 0x44 // Size: 0x04
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.BattleSearchItemSortingInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FBattleSearchItemSortingInfo {
	// Fields
	struct FSearchedPickUpItemResult SearchItemResult; // Offset: 0x00 // Size: 0x40
	bool bHighPriority; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x3]; // Offset: 0x41 // Size: 0x03
	int pickCount; // Offset: 0x44 // Size: 0x04
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.BattleItemSortingInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FBattleItemSortingInfo {
	// Fields
	struct FItemDefineID ItemDefineID; // Offset: 0x00 // Size: 0x18
	bool bHighPriority; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleAvatarProperty
// Size: 0xc0 // Inherited bytes: 0x00
struct FVehicleAvatarProperty {
	// Fields
	struct USkeletalMesh* TPPMesh; // Offset: 0x00 // Size: 0x28
	struct USkeletalMesh* FPPMesh; // Offset: 0x28 // Size: 0x28
	struct TArray<struct FWheelSetup> WheelSetups; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FWheelHubSetup> WheelHubSetups; // Offset: 0x60 // Size: 0x10
	struct TArray<struct FSTExtraVehicleWheelHP> WheelsHP; // Offset: 0x70 // Size: 0x10
	struct FVehicleTransmissionData GearSetup; // Offset: 0x80 // Size: 0x30
	struct FVector CenterOfMassOffset; // Offset: 0xb0 // Size: 0x0c
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.STExtraVehicleWheelHP
// Size: 0x20 // Inherited bytes: 0x00
struct FSTExtraVehicleWheelHP {
	// Fields
	float HPMax; // Offset: 0x00 // Size: 0x04
	bool DontDamageWheels; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct FName BoneName; // Offset: 0x08 // Size: 0x08
	struct TArray<struct FName> AssociationBoneName; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WheelHubSetup
// Size: 0x20 // Inherited bytes: 0x00
struct FWheelHubSetup {
	// Fields
	struct UVehicleWheel* WheelClass; // Offset: 0x00 // Size: 0x08
	struct FName TireBoneName; // Offset: 0x08 // Size: 0x08
	struct TArray<struct FName> AssociationBoneName; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleAttachmentAvatarConfig
// Size: 0x38 // Inherited bytes: 0x00
struct FVehicleAttachmentAvatarConfig {
	// Fields
	struct FName AttachmentTag; // Offset: 0x00 // Size: 0x08
	struct FName MeshTag; // Offset: 0x08 // Size: 0x08
	struct USkeletalMesh* SkeletalMesh; // Offset: 0x10 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehDecalCfg
// Size: 0x78 // Inherited bytes: 0x00
struct FVehDecalCfg {
	// Fields
	bool Enable; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float NeedParkTime; // Offset: 0x04 // Size: 0x04
	struct UMaterialInterface* DecalMaterial; // Offset: 0x08 // Size: 0x28
	struct UTexture* DecalTexture; // Offset: 0x30 // Size: 0x28
	struct FVector2D UVScale; // Offset: 0x58 // Size: 0x08
	struct FVector2D UVOffset; // Offset: 0x60 // Size: 0x08
	struct FVector DecalSize; // Offset: 0x68 // Size: 0x0c
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleMatParamModifyCfg
// Size: 0x88 // Inherited bytes: 0x00
struct FVehicleMatParamModifyCfg {
	// Fields
	struct FName ParamName; // Offset: 0x00 // Size: 0x08
	enum class EVehicleModifyMatParamType ParamType; // Offset: 0x08 // Size: 0x01
	enum class EVehicleModifyMatParamUsage Usage; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
	struct FRuntimeFloatCurve ParamModifyCurve; // Offset: 0x10 // Size: 0x78
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehCharAnimDataWrapper
// Size: 0x18 // Inherited bytes: 0x00
struct FVehCharAnimDataWrapper {
	// Fields
	struct FName AnimCompTag; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FVehCharAnimData> VehCharAnimDataList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponPendantMap
// Size: 0x18 // Inherited bytes: 0x00
struct FWeaponPendantMap {
	// Fields
	int WeaponId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FWeaponPendantSocket> PendantInfoList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponPendantSocket
// Size: 0x70 // Inherited bytes: 0x00
struct FWeaponPendantSocket {
	// Fields
	enum class EWeaponPendantSocketType PendantSocketType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int PendantIndex; // Offset: 0x04 // Size: 0x04
	bool IsOpenConstraint; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct FAvatarPendantConfig AnimConstraint; // Offset: 0x10 // Size: 0x60
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponIdleAnimCfg
// Size: 0x50 // Inherited bytes: 0x00
struct FWeaponIdleAnimCfg {
	// Fields
	struct UAnimMontage* PawnAnim; // Offset: 0x00 // Size: 0x28
	struct UAnimMontage* WeaponAnim; // Offset: 0x28 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponAttachmentConfig
// Size: 0x228 // Inherited bytes: 0x00
struct FWeaponAttachmentConfig {
	// Fields
	struct FText AttachmentName; // Offset: 0x00 // Size: 0x18
	enum class EWeaponAttachmentSocketType AttachmentSocketType; // Offset: 0x18 // Size: 0x01
	enum class EWeaponSubSlotType SubSlot; // Offset: 0x19 // Size: 0x01
	enum class EOpticalSightType SightType; // Offset: 0x1a // Size: 0x01
	bool IsExtendMaxBulletNumInOneClip; // Offset: 0x1b // Size: 0x01
	bool IsSilencer; // Offset: 0x1c // Size: 0x01
	bool IsFireSuppressor; // Offset: 0x1d // Size: 0x01
	bool IsCompensator; // Offset: 0x1e // Size: 0x01
	char pad_0x1F[0x1]; // Offset: 0x1f // Size: 0x01
	struct TArray<struct FWeaponAttachmentAttrModify> WeaponAttachmentAttrModifys; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FWeaponAttachmentDesc> WeaponAttachmentDescs; // Offset: 0x30 // Size: 0x10
	struct TMap<int, struct FName> socketTypeToName; // Offset: 0x40 // Size: 0x50
	struct FWeaponMeshCfg MeshPackage; // Offset: 0x90 // Size: 0x150
	struct TArray<struct FWeaponMeshCfg> ExtMeshList; // Offset: 0x1e0 // Size: 0x10
	struct TArray<struct FReplacedAttament> replacementWeapon; // Offset: 0x1f0 // Size: 0x10
	struct TArray<struct UAnimationAsset*> AttachmentAnimList; // Offset: 0x200 // Size: 0x10
	struct FItemDefineID ParentID; // Offset: 0x210 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.ReplacedAttament
// Size: 0x188 // Inherited bytes: 0x00
struct FReplacedAttament {
	// Fields
	struct TArray<struct FItemDefineID> targetWeaponIDList; // Offset: 0x00 // Size: 0x10
	struct FWeaponMeshCfg replacedAttachmentCfg; // Offset: 0x10 // Size: 0x150
	struct TArray<struct FWeaponMeshCfg> ExtReplacedAttachmentCfgList; // Offset: 0x160 // Size: 0x10
	int replacedAttachmentMatIndex; // Offset: 0x170 // Size: 0x04
	char pad_0x174[0x4]; // Offset: 0x174 // Size: 0x04
	struct TArray<struct UAnimationAsset*> replacedAttachmentAnimList; // Offset: 0x178 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponAttachmentDesc
// Size: 0x30 // Inherited bytes: 0x00
struct FWeaponAttachmentDesc {
	// Fields
	struct FText Desc; // Offset: 0x00 // Size: 0x18
	struct FText DescValue; // Offset: 0x18 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponAttachmentAttrModify
// Size: 0x40 // Inherited bytes: 0x00
struct FWeaponAttachmentAttrModify {
	// Fields
	struct FString ModifyAttr; // Offset: 0x00 // Size: 0x10
	enum class EAttrOperator Op; // Offset: 0x10 // Size: 0x01
	bool bModifyResource; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x2]; // Offset: 0x12 // Size: 0x02
	float ModifyValue; // Offset: 0x14 // Size: 0x04
	struct UObject* ModifyResValue; // Offset: 0x18 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponKillEffectCfg
// Size: 0x08 // Inherited bytes: 0x00
struct FWeaponKillEffectCfg {
	// Fields
	struct APlayerTombBox* DeadInventoryBoxTemplate; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.WingmanAvatarData
// Size: 0x30 // Inherited bytes: 0x00
struct FWingmanAvatarData {
	// Fields
	struct FName SlotID; // Offset: 0x00 // Size: 0x08
	struct UMaterialInterface* MatInstance; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvengerItem
// Size: 0x08 // Inherited bytes: 0x00
struct FAvengerItem {
	// Fields
	int ItemTableID; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DollyZoomParam
// Size: 0x0c // Inherited bytes: 0x00
struct FDollyZoomParam {
	// Fields
	float FOV; // Offset: 0x00 // Size: 0x04
	float Scale; // Offset: 0x04 // Size: 0x04
	float Offset; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CorpsToPlayerKeyInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FCorpsToPlayerKeyInfo {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	int CorpsID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CorpsDetailInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FCorpsDetailInfo {
	// Fields
	struct FCorpsBaseInfo CorpBaseInfo; // Offset: 0x00 // Size: 0x20
	int CorpsLiveNumber; // Offset: 0x20 // Size: 0x04
	int CorpsTotalNumber; // Offset: 0x24 // Size: 0x04
	int TotalKillNumber; // Offset: 0x28 // Size: 0x04
	int OnOutGameRealTimeRank; // Offset: 0x2c // Size: 0x04
	float MaxSurvivalTime; // Offset: 0x30 // Size: 0x04
	float TotalDamage; // Offset: 0x34 // Size: 0x04
	bool bIsOutGame; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.CorpsBaseInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FCorpsBaseInfo {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString CorpsName; // Offset: 0x08 // Size: 0x10
	int CorpsHeadIconID; // Offset: 0x18 // Size: 0x04
	int CorpsGrad; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CorpsKillInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FCorpsKillInfo {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	int KilledNum; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.GroupTeams
// Size: 0x10 // Inherited bytes: 0x00
struct FGroupTeams {
	// Fields
	struct TArray<int> Teams; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.GroupPlayers
// Size: 0x10 // Inherited bytes: 0x00
struct FGroupPlayers {
	// Fields
	struct TArray<uint32_t> Players; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIControllerList
// Size: 0x10 // Inherited bytes: 0x00
struct FAIControllerList {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIPawnPoolItem
// Size: 0x10 // Inherited bytes: 0x00
struct FAIPawnPoolItem {
	// Fields
	struct ASTExtraBaseCharacter* PlayerPawn; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.DSTickRateOptimize
// Size: 0x10 // Inherited bytes: 0x00
struct FDSTickRateOptimize {
	// Fields
	float TickFrequency; // Offset: 0x00 // Size: 0x04
	float NetConsiderFrequency; // Offset: 0x04 // Size: 0x04
	float NetUpdateFrequency; // Offset: 0x08 // Size: 0x04
	float MinNetUpdateFrequency; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemAttach
// Size: 0x18 // Inherited bytes: 0x00
struct FItemAttach {
	// Fields
	int BaseItemID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FAddItemInfo> AttachItemList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AddItemInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FAddItemInfo {
	// Fields
	int AddItemID; // Offset: 0x00 // Size: 0x04
	int AddItemNum; // Offset: 0x04 // Size: 0x04
	bool TotalNumLimit; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayerStartObjets
// Size: 0x30 // Inherited bytes: 0x00
struct FPlayerStartObjets {
	// Fields
	struct UObject* Objects; // Offset: 0x00 // Size: 0x08
	struct FVector SpawnLoc; // Offset: 0x08 // Size: 0x0c
	struct FRotator SpawnRot; // Offset: 0x14 // Size: 0x0c
	struct FVector Scale; // Offset: 0x20 // Size: 0x0c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeviceSmartBearerOverrideConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FDeviceSmartBearerOverrideConfig {
	// Fields
	struct FString DeviceName; // Offset: 0x00 // Size: 0x10
	struct FSmartBearerConfig SmartBearerConfig; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SmartBearerConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FSmartBearerConfig {
	// Fields
	float MaxBearerNum; // Offset: 0x00 // Size: 0x04
	int NormalSkinShowNum; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShadowOptConfig
// Size: 0x34 // Inherited bytes: 0x00
struct FShadowOptConfig {
	// Fields
	bool Enable; // Offset: 0x00 // Size: 0x01
	char DeviceLevel; // Offset: 0x01 // Size: 0x01
	char BearerType; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	float LOD0_ScreenSize; // Offset: 0x04 // Size: 0x04
	int LOD0_MaxNum; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	float LOD1_ScreenSize; // Offset: 0x10 // Size: 0x04
	int LOD1_MaxNum; // Offset: 0x14 // Size: 0x04
	char pad_0x18[0x4]; // Offset: 0x18 // Size: 0x04
	float LOD2_ScreenSize; // Offset: 0x1c // Size: 0x04
	int LOD2_MaxNum; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x10]; // Offset: 0x24 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MeshOptConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FMeshOptConfig {
	// Fields
	char DeviceLevel; // Offset: 0x00 // Size: 0x01
	char LODBias; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float StaticMeshOverrideScreenSize; // Offset: 0x04 // Size: 0x04
	float SkeletMeshOverrideScreenSize; // Offset: 0x08 // Size: 0x04
	bool bUseAvatarMerge; // Offset: 0x0c // Size: 0x01
	char AvatarMergeStripTopLOD; // Offset: 0x0d // Size: 0x01
	char pad_0xE[0x2]; // Offset: 0x0e // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.TextureLODBiasOverrideInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FTextureLODBiasOverrideInfo {
	// Fields
	enum class TextureGroup Group; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<int> OverrideLODBias; // Offset: 0x08 // Size: 0x10
	char pad_0x18[0x10]; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.BitMsg
// Size: 0x28 // Inherited bytes: 0x00
struct FBitMsg {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.BitMsgDelta
// Size: 0x28 // Inherited bytes: 0x00
struct FBitMsgDelta {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.ScanOwnerInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FScanOwnerInfo {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	float ScanRadius; // Offset: 0x0c // Size: 0x04
	int TimeLeft; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ScanTargetRepInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FScanTargetRepInfo {
	// Fields
	struct TWeakObjectPtr<struct ASTExtraPlayerState> TargetState; // Offset: 0x00 // Size: 0x08
	int MarkInstID; // Offset: 0x08 // Size: 0x04
	struct FVector MarkCircleCenter; // Offset: 0x0c // Size: 0x0c
	float MarkCircleRadius; // Offset: 0x18 // Size: 0x04
	float RotationAngle; // Offset: 0x1c // Size: 0x04
	struct FString PlayerKey; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.HomeMapBaseRegion
// Size: 0x48 // Inherited bytes: 0x00
struct FHomeMapBaseRegion {
	// Fields
	struct FHomeBaseRegion BaseRegionLeft; // Offset: 0x00 // Size: 0x24
	struct FHomeBaseRegion BaseRegionRight; // Offset: 0x24 // Size: 0x24
};

// Object Name: ScriptStruct ShadowTrackerExtra.HomeBaseRegion
// Size: 0x24 // Inherited bytes: 0x00
struct FHomeBaseRegion {
	// Fields
	int RegionID; // Offset: 0x00 // Size: 0x04
	struct FVector2D P1; // Offset: 0x04 // Size: 0x08
	struct FVector2D P2; // Offset: 0x0c // Size: 0x08
	struct FVector2D P3; // Offset: 0x14 // Size: 0x08
	struct FVector2D P4; // Offset: 0x1c // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AddWeaponAnimInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FAddWeaponAnimInfo {
	// Fields
	int BaseItemID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FLobbyCharacterWeaponAnimData> addAnimData; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTTaskMobOnceMemory
// Size: 0x04 // Inherited bytes: 0x00
struct FBTTaskMobOnceMemory {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShootingAimConfigContainer
// Size: 0x50 // Inherited bytes: 0x00
struct FShootingAimConfigContainer {
	// Fields
	struct TMap<float, struct FShootingAimConfig> AimConfig; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShootingAimConfig
// Size: 0x14 // Inherited bytes: 0x00
struct FShootingAimConfig {
	// Fields
	enum class EAIWeaponShootType WeaponShotType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float AimDeviationScale; // Offset: 0x04 // Size: 0x04
	float MinAimDeviationScale; // Offset: 0x08 // Size: 0x04
	struct FVector2D RandomShootFreqRange; // Offset: 0x0c // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.DifficultyShootingConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FDifficultyShootingConfig {
	// Fields
	enum class EAIWeaponShootType WeaponShotType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float DeviationScale; // Offset: 0x04 // Size: 0x04
	struct FVector2D RandomShootFreqRange; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTAICheckMaxDistanceFromSpawnPointMemory
// Size: 0x2c // Inherited bytes: 0x00
struct FBTAICheckMaxDistanceFromSpawnPointMemory {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
	struct FVector SpawnLocation; // Offset: 0x04 // Size: 0x0c
	struct FBox MaxMoveDistanceVolumeBox; // Offset: 0x10 // Size: 0x1c
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherToRange
// Size: 0x10 // Inherited bytes: 0x00
struct FWeatherToRange {
	// Fields
	struct TArray<struct FWeaponTypeToRange> Ranges; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponTypeToRange
// Size: 0x08 // Inherited bytes: 0x00
struct FWeaponTypeToRange {
	// Fields
	enum class EWeaponTypeNew WeaponType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Range; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponType2Range
// Size: 0x0c // Inherited bytes: 0x00
struct FWeaponType2Range {
	// Fields
	enum class EWeaponTypeNew WeaponType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Range; // Offset: 0x04 // Size: 0x04
	float NightRange; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponTypeToRangeWithPawnState
// Size: 0x58 // Inherited bytes: 0x00
struct FWeaponTypeToRangeWithPawnState {
	// Fields
	enum class EWeaponTypeNew WeaponType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TMap<enum class EPawnState, struct FShapeRangeParam> StateRange; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShapeRangeParam
// Size: 0x0c // Inherited bytes: 0x00
struct FShapeRangeParam {
	// Fields
	float CircleR; // Offset: 0x00 // Size: 0x04
	float SectorR; // Offset: 0x04 // Size: 0x04
	float SectorDegree; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SightFanInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FSightFanInfo {
	// Fields
	float Radius; // Offset: 0x00 // Size: 0x04
	float Angle; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InTroubleTeleportConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FInTroubleTeleportConfig {
	// Fields
	float SrcCheckRadius; // Offset: 0x00 // Size: 0x04
	float DstCheckRadius; // Offset: 0x04 // Size: 0x04
	uint32_t TryFindDstLocNum; // Offset: 0x08 // Size: 0x04
	bool OnlyTeleportToLand; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeliverControlRatingConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FDeliverControlRatingConfig {
	// Fields
	int Rating; // Offset: 0x00 // Size: 0x04
	float InnerRadius1; // Offset: 0x04 // Size: 0x04
	float InnerRadius2; // Offset: 0x08 // Size: 0x04
	float OuterRadius; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AIDistantJudgeNoftify
// Size: 0x30 // Inherited bytes: 0x00
struct FAIDistantJudgeNoftify {
	// Fields
	float RightValue; // Offset: 0x00 // Size: 0x04
	int SetBBValue; // Offset: 0x04 // Size: 0x04
	struct FBlackboardKeySelector NotifyBlackBoardKey; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTFlyingChooseEnemyMemory
// Size: 0x0c // Inherited bytes: 0x00
struct FBTFlyingChooseEnemyMemory {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTMobAddHpMemory
// Size: 0x01 // Inherited bytes: 0x00
struct FBTMobAddHpMemory {
	// Fields
	bool HPBuffAdded; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTMobCheckLoseTargetMemory
// Size: 0x08 // Inherited bytes: 0x00
struct FBTMobCheckLoseTargetMemory {
	// Fields
	bool LastLoseTarget; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float LoseTargetElapsedTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTMobHearingMemory
// Size: 0x28 // Inherited bytes: 0x00
struct FBTMobHearingMemory {
	// Fields
	struct FNoiseInfo LastChosenNoiseInfo; // Offset: 0x00 // Size: 0x24
	float LockNoiseElapsedTime; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.NoiseInfo
// Size: 0x24 // Inherited bytes: 0x00
struct FNoiseInfo {
	// Fields
	enum class ESTAINoiseType NoiseType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct TWeakObjectPtr<struct AActor> Instigator; // Offset: 0x04 // Size: 0x08
	struct FVector NoiseLocation; // Offset: 0x0c // Size: 0x0c
	float LoudnessAtStart; // Offset: 0x18 // Size: 0x04
	float LoudnessHeard; // Offset: 0x1c // Size: 0x04
	float HeardTime; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTMobMoveBlockTimerMemory
// Size: 0x04 // Inherited bytes: 0x00
struct FBTMobMoveBlockTimerMemory {
	// Fields
	float BlockElapsedTime; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTAISenseGrenadeMemory
// Size: 0x260 // Inherited bytes: 0x00
struct FBTAISenseGrenadeMemory {
	// Fields
	struct TMap<enum class EAISenseGrenadeType, float> GrenadeSensedDistance; // Offset: 0x00 // Size: 0x50
	struct TMap<enum class EAISenseGrenadeType, float> GrenadeSensedDistanceSquared; // Offset: 0x50 // Size: 0x50
	float fMaxSenseDistance; // Offset: 0xa0 // Size: 0x04
	char pad_0xA4[0x11c]; // Offset: 0xa4 // Size: 0x11c
	struct TMap<enum class EAISenseGrenadeType, struct FAISenseGrenadeBBKeyInfo> GrenadeBBKeyInfo; // Offset: 0x1c0 // Size: 0x50
	struct TMap<struct UObject*, enum class EAISenseGrenadeType> GrenadeClassesMap; // Offset: 0x210 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.AISenseGrenadeBBKeyInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FAISenseGrenadeBBKeyInfo {
	// Fields
	enum class EAISenseGrenadeType GrenadeType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FBlackboardKeySelector BBKeyGrenadeActor; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.BPAISenseGrenadeDistanceConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FBPAISenseGrenadeDistanceConfig {
	// Fields
	enum class EAISenseGrenadeType GrenadeType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float GrenadeSenseDistance; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AISenseGrenadeClassConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FAISenseGrenadeClassConfig {
	// Fields
	struct TArray<struct UObject*> IncludeClassArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ObjectTypeAvoidanceWeights
// Size: 0x68 // Inherited bytes: 0x00
struct FObjectTypeAvoidanceWeights {
	// Fields
	int DefaultAvoidanceResponseWeight; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TMap<struct AActor*, int> ActorFilterResponseMap; // Offset: 0x08 // Size: 0x50
	struct TArray<struct AActor*> IgnoreActorFilterList; // Offset: 0x58 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvoidanceBoxTraceSettings
// Size: 0x28 // Inherited bytes: 0x00
struct FAvoidanceBoxTraceSettings {
	// Fields
	float TraceForwardOffset; // Offset: 0x00 // Size: 0x04
	float TraceLength; // Offset: 0x04 // Size: 0x04
	struct FVector TraceHalfSize; // Offset: 0x08 // Size: 0x0c
	struct FRotator TraceOrientation; // Offset: 0x14 // Size: 0x0c
	float TopSpeedTraceSizeMultiplier; // Offset: 0x20 // Size: 0x04
	float TopSpeed; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.TaskAddItem
// Size: 0x08 // Inherited bytes: 0x00
struct FTaskAddItem {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int ItemCount; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DifficultyTimeConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FDifficultyTimeConfig {
	// Fields
	float WaitTime; // Offset: 0x00 // Size: 0x04
	float RandomDeviation; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTTaskCrowdMoveMemory
// Size: 0x78 // Inherited bytes: 0x00
struct FBTTaskCrowdMoveMemory {
	// Fields
	char pad_0x0[0x78]; // Offset: 0x00 // Size: 0x78
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTTaskForceIdleMemory
// Size: 0x0c // Inherited bytes: 0x00
struct FBTTaskForceIdleMemory {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTTaskEventsOfWayPointMemory
// Size: 0x30 // Inherited bytes: 0x00
struct FBTTaskEventsOfWayPointMemory {
	// Fields
	struct TArray<struct FWayPointEvent> CacheWayPointEvents; // Offset: 0x00 // Size: 0x10
	struct FWayPointEvent CurrentExecutingEvent; // Offset: 0x10 // Size: 0x20
};

// Object Name: ScriptStruct ShadowTrackerExtra.GeneralRandLocationRetryRule
// Size: 0x0c // Inherited bytes: 0x00
struct FGeneralRandLocationRetryRule {
	// Fields
	float AngleRangeMin; // Offset: 0x00 // Size: 0x04
	float AngleRangeMax; // Offset: 0x04 // Size: 0x04
	float ScanStep; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTLaunchMoveSpeedCurve
// Size: 0x10 // Inherited bytes: 0x00
struct FBTLaunchMoveSpeedCurve {
	// Fields
	float DistanceThreshold; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UCurveFloat* LaunchSpeedCurve; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTTaskMobExplodeMemory
// Size: 0x01 // Inherited bytes: 0x00
struct FBTTaskMobExplodeMemory {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.MobRandLocationRetryRule
// Size: 0x0c // Inherited bytes: 0x00
struct FMobRandLocationRetryRule {
	// Fields
	float AngleRangeMin; // Offset: 0x00 // Size: 0x04
	float AngleRangeMax; // Offset: 0x04 // Size: 0x04
	int RetryTimes; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTTaskGetNearDeathCharNearbyMemory
// Size: 0x0c // Inherited bytes: 0x00
struct FBTTaskGetNearDeathCharNearbyMemory {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTTaskMobGetRandomAttackTargetInRadius
// Size: 0x08 // Inherited bytes: 0x00
struct FBTTaskMobGetRandomAttackTargetInRadius {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTTaskGetVehicleNearbyMemory
// Size: 0x0c // Inherited bytes: 0x00
struct FBTTaskGetVehicleNearbyMemory {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTTaskMoveAroundMemory
// Size: 0xa0 // Inherited bytes: 0x00
struct FBTTaskMoveAroundMemory {
	// Fields
	char pad_0x0[0x68]; // Offset: 0x00 // Size: 0x68
	struct AActor* FocusActor; // Offset: 0x68 // Size: 0x08
	char pad_0x70[0x30]; // Offset: 0x70 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTTaskRotateToTargetMemory
// Size: 0x08 // Inherited bytes: 0x00
struct FBTTaskRotateToTargetMemory {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AITaskNodeThrowGrenadeTargetLocRandomableConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FAITaskNodeThrowGrenadeTargetLocRandomableConfig {
	// Fields
	float RandomRange; // Offset: 0x00 // Size: 0x04
	int RandomTimes; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTAICharacterCastSkillMemory
// Size: 0x34 // Inherited bytes: 0x00
struct FBTAICharacterCastSkillMemory {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
	struct FVector FocusLocation; // Offset: 0x04 // Size: 0x0c
	struct TWeakObjectPtr<struct AActor> FocusActor; // Offset: 0x10 // Size: 0x08
	struct FVector TossTargetLoc; // Offset: 0x18 // Size: 0x0c
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FVector GrenadeThrowStartLoc; // Offset: 0x28 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.FindBuildingRatingConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FFindBuildingRatingConfig {
	// Fields
	int Rating; // Offset: 0x00 // Size: 0x04
	float SearchRadius; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BTTaskParachuteJumpBaseMemory
// Size: 0x0c // Inherited bytes: 0x00
struct FBTTaskParachuteJumpBaseMemory {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.BoardSideBlurry
// Size: 0x20 // Inherited bytes: 0x00
struct FBoardSideBlurry {
	// Fields
	float Up; // Offset: 0x00 // Size: 0x04
	float Down; // Offset: 0x04 // Size: 0x04
	float Left; // Offset: 0x08 // Size: 0x04
	float Right; // Offset: 0x0c // Size: 0x04
	float LeftUp; // Offset: 0x10 // Size: 0x04
	float LeftDown; // Offset: 0x14 // Size: 0x04
	float RightUp; // Offset: 0x18 // Size: 0x04
	float RightDown; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BoardPos
// Size: 0x08 // Inherited bytes: 0x00
struct FBoardPos {
	// Fields
	int X; // Offset: 0x00 // Size: 0x04
	int Y; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CameraSettings
// Size: 0x14 // Inherited bytes: 0x00
struct FCameraSettings {
	// Fields
	float TargetArmLength; // Offset: 0x00 // Size: 0x04
	float LagSpeed; // Offset: 0x04 // Size: 0x04
	struct FVector SocketOffset; // Offset: 0x08 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionPawnClassConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FInfectionPawnClassConfig {
	// Fields
	enum class ECharacterSubType InfectionType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct APawn* InfectionPawn; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterThrowData
// Size: 0x70 // Inherited bytes: 0x00
struct FCharacterThrowData {
	// Fields
	struct FVector RelativeLocation_Stand; // Offset: 0x00 // Size: 0x0c
	struct FVector RelativeLocation_Crouch; // Offset: 0x0c // Size: 0x0c
	struct FVector RelativeLocation_Prone; // Offset: 0x18 // Size: 0x0c
	struct FVector RelativeLocation_Vehicle; // Offset: 0x24 // Size: 0x0c
	struct FThrowableAnim StandAnim; // Offset: 0x30 // Size: 0x10
	struct FThrowableAnim CrouchAnim; // Offset: 0x40 // Size: 0x10
	struct FThrowableAnim ProneAnim; // Offset: 0x50 // Size: 0x10
	struct FThrowableAnim VehicleAnim; // Offset: 0x60 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ThrowableAnim
// Size: 0x10 // Inherited bytes: 0x00
struct FThrowableAnim {
	// Fields
	struct UAnimMontage* Prepare; // Offset: 0x00 // Size: 0x08
	struct UAnimMontage* Release; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.QuickChatIDAndAudio
// Size: 0x0c // Inherited bytes: 0x00
struct FQuickChatIDAndAudio {
	// Fields
	int chatTextID; // Offset: 0x00 // Size: 0x04
	int RealTextID; // Offset: 0x04 // Size: 0x04
	int AlternateTextID; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.QuickGroundFlag
// Size: 0x14 // Inherited bytes: 0x00
struct FQuickGroundFlag {
	// Fields
	int Index; // Offset: 0x00 // Size: 0x04
	int flagID; // Offset: 0x04 // Size: 0x04
	struct FVector hitPosition; // Offset: 0x08 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.QuickChatFlag
// Size: 0x28 // Inherited bytes: 0x00
struct FQuickChatFlag {
	// Fields
	enum class ChatFlagType Type; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<int> chatIDList; // Offset: 0x08 // Size: 0x10
	int AlternateChatID; // Offset: 0x18 // Size: 0x04
	int FlagIndex; // Offset: 0x1c // Size: 0x04
	int traceDist; // Offset: 0x20 // Size: 0x04
	float minDist; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.QuickChatOption
// Size: 0x10 // Inherited bytes: 0x00
struct FQuickChatOption {
	// Fields
	int chatTextID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UAkAudioEvent* audioEvent1; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.IngameInvitedNode
// Size: 0x20 // Inherited bytes: 0x00
struct FIngameInvitedNode {
	// Fields
	struct FString PlayerName; // Offset: 0x00 // Size: 0x10
	struct FString gid; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.IngameFriendChat
// Size: 0x10 // Inherited bytes: 0x00
struct FIngameFriendChat {
	// Fields
	struct TArray<struct FIngameFriendChatMsg> ChatList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.IngameFriendChatMsg
// Size: 0x30 // Inherited bytes: 0x00
struct FIngameFriendChatMsg {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct FString Content; // Offset: 0x10 // Size: 0x10
	bool IsSelf; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	int MsgType; // Offset: 0x24 // Size: 0x04
	bool bReply; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.InGameFilterChatMsg
// Size: 0x18 // Inherited bytes: 0x00
struct FInGameFilterChatMsg {
	// Fields
	struct FString PlayerName; // Offset: 0x00 // Size: 0x10
	bool isMe; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.InGameChatMsg
// Size: 0x60 // Inherited bytes: 0x00
struct FInGameChatMsg {
	// Fields
	struct FString PlayerName; // Offset: 0x00 // Size: 0x10
	uint32_t playerIdentifier; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString msgContent; // Offset: 0x18 // Size: 0x10
	int MsgID; // Offset: 0x28 // Size: 0x04
	int audioID; // Offset: 0x2c // Size: 0x04
	int ItemId; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString PlayerKeyString; // Offset: 0x38 // Size: 0x10
	bool hitValid; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	struct FVector hitPosition; // Offset: 0x4c // Size: 0x0c
	int itemIDOnGround; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.OverlapCullingData
// Size: 0x08 // Inherited bytes: 0x00
struct FOverlapCullingData {
	// Fields
	float UpperCullPlane; // Offset: 0x00 // Size: 0x04
	float DownerCullPlane; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CirCleCfg
// Size: 0xb0 // Inherited bytes: 0x00
struct FCirCleCfg {
	// Fields
	int CircleID; // Offset: 0x00 // Size: 0x04
	float DelayTime; // Offset: 0x04 // Size: 0x04
	float RadiusWhenDestoryMap; // Offset: 0x08 // Size: 0x04
	float SafeZoneAppeartime; // Offset: 0x0c // Size: 0x04
	bool bIsCircleWarningUseFilter; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct TArray<float> BlueCirclePreWarning; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FCircleWarningConfig> BlueCirclePreWarningWithFilter; // Offset: 0x28 // Size: 0x10
	float LastTime; // Offset: 0x38 // Size: 0x04
	float Pain; // Offset: 0x3c // Size: 0x04
	bool bUseCustomBluePoint; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x3]; // Offset: 0x41 // Size: 0x03
	struct FVector2D bluepoint; // Offset: 0x44 // Size: 0x08
	float blueradius; // Offset: 0x4c // Size: 0x04
	bool bUseCustomWhitePoint; // Offset: 0x50 // Size: 0x01
	bool bUseCustomWhiteStrategy; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0x6]; // Offset: 0x52 // Size: 0x06
	struct TArray<struct FVector> Whitepoints; // Offset: 0x58 // Size: 0x10
	float whiteradius; // Offset: 0x68 // Size: 0x04
	float Alpha; // Offset: 0x6c // Size: 0x04
	bool bUseContainActor; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x3]; // Offset: 0x71 // Size: 0x03
	float DestinyChance; // Offset: 0x74 // Size: 0x04
	bool bActiveScreenSize; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x3]; // Offset: 0x79 // Size: 0x03
	float ScreenSizeFactor; // Offset: 0x7c // Size: 0x04
	float ExtraRadius; // Offset: 0x80 // Size: 0x04
	bool bEnableDamageMagnifier; // Offset: 0x84 // Size: 0x01
	char pad_0x85[0x3]; // Offset: 0x85 // Size: 0x03
	float DamageMagnifierRange; // Offset: 0x88 // Size: 0x04
	float DamageMagnifier; // Offset: 0x8c // Size: 0x04
	struct UCurveFloat* DamageMagnifierCurve; // Offset: 0x90 // Size: 0x08
	struct TArray<struct FVector> AvoidPoints; // Offset: 0x98 // Size: 0x10
	float EdgeDistance; // Offset: 0xa8 // Size: 0x04
	bool bUseAvoidPoints; // Offset: 0xac // Size: 0x01
	char pad_0xAD[0x3]; // Offset: 0xad // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.CircleWarningConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FCircleWarningConfig {
	// Fields
	float WarningTime; // Offset: 0x00 // Size: 0x04
	enum class InCircleState WarningState; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleSysColor
// Size: 0x50 // Inherited bytes: 0x00
struct FParticleSysColor {
	// Fields
	struct TMap<struct FString, struct FLinearColor> colorMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.HandleParticleSystem
// Size: 0x0c // Inherited bytes: 0x00
struct FHandleParticleSystem {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	int Type; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HandleMesh
// Size: 0x0c // Inherited bytes: 0x00
struct FHandleMesh {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	int Type; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ImageOriginal
// Size: 0x1c // Inherited bytes: 0x00
struct FImageOriginal {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FLinearColor OriginalColir; // Offset: 0x08 // Size: 0x10
	int Type; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SightMaterialModify
// Size: 0x20 // Inherited bytes: 0x00
struct FSightMaterialModify {
	// Fields
	struct TArray<struct FSightMaterialModifyItem> AimMaterialModify; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FSightMaterialModifyItem> NoAimMaterialModify; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SightMaterialModifyItem
// Size: 0x20 // Inherited bytes: 0x00
struct FSightMaterialModifyItem {
	// Fields
	int MaterialID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FName ParameterName; // Offset: 0x08 // Size: 0x08
	struct FLinearColor Value; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponFireResetData
// Size: 0x0c // Inherited bytes: 0x00
struct FWeaponFireResetData {
	// Fields
	enum class EFireResetType ResetType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float ResetTime; // Offset: 0x04 // Size: 0x04
	char pad_0x8[0x4]; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponCrossHairHitPerformData
// Size: 0x40 // Inherited bytes: 0x18
struct FWeaponCrossHairHitPerformData : FWeaponCrossHairPerformData {
	// Fields
	float DefaultShowHitTime; // Offset: 0x14 // Size: 0x04
	float DamageRangeMin; // Offset: 0x18 // Size: 0x04
	float DamageRangeMax; // Offset: 0x1c // Size: 0x04
	float DamageScaleSpreadMin; // Offset: 0x20 // Size: 0x04
	float DamageScaleSpreadMax; // Offset: 0x24 // Size: 0x04
	float CurDamageScaleMin; // Offset: 0x28 // Size: 0x04
	float CurDamageScaleMax; // Offset: 0x2c // Size: 0x04
	float CurDamageScaleDecreaseSpeed; // Offset: 0x30 // Size: 0x04
	float ShowHitCrosshairLeftTime; // Offset: 0x34 // Size: 0x04
	float CurDamageScale; // Offset: 0x38 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DrawCircleItemData
// Size: 0x28 // Inherited bytes: 0x00
struct FDrawCircleItemData {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.DrawBoxItemData
// Size: 0x30 // Inherited bytes: 0x00
struct FDrawBoxItemData {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x00 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.CrowdAgent
// Size: 0x318 // Inherited bytes: 0x00
struct FCrowdAgent {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
	struct AActor* actorPtr; // Offset: 0x18 // Size: 0x08
	char pad_0x20[0x2f8]; // Offset: 0x20 // Size: 0x2f8
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomCndWrappperIns
// Size: 0x10 // Inherited bytes: 0x00
struct FCustomCndWrappperIns {
	// Fields
	struct UCustomCndWrapper* Wrapper; // Offset: 0x00 // Size: 0x08
	int CndWrapperId; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomCndIns
// Size: 0x08 // Inherited bytes: 0x00
struct FCustomCndIns {
	// Fields
	struct UCustomCondition* Cnd; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ChildPendingActiveObject
// Size: 0x78 // Inherited bytes: 0x00
struct FChildPendingActiveObject {
	// Fields
	struct UClass* ChildWidgetClass; // Offset: 0x00 // Size: 0x28
	struct FAnchorData Anchor; // Offset: 0x28 // Size: 0x28
	bool bAutoSize; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x3]; // Offset: 0x51 // Size: 0x03
	int ZOrder; // Offset: 0x54 // Size: 0x04
	struct FString MountName; // Offset: 0x58 // Size: 0x10
	struct FString MountOuterName; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ChildPendingActiveWidget
// Size: 0x80 // Inherited bytes: 0x00
struct FChildPendingActiveWidget {
	// Fields
	struct UClass* ChildWidgetClass; // Offset: 0x00 // Size: 0x28
	struct FString WidgetTreeNameToAssign; // Offset: 0x28 // Size: 0x10
	struct FAnchorData Anchor; // Offset: 0x38 // Size: 0x28
	bool bAutoSize; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x3]; // Offset: 0x61 // Size: 0x03
	int ZOrder; // Offset: 0x64 // Size: 0x04
	struct TArray<struct FString> ModeUIList; // Offset: 0x68 // Size: 0x10
	bool bDefaultCreate; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x7]; // Offset: 0x79 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.DDMCData
// Size: 0x20 // Inherited bytes: 0x00
struct FDDMCData {
	// Fields
	struct TArray<struct FSoftObjectPath> Stuffs; // Offset: 0x00 // Size: 0x10
	int HPPercentageRangeMin; // Offset: 0x10 // Size: 0x04
	int HPPercentageRangeMax; // Offset: 0x14 // Size: 0x04
	bool bUseRPC; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.DamageNumberTeamColorInfo
// Size: 0x2c // Inherited bytes: 0x00
struct FDamageNumberTeamColorInfo {
	// Fields
	char pad_0x0[0x2c]; // Offset: 0x00 // Size: 0x2c
};

// Object Name: ScriptStruct ShadowTrackerExtra.DamageNumberConfig
// Size: 0x80 // Inherited bytes: 0x00
struct FDamageNumberConfig {
	// Fields
	float UpScaleFactor; // Offset: 0x00 // Size: 0x04
	int ScaleRandom; // Offset: 0x04 // Size: 0x04
	float ScaleRandOffset; // Offset: 0x08 // Size: 0x04
	struct FLinearColor HeadDrawColor; // Offset: 0x0c // Size: 0x10
	struct FLinearColor HeadDrawOutlineColor; // Offset: 0x1c // Size: 0x10
	int HeadOutlineSize; // Offset: 0x2c // Size: 0x04
	int HeadSizeScale; // Offset: 0x30 // Size: 0x04
	struct FLinearColor BodyDrawColor; // Offset: 0x34 // Size: 0x10
	struct FLinearColor BodyDrawOutlineColor; // Offset: 0x44 // Size: 0x10
	int BodyOutlineSize; // Offset: 0x54 // Size: 0x04
	int BodySizeScale; // Offset: 0x58 // Size: 0x04
	struct FVector2D DefalutOringialPosition; // Offset: 0x5c // Size: 0x08
	struct FVector2D OringialPositionEnemy; // Offset: 0x64 // Size: 0x08
	int OringialPosRandom; // Offset: 0x6c // Size: 0x04
	struct UCurveVector* SpeedCurve; // Offset: 0x70 // Size: 0x08
	float TimeLife; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DamageNumber
// Size: 0xa0 // Inherited bytes: 0x00
struct FDamageNumber {
	// Fields
	char pad_0x0[0xa0]; // Offset: 0x00 // Size: 0xa0
};

// Object Name: ScriptStruct ShadowTrackerExtra.FireEventConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FFireEventConfig {
	// Fields
	int EventId; // Offset: 0x00 // Size: 0x04
	float RandomOccur; // Offset: 0x04 // Size: 0x04
	float RandomTimeRange; // Offset: 0x08 // Size: 0x04
	int EventParam; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PVEFireEventConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FPVEFireEventConfig {
	// Fields
	int EventId; // Offset: 0x00 // Size: 0x04
	float RandomOccur; // Offset: 0x04 // Size: 0x04
	float RandomTimeRange; // Offset: 0x08 // Size: 0x04
	int EventParam; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeadBoxParticleSystemAsset
// Size: 0x70 // Inherited bytes: 0x00
struct FDeadBoxParticleSystemAsset {
	// Fields
	struct UParticleSystem* Particle; // Offset: 0x00 // Size: 0x28
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FTransform ParticleTransform; // Offset: 0x30 // Size: 0x30
	bool bAutoDestroy; // Offset: 0x60 // Size: 0x01
	bool bAutoActivate; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0xe]; // Offset: 0x62 // Size: 0x0e
};

// Object Name: ScriptStruct ShadowTrackerExtra.BRDeathMatchPlayerStateHistoryData
// Size: 0x18 // Inherited bytes: 0x00
struct FBRDeathMatchPlayerStateHistoryData {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	int Kills; // Offset: 0x04 // Size: 0x04
	int Assists; // Offset: 0x08 // Size: 0x04
	int Deaths; // Offset: 0x0c // Size: 0x04
	int Score; // Offset: 0x10 // Size: 0x04
	int ContinuouKills; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeathMatchTeamScoreData
// Size: 0x30 // Inherited bytes: 0x00
struct FDeathMatchTeamScoreData {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Result; // Offset: 0x08 // Size: 0x10
	int TeamRank; // Offset: 0x18 // Size: 0x04
	int TeamScore; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FDeathMatchPlayerStateData> PlayerStateDatas; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeathMatchPlayerStartSelectConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FDeathMatchPlayerStartSelectConfig {
	// Fields
	bool bIsEnabled; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float NoEnemyRangeRadius; // Offset: 0x04 // Size: 0x04
	float ExistTeammateRanageRadius; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WWIEBankContainer
// Size: 0x10 // Inherited bytes: 0x00
struct FWWIEBankContainer {
	// Fields
	struct UAkAudioEvent* MaleBank; // Offset: 0x00 // Size: 0x08
	struct UAkAudioEvent* FemaleBank; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.DecalBakingRTCache
// Size: 0x30 // Inherited bytes: 0x00
struct FDecalBakingRTCache {
	// Fields
	enum class EDIYDecalBakingType DecalBakingType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString PlayerUID; // Offset: 0x08 // Size: 0x10
	int WeaponAvatarID; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct UTextureRenderTarget2D* TextureRenderTarget; // Offset: 0x20 // Size: 0x08
	float LastActiveTime; // Offset: 0x28 // Size: 0x04
	bool bMainRoleRT; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.DeliveryCondition
// Size: 0x08 // Inherited bytes: 0x00
struct FDeliveryCondition {
	// Fields
	struct UDeliveryConditionCheck* CheckCnd; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.DesertStormMiniMapData
// Size: 0x78 // Inherited bytes: 0x00
struct FDesertStormMiniMapData {
	// Fields
	char pad_0x0[0x70]; // Offset: 0x00 // Size: 0x70
	int NormalIconID; // Offset: 0x70 // Size: 0x04
	int GrayIconID; // Offset: 0x74 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DragonBreathRepMovement
// Size: 0x28 // Inherited bytes: 0x00
struct FDragonBreathRepMovement {
	// Fields
	struct FVector LinearVelocity; // Offset: 0x00 // Size: 0x0c
	struct FVector Location; // Offset: 0x0c // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x18 // Size: 0x0c
	enum class EVectorQuantization LocationQuantizationLevel; // Offset: 0x24 // Size: 0x01
	enum class EVectorQuantization VelocityQuantizationLevel; // Offset: 0x25 // Size: 0x01
	enum class ERotatorQuantization RotationQuantizationLevel; // Offset: 0x26 // Size: 0x01
	char pad_0x27[0x1]; // Offset: 0x27 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.DropGroupContainer
// Size: 0x18 // Inherited bytes: 0x00
struct FDropGroupContainer {
	// Fields
	int GroupIndex; // Offset: 0x00 // Size: 0x04
	float GroupTime; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FItemCurveAnim> List; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemCurveAnim
// Size: 0x58 // Inherited bytes: 0x00
struct FItemCurveAnim {
	// Fields
	enum class EItemCurveAnimState CurState; // Offset: 0x00 // Size: 0x01
	bool ShowGroundEffect; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float DropDuration; // Offset: 0x04 // Size: 0x04
	float CurrentTime; // Offset: 0x08 // Size: 0x04
	float DropStartSpeed; // Offset: 0x0c // Size: 0x04
	float DelayDestroyParticleTime; // Offset: 0x10 // Size: 0x04
	float DelayStartTime; // Offset: 0x14 // Size: 0x04
	float DelayDestroyGroundParticleTime; // Offset: 0x18 // Size: 0x04
	struct FVector StartPos; // Offset: 0x1c // Size: 0x0c
	struct FVector EndPos; // Offset: 0x28 // Size: 0x0c
	struct TWeakObjectPtr<struct AActor> TargetActor; // Offset: 0x34 // Size: 0x08
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct UParticleSystemComponent* TailParticleComponent; // Offset: 0x40 // Size: 0x08
	struct UParticleSystemComponent* GroundParticleComponent; // Offset: 0x48 // Size: 0x08
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.DynamicBatchActorMap
// Size: 0x50 // Inherited bytes: 0x00
struct FDynamicBatchActorMap {
	// Fields
	struct TMap<struct UObject*, struct ADynamicBatchActor*> Value; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.UIWidgetConfig
// Size: 0x88 // Inherited bytes: 0x00
struct FUIWidgetConfig {
	// Fields
	struct UClass* WidgetClassPath; // Offset: 0x00 // Size: 0x28
	int ZOrder; // Offset: 0x28 // Size: 0x04
	struct FMargin MarginData; // Offset: 0x2c // Size: 0x10
	struct FAnchors AnchorsData; // Offset: 0x3c // Size: 0x10
	struct FVector2D Position; // Offset: 0x4c // Size: 0x08
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FString MountName; // Offset: 0x58 // Size: 0x10
	struct FString MountOuterName; // Offset: 0x68 // Size: 0x10
	bool bMountUIRoot; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x7]; // Offset: 0x79 // Size: 0x07
	struct UObject* UIWidgetClass; // Offset: 0x80 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.LevelCopyInfo
// Size: 0xc0 // Inherited bytes: 0x00
struct FLevelCopyInfo {
	// Fields
	struct TSet<struct FString> PackageNames; // Offset: 0x00 // Size: 0x50
	struct ULevelStreaming* LevelStreamingClass; // Offset: 0x50 // Size: 0x08
	struct FVector2D LayoutGridSize; // Offset: 0x58 // Size: 0x08
	int LayoutRowNum; // Offset: 0x60 // Size: 0x04
	struct FVector StartLocOfLevel; // Offset: 0x64 // Size: 0x0c
	struct FVector StartLocOfStreamVolume; // Offset: 0x70 // Size: 0x0c
	struct FVector StartLocOfPlayerStart; // Offset: 0x7c // Size: 0x0c
	struct FVector StartLocOfMinMapPoint; // Offset: 0x88 // Size: 0x0c
	char pad_0x94[0x4]; // Offset: 0x94 // Size: 0x04
	struct FString StreamVolumeName; // Offset: 0x98 // Size: 0x10
	struct FString PlayerStartName; // Offset: 0xa8 // Size: 0x10
	struct AActor* MiniMapStandardPoint; // Offset: 0xb8 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.DynamicOptimizeComponentTick
// Size: 0x20 // Inherited bytes: 0x00
struct FDynamicOptimizeComponentTick {
	// Fields
	bool bIsActive; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString Reason; // Offset: 0x08 // Size: 0x10
	bool bTickEnable; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.DynamicOptimizeComponentFull
// Size: 0x28 // Inherited bytes: 0x00
struct FDynamicOptimizeComponentFull {
	// Fields
	bool bAbsoluteLocation; // Offset: 0x00 // Size: 0x01
	bool bAbsoluteRotation; // Offset: 0x01 // Size: 0x01
	bool bAbsoluteScale; // Offset: 0x02 // Size: 0x01
	bool bSkipUpdateChildTransforms; // Offset: 0x03 // Size: 0x01
	bool bShouldUpdateOverLaps; // Offset: 0x04 // Size: 0x01
	bool bShouldUpdatePhysicsVolume; // Offset: 0x05 // Size: 0x01
	bool bNoSkeletonUpdate; // Offset: 0x06 // Size: 0x01
	enum class ECollisionEnabled CollisionType; // Offset: 0x07 // Size: 0x01
	bool bVisible; // Offset: 0x08 // Size: 0x01
	bool bHide; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
	bool bIsActive; // Offset: 0x10 // Size: 0x01
	bool bReplicate; // Offset: 0x11 // Size: 0x01
	bool bTickEnable; // Offset: 0x12 // Size: 0x01
	char pad_0x13[0x5]; // Offset: 0x13 // Size: 0x05
	struct FString Reason; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherFogCfg
// Size: 0x50 // Inherited bytes: 0x00
struct FWeatherFogCfg {
	// Fields
	struct TArray<enum class EWeatherStatusType> WeatherTypeList; // Offset: 0x00 // Size: 0x10
	struct AExponentialHeightFog* Fog; // Offset: 0x10 // Size: 0x08
	struct FWeatherDstFog DstWeatherFog; // Offset: 0x18 // Size: 0x14
	struct FWeatherSrcFog SrcWeatherFog; // Offset: 0x2c // Size: 0x0c
	float blendTime; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct TArray<struct UDynamicWeatherController*> WeatherControllerList; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherSrcFog
// Size: 0x0c // Inherited bytes: 0x00
struct FWeatherSrcFog {
	// Fields
	float StartDistance; // Offset: 0x00 // Size: 0x04
	float CustomFogLow_DensityCoefficient; // Offset: 0x04 // Size: 0x04
	float CustomFogHigh_DensityCoefficient; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherDstFog
// Size: 0x14 // Inherited bytes: 0x00
struct FWeatherDstFog {
	// Fields
	bool UseStartDistance; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float StartDistance; // Offset: 0x04 // Size: 0x04
	bool UseDensityCoefficient; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float CustomFogLow_DensityCoefficient; // Offset: 0x0c // Size: 0x04
	float CustomFogHigh_DensityCoefficient; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayerKeyDstWeather
// Size: 0x08 // Inherited bytes: 0x00
struct FPlayerKeyDstWeather {
	// Fields
	struct ASTExtraPlayerController* PC; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ScreenAppearanceCfg
// Size: 0x28 // Inherited bytes: 0x00
struct FScreenAppearanceCfg {
	// Fields
	bool UseScreenAppearance; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString ScreenAppearanceName; // Offset: 0x08 // Size: 0x10
	enum class EScreenParticleEffectType ParticleType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	float ScreenAppearanceConcentration; // Offset: 0x1c // Size: 0x04
	struct FName ShaderName; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherDebugView
// Size: 0x28 // Inherited bytes: 0x00
struct FWeatherDebugView {
	// Fields
	struct FString CurrentWeather; // Offset: 0x00 // Size: 0x10
	struct FString WeatherStage; // Offset: 0x10 // Size: 0x10
	float TotalElapsedTime; // Offset: 0x20 // Size: 0x04
	float WeatherElapsedTime; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherObject
// Size: 0x68 // Inherited bytes: 0x00
struct FWeatherObject {
	// Fields
	float MainLight_Density; // Offset: 0x00 // Size: 0x04
	struct FLinearColor MainLight_Color; // Offset: 0x04 // Size: 0x10
	float MainLight_Temperature; // Offset: 0x14 // Size: 0x04
	struct FRotator MainLight_Rotation; // Offset: 0x18 // Size: 0x0c
	float SkyLight_Density; // Offset: 0x24 // Size: 0x04
	struct FLinearColor SkyLight_Color; // Offset: 0x28 // Size: 0x10
	float CustomFogLow_DensityCoefficient; // Offset: 0x38 // Size: 0x04
	struct FLinearColor CustomFogLow_Color; // Offset: 0x3c // Size: 0x10
	float CustomFogHigh_DensityCoefficient; // Offset: 0x4c // Size: 0x04
	struct FLinearColor CustomFogHigh_Color; // Offset: 0x50 // Size: 0x10
	float HeightFallOff; // Offset: 0x60 // Size: 0x04
	float StartDistance; // Offset: 0x64 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherStatus
// Size: 0x02 // Inherited bytes: 0x00
struct FWeatherStatus {
	// Fields
	enum class EWeatherStatusType WeaterType; // Offset: 0x00 // Size: 0x01
	enum class EWeatherChangeStatus WeaterStatus; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.EliteProjectile_MeleeHurtEffect
// Size: 0x38 // Inherited bytes: 0x00
struct FEliteProjectile_MeleeHurtEffect {
	// Fields
	struct UParticleSystem* Template_Effect; // Offset: 0x00 // Size: 0x08
	struct FName SocketName; // Offset: 0x08 // Size: 0x08
	struct FName HurtRotationSocketName; // Offset: 0x10 // Size: 0x08
	float Scale; // Offset: 0x18 // Size: 0x04
	struct FVector LocationOffset; // Offset: 0x1c // Size: 0x0c
	struct FRotator RotationOffset; // Offset: 0x28 // Size: 0x0c
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SegmentPoint
// Size: 0x18 // Inherited bytes: 0x00
struct FSegmentPoint {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FVector Normal; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.ConditionAndRestriction
// Size: 0x01 // Inherited bytes: 0x00
struct FConditionAndRestriction {
	// Fields
	char bEnable : 1; // Offset: 0x00 // Size: 0x01
	char bSatisfied : 1; // Offset: 0x00 // Size: 0x01
	char bRestriction : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_3 : 5; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActorLocationMarker
// Size: 0x18 // Inherited bytes: 0x00
struct FActorLocationMarker {
	// Fields
	struct UActorPositionWidget* LocationMarkerClass; // Offset: 0x00 // Size: 0x08
	struct UTexture2D* MarkerTex; // Offset: 0x08 // Size: 0x08
	char pad_0x10[0x8]; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.DamageApplyFunction
// Size: 0x18 // Inherited bytes: 0x00
struct FDamageApplyFunction {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct UDamageType* DamageTypeClass; // Offset: 0x08 // Size: 0x08
	int ItemId; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RadialDamageApplyFunction
// Size: 0x28 // Inherited bytes: 0x18
struct FRadialDamageApplyFunction : FDamageApplyFunction {
	// Fields
	struct UCurveFloat* DamageCurve; // Offset: 0x18 // Size: 0x08
	float BaseMomentum; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HorizontalVerticalRadialDamageFunction
// Size: 0x30 // Inherited bytes: 0x28
struct FHorizontalVerticalRadialDamageFunction : FRadialDamageApplyFunction {
	// Fields
	struct UCurveFloat* DistanceCurveVertical; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.PointDamageApplyFunction
// Size: 0x18 // Inherited bytes: 0x18
struct FPointDamageApplyFunction : FDamageApplyFunction {
	// Fields
	float Damage; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuffApplierFunction
// Size: 0x38 // Inherited bytes: 0x00
struct FBuffApplierFunction {
	// Fields
	struct FName BuffName; // Offset: 0x00 // Size: 0x08
	struct UCurveFloat* DurationCurve; // Offset: 0x08 // Size: 0x08
	char bRemoveBuffFromExpiredTargets : 1; // Offset: 0x10 // Size: 0x01
	char bRefreshBuff : 1; // Offset: 0x10 // Size: 0x01
	char bClearBuffsOnDisabled : 1; // Offset: 0x10 // Size: 0x01
	char pad_0x10_3 : 5; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct TArray<struct AActor*> LastTimeTargets; // Offset: 0x18 // Size: 0x10
	struct AActor* Causer; // Offset: 0x28 // Size: 0x08
	struct AController* Instigator; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ProjectileVoiceCheckEvent
// Size: 0x08 // Inherited bytes: 0x00
struct FProjectileVoiceCheckEvent {
	// Fields
	float VoiceCheckRadius; // Offset: 0x00 // Size: 0x04
	float DisplayDuration; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ExplosionCameraShakeFunction
// Size: 0x30 // Inherited bytes: 0x00
struct FExplosionCameraShakeFunction {
	// Fields
	struct UCameraShake* FrontShake; // Offset: 0x00 // Size: 0x08
	struct UCameraShake* BackShake; // Offset: 0x08 // Size: 0x08
	struct UCameraShake* RightShake; // Offset: 0x10 // Size: 0x08
	struct UCameraShake* LeftShake; // Offset: 0x18 // Size: 0x08
	struct UCurveFloat* ShakeIntensityCurve; // Offset: 0x20 // Size: 0x08
	enum class ECameraAnimPlaySpace CameraAnimPlaySpace; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.ProjectileExplosionNoise
// Size: 0x38 // Inherited bytes: 0x00
struct FProjectileExplosionNoise {
	// Fields
	float NoiseRadius; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UAkAudioEvent* AkEvent; // Offset: 0x08 // Size: 0x08
	struct FString RTPC_ExplosionDistance_2; // Offset: 0x10 // Size: 0x10
	struct FString RTPC_ExplosionDistance_3; // Offset: 0x20 // Size: 0x10
	float RTPCValue_3; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ProjectileRepMovement
// Size: 0x28 // Inherited bytes: 0x00
struct FProjectileRepMovement {
	// Fields
	struct FVector LinearVelocity; // Offset: 0x00 // Size: 0x0c
	struct FVector Location; // Offset: 0x0c // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x18 // Size: 0x0c
	char bReplicateRotation : 1; // Offset: 0x24 // Size: 0x01
	char pad_0x24_1 : 7; // Offset: 0x24 // Size: 0x01
	enum class EVectorQuantization LocationQuantizationLevel; // Offset: 0x25 // Size: 0x01
	enum class EVectorQuantization VelocityQuantizationLevel; // Offset: 0x26 // Size: 0x01
	enum class ERotatorQuantization RotationQuantizationLevel; // Offset: 0x27 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.ProjectileEvent
// Size: 0x30 // Inherited bytes: 0x00
struct FProjectileEvent {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x0c // Size: 0x0c
	char EventFlag; // Offset: 0x18 // Size: 0x01
	enum class EProjectileEventType EventType; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x6]; // Offset: 0x1a // Size: 0x06
	struct TArray<enum class EProjectileEventType> ReplicatedEvents; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ProjectileHealthSetting
// Size: 0x08 // Inherited bytes: 0x00
struct FProjectileHealthSetting {
	// Fields
	float Health; // Offset: 0x00 // Size: 0x04
	float DamageScale; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ThrowReplaceCharAnimData
// Size: 0x28 // Inherited bytes: 0x00
struct FThrowReplaceCharAnimData {
	// Fields
	enum class ECharacterAnimType CharacterAnimType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct UAnimationAsset*> PoseAnimList; // Offset: 0x08 // Size: 0x10
	struct TArray<struct UAnimationAsset*> FPPPoseAnimList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.EnhancerSpotPlayerSkill
// Size: 0x08 // Inherited bytes: 0x00
struct FEnhancerSpotPlayerSkill {
	// Fields
	enum class ECharacterSubType PawnSubType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int SkillID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.NeedActiveEnhanceSpotSruct
// Size: 0x10 // Inherited bytes: 0x00
struct FNeedActiveEnhanceSpotSruct {
	// Fields
	struct TArray<struct AEnhancerSpot*> TempNeedActiveSpotList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShootVerifyConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FShootVerifyConfig {
	// Fields
	float ClientMuzzleHeightMax; // Offset: 0x00 // Size: 0x04
	float ClientPureMuzzleHeightMax; // Offset: 0x04 // Size: 0x04
	float VehicleWeaponClientMuzzleHeightMax; // Offset: 0x08 // Size: 0x04
	float VehicleWeaponClientPureMuzzleHeightMax; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.UEnvParamData
// Size: 0x60 // Inherited bytes: 0x00
struct FUEnvParamData {
	// Fields
	struct FString Desc; // Offset: 0x00 // Size: 0x10
	struct FSkyLightData SkyLight; // Offset: 0x10 // Size: 0x14
	struct FDirectionalLightData DirectionalLight; // Offset: 0x24 // Size: 0x14
	struct FHeightFogData HeightFog; // Offset: 0x38 // Size: 0x24
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HeightFogData
// Size: 0x24 // Inherited bytes: 0x00
struct FHeightFogData {
	// Fields
	float FogDensity; // Offset: 0x00 // Size: 0x04
	struct FLinearColor FogInscatteringColor; // Offset: 0x04 // Size: 0x10
	float FogHeightFalloff; // Offset: 0x14 // Size: 0x04
	float FogMaxOpacity; // Offset: 0x18 // Size: 0x04
	float StartDistance; // Offset: 0x1c // Size: 0x04
	float FogCutoffDistance; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DirectionalLightData
// Size: 0x14 // Inherited bytes: 0x00
struct FDirectionalLightData {
	// Fields
	float Intensity; // Offset: 0x00 // Size: 0x04
	struct FLinearColor LightColor; // Offset: 0x04 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkyLightData
// Size: 0x14 // Inherited bytes: 0x00
struct FSkyLightData {
	// Fields
	float Intensity; // Offset: 0x00 // Size: 0x04
	struct FLinearColor LightColor; // Offset: 0x04 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.UnderEnermyAttackCharacter
// Size: 0x48 // Inherited bytes: 0x00
struct FUnderEnermyAttackCharacter {
	// Fields
	float FinalDamage; // Offset: 0x00 // Size: 0x04
	float LastHealth; // Offset: 0x04 // Size: 0x04
	char DamageHitPos; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	uint64 OldStates; // Offset: 0x10 // Size: 0x08
	bool bFatalHealthCost; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct FString BigHeadDurabilityIndexName; // Offset: 0x20 // Size: 0x10
	struct FString BigBodyDurabilityIndexName; // Offset: 0x30 // Size: 0x10
	float OldBigHeadDurability; // Offset: 0x40 // Size: 0x04
	float OldBigBodyDurability; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ExFootIKInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FExFootIKInfo {
	// Fields
	struct FName IKBoneOrSocketName; // Offset: 0x00 // Size: 0x08
	struct FName FixedBoneOrSocketName; // Offset: 0x08 // Size: 0x08
	struct FVector IKBoneOrSocketOffset; // Offset: 0x10 // Size: 0x0c
	struct FVector IKEffectorOffset; // Offset: 0x1c // Size: 0x0c
	struct FRotator IKEffectorRotation; // Offset: 0x28 // Size: 0x0c
	char pad_0x34[0x1c]; // Offset: 0x34 // Size: 0x1c
};

// Object Name: ScriptStruct ShadowTrackerExtra.ExplosionFinderWrapper
// Size: 0x08 // Inherited bytes: 0x00
struct FExplosionFinderWrapper {
	// Fields
	struct UExplosionFinder* ExplosionFinder; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActorFilterParams
// Size: 0x28 // Inherited bytes: 0x00
struct FActorFilterParams {
	// Fields
	struct AActor* Causer; // Offset: 0x00 // Size: 0x08
	struct AController* Instigator; // Offset: 0x08 // Size: 0x08
	struct FVector Origin; // Offset: 0x10 // Size: 0x0c
	struct FVector Direction; // Offset: 0x1c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.FinderResult
// Size: 0x90 // Inherited bytes: 0x00
struct FFinderResult {
	// Fields
	struct FHitResult Hit; // Offset: 0x00 // Size: 0x88
	char bMarkForRemoving : 1; // Offset: 0x88 // Size: 0x01
	char bMarkForKeeping : 1; // Offset: 0x88 // Size: 0x01
	char pad_0x88_2 : 6; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x7]; // Offset: 0x89 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.FakePlayerCustomRow
// Size: 0x58 // Inherited bytes: 0x00
struct FFakePlayerCustomRow {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString ControllerPath; // Offset: 0x08 // Size: 0x10
	struct FString Name; // Offset: 0x18 // Size: 0x10
	int gender; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString ItemStr; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FGameModePlayerItem> PlayerItems; // Offset: 0x40 // Size: 0x10
	int IsUseRandomName; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.FakePlayerSpeciesParams
// Size: 0x18 // Inherited bytes: 0x00
struct FFakePlayerSpeciesParams {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	int TeamID; // Offset: 0x04 // Size: 0x04
	int SingleId; // Offset: 0x08 // Size: 0x04
	int ParamsID; // Offset: 0x0c // Size: 0x04
	int CampID; // Offset: 0x10 // Size: 0x04
	bool bAddToAIActingManager; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.FakePlayerParams
// Size: 0x10 // Inherited bytes: 0x00
struct FFakePlayerParams {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	int ParamsID; // Offset: 0x04 // Size: 0x04
	int CampID; // Offset: 0x08 // Size: 0x04
	bool bUsePool; // Offset: 0x0c // Size: 0x01
	bool bAddToAIActingManager; // Offset: 0x0d // Size: 0x01
	char pad_0xE[0x2]; // Offset: 0x0e // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.FeatureSetItem
// Size: 0x58 // Inherited bytes: 0x00
struct FFeatureSetItem {
	// Fields
	char pad_0x0[0x58]; // Offset: 0x00 // Size: 0x58
};

// Object Name: ScriptStruct ShadowTrackerExtra.FeatureConfigItem
// Size: 0xa8 // Inherited bytes: 0x00
struct FFeatureConfigItem {
	// Fields
	struct FString TargetClassName; // Offset: 0x00 // Size: 0x10
	int bUseFeatureSet; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FString> ExcludeComponentsList_DS; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FString> ExcludeComponentsList_Autonomous; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FString> ExcludeComponentsList_Team; // Offset: 0x38 // Size: 0x10
	struct TArray<struct FString> ExcludeComponentsList_NonTeam; // Offset: 0x48 // Size: 0x10
	struct TArray<struct FString> ExcludeComponentsList_DSAI; // Offset: 0x58 // Size: 0x10
	struct TArray<struct FString> ExcludeComponentsList_DSMLAI; // Offset: 0x68 // Size: 0x10
	struct TArray<struct FString> ExcludeComponentsList_ClientAI; // Offset: 0x78 // Size: 0x10
	struct TArray<struct FString> ExcludeComponentsList_Standalone; // Offset: 0x88 // Size: 0x10
	struct TArray<struct FString> ExcludeComponentsList_StandaloneAI; // Offset: 0x98 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.TempleSpawnConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FTempleSpawnConfig {
	// Fields
	struct FVector SpawnLocation; // Offset: 0x00 // Size: 0x0c
	struct FRotator SpawnRotation; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShowTextWidgetData
// Size: 0x28 // Inherited bytes: 0x00
struct FShowTextWidgetData {
	// Fields
	struct UUserWidget* FloatingTextWidget; // Offset: 0x00 // Size: 0x08
	float RecycleTime; // Offset: 0x08 // Size: 0x04
	struct FVector ShowWorldPos; // Offset: 0x0c // Size: 0x0c
	struct FVector RandomOffset; // Offset: 0x18 // Size: 0x0c
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.FloatingTextData
// Size: 0x14 // Inherited bytes: 0x00
struct FFloatingTextData {
	// Fields
	float BaseDamage; // Offset: 0x00 // Size: 0x04
	bool IsHeadShot; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct FVector_NetQuantize ImpactPoint; // Offset: 0x08 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.RepFlyingMovement
// Size: 0x18 // Inherited bytes: 0x00
struct FRepFlyingMovement {
	// Fields
	float FlySpeed; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FVector_NetQuantize100> FlyingNavigationPath; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayerStartGroup
// Size: 0x20 // Inherited bytes: 0x00
struct FPlayerStartGroup {
	// Fields
	int GroupID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct ASTExtraPlayerStart*> PlayerStarts; // Offset: 0x08 // Size: 0x10
	char pad_0x18[0x8]; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.FourInOneRoleLevelMap
// Size: 0x01 // Inherited bytes: 0x00
struct FFourInOneRoleLevelMap {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.FramingTickConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FFramingTickConfig {
	// Fields
	bool Enable; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float LOD0_ScreenSize; // Offset: 0x04 // Size: 0x04
	uint32_t LOD0_FrameIntervel; // Offset: 0x08 // Size: 0x04
	float LOD1_ScreenSize; // Offset: 0x0c // Size: 0x04
	uint32_t LOD1_FrameIntervel; // Offset: 0x10 // Size: 0x04
	float LOD2_ScreenSize; // Offset: 0x14 // Size: 0x04
	uint32_t LOD2_FrameIntervel; // Offset: 0x18 // Size: 0x04
	float LOD3_ScreenSize; // Offset: 0x1c // Size: 0x04
	uint32_t LOD3_FrameIntervel; // Offset: 0x20 // Size: 0x04
	float LOD4_ScreenSize; // Offset: 0x24 // Size: 0x04
	uint32_t LOD4_FrameIntervel; // Offset: 0x28 // Size: 0x04
	uint32_t ClassID; // Offset: 0x2c // Size: 0x04
	char pad_0x30[0x20]; // Offset: 0x30 // Size: 0x20
};

// Object Name: ScriptStruct ShadowTrackerExtra.SingleLevelObjArray
// Size: 0x10 // Inherited bytes: 0x00
struct FSingleLevelObjArray {
	// Fields
	struct TArray<struct AActor*> LevelObjs; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.LevelRelifePointInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FLevelRelifePointInfo {
	// Fields
	struct FGameLevelDesc LevelDesc; // Offset: 0x00 // Size: 0x18
	struct TArray<struct FRelifePointInfo> RelifePointList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RelifePointInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FRelifePointInfo {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0xc]; // Offset: 0x04 // Size: 0x0c
	struct FTransform RelifeTrans; // Offset: 0x10 // Size: 0x30
	bool IsActivePoint; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0xf]; // Offset: 0x41 // Size: 0x0f
};

// Object Name: ScriptStruct ShadowTrackerExtra.AliveMonsterNum
// Size: 0x08 // Inherited bytes: 0x00
struct FAliveMonsterNum {
	// Fields
	int Num; // Offset: 0x00 // Size: 0x04
	enum class EMonsterSpawnSourceType SourceType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.GameModeParam
// Size: 0x58 // Inherited bytes: 0x00
struct FGameModeParam {
	// Fields
	float Radius0; // Offset: 0x00 // Size: 0x04
	float Radius1; // Offset: 0x04 // Size: 0x04
	float Radius3; // Offset: 0x08 // Size: 0x04
	bool bUsingPolygon; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float Radius2; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FVector2D> PolygonPoints; // Offset: 0x18 // Size: 0x10
	float BlueCircleRadius; // Offset: 0x28 // Size: 0x04
	struct FVector MapCenter; // Offset: 0x2c // Size: 0x0c
	float PlaneSpeed; // Offset: 0x38 // Size: 0x04
	float PlaneHeight; // Offset: 0x3c // Size: 0x04
	float CanOpenParachuteHeight; // Offset: 0x40 // Size: 0x04
	float ForceOpenParachuteHeight; // Offset: 0x44 // Size: 0x04
	float CloseParachuteHeight; // Offset: 0x48 // Size: 0x04
	bool bCrossCenter; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
	float CrossCenterRadius; // Offset: 0x50 // Size: 0x04
	float FixedJumpPointRate; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.GameModeParms
// Size: 0x1b0 // Inherited bytes: 0x00
struct FGameModeParms {
	// Fields
	struct FSubSystemConfig SSC_DeferredExitGame; // Offset: 0x00 // Size: 0x30
	struct FSubSystemConfig SSC_RecallTeammate; // Offset: 0x30 // Size: 0x30
	struct FSubSystemConfig SSC_RescueHelicopter; // Offset: 0x60 // Size: 0x30
	struct FSubSystemConfig SSC_HeavyWeapon; // Offset: 0x90 // Size: 0x30
	struct FSubSystemConfig SSC_TDMHardPoint; // Offset: 0xc0 // Size: 0x30
	struct FSubSystemConfig SSC_VisualField; // Offset: 0xf0 // Size: 0x30
	struct FSubSystemConfig SSC_WorldActorFlag; // Offset: 0x120 // Size: 0x30
	struct FSubSystemConfig SSC_SuperCold; // Offset: 0x150 // Size: 0x30
	struct FSubSystemConfig SSC_ARWeaponManager; // Offset: 0x180 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.SubSystemConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FSubSystemConfig {
	// Fields
	enum class ESubSystemType SubSystemId; // Offset: 0x00 // Size: 0x01
	bool bEnable; // Offset: 0x01 // Size: 0x01
	enum class EConstructType ConstructType; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x5]; // Offset: 0x03 // Size: 0x05
	struct UObject* SubSystemClass; // Offset: 0x08 // Size: 0x08
	struct FDynamicCompConfig DCC_PlayerController; // Offset: 0x10 // Size: 0x10
	struct FDynamicCompConfig DCC_PlayerPawn; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DynamicCompConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FDynamicCompConfig {
	// Fields
	bool bIsServerOnly; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UObject* DynamicCompClass; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.BornPlayerStartData
// Size: 0x18 // Inherited bytes: 0x00
struct FBornPlayerStartData {
	// Fields
	int BornPointID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct ASTExtraPlayerStart*> PlayerStarts; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlaneTypes
// Size: 0x18 // Inherited bytes: 0x00
struct FPlaneTypes {
	// Fields
	int SeasonIdx; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString PlaneClassFullPath; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ReplayFileHeader
// Size: 0x58 // Inherited bytes: 0x00
struct FReplayFileHeader {
	// Fields
	int ReplayFileFormatRevision; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString ReplayName; // Offset: 0x08 // Size: 0x10
	struct FString ReplayVersion; // Offset: 0x18 // Size: 0x10
	int DateTime; // Offset: 0x28 // Size: 0x04
	float TotalTime; // Offset: 0x2c // Size: 0x04
	struct FString roomName; // Offset: 0x30 // Size: 0x10
	int GameModeID; // Offset: 0x40 // Size: 0x04
	int SubModeId; // Offset: 0x44 // Size: 0x04
	int MapId; // Offset: 0x48 // Size: 0x04
	int PlayerNum; // Offset: 0x4c // Size: 0x04
	int CustomGameModeId; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CVarConfigItem
// Size: 0x20 // Inherited bytes: 0x00
struct FCVarConfigItem {
	// Fields
	struct FString Key; // Offset: 0x00 // Size: 0x10
	struct FString Value; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RenderStyleAndPPMaping
// Size: 0x50 // Inherited bytes: 0x00
struct FRenderStyleAndPPMaping {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.GPProfileMatch
// Size: 0x20 // Inherited bytes: 0x00
struct FGPProfileMatch {
	// Fields
	struct FString Profile; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FGPProfileMatchItem> Match; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.GPProfileMatchItem
// Size: 0x18 // Inherited bytes: 0x00
struct FGPProfileMatchItem {
	// Fields
	enum class EGPSourceType SourceType; // Offset: 0x00 // Size: 0x01
	enum class EGPCompareType CompareType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct FString MatchString; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.GrenadePredictResult
// Size: 0x30 // Inherited bytes: 0x00
struct FGrenadePredictResult {
	// Fields
	struct TArray<struct FVector> SplinePoints; // Offset: 0x00 // Size: 0x10
	bool IsHitActor; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	struct FVector HitActorLocation; // Offset: 0x14 // Size: 0x0c
	struct FRotator HitActorRotation; // Offset: 0x20 // Size: 0x0c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.GuideInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FGuideInfo {
	// Fields
	struct UWidget* Widget; // Offset: 0x00 // Size: 0x08
	int guildUI; // Offset: 0x08 // Size: 0x04
	struct FVector2D Offset; // Offset: 0x0c // Size: 0x08
	struct FVector2D Size; // Offset: 0x14 // Size: 0x08
	int childData; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HardPointTeamScoreData
// Size: 0x08 // Inherited bytes: 0x00
struct FHardPointTeamScoreData {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	int Score; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HardPointSwitchConfigData
// Size: 0x10 // Inherited bytes: 0x00
struct FHardPointSwitchConfigData {
	// Fields
	struct TArray<struct FHardPointSwitchConfig> SwitchConfigList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.HardPointSwitchConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FHardPointSwitchConfig {
	// Fields
	float WaitTime; // Offset: 0x00 // Size: 0x04
	int HardPointID; // Offset: 0x04 // Size: 0x04
	float ActivateTime; // Offset: 0x08 // Size: 0x04
	int WinScore; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HardPointStopJoinConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FHardPointStopJoinConfig {
	// Fields
	bool bIsEnabled; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int HardPointIndex; // Offset: 0x04 // Size: 0x04
	float ActivatedTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActivatedHardPointDataRecord
// Size: 0x78 // Inherited bytes: 0x00
struct FActivatedHardPointDataRecord {
	// Fields
	struct AHardPointActor* HardPointActor; // Offset: 0x00 // Size: 0x08
	int WinTeamID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x6c]; // Offset: 0x0c // Size: 0x6c
};

// Object Name: ScriptStruct ShadowTrackerExtra.HardPoint_TeamScoreData
// Size: 0x18 // Inherited bytes: 0x00
struct FHardPoint_TeamScoreData {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	int OccupyScore; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FHardPoint_PlayerScoreData> PlayerScoreDataList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.HardPoint_PlayerScoreData
// Size: 0x08 // Inherited bytes: 0x00
struct FHardPoint_PlayerScoreData {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	int OccupyScore; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HUDRenderObject
// Size: 0x38 // Inherited bytes: 0x00
struct FHUDRenderObject {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	bool bHidden; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float RenderPriority; // Offset: 0x0c // Size: 0x04
	struct FVector2D Position; // Offset: 0x10 // Size: 0x08
	struct FVector2D Size; // Offset: 0x18 // Size: 0x08
	struct FLinearColor RenderColor; // Offset: 0x20 // Size: 0x10
	float RenderOpacity; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HUDRenderObject_Text
// Size: 0xa0 // Inherited bytes: 0x38
struct FHUDRenderObject_Text : FHUDRenderObject {
	// Fields
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10
	struct FText Text; // Offset: 0x48 // Size: 0x18
	struct UFont* Font; // Offset: 0x60 // Size: 0x08
	float TextScale; // Offset: 0x68 // Size: 0x04
	bool bDrawShadow; // Offset: 0x6c // Size: 0x01
	char pad_0x6D[0x3]; // Offset: 0x6d // Size: 0x03
	struct FVector2D ShadowDirection; // Offset: 0x70 // Size: 0x08
	struct FLinearColor ShadowColor; // Offset: 0x78 // Size: 0x10
	bool bDrawOutline; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x3]; // Offset: 0x89 // Size: 0x03
	struct FLinearColor OutlineColor; // Offset: 0x8c // Size: 0x10
	enum class ETextHorzPos HorzPosition; // Offset: 0x9c // Size: 0x01
	enum class ETextVertPos VertPosition; // Offset: 0x9d // Size: 0x01
	char pad_0x9E[0x2]; // Offset: 0x9e // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.HUDRenderObject_Texture
// Size: 0x80 // Inherited bytes: 0x38
struct FHUDRenderObject_Texture : FHUDRenderObject {
	// Fields
	struct UTexture* Atlas; // Offset: 0x38 // Size: 0x08
	struct FTextureUVs UVs; // Offset: 0x40 // Size: 0x10
	bool bUseTeamColors; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
	struct TArray<struct FLinearColor> TeamColorOverrides; // Offset: 0x58 // Size: 0x10
	bool bIsBorderElement; // Offset: 0x68 // Size: 0x01
	bool bIsSlateElement; // Offset: 0x69 // Size: 0x01
	char pad_0x6A[0x2]; // Offset: 0x6a // Size: 0x02
	struct FVector2D RenderOffset; // Offset: 0x6c // Size: 0x08
	float Rotation; // Offset: 0x74 // Size: 0x04
	struct FVector2D RotPivot; // Offset: 0x78 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.TextureUVs
// Size: 0x10 // Inherited bytes: 0x00
struct FTextureUVs {
	// Fields
	float U; // Offset: 0x00 // Size: 0x04
	float V; // Offset: 0x04 // Size: 0x04
	float UL; // Offset: 0x08 // Size: 0x04
	float VL; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DecalBlock
// Size: 0x10 // Inherited bytes: 0x00
struct FDecalBlock {
	// Fields
	struct UMaterialInterface* DecalMaterial; // Offset: 0x00 // Size: 0x08
	struct UTexture* DecalTexure; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.HardLevelRange
// Size: 0x08 // Inherited bytes: 0x00
struct FHardLevelRange {
	// Fields
	int Min; // Offset: 0x00 // Size: 0x04
	int Max; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectedArea
// Size: 0x1c // Inherited bytes: 0x00
struct FInfectedArea {
	// Fields
	int AreaID; // Offset: 0x00 // Size: 0x04
	struct FVector AreaPosition; // Offset: 0x04 // Size: 0x0c
	float Radius; // Offset: 0x10 // Size: 0x04
	int Level; // Offset: 0x14 // Size: 0x04
	bool IsActive; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.WidgetHPCheckParam
// Size: 0x38 // Inherited bytes: 0x00
struct FWidgetHPCheckParam {
	// Fields
	struct TArray<enum class EObjectTypeQuery> CheckObjectTypes; // Offset: 0x00 // Size: 0x10
	struct TArray<struct AActor*> ValidActorClass; // Offset: 0x10 // Size: 0x10
	float SphereCheckRadius; // Offset: 0x20 // Size: 0x04
	float CheckDistance; // Offset: 0x24 // Size: 0x04
	float CheckAngle; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FName SocketName; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.Interp3ControlPoint
// Size: 0x34 // Inherited bytes: 0x1c
struct FInterp3ControlPoint : FInterpControlPoint {
	// Fields
	struct FRotator RotationControlPoint; // Offset: 0x1c // Size: 0x0c
	float RotationRadius; // Offset: 0x28 // Size: 0x04
	enum class EInterp3Method Interp3Method; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x7]; // Offset: 0x2d // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.DropIDData
// Size: 0x10 // Inherited bytes: 0x00
struct FDropIDData {
	// Fields
	struct TArray<struct FName> DropRowList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DropToGroundData
// Size: 0x40 // Inherited bytes: 0x00
struct FDropToGroundData {
	// Fields
	struct FPickUpItemData PickUpItemData; // Offset: 0x00 // Size: 0x38
	int ItemId; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WaitDropData
// Size: 0x48 // Inherited bytes: 0x00
struct FWaitDropData {
	// Fields
	struct ASTExtraBaseCharacter* KillerPawn; // Offset: 0x00 // Size: 0x08
	struct FString DeadPawnDesc; // Offset: 0x08 // Size: 0x10
	struct FVector DropGroundPoint; // Offset: 0x18 // Size: 0x0c
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct APlayerTombBox* DropTomb; // Offset: 0x28 // Size: 0x08
	struct TArray<int> DropPlanIDList; // Offset: 0x30 // Size: 0x10
	bool bDropedByPlayer; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.RandomDropData
// Size: 0x40 // Inherited bytes: 0x00
struct FRandomDropData {
	// Fields
	struct TArray<int> ItemIdList; // Offset: 0x00 // Size: 0x10
	int RuleID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<int> ItemCountList; // Offset: 0x18 // Size: 0x10
	float Weight; // Offset: 0x28 // Size: 0x04
	int DropMode; // Offset: 0x2c // Size: 0x04
	int MinAttachment; // Offset: 0x30 // Size: 0x04
	int MaxAttachment; // Offset: 0x34 // Size: 0x04
	int ItemIDStyle; // Offset: 0x38 // Size: 0x04
	bool bDropOnDead; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.DropItemConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FDropItemConfig {
	// Fields
	int ItemDropPercent; // Offset: 0x00 // Size: 0x04
	int ItemDropRuleID; // Offset: 0x04 // Size: 0x04
	int RandomCount; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RemainItemRuleDataRow
// Size: 0x14 // Inherited bytes: 0x00
struct FRemainItemRuleDataRow {
	// Fields
	int KeyID; // Offset: 0x00 // Size: 0x04
	int ItemId; // Offset: 0x04 // Size: 0x04
	int itemType; // Offset: 0x08 // Size: 0x04
	int ItemSubType; // Offset: 0x0c // Size: 0x04
	int RemainPerc; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemsBoxDataTableRow
// Size: 0x70 // Inherited bytes: 0x08
struct FItemsBoxDataTableRow : FTableRowBase {
	// Fields
	struct FString Category; // Offset: 0x08 // Size: 0x10
	int Weight; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TMap<struct APickUpWrapperActor*, int> ItemsData; // Offset: 0x20 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemsBoxConfigDataAssetConfigGroup
// Size: 0x20 // Inherited bytes: 0x00
struct FItemsBoxConfigDataAssetConfigGroup {
	// Fields
	struct FString GroupName; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FItemsBoxConfigDataAssetConfigItem> ConfigItems; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemsBoxConfigDataAssetConfigItem
// Size: 0x18 // Inherited bytes: 0x00
struct FItemsBoxConfigDataAssetConfigItem {
	// Fields
	float ProbabilityPercent; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString CategoryFilter; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DistanceContinueHitCheck
// Size: 0x2c // Inherited bytes: 0x00
struct FDistanceContinueHitCheck {
	// Fields
	float CheckDisSquared; // Offset: 0x00 // Size: 0x04
	int MaxContinueTimes; // Offset: 0x04 // Size: 0x04
	float ShootIntervalBuff; // Offset: 0x08 // Size: 0x04
	float MaxCheatTimes; // Offset: 0x0c // Size: 0x04
	char pad_0x10[0x1c]; // Offset: 0x10 // Size: 0x1c
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShootVerifyParameter
// Size: 0x18 // Inherited bytes: 0x00
struct FShootVerifyParameter {
	// Fields
	struct ASTExtraShootWeapon* Weapon; // Offset: 0x00 // Size: 0x08
	struct ASTExtraCharacter* Shooter; // Offset: 0x08 // Size: 0x08
	char pad_0x10[0x8]; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.IndefiniteVerifyCfg
// Size: 0x08 // Inherited bytes: 0x00
struct FIndefiniteVerifyCfg {
	// Fields
	int CountThreshold; // Offset: 0x00 // Size: 0x04
	float PercentThreshold; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ServerCheckBox
// Size: 0x4c // Inherited bytes: 0x00
struct FServerCheckBox {
	// Fields
	enum class ESTEPoseState PoseID; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector BodyBoundBoxExtent; // Offset: 0x04 // Size: 0x0c
	struct FVector HeadBoundBoxExtent; // Offset: 0x10 // Size: 0x0c
	struct FVector Offset; // Offset: 0x1c // Size: 0x0c
	struct FVector PitchOffset; // Offset: 0x28 // Size: 0x0c
	float ReferenceHSlope; // Offset: 0x34 // Size: 0x04
	float ReferenceVSlope; // Offset: 0x38 // Size: 0x04
	float HMinScale; // Offset: 0x3c // Size: 0x04
	float VMinScale; // Offset: 0x40 // Size: 0x04
	float HMaxScale; // Offset: 0x44 // Size: 0x04
	float VMaxScale; // Offset: 0x48 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HeightLOD
// Size: 0x08 // Inherited bytes: 0x00
struct FHeightLOD {
	// Fields
	float Height; // Offset: 0x00 // Size: 0x04
	int LOD; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.LensFlareElement
// Size: 0x28 // Inherited bytes: 0x00
struct FLensFlareElement {
	// Fields
	float Position; // Offset: 0x00 // Size: 0x04
	float Size; // Offset: 0x04 // Size: 0x04
	struct FVector2D UV0; // Offset: 0x08 // Size: 0x08
	struct FVector2D UVSize; // Offset: 0x10 // Size: 0x08
	struct FLinearColor Color; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.LevelArearAssetInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FLevelArearAssetInfo {
	// Fields
	struct TArray<struct UTexture*> TextureList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct UMaterialInterface*> MaterialList; // Offset: 0x10 // Size: 0x10
	struct TArray<struct USkeletalMesh*> SkeletalMeshList; // Offset: 0x20 // Size: 0x10
	struct TArray<struct UStaticMesh*> StaticMeshList; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ZombieWaveUIState
// Size: 0x18 // Inherited bytes: 0x00
struct FZombieWaveUIState {
	// Fields
	int TypeId; // Offset: 0x00 // Size: 0x04
	int CountdownTime; // Offset: 0x04 // Size: 0x04
	struct FString ShowString; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.LobbyBgMatData
// Size: 0x10 // Inherited bytes: 0x00
struct FLobbyBgMatData {
	// Fields
	enum class ELobbyBgMatType matType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UMaterialInstance* matPtr; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.XTaskSaveData
// Size: 0x14 // Inherited bytes: 0x00
struct FXTaskSaveData {
	// Fields
	int TaskId; // Offset: 0x00 // Size: 0x04
	int CurProgress; // Offset: 0x04 // Size: 0x04
	int AimProgress; // Offset: 0x08 // Size: 0x04
	int FobidShow; // Offset: 0x0c // Size: 0x04
	enum class FXTaskStateType State; // Offset: 0x10 // Size: 0x01
	enum class EXTaskType TaskType; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x2]; // Offset: 0x12 // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.XTaskExtraSyncData
// Size: 0x20 // Inherited bytes: 0x00
struct FXTaskExtraSyncData {
	// Fields
	int TaskId; // Offset: 0x00 // Size: 0x04
	enum class EXTaskType TaskType; // Offset: 0x04 // Size: 0x01
	bool TimerEnabled; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	float CurAccumTime; // Offset: 0x08 // Size: 0x04
	float TotalTime; // Offset: 0x0c // Size: 0x04
	float ServerStartTime; // Offset: 0x10 // Size: 0x04
	struct FVector Position; // Offset: 0x14 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.XTaskSyncData
// Size: 0x10 // Inherited bytes: 0x00
struct FXTaskSyncData {
	// Fields
	int TaskId; // Offset: 0x00 // Size: 0x04
	int CurProgress; // Offset: 0x04 // Size: 0x04
	int AimProgress; // Offset: 0x08 // Size: 0x04
	enum class FXTaskStateType State; // Offset: 0x0c // Size: 0x01
	enum class EXTaskType TaskType; // Offset: 0x0d // Size: 0x01
	char pad_0xE[0x2]; // Offset: 0x0e // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.MarkDispatchAction
// Size: 0xa0 // Inherited bytes: 0x00
struct FMarkDispatchAction {
	// Fields
	enum class EMarkDispatchActionType ActionType; // Offset: 0x00 // Size: 0x01
	enum class EMarkDispatchRange RangeType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct FMarkSyncData SyncData; // Offset: 0x08 // Size: 0x70
	float DispatchDelayTime; // Offset: 0x78 // Size: 0x04
	float RangeRad; // Offset: 0x7c // Size: 0x04
	struct TWeakObjectPtr<struct ASTExtraPlayerState> WeakPlayerState; // Offset: 0x80 // Size: 0x08
	float DispatchTime; // Offset: 0x88 // Size: 0x04
	bool bIsFromLocal; // Offset: 0x8c // Size: 0x01
	char pad_0x8D[0x3]; // Offset: 0x8d // Size: 0x03
	DelegateProperty OnMapAlertSet; // Offset: 0x90 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MapMarksUpdateInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FMapMarksUpdateInfo {
	// Fields
	struct TArray<struct FVector2D> MultiMarkLocs; // Offset: 0x00 // Size: 0x10
	bool IsShow; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	float Opacity; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MapImageMarkData
// Size: 0x40 // Inherited bytes: 0x00
struct FMapImageMarkData {
	// Fields
	int ConfigId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UImage* Image; // Offset: 0x08 // Size: 0x08
	struct FVector CurrentWorldPos; // Offset: 0x10 // Size: 0x0c
	struct FRotator CurrentWorldRot; // Offset: 0x1c // Size: 0x0c
	struct FVector2D OriginalSize; // Offset: 0x28 // Size: 0x08
	bool bIsUpdateSize; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	struct FVector2D MaxSize; // Offset: 0x34 // Size: 0x08
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.UpdateStateChangePorperty
// Size: 0x38 // Inherited bytes: 0x00
struct FUpdateStateChangePorperty {
	// Fields
	struct UWidget* UpdateWidget; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FString> IconPathArray; // Offset: 0x08 // Size: 0x10
	struct TArray<enum class ESlateVisibility> IconVisibleArray; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FLinearColor> IconColorArray; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SingleMarkInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FSingleMarkInfo {
	// Fields
	enum class EUIMarkState MarkState; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UMapUIMarkBaseWidget* pWidget; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.MatScalarBlendEffect
// Size: 0xb0 // Inherited bytes: 0x00
struct FMatScalarBlendEffect {
	// Fields
	struct FRuntimeFloatCurve BlendCurve; // Offset: 0x00 // Size: 0x78
	struct FName ParamName; // Offset: 0x78 // Size: 0x08
	struct UMeshComponent* BlendMeshComponent; // Offset: 0x80 // Size: 0x08
	struct UMaterialInterface* OriMatInstance; // Offset: 0x88 // Size: 0x08
	struct UMaterialInstanceDynamic* MatDynamic; // Offset: 0x90 // Size: 0x08
	char pad_0x98[0x18]; // Offset: 0x98 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.MobAIStateData
// Size: 0xb8 // Inherited bytes: 0x00
struct FMobAIStateData {
	// Fields
	char pad_0x0[0xb8]; // Offset: 0x00 // Size: 0xb8
};

// Object Name: ScriptStruct ShadowTrackerExtra.HatredInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FHatredInfo {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.NoiseCheckResult
// Size: 0x08 // Inherited bytes: 0x00
struct FNoiseCheckResult {
	// Fields
	bool Result; // Offset: 0x00 // Size: 0x01
	enum class ESTAINoiseType NoiseType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float LoudnessHeard; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ModAdapterSpawnInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FModAdapterSpawnInfo {
	// Fields
	struct AActor* RelatedActor; // Offset: 0x00 // Size: 0x08
	struct FName LightType; // Offset: 0x08 // Size: 0x08
	struct FTransform SpawnTransform; // Offset: 0x10 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterAnimGroup
// Size: 0x18 // Inherited bytes: 0x00
struct FMonsterAnimGroup {
	// Fields
	int MonsterID; // Offset: 0x00 // Size: 0x04
	int RandomAnimID; // Offset: 0x04 // Size: 0x04
	struct TArray<struct TWeakObjectPtr<struct ASTExtraSimpleCharacter>> MonsterGroup; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterSpecialStateTableRow
// Size: 0x38 // Inherited bytes: 0x00
struct FMonsterSpecialStateTableRow {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> BornSkillList; // Offset: 0x08 // Size: 0x10
	struct TArray<int> RageSkillIdList; // Offset: 0x18 // Size: 0x10
	struct TArray<int> AloneSkillIdList; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterTableRow
// Size: 0xe8 // Inherited bytes: 0x00
struct FMonsterTableRow {
	// Fields
	int MonsterID; // Offset: 0x00 // Size: 0x04
	int MonsterTeamID; // Offset: 0x04 // Size: 0x04
	struct FString MonsterName; // Offset: 0x08 // Size: 0x10
	struct FString MonsterNameID; // Offset: 0x18 // Size: 0x10
	int MonsterLevel; // Offset: 0x28 // Size: 0x04
	int BPID; // Offset: 0x2c // Size: 0x04
	int Gold; // Offset: 0x30 // Size: 0x04
	int SuperGold; // Offset: 0x34 // Size: 0x04
	int Score; // Offset: 0x38 // Size: 0x04
	int SpecialStateID; // Offset: 0x3c // Size: 0x04
	int DropID; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FMonsterDropTableRow DropData; // Offset: 0x48 // Size: 0x28
	int Rarity; // Offset: 0x70 // Size: 0x04
	int MonsterType; // Offset: 0x74 // Size: 0x04
	int MonsterFuncType; // Offset: 0x78 // Size: 0x04
	int Attack; // Offset: 0x7c // Size: 0x04
	int Armor; // Offset: 0x80 // Size: 0x04
	int Pierce; // Offset: 0x84 // Size: 0x04
	int Health; // Offset: 0x88 // Size: 0x04
	int AI; // Offset: 0x8c // Size: 0x04
	int SkillStrength; // Offset: 0x90 // Size: 0x04
	int HealthBarCount; // Offset: 0x94 // Size: 0x04
	float SpeedScale; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
	struct TArray<float> Resistances; // Offset: 0xa0 // Size: 0x10
	struct TArray<int> PaSkillIds; // Offset: 0xb0 // Size: 0x10
	struct FString BPPath; // Offset: 0xc0 // Size: 0x10
	int RageTimer; // Offset: 0xd0 // Size: 0x04
	int NeedSendAttackFlow; // Offset: 0xd4 // Size: 0x04
	bool bEnableAvatar; // Offset: 0xd8 // Size: 0x01
	char pad_0xD9[0x3]; // Offset: 0xd9 // Size: 0x03
	float TakeDamageScale; // Offset: 0xdc // Size: 0x04
	float DamageScale; // Offset: 0xe0 // Size: 0x04
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterDropTableRow
// Size: 0x28 // Inherited bytes: 0x00
struct FMonsterDropTableRow {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FMonsterSingleDropIds> DropIds; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FMonsterSingleBulletDropIds> BulletDropIds; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterSingleBulletDropIds
// Size: 0x20 // Inherited bytes: 0x00
struct FMonsterSingleBulletDropIds {
	// Fields
	struct TArray<int> BulletDropIds; // Offset: 0x00 // Size: 0x10
	struct TArray<int> BulletDropParams; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterSingleDropIds
// Size: 0x10 // Inherited bytes: 0x00
struct FMonsterSingleDropIds {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterFloatingTextData
// Size: 0x14 // Inherited bytes: 0x00
struct FMonsterFloatingTextData {
	// Fields
	float BaseDamage; // Offset: 0x00 // Size: 0x04
	bool IsHeadShot; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct FVector_NetQuantize ImpactPoint; // Offset: 0x08 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpawnTableData
// Size: 0x18 // Inherited bytes: 0x00
struct FSpawnTableData {
	// Fields
	int PawnID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString PathName; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpawnGroupItemInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FSpawnGroupItemInfo {
	// Fields
	int PawnGroupID; // Offset: 0x00 // Size: 0x04
	int PawnID; // Offset: 0x04 // Size: 0x04
	int PawnPercent; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterSpeciesParams
// Size: 0x68 // Inherited bytes: 0x00
struct FMonsterSpeciesParams {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FMonsterParams Params; // Offset: 0x08 // Size: 0x58
	int SingleId; // Offset: 0x60 // Size: 0x04
	bool bForceSpawn; // Offset: 0x64 // Size: 0x01
	char pad_0x65[0x3]; // Offset: 0x65 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterParams
// Size: 0x58 // Inherited bytes: 0x00
struct FMonsterParams {
	// Fields
	char pad_0x0[0x58]; // Offset: 0x00 // Size: 0x58
};

// Object Name: ScriptStruct ShadowTrackerExtra.DelaySpawnActionTimerRegister
// Size: 0x08 // Inherited bytes: 0x00
struct FDelaySpawnActionTimerRegister {
	// Fields
	int RegisterID; // Offset: 0x00 // Size: 0x04
	int ActionType; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.GM_MonsterSpawnAction
// Size: 0x20 // Inherited bytes: 0x00
struct FGM_MonsterSpawnAction {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	int Times; // Offset: 0x04 // Size: 0x04
	int interval; // Offset: 0x08 // Size: 0x04
	int MinRandTime; // Offset: 0x0c // Size: 0x04
	int MaxRandTime; // Offset: 0x10 // Size: 0x04
	int MaxLimit; // Offset: 0x14 // Size: 0x04
	int LimitType; // Offset: 0x18 // Size: 0x04
	int AdjustPlanID; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterSpawnAction
// Size: 0x38 // Inherited bytes: 0x00
struct FMonsterSpawnAction {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x00 // Size: 0x38
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterSpawnPlanIDAdjust
// Size: 0x0c // Inherited bytes: 0x00
struct FMonsterSpawnPlanIDAdjust {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterSpawnPlan
// Size: 0x10 // Inherited bytes: 0x00
struct FMonsterSpawnPlan {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterLimit
// Size: 0x0c // Inherited bytes: 0x00
struct FMonsterLimit {
	// Fields
	int WeatherPhase; // Offset: 0x00 // Size: 0x04
	int NumLimit; // Offset: 0x04 // Size: 0x04
	int CurRefreshNum; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.LevelMonsterGenerateInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FLevelMonsterGenerateInfo {
	// Fields
	struct FGameLevelDesc LevelDesc; // Offset: 0x00 // Size: 0x18
	struct TArray<struct FMonsterGenerateInfo> DelayGenerateInfoList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.LevelMonsterWaveRun
// Size: 0x28 // Inherited bytes: 0x00
struct FLevelMonsterWaveRun {
	// Fields
	struct FGameLevelDesc LevelDesc; // Offset: 0x00 // Size: 0x18
	struct TArray<struct FMonsterWaveRunInfo> WaveRunInfoList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterWaveRunInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FMonsterWaveRunInfo {
	// Fields
	int CallNum; // Offset: 0x00 // Size: 0x04
	int TotalMonsterNum; // Offset: 0x04 // Size: 0x04
	int GenerateMonsterNum; // Offset: 0x08 // Size: 0x04
	int DeadMonsterNum; // Offset: 0x0c // Size: 0x04
	int EndNum; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.LevelMonsterWaveCfg
// Size: 0x30 // Inherited bytes: 0x00
struct FLevelMonsterWaveCfg {
	// Fields
	struct FGameLevelDesc LevelDesc; // Offset: 0x00 // Size: 0x18
	int DiffcultPerc; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FMonsterWave> WaveCfgList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayerMonsterSpot
// Size: 0x18 // Inherited bytes: 0x00
struct FPlayerMonsterSpot {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FVector> SpotList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterLine
// Size: 0x1c // Inherited bytes: 0x00
struct FMonsterLine {
	// Fields
	int CallNum; // Offset: 0x00 // Size: 0x04
	struct FVector StartPos; // Offset: 0x04 // Size: 0x0c
	struct FVector EndPos; // Offset: 0x10 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemCallMonsterLimit
// Size: 0x0c // Inherited bytes: 0x00
struct FItemCallMonsterLimit {
	// Fields
	int WeatherPhase; // Offset: 0x00 // Size: 0x04
	int LimitItemCallNum; // Offset: 0x04 // Size: 0x04
	int LimitTotalNum; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirDragConfig
// Size: 0x58 // Inherited bytes: 0x00
struct FAirDragConfig {
	// Fields
	struct FMappedData SpeedToForwardForceMap; // Offset: 0x00 // Size: 0x10
	struct FMappedData ForwardVelocityDotToForwardForceMap; // Offset: 0x10 // Size: 0x10
	struct UCurveFloat* SpeedToForwardMergeCurve; // Offset: 0x20 // Size: 0x08
	struct UCurveVector* SpeedDragCurve; // Offset: 0x28 // Size: 0x08
	struct UCurveVector* HeightToSpeedCurve; // Offset: 0x30 // Size: 0x08
	float EngineOffDragScale; // Offset: 0x38 // Size: 0x04
	float ZeroThrottleDragThreshold; // Offset: 0x3c // Size: 0x04
	float ZeroThrottleRelAltitudeDragThreshold; // Offset: 0x40 // Size: 0x04
	struct FMappedData ZeroThrottleDrag; // Offset: 0x44 // Size: 0x10
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MappedData
// Size: 0x10 // Inherited bytes: 0x00
struct FMappedData {
	// Fields
	struct FVector2D InputMap; // Offset: 0x00 // Size: 0x08
	struct FVector2D OutputMap; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirControlLimitConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FAirControlLimitConfig {
	// Fields
	float MaxRoll; // Offset: 0x00 // Size: 0x04
	float MaxPitch; // Offset: 0x04 // Size: 0x04
	float MaxYaw; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirControlForceConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FAirControlForceConfig {
	// Fields
	float TorqueMassScale; // Offset: 0x00 // Size: 0x04
	struct FVector StaticCOMOffset; // Offset: 0x04 // Size: 0x0c
	struct FMappedData SpeedToControlForceMap; // Offset: 0x10 // Size: 0x10
	struct UCurveVector* RollControlCurve; // Offset: 0x20 // Size: 0x08
	struct UCurveVector* PitchControlCurve; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirControlTorqueConfig
// Size: 0x88 // Inherited bytes: 0x00
struct FAirControlTorqueConfig {
	// Fields
	float RollForceScale; // Offset: 0x00 // Size: 0x04
	float PitchForceScale; // Offset: 0x04 // Size: 0x04
	struct FMappedData SpeedToRollForceMap; // Offset: 0x08 // Size: 0x10
	struct FMappedData SpeedToPitchForceMap; // Offset: 0x18 // Size: 0x10
	struct FMappedData SpeedToRollDampingMap; // Offset: 0x28 // Size: 0x10
	struct FMappedData SpeedToPitchDampingMap; // Offset: 0x38 // Size: 0x10
	struct FMappedData SpeedToYawDampingMap; // Offset: 0x48 // Size: 0x10
	struct FMappedData RollTargetForceMap; // Offset: 0x58 // Size: 0x10
	struct FMappedData PitchTargetForceMap; // Offset: 0x68 // Size: 0x10
	struct FMappedData RollToPitchForceMap; // Offset: 0x78 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirLiftConfig
// Size: 0xb8 // Inherited bytes: 0x00
struct FAirLiftConfig {
	// Fields
	float LiftForceMassScale; // Offset: 0x00 // Size: 0x04
	struct FMappedData SpeedToLiftForceMap; // Offset: 0x04 // Size: 0x10
	struct FVector LiftForceStaticOffset; // Offset: 0x14 // Size: 0x0c
	struct FMappedData RollLiftOffsetMap; // Offset: 0x20 // Size: 0x10
	struct FVector RollLiftOffsetVector; // Offset: 0x30 // Size: 0x0c
	struct FMappedData PitchLiftOffsetMap; // Offset: 0x3c // Size: 0x10
	struct FVector PitchLiftOffsetVector; // Offset: 0x4c // Size: 0x0c
	float GroundEffectMaxDistance; // Offset: 0x58 // Size: 0x04
	float GroundEffectMassScale; // Offset: 0x5c // Size: 0x04
	struct FVector GroundEffectExtent; // Offset: 0x60 // Size: 0x0c
	struct FMappedData GroundEffectSpeedMap; // Offset: 0x6c // Size: 0x10
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
	struct UCurveFloat* GroundEffectPowerCurve; // Offset: 0x80 // Size: 0x08
	struct UCurveFloat* GroundEffectOffsetCurve; // Offset: 0x88 // Size: 0x08
	struct FVector GroundEffectTraceOffset; // Offset: 0x90 // Size: 0x0c
	struct FMappedData GroundEffectAlphaOffsetMap; // Offset: 0x9c // Size: 0x10
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct UCurveFloat* AltitudeToLiftFactorCurve; // Offset: 0xb0 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirEngineState
// Size: 0x2c // Inherited bytes: 0x00
struct FAirEngineState {
	// Fields
	bool bIsEngineOn; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float EngineOnAlpha; // Offset: 0x04 // Size: 0x04
	float EnginePower; // Offset: 0x08 // Size: 0x04
	float EnginePowerAlpha; // Offset: 0x0c // Size: 0x04
	float CurrentEngineThrottle; // Offset: 0x10 // Size: 0x04
	float CurrentRotorThrottle; // Offset: 0x14 // Size: 0x04
	float CurrentRotorRPM; // Offset: 0x18 // Size: 0x04
	float TargetRotorRPM; // Offset: 0x1c // Size: 0x04
	float CurrentRotorRotation; // Offset: 0x20 // Size: 0x04
	float CurrentRotorRotationFast; // Offset: 0x24 // Size: 0x04
	bool bIsFastRotorActive; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirVehicleState
// Size: 0x34 // Inherited bytes: 0x00
struct FAirVehicleState {
	// Fields
	float SpeedInKm; // Offset: 0x00 // Size: 0x04
	float RelativeAltitudeMeters; // Offset: 0x04 // Size: 0x04
	float RelativeAltitudeAlpha; // Offset: 0x08 // Size: 0x04
	float AbsoluteAltitudeMeters; // Offset: 0x0c // Size: 0x04
	float ClimbRate; // Offset: 0x10 // Size: 0x04
	float EngineForceNormalized; // Offset: 0x14 // Size: 0x04
	float GroundEffectAlpha; // Offset: 0x18 // Size: 0x04
	struct FVector GroundEffectLocation; // Offset: 0x1c // Size: 0x0c
	struct FVector GroundEffectNormal; // Offset: 0x28 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirEngineConfig
// Size: 0xa0 // Inherited bytes: 0x00
struct FAirEngineConfig {
	// Fields
	float TorqueMassScale; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UCurveVector* EngineCurve; // Offset: 0x08 // Size: 0x08
	struct FVector StaticCOMOffset; // Offset: 0x10 // Size: 0x0c
	struct FVector RollInputOffsetVector; // Offset: 0x1c // Size: 0x0c
	struct FMappedData RollInputOffsetMap; // Offset: 0x28 // Size: 0x10
	struct FVector PitchInputOffsetVector; // Offset: 0x38 // Size: 0x0c
	struct FMappedData PitchInputOffsetMap; // Offset: 0x44 // Size: 0x10
	struct FMappedData ElevationScalarSpeedMap; // Offset: 0x54 // Size: 0x10
	struct FMappedData ReverseRelativeAltMap; // Offset: 0x64 // Size: 0x10
	struct FMappedData ReverseBackSpeedMap; // Offset: 0x74 // Size: 0x10
	float MinThrottleForBackForce; // Offset: 0x84 // Size: 0x04
	float MinSpeedInKmForFastOn; // Offset: 0x88 // Size: 0x04
	float MinRotorRpmForFastOn; // Offset: 0x8c // Size: 0x04
	struct FInputInterpSetting FastOnInterp; // Offset: 0x90 // Size: 0x08
	struct FInputInterpSetting SlowOnInterp; // Offset: 0x98 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.InputInterpSetting
// Size: 0x08 // Inherited bytes: 0x00
struct FInputInterpSetting {
	// Fields
	float RiseRate; // Offset: 0x00 // Size: 0x04
	float FallRate; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirRotorConfig
// Size: 0x48 // Inherited bytes: 0x00
struct FAirRotorConfig {
	// Fields
	struct FInputInterpSetting ThrottleInterpForward; // Offset: 0x00 // Size: 0x08
	struct FInputInterpSetting ThrottleInterpReverse; // Offset: 0x08 // Size: 0x08
	struct FMappedData RotorSpeedThrottleOffset; // Offset: 0x10 // Size: 0x10
	struct FMappedData EnginePowerRotorSpeedScale; // Offset: 0x20 // Size: 0x10
	struct UCurveFloat* ThrottleToRPMCurve; // Offset: 0x30 // Size: 0x08
	float EngineOnRPMInterpSpeed; // Offset: 0x38 // Size: 0x04
	float EngineOffRPMInterpSpeed; // Offset: 0x3c // Size: 0x04
	float FastRotorOnSpeed; // Offset: 0x40 // Size: 0x04
	float FastRotorOffSpeed; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirInputConfig
// Size: 0x20 // Inherited bytes: 0x00
struct FAirInputConfig {
	// Fields
	struct FInputInterpSetting RollInterpolation; // Offset: 0x00 // Size: 0x08
	struct FInputInterpSetting PitchInterpolation; // Offset: 0x08 // Size: 0x08
	struct FInputInterpSetting ThrottleForwardInterpolation; // Offset: 0x10 // Size: 0x08
	struct FInputInterpSetting ThrottleBackwardInterpolation; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirGeneralConfig
// Size: 0x20 // Inherited bytes: 0x00
struct FAirGeneralConfig {
	// Fields
	bool bCheckRelativeAltitude; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float MaxRelAltitudeDistInM; // Offset: 0x04 // Size: 0x04
	float MaxTraceDistInM; // Offset: 0x08 // Size: 0x04
	float MinSpeedForAirTick; // Offset: 0x0c // Size: 0x04
	struct FMappedData SpeedToAnimInputMap; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirInput
// Size: 0x10 // Inherited bytes: 0x00
struct FAirInput {
	// Fields
	float Throttle; // Offset: 0x00 // Size: 0x04
	struct FVector AxisControls; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.RealtimeMoveSpeedCheck
// Size: 0x20 // Inherited bytes: 0x00
struct FRealtimeMoveSpeedCheck {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct ShadowTrackerExtra.ClientMoveSpeedCheck
// Size: 0x28 // Inherited bytes: 0x00
struct FClientMoveSpeedCheck {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.ClientTimeSpeedCheck
// Size: 0x3c // Inherited bytes: 0x00
struct FClientTimeSpeedCheck {
	// Fields
	char pad_0x0[0x24]; // Offset: 0x00 // Size: 0x24
	float CheckTimeDeltaInterval; // Offset: 0x24 // Size: 0x04
	float MaxClientTimeDeltaAheadServer; // Offset: 0x28 // Size: 0x04
	float MaxPublishForbidMoveTime; // Offset: 0x2c // Size: 0x04
	float MaxServerTimeDelta; // Offset: 0x30 // Size: 0x04
	float MaxClientAheadServerTotalTime; // Offset: 0x34 // Size: 0x04
	int MaxProcessCounterOneFrame; // Offset: 0x38 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.Strategy6MoveVector
// Size: 0x20 // Inherited bytes: 0x00
struct FStrategy6MoveVector {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterZMoveDistanceCheck
// Size: 0x34 // Inherited bytes: 0x00
struct FCharacterZMoveDistanceCheck {
	// Fields
	uint32_t bIsOpen; // Offset: 0x00 // Size: 0x04
	int MaxAllowCheatMoveTimes; // Offset: 0x04 // Size: 0x04
	float MaxAllowMoveZHeight; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x28]; // Offset: 0x0c // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.MoveCheatAntiStrategy2
// Size: 0x58 // Inherited bytes: 0x00
struct FMoveCheatAntiStrategy2 {
	// Fields
	uint32_t bIsOpen; // Offset: 0x00 // Size: 0x04
	float CheckTimeSpeedIntervel; // Offset: 0x04 // Size: 0x04
	int MaxAllowCheatMoveTimes; // Offset: 0x08 // Size: 0x04
	float MaxMoveDistanceScaleFactor; // Offset: 0x0c // Size: 0x04
	float MaxPublishForbidMoveTime; // Offset: 0x10 // Size: 0x04
	float MaxMoveSpeedValue; // Offset: 0x14 // Size: 0x04
	int MaxSpeedSplitNum; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x3c]; // Offset: 0x1c // Size: 0x3c
};

// Object Name: ScriptStruct ShadowTrackerExtra.MoveCheatAntiStrategy
// Size: 0x90 // Inherited bytes: 0x00
struct FMoveCheatAntiStrategy {
	// Fields
	uint32_t bIsOpen; // Offset: 0x00 // Size: 0x04
	float MaxAllowClientSideTimeLag; // Offset: 0x04 // Size: 0x04
	float CheckTimeSpeedIntervel; // Offset: 0x08 // Size: 0x04
	int MaxAllowCheatMoveTimes; // Offset: 0x0c // Size: 0x04
	float MaxMoveDistanceScaleFactor; // Offset: 0x10 // Size: 0x04
	float MaxPublishForbidMoveTime; // Offset: 0x14 // Size: 0x04
	float ServerSendPingIntervel; // Offset: 0x18 // Size: 0x04
	float MaxMoveSpeedValue; // Offset: 0x1c // Size: 0x04
	int MaxSpeedSplitNum; // Offset: 0x20 // Size: 0x04
	int MaxContinuousCheatMoveTimes; // Offset: 0x24 // Size: 0x04
	int MaxClientSpeed; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x64]; // Offset: 0x2c // Size: 0x64
};

// Object Name: ScriptStruct ShadowTrackerExtra.SubLevelComponentMapValue
// Size: 0x140 // Inherited bytes: 0x00
struct FSubLevelComponentMapValue {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct TArray<int> IndexOffsetArray; // Offset: 0x10 // Size: 0x10
	struct TArray<int> VertexOffsetIndex; // Offset: 0x20 // Size: 0x10
	struct TArray<int> BorderIndex1; // Offset: 0x30 // Size: 0x10
	struct TArray<int> BorderIndex2; // Offset: 0x40 // Size: 0x10
	struct TArray<int> BorderIndex3; // Offset: 0x50 // Size: 0x10
	struct TArray<int> BorderIndex4; // Offset: 0x60 // Size: 0x10
	struct TArray<int> UnderBorderIndex1; // Offset: 0x70 // Size: 0x10
	struct TArray<int> UnderBorderIndex2; // Offset: 0x80 // Size: 0x10
	struct TArray<int> UnderBorderIndex3; // Offset: 0x90 // Size: 0x10
	struct TArray<int> UnderBorderIndex4; // Offset: 0xa0 // Size: 0x10
	struct TArray<int> BorderIndicesBuffer1; // Offset: 0xb0 // Size: 0x10
	struct TArray<int> BorderIndicesBuffer2; // Offset: 0xc0 // Size: 0x10
	struct TArray<int> BorderIndicesBuffer3; // Offset: 0xd0 // Size: 0x10
	struct TArray<int> BorderIndicesBuffer4; // Offset: 0xe0 // Size: 0x10
	struct FString Sibling1Name; // Offset: 0xf0 // Size: 0x10
	struct FString Sibling2Name; // Offset: 0x100 // Size: 0x10
	struct FString Sibling3Name; // Offset: 0x110 // Size: 0x10
	struct FString Sibling4Name; // Offset: 0x120 // Size: 0x10
	int Sibling1Idx; // Offset: 0x130 // Size: 0x04
	int Sibling2Idx; // Offset: 0x134 // Size: 0x04
	int Sibling3Idx; // Offset: 0x138 // Size: 0x04
	int Sibling4Idx; // Offset: 0x13c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomMarkDataInNavigator
// Size: 0x28 // Inherited bytes: 0x00
struct FCustomMarkDataInNavigator {
	// Fields
	int MarkInstID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UUserWidget* MarkWidget; // Offset: 0x08 // Size: 0x08
	struct UTextBlock* MarkDistanceText; // Offset: 0x10 // Size: 0x08
	struct FVector MarkLocation; // Offset: 0x18 // Size: 0x0c
	bool bAdjustWhenOutRange; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.StatProfileMonitorBase
// Size: 0x10 // Inherited bytes: 0x00
struct FStatProfileMonitorBase {
	// Fields
	int MinClientNum; // Offset: 0x00 // Size: 0x04
	float StartTime; // Offset: 0x04 // Size: 0x04
	float Duration; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.NetProfileMonitorBase
// Size: 0x18 // Inherited bytes: 0x00
struct FNetProfileMonitorBase {
	// Fields
	enum class ENetProfileMonitorArg NetProfileMonitorArg; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	double Threshold; // Offset: 0x08 // Size: 0x08
	float Duration; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.NetProfileConditionBase
// Size: 0x0c // Inherited bytes: 0x00
struct FNetProfileConditionBase {
	// Fields
	enum class ENetProfileCondition Condition; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Duration; // Offset: 0x04 // Size: 0x04
	char pad_0x8[0x4]; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.NetProfileTimeBase
// Size: 0x0c // Inherited bytes: 0x00
struct FNetProfileTimeBase {
	// Fields
	float StartTime; // Offset: 0x00 // Size: 0x04
	float Duration; // Offset: 0x04 // Size: 0x04
	char pad_0x8[0x4]; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponDurabilityConfig
// Size: 0x28 // Inherited bytes: 0x00
struct FWeaponDurabilityConfig {
	// Fields
	float LowDurabilityRate; // Offset: 0x00 // Size: 0x04
	float GameEndReduceRate; // Offset: 0x04 // Size: 0x04
	struct FString DurabilityLowAttrModifierID; // Offset: 0x08 // Size: 0x10
	struct FString DurabilityLossAttrModifierID; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.BattleWeaponItemDisplayData
// Size: 0x20 // Inherited bytes: 0x00
struct FBattleWeaponItemDisplayData {
	// Fields
	struct FString ItemName; // Offset: 0x00 // Size: 0x10
	struct FString WhiteIconPath; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.BulletHitInfoRepData
// Size: 0x40 // Inherited bytes: 0x00
struct FBulletHitInfoRepData {
	// Fields
	struct FVector ImpactPoint; // Offset: 0x00 // Size: 0x0c
	struct FVector_NetQuantizeNormal ImpactNormal; // Offset: 0x0c // Size: 0x0c
	struct FVector ShootMomentMuzzlePos; // Offset: 0x18 // Size: 0x0c
	char SurfaceType; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x28 // Size: 0x08
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // Offset: 0x30 // Size: 0x08
	int ClientTimeStamp; // Offset: 0x38 // Size: 0x04
	char HitBodyType; // Offset: 0x3c // Size: 0x01
	char bIsUnderWater : 1; // Offset: 0x3d // Size: 0x01
	char pad_0x3D_1 : 7; // Offset: 0x3d // Size: 0x01
	char pad_0x3E[0x2]; // Offset: 0x3e // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponAttachmentSlot
// Size: 0x04 // Inherited bytes: 0x00
struct FWeaponAttachmentSlot {
	// Fields
	int TypeSpecificID; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ScopeZoomConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FScopeZoomConfig {
	// Fields
	int DisplayMaxScale; // Offset: 0x00 // Size: 0x04
	int DisplayMinScale; // Offset: 0x04 // Size: 0x04
	struct UCurveFloat* FovCurve; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SwitchWeaponReplicatedToOwnerData
// Size: 0x08 // Inherited bytes: 0x00
struct FSwitchWeaponReplicatedToOwnerData {
	// Fields
	enum class ESurviveWeaponPropSlot Slot; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int OperationIndex; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DestroyWeaponReplicatedToOwnerData
// Size: 0x10 // Inherited bytes: 0x00
struct FDestroyWeaponReplicatedToOwnerData {
	// Fields
	struct FName LogicSocket; // Offset: 0x00 // Size: 0x08
	int OperationIndex; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DisUseWeaponReplicatedToOwnerData
// Size: 0x04 // Inherited bytes: 0x00
struct FDisUseWeaponReplicatedToOwnerData {
	// Fields
	int OperationIndex; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.UseWeaponReplicatedToOwnerData
// Size: 0x10 // Inherited bytes: 0x00
struct FUseWeaponReplicatedToOwnerData {
	// Fields
	struct FName LogicSocket; // Offset: 0x00 // Size: 0x08
	bool bNeedWaitHandleSpawnFinishedOnClient; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int OperationIndex; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AutoAimingConfigByGameMode
// Size: 0x118 // Inherited bytes: 0x00
struct FAutoAimingConfigByGameMode {
	// Fields
	struct AGameStateBase* GameStateClass; // Offset: 0x00 // Size: 0x08
	struct FAutoAimingConfig AutoAimingConfig; // Offset: 0x08 // Size: 0x110
};

// Object Name: ScriptStruct ShadowTrackerExtra.SDeviation
// Size: 0x44 // Inherited bytes: 0x00
struct FSDeviation {
	// Fields
	float DeviationBase; // Offset: 0x00 // Size: 0x04
	float DeviationBaseAim; // Offset: 0x04 // Size: 0x04
	float DeviationBaseADS; // Offset: 0x08 // Size: 0x04
	float DeviationRecoilGain; // Offset: 0x0c // Size: 0x04
	float DeviationRecoilGainAim; // Offset: 0x10 // Size: 0x04
	float DeviationRecoilGainADS; // Offset: 0x14 // Size: 0x04
	float DeviationMax; // Offset: 0x18 // Size: 0x04
	float DeviationMinMove; // Offset: 0x1c // Size: 0x04
	float DeviationMaxMove; // Offset: 0x20 // Size: 0x04
	float DeviationMoveMultiplier; // Offset: 0x24 // Size: 0x04
	float DeviationMoveMinRefrence; // Offset: 0x28 // Size: 0x04
	float DeviationMoveMaxRefrence; // Offset: 0x2c // Size: 0x04
	float DeviationStanceStand; // Offset: 0x30 // Size: 0x04
	float DeviationStanceCrouch; // Offset: 0x34 // Size: 0x04
	float DeviationStanceProne; // Offset: 0x38 // Size: 0x04
	float DeviationStanceJump; // Offset: 0x3c // Size: 0x04
	float DeviationShoulderMultiplier; // Offset: 0x40 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SRecoilInfo
// Size: 0x70 // Inherited bytes: 0x00
struct FSRecoilInfo {
	// Fields
	float VerticalRecoilMin; // Offset: 0x00 // Size: 0x04
	float VerticalRecoilMax; // Offset: 0x04 // Size: 0x04
	float VerticalRecoilVariation; // Offset: 0x08 // Size: 0x04
	float VerticalRecoveryModifier; // Offset: 0x0c // Size: 0x04
	float VerticalRecoveryClamp; // Offset: 0x10 // Size: 0x04
	float VerticalRecoveryMax; // Offset: 0x14 // Size: 0x04
	float LeftMax; // Offset: 0x18 // Size: 0x04
	float RightMax; // Offset: 0x1c // Size: 0x04
	float HorizontalTendency; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct UCurveVector* RecoilCurve; // Offset: 0x28 // Size: 0x08
	int BulletPerSwitch; // Offset: 0x30 // Size: 0x04
	float TimePerSwitch; // Offset: 0x34 // Size: 0x04
	bool SwitchOnTime; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	float RecoilSpeedVertical; // Offset: 0x3c // Size: 0x04
	float RecoilSpeedHorizontal; // Offset: 0x40 // Size: 0x04
	float RecovertySpeedVertical; // Offset: 0x44 // Size: 0x04
	float RecoilValueClimb; // Offset: 0x48 // Size: 0x04
	float RecoilValueFail; // Offset: 0x4c // Size: 0x04
	float RecoilModifierStand; // Offset: 0x50 // Size: 0x04
	float RecoilModifierCrouch; // Offset: 0x54 // Size: 0x04
	float RecoilModifierProne; // Offset: 0x58 // Size: 0x04
	float RecoilHorizontalMinScalar; // Offset: 0x5c // Size: 0x04
	float BurstEmptyDelay; // Offset: 0x60 // Size: 0x04
	bool ShootSightReturn; // Offset: 0x64 // Size: 0x01
	char pad_0x65[0x3]; // Offset: 0x65 // Size: 0x03
	float ShootSightReturnSpeed; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponNotifyActionData
// Size: 0x08 // Inherited bytes: 0x00
struct FWeaponNotifyActionData {
	// Fields
	int OperationIndex; // Offset: 0x00 // Size: 0x04
	enum class EWeaponAction Action; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponReloadData
// Size: 0x0c // Inherited bytes: 0x00
struct FWeaponReloadData {
	// Fields
	float FillTime; // Offset: 0x00 // Size: 0x04
	float SingleBulletPrepareTime; // Offset: 0x04 // Size: 0x04
	float UploadTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BattleGoodsInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FBattleGoodsInfo {
	// Fields
	int GoodID; // Offset: 0x00 // Size: 0x04
	int GoodBuyType; // Offset: 0x04 // Size: 0x04
	struct FString ItemId; // Offset: 0x08 // Size: 0x10
	int BattleLimitCount; // Offset: 0x18 // Size: 0x04
	int StoreLimitCount; // Offset: 0x1c // Size: 0x04
	int PlayerLimitCount; // Offset: 0x20 // Size: 0x04
	int TimeLimit; // Offset: 0x24 // Size: 0x04
	int itemType; // Offset: 0x28 // Size: 0x04
	int ItemOrder; // Offset: 0x2c // Size: 0x04
	int ItemCountPerBuy; // Offset: 0x30 // Size: 0x04
	int price; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DesertGoodsInfo
// Size: 0x40 // Inherited bytes: 0x38
struct FDesertGoodsInfo : FBattleGoodsInfo {
	// Fields
	int Discount; // Offset: 0x38 // Size: 0x04
	int DiscountPrice; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CurrencyInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FCurrencyInfo {
	// Fields
	enum class ECurrencyType Type; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString Name; // Offset: 0x08 // Size: 0x10
	struct FString Icon; // Offset: 0x18 // Size: 0x10
	struct FString Comment; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuyGoodsInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FBuyGoodsInfo {
	// Fields
	int BuyGoodsItemID; // Offset: 0x00 // Size: 0x04
	int BuyGoodsItemCount; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HideGoodsInfo
// Size: 0x04 // Inherited bytes: 0x00
struct FHideGoodsInfo {
	// Fields
	int GoodID; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.GoodsInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FGoodsInfo {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
	int MaxCount; // Offset: 0x08 // Size: 0x04
	bool RandomHide; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.AdditionalAudioEventMap
// Size: 0x50 // Inherited bytes: 0x00
struct FAdditionalAudioEventMap {
	// Fields
	struct TMap<struct FString, struct FMutilAudioEvent> AdditionalAudioEventMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.MutilAudioEvent
// Size: 0x10 // Inherited bytes: 0x00
struct FMutilAudioEvent {
	// Fields
	struct TArray<struct UAkAudioEvent*> MutilAudioEvent; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.OverrideAudioEventMap
// Size: 0x50 // Inherited bytes: 0x00
struct FOverrideAudioEventMap {
	// Fields
	struct TMap<struct FString, struct UAkAudioEvent*> OverrideAudioEventMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.TeamData
// Size: 0x10 // Inherited bytes: 0x00
struct FTeamData {
	// Fields
	struct TArray<struct FHeadItem> TeamHeadItems; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.HeadItem
// Size: 0x18 // Inherited bytes: 0x00
struct FHeadItem {
	// Fields
	struct FString PlayerName; // Offset: 0x00 // Size: 0x10
	struct UOBModePositionWidget* HeadItemWidget; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleParticleComps
// Size: 0x10 // Inherited bytes: 0x00
struct FVehicleParticleComps {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.OpenCollisionLODAngle
// Size: 0x08 // Inherited bytes: 0x00
struct FOpenCollisionLODAngle {
	// Fields
	float DistSq; // Offset: 0x00 // Size: 0x04
	float Angle; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleDistance
// Size: 0x0c // Inherited bytes: 0x00
struct FParticleDistance {
	// Fields
	struct TWeakObjectPtr<struct UParticleSystemComponent> ParticleSystemComp; // Offset: 0x00 // Size: 0x08
	int ToPlayerDistance; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleCache
// Size: 0x18 // Inherited bytes: 0x00
struct FParticleCache {
	// Fields
	struct TArray<struct UParticleSystemComponent*> CachedParticles; // Offset: 0x00 // Size: 0x10
	char pad_0x10[0x8]; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticlePool
// Size: 0x20 // Inherited bytes: 0x00
struct FParticlePool {
	// Fields
	int VisiableParticleNum; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct TWeakObjectPtr<struct UParticleSystemComponent>> Pool; // Offset: 0x08 // Size: 0x10
	int Size; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleCacheConfig
// Size: 0x28 // Inherited bytes: 0x00
struct FParticleCacheConfig {
	// Fields
	struct FName ParticleName; // Offset: 0x00 // Size: 0x08
	float MaxCullingDistance; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FParticleCountLimit> CountLimit; // Offset: 0x10 // Size: 0x10
	enum class EDisplayPolicy DisplayPolicy; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	int DeviceLevelLimit; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleCountLimit
// Size: 0x08 // Inherited bytes: 0x00
struct FParticleCountLimit {
	// Fields
	int Level; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PenetrateSurfaceResult
// Size: 0x38 // Inherited bytes: 0x00
struct FPenetrateSurfaceResult {
	// Fields
	enum class EPhysicalSurface SurfaceType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector InPoint; // Offset: 0x04 // Size: 0x0c
	struct FVector OutPoint; // Offset: 0x10 // Size: 0x0c
	struct FVector Normal; // Offset: 0x1c // Size: 0x0c
	struct TArray<struct FName> Tags; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PersistBase
// Size: 0x08 // Inherited bytes: 0x00
struct FPersistBase {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.PersistLevelSequenceInfo
// Size: 0x60 // Inherited bytes: 0x08
struct FPersistLevelSequenceInfo : FPersistBase {
	// Fields
	struct TArray<struct FLevelSequenceBindingInfo> LevelSequenceBindings; // Offset: 0x08 // Size: 0x10
	struct ALevelSequenceActor* SequenceActorClass; // Offset: 0x18 // Size: 0x08
	struct FTransform TransfromOrigin; // Offset: 0x20 // Size: 0x30
	struct AActor* TransfromOriginActor; // Offset: 0x50 // Size: 0x08
	float StartPlayTimeSeconds; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.LevelSequenceBindingInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FLevelSequenceBindingInfo {
	// Fields
	struct FMovieSceneObjectBindingID Binding; // Offset: 0x00 // Size: 0x18
	struct AActor* Actor; // Offset: 0x18 // Size: 0x08
	bool bBindingCharacterDisableMove; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.PersistPlaySequenceInfo
// Size: 0x18 // Inherited bytes: 0x08
struct FPersistPlaySequenceInfo : FPersistBase {
	// Fields
	bool bSetUp; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	struct TWeakObjectPtr<struct AActor> OwningActor; // Offset: 0x0c // Size: 0x08
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PetMeshPackage
// Size: 0xd8 // Inherited bytes: 0x08
struct FPetMeshPackage : FAssetPackage {
	// Fields
	struct UStaticMesh* stMesh; // Offset: 0x08 // Size: 0x28
	struct USkeletalMesh* skMesh; // Offset: 0x30 // Size: 0x28
	struct UAnimInstance* animBP; // Offset: 0x58 // Size: 0x08
	struct TArray<struct FParticleAsset> ParticleData; // Offset: 0x60 // Size: 0x10
	struct UMaterialInterface* Mat; // Offset: 0x70 // Size: 0x28
	struct UMaterialInterface* MatBase; // Offset: 0x98 // Size: 0x28
	struct TArray<struct FMaterialAsset> additionalMats; // Offset: 0xc0 // Size: 0x10
	char pad_0xD0[0x8]; // Offset: 0xd0 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.PetEventPlayerStateTypeSt
// Size: 0x02 // Inherited bytes: 0x00
struct FPetEventPlayerStateTypeSt {
	// Fields
	enum class EPawnState PawnState; // Offset: 0x00 // Size: 0x01
	enum class EPawnStateChangeType StateChangeType; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.PetAttachInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FPetAttachInfo {
	// Fields
	struct FName AttachSocketName; // Offset: 0x00 // Size: 0x08
	struct FVector AttachOffset; // Offset: 0x08 // Size: 0x0c
	struct FRotator AttachRotation; // Offset: 0x14 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.FixPetAttachInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FFixPetAttachInfo {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int PetId; // Offset: 0x04 // Size: 0x04
	int Priority; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PetMontageConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FPetMontageConfig {
	// Fields
	int AnimationAssetId; // Offset: 0x00 // Size: 0x04
	int Weight; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PetEventItemIns
// Size: 0x18 // Inherited bytes: 0x00
struct FPetEventItemIns {
	// Fields
	struct FString Tips; // Offset: 0x00 // Size: 0x10
	struct UPetEventItem* EventItem; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.PickUpWrapperItem
// Size: 0x48 // Inherited bytes: 0x00
struct FPickUpWrapperItem {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x18
	int Count; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // Offset: 0x20 // Size: 0x10
	int ParentIndex; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FName ParentSideAssociationName; // Offset: 0x38 // Size: 0x08
	int ItemInstanceID; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DropEffectData
// Size: 0x20 // Inherited bytes: 0x00
struct FDropEffectData {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	float Duration; // Offset: 0x04 // Size: 0x04
	struct FString EffectPath; // Offset: 0x08 // Size: 0x10
	struct FColor EffectColor; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PickupWrapperInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FPickupWrapperInfo {
	// Fields
	struct TWeakObjectPtr<struct APickUpWrapperActor> PickUpActor; // Offset: 0x00 // Size: 0x08
	bool bRecentlyRendered; // Offset: 0x08 // Size: 0x01
	bool bEffectSpawnd; // Offset: 0x09 // Size: 0x01
	bool bShowEffect; // Offset: 0x0a // Size: 0x01
	char pad_0xB[0x1]; // Offset: 0x0b // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.PickupCountLimit
// Size: 0x08 // Inherited bytes: 0x00
struct FPickupCountLimit {
	// Fields
	int DeviceLevel; // Offset: 0x00 // Size: 0x04
	int CountLimit; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AsianVehicleInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FAsianVehicleInfo {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	int Fuel; // Offset: 0x04 // Size: 0x04
	int FuelMax; // Offset: 0x08 // Size: 0x04
	int Speed; // Offset: 0x0c // Size: 0x04
	int RefuelingTime; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AsianCheckPointInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FAsianCheckPointInfo {
	// Fields
	int CheckPointID; // Offset: 0x00 // Size: 0x04
	int CheckPointType; // Offset: 0x04 // Size: 0x04
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.AsianTeamInfoHighFrequency
// Size: 0x2c // Inherited bytes: 0x00
struct FAsianTeamInfoHighFrequency {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	int TeamCurrentPoints; // Offset: 0x04 // Size: 0x04
	int TeamEarnPoints; // Offset: 0x08 // Size: 0x04
	int TeamLosePoints; // Offset: 0x0c // Size: 0x04
	int TeamOrder; // Offset: 0x10 // Size: 0x04
	struct FVector WorstLocation; // Offset: 0x14 // Size: 0x0c
	struct FVector VehicleLocation; // Offset: 0x20 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.AsianTeamInfoLowFrequency
// Size: 0x50 // Inherited bytes: 0x00
struct FAsianTeamInfoLowFrequency {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	int CountryID; // Offset: 0x04 // Size: 0x04
	struct FString country; // Offset: 0x08 // Size: 0x10
	struct FString CountryFullName; // Offset: 0x18 // Size: 0x10
	struct FString CountryIconURL; // Offset: 0x28 // Size: 0x10
	enum class EAsianGamesTeamColor TeamColor; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct ASTExtraVehicleBase* Vehicle; // Offset: 0x40 // Size: 0x08
	int VehicleSkinID; // Offset: 0x48 // Size: 0x04
	bool IsCheated; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.AsianTeamInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FAsianTeamInfo {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct ALuaActor* TeamCurrentStage; // Offset: 0x08 // Size: 0x08
	struct ALuaActor* TeamCurrentScoreStage; // Offset: 0x10 // Size: 0x08
	int StageProgress; // Offset: 0x18 // Size: 0x04
	int StageTotal; // Offset: 0x1c // Size: 0x04
	int Stage; // Offset: 0x20 // Size: 0x04
	float CompletedStageTime; // Offset: 0x24 // Size: 0x04
	float CompletedStageTimeStamp; // Offset: 0x28 // Size: 0x04
	float OverTime; // Offset: 0x2c // Size: 0x04
	bool bOver; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.TeamChangeStageInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FTeamChangeStageInfo {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	float CompletedTime; // Offset: 0x04 // Size: 0x04
	float CompletedTimeStamp; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct ALuaActor* NewStage; // Offset: 0x10 // Size: 0x08
	struct ALuaActor* OldStage; // Offset: 0x18 // Size: 0x08
	struct ALuaActor* NewScoreStage; // Offset: 0x20 // Size: 0x08
	int StageProgress; // Offset: 0x28 // Size: 0x04
	int StageTotal; // Offset: 0x2c // Size: 0x04
	int Stage; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlaneData
// Size: 0x98 // Inherited bytes: 0x00
struct FPlaneData {
	// Fields
	int FlightNo; // Offset: 0x00 // Size: 0x04
	bool bStarted; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct AActor* ThePlane; // Offset: 0x08 // Size: 0x08
	bool bCanJump; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	struct FVector PlaneVelocity; // Offset: 0x14 // Size: 0x0c
	struct FVector PlaneStartLoc; // Offset: 0x20 // Size: 0x0c
	struct FVector PlaneEndLoc; // Offset: 0x2c // Size: 0x0c
	struct FVector2D CanJumpLoc; // Offset: 0x38 // Size: 0x08
	struct FVector2D ForceJumpLoc; // Offset: 0x40 // Size: 0x08
	float PlaneHeight; // Offset: 0x48 // Size: 0x04
	int TotalPlayerNum; // Offset: 0x4c // Size: 0x04
	struct TArray<struct APlayerController*> TotalPlayers; // Offset: 0x50 // Size: 0x10
	struct TArray<struct APlayerController*> CurPlayers; // Offset: 0x60 // Size: 0x10
	int TotalAINum; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct TArray<struct AAIController*> TotalAIs; // Offset: 0x78 // Size: 0x10
	int CurAINum; // Offset: 0x88 // Size: 0x04
	float FixedJumpPointRate; // Offset: 0x8c // Size: 0x04
	bool bCanFixedJump; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.SyncPlatformMovement
// Size: 0x0c // Inherited bytes: 0x00
struct FSyncPlatformMovement {
	// Fields
	struct FVector Velocity; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.TempleItemCollisionData
// Size: 0x03 // Inherited bytes: 0x00
struct FTempleItemCollisionData {
	// Fields
	enum class ECollisionEnabled CollisionType; // Offset: 0x00 // Size: 0x01
	bool bEnable; // Offset: 0x01 // Size: 0x01
	bool bSpecialItemToClose; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayerAutoNavOperator
// Size: 0x28 // Inherited bytes: 0x00
struct FPlayerAutoNavOperator {
	// Fields
	bool bIsCached; // Offset: 0x00 // Size: 0x01
	enum class EPlayerAutoNavMode CurMode; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct FString TargetParam; // Offset: 0x08 // Size: 0x10
	struct FVector TargetDesc; // Offset: 0x18 // Size: 0x0c
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ExtractDamageParam
// Size: 0x18 // Inherited bytes: 0x00
struct FExtractDamageParam {
	// Fields
	int DamageType; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> KillFXItemID; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.HItResuktWithVisbility
// Size: 0x90 // Inherited bytes: 0x00
struct FHItResuktWithVisbility {
	// Fields
	char pad_0x0[0x90]; // Offset: 0x00 // Size: 0x90
};

// Object Name: ScriptStruct ShadowTrackerExtra.LowTemperatureDamageEvent
// Size: 0xb0 // Inherited bytes: 0xb0
struct FLowTemperatureDamageEvent : FSTPointDamageEvent {
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillDamageEvent
// Size: 0xc0 // Inherited bytes: 0xb0
struct FSkillDamageEvent : FSTPointDamageEvent {
	// Fields
	char pad_0xB0[0x10]; // Offset: 0xb0 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PoisonFogDamageEvent
// Size: 0xb0 // Inherited bytes: 0xb0
struct FPoisonFogDamageEvent : FSTPointDamageEvent {
};

// Object Name: ScriptStruct ShadowTrackerExtra.FpsVaultDataParam
// Size: 0x28 // Inherited bytes: 0x00
struct FFpsVaultDataParam {
	// Fields
	float Height; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString montageName; // Offset: 0x08 // Size: 0x10
	float TimeLength; // Offset: 0x18 // Size: 0x04
	bool isjump; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
	float movespeed; // Offset: 0x20 // Size: 0x04
	float SpeedRate; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VaultCheckRule
// Size: 0x10 // Inherited bytes: 0x00
struct FVaultCheckRule {
	// Fields
	float CheckHeight; // Offset: 0x00 // Size: 0x04
	float standCheckDis; // Offset: 0x04 // Size: 0x04
	float walkCheckDis; // Offset: 0x08 // Size: 0x04
	float sprintCheckDis; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VaultDataParam
// Size: 0x60 // Inherited bytes: 0x00
struct FVaultDataParam {
	// Fields
	struct FString montageSectionName; // Offset: 0x00 // Size: 0x10
	struct UCurveFloat* upCurve; // Offset: 0x10 // Size: 0x08
	struct UCurveFloat* forwardCurve; // Offset: 0x18 // Size: 0x08
	float blockdis; // Offset: 0x20 // Size: 0x04
	float blockheight; // Offset: 0x24 // Size: 0x04
	float blokcThicklength; // Offset: 0x28 // Size: 0x04
	bool isjump; // Offset: 0x2c // Size: 0x01
	bool forceStartSync; // Offset: 0x2d // Size: 0x01
	char pad_0x2E[0x2]; // Offset: 0x2e // Size: 0x02
	float CountTime; // Offset: 0x30 // Size: 0x04
	float playSpeed; // Offset: 0x34 // Size: 0x04
	float speedChangeTime; // Offset: 0x38 // Size: 0x04
	float changeSpeedRate; // Offset: 0x3c // Size: 0x04
	bool standState; // Offset: 0x40 // Size: 0x01
	bool walkState; // Offset: 0x41 // Size: 0x01
	bool SprintState; // Offset: 0x42 // Size: 0x01
	bool isPutUpGun; // Offset: 0x43 // Size: 0x01
	float BreakWindowDelayTime; // Offset: 0x44 // Size: 0x04
	bool isCancelable; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	float MinCancelVTimer; // Offset: 0x4c // Size: 0x04
	float MaxCancelVTimer; // Offset: 0x50 // Size: 0x04
	bool fallingVault; // Offset: 0x54 // Size: 0x01
	char pad_0x55[0x3]; // Offset: 0x55 // Size: 0x03
	float fallingvaultMinHeight; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RespawnDelayAddItemList
// Size: 0x10 // Inherited bytes: 0x00
struct FRespawnDelayAddItemList {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RespawnDelayAddItem
// Size: 0x08 // Inherited bytes: 0x00
struct FRespawnDelayAddItem {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.RespawnIgnoreItemType
// Size: 0x10 // Inherited bytes: 0x00
struct FRespawnIgnoreItemType {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RespawnKeepAllItemData
// Size: 0x20 // Inherited bytes: 0x00
struct FRespawnKeepAllItemData {
	// Fields
	struct TArray<struct FRespawnKeepItemData> ItemDatas; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FRespawnKeepWeaponData> WeaponDatas; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RespawnKeepItemData
// Size: 0x20 // Inherited bytes: 0x00
struct FRespawnKeepItemData {
	// Fields
	int ItemTypeID; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
	bool TotalNumLimit; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x17]; // Offset: 0x09 // Size: 0x17
};

// Object Name: ScriptStruct ShadowTrackerExtra.RespawnKeepWeaponData
// Size: 0x40 // Inherited bytes: 0x20
struct FRespawnKeepWeaponData : FRespawnKeepItemData {
	// Fields
	enum class ESurviveWeaponPropSlot WeaponSlot; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct TArray<struct FRespawnKeepItemData> AttachmentDatas; // Offset: 0x28 // Size: 0x10
	int ClipBulletNum; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ReplaceWeaponDataMap
// Size: 0x50 // Inherited bytes: 0x00
struct FReplaceWeaponDataMap {
	// Fields
	struct TMap<enum class ESurviveWeaponPropSlot, struct FReplaceWeaponData> ReplaceWeaponDataMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.ReplaceWeaponData
// Size: 0xd0 // Inherited bytes: 0x00
struct FReplaceWeaponData {
	// Fields
	int WeaponId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FBattleItemData WeaponItemData; // Offset: 0x08 // Size: 0xb8
	struct TArray<struct FBattleItemData> WeaponAssociateItemDataList; // Offset: 0xc0 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RevivalCardItemPickData
// Size: 0x38 // Inherited bytes: 0x00
struct FRevivalCardItemPickData {
	// Fields
	uint32_t PickUpPlayerID; // Offset: 0x00 // Size: 0x04
	uint32_t DroperPlayerID; // Offset: 0x04 // Size: 0x04
	int64_t PickupTime; // Offset: 0x08 // Size: 0x08
	int64_t DroperTime; // Offset: 0x10 // Size: 0x08
	struct FString PickUpName; // Offset: 0x18 // Size: 0x10
	struct FString DroperPlayerName; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemTombParticle
// Size: 0x88 // Inherited bytes: 0x00
struct FItemTombParticle {
	// Fields
	struct UParticleSystem* SoftPS; // Offset: 0x00 // Size: 0x28
	struct UParticleSystemComponent* PS; // Offset: 0x28 // Size: 0x08
	struct TSet<int> ItemSpecificIDArray; // Offset: 0x30 // Size: 0x50
	char pad_0x80[0x8]; // Offset: 0x80 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.TombboxLifeSpanStruct
// Size: 0x10 // Inherited bytes: 0x00
struct FTombboxLifeSpanStruct {
	// Fields
	struct AUAEGameMode* GameModeClass; // Offset: 0x00 // Size: 0x08
	int LifeSpan; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirDropVisionInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FAirDropVisionInfo {
	// Fields
	int AirDropId; // Offset: 0x00 // Size: 0x04
	struct FVector Position; // Offset: 0x04 // Size: 0x0c
	bool IsSmoking; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.IslandInteractionEmoteConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FIslandInteractionEmoteConfig {
	// Fields
	int PrepareEmoteId; // Offset: 0x00 // Size: 0x04
	int SelfEmoteId; // Offset: 0x04 // Size: 0x04
	int OtherEmoteId; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponVisualBulletClientModeConfig
// Size: 0xb0 // Inherited bytes: 0x00
struct FWeaponVisualBulletClientModeConfig {
	// Fields
	struct FWeaponVisualBulletCameraModeConfig AutonomousClientSetting; // Offset: 0x00 // Size: 0x30
	struct FWeaponVisualBulletCameraModeConfig OBPawnPerspectiveClientSetting; // Offset: 0x30 // Size: 0x30
	struct FWeaponVisualBulletCameraModeConfig ReplayPawnPerspectiveClientSetting; // Offset: 0x60 // Size: 0x30
	struct FWeaponVisualBulletItemConfig DefaultSetting; // Offset: 0x90 // Size: 0x10
	struct FWeaponVisualBulletItemConfig ReplayDefaultSetting; // Offset: 0xa0 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponVisualBulletCameraModeConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FWeaponVisualBulletCameraModeConfig {
	// Fields
	struct FWeaponVisualBulletItemConfig FPPSetting; // Offset: 0x00 // Size: 0x10
	struct FWeaponVisualBulletItemConfig TPPSetting; // Offset: 0x10 // Size: 0x10
	struct FWeaponVisualBulletItemConfig GunADSSetting; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomMiniMapGuideLineInfo
// Size: 0x3c // Inherited bytes: 0x00
struct FCustomMiniMapGuideLineInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	enum class EAddMarkFlag MapAdded; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	struct FVector StartLoc; // Offset: 0x0c // Size: 0x0c
	struct FVector EndLoc; // Offset: 0x18 // Size: 0x0c
	struct FLinearColor DrawColor; // Offset: 0x24 // Size: 0x10
	float LineDashSize; // Offset: 0x34 // Size: 0x04
	float LineThickness; // Offset: 0x38 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SlotWeaponData
// Size: 0x18 // Inherited bytes: 0x00
struct FSlotWeaponData {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> AttachMentIDList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimpleDamageRepData
// Size: 0x28 // Inherited bytes: 0x00
struct FSimpleDamageRepData {
	// Fields
	float Damage; // Offset: 0x00 // Size: 0x04
	float CurrentHeath; // Offset: 0x04 // Size: 0x04
	bool IsFatalHealthCost; // Offset: 0x08 // Size: 0x01
	bool IsHeadShotDamage; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
	struct APawn* DamageInstigatorPawn; // Offset: 0x10 // Size: 0x08
	struct APawn* DamageReceiver; // Offset: 0x18 // Size: 0x08
	int NetCounter; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SuperAirDropBoxDataItem
// Size: 0x10 // Inherited bytes: 0x00
struct FSuperAirDropBoxDataItem {
	// Fields
	float GenerateRate; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UDataTable* Table; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SoundData
// Size: 0x14 // Inherited bytes: 0x00
struct FSoundData {
	// Fields
	enum class FSoundType soundType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector SoundDir; // Offset: 0x04 // Size: 0x0c
	float SoundVolume; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AkEventTableRow
// Size: 0x18 // Inherited bytes: 0x08
struct FAkEventTableRow : FTableRowBase {
	// Fields
	int ID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct UAkAudioEvent* AkEvent; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.PickUpGlobalDAndWrapperTableRow
// Size: 0x18 // Inherited bytes: 0x08
struct FPickUpGlobalDAndWrapperTableRow : FTableRowBase {
	// Fields
	int ID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct APickUpWrapperActor* Template; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.PickUpActionReplicatedDataBroadcast
// Size: 0x0c // Inherited bytes: 0x00
struct FPickUpActionReplicatedDataBroadcast {
	// Fields
	int ActionID; // Offset: 0x00 // Size: 0x04
	int TargetPickUpItemID; // Offset: 0x04 // Size: 0x04
	enum class EHandlePickUpActionReplicatedDataActionType ActionType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.PickUpActionReplicatedData
// Size: 0x20 // Inherited bytes: 0x00
struct FPickUpActionReplicatedData {
	// Fields
	int ActionID; // Offset: 0x00 // Size: 0x04
	int TargetPickUpItemID; // Offset: 0x04 // Size: 0x04
	struct AActor* ServerTargetActor; // Offset: 0x08 // Size: 0x08
	struct AActor* WrapperActor; // Offset: 0x10 // Size: 0x08
	enum class EHandlePickUpActionReplicatedDataActionType ActionType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.ConsumeItemCDData
// Size: 0x0c // Inherited bytes: 0x00
struct FConsumeItemCDData {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.ConsumeItemDataTableRow
// Size: 0x28 // Inherited bytes: 0x10
struct FConsumeItemDataTableRow : FSurviveTableRowBase {
	// Fields
	int ConsumeItemID; // Offset: 0x10 // Size: 0x04
	enum class EConsumeItemType Type; // Offset: 0x14 // Size: 0x01
	enum class EConsumeItemCategory Category; // Offset: 0x15 // Size: 0x01
	char pad_0x16[0x2]; // Offset: 0x16 // Size: 0x02
	float ConsumeCD; // Offset: 0x18 // Size: 0x04
	float RecoverHealthPercentage; // Offset: 0x1c // Size: 0x04
	float MaxRecoverHealthPercentage; // Offset: 0x20 // Size: 0x04
	float RecoverEnegy; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayerEquipmentItemData
// Size: 0x1d0 // Inherited bytes: 0x00
struct FPlayerEquipmentItemData {
	// Fields
	struct FPickUpGlobalDataTableRow PickUpGlobalDataTableRow; // Offset: 0x00 // Size: 0x1b0
	struct FPlayerEquipmentDataTableRow PlayerEquipmentDataTableRow; // Offset: 0x1b0 // Size: 0x20
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayerEquipmentDataTableRow
// Size: 0x20 // Inherited bytes: 0x10
struct FPlayerEquipmentDataTableRow : FSurviveTableRowBase {
	// Fields
	int PlayerEquipmentID; // Offset: 0x10 // Size: 0x04
	enum class EPlayerEquipmentSlotType Type; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	float DamageMultiplyAdditionalRate; // Offset: 0x18 // Size: 0x04
	bool bIsAvata; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.MainSlotItemData
// Size: 0x1e0 // Inherited bytes: 0x00
struct FMainSlotItemData {
	// Fields
	struct FPickUpGlobalDataTableRow PickUpGlobalDataTableRow; // Offset: 0x00 // Size: 0x1b0
	struct FWeaponDataTableRow WeaponDataTableRow; // Offset: 0x1b0 // Size: 0x28
	struct AActor* TargetActor; // Offset: 0x1d8 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponDataTableRow
// Size: 0x28 // Inherited bytes: 0x10
struct FWeaponDataTableRow : FSurviveTableRowBase {
	// Fields
	int WeaponId; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct ASTExtraWeapon* WeaponTemplate; // Offset: 0x18 // Size: 0x08
	enum class ESurvivePickUpCategory SurvivePickUpCategory; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.UseBackpackItemParams
// Size: 0x01 // Inherited bytes: 0x00
struct FUseBackpackItemParams {
	// Fields
	enum class ESurviveWeaponPropSlot TargetEquipWeaponComponentMainSlot; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.BackpackItemData
// Size: 0x1c8 // Inherited bytes: 0x00
struct FBackpackItemData {
	// Fields
	int Num; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FPickUpGlobalDataTableRow BaseData; // Offset: 0x08 // Size: 0x1b0
	bool bIsUsing; // Offset: 0x1b8 // Size: 0x01
	char pad_0x1B9[0x3]; // Offset: 0x1b9 // Size: 0x03
	float FinishPercentage; // Offset: 0x1bc // Size: 0x04
	enum class ESurvivePickUpGlobalCategory SurvivePickUpGlobalCategory; // Offset: 0x1c0 // Size: 0x01
	char pad_0x1C1[0x7]; // Offset: 0x1c1 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.JudgePickupUsefulItem
// Size: 0x40 // Inherited bytes: 0x00
struct FJudgePickupUsefulItem {
	// Fields
	struct FPickUpItemData MainItemData; // Offset: 0x00 // Size: 0x38
	int NetGUIDOffsetValue; // Offset: 0x38 // Size: 0x04
	bool DropedByPlayer; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.VaultAnimDataPath
// Size: 0x20 // Inherited bytes: 0x00
struct FVaultAnimDataPath {
	// Fields
	struct FString VaultAnimPath; // Offset: 0x00 // Size: 0x10
	struct FString TeamVaultAnimPath; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.OutlineConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FOutlineConfig {
	// Fields
	struct FLinearColor Color; // Offset: 0x00 // Size: 0x10
	float Thickness; // Offset: 0x10 // Size: 0x04
	bool IsEnable; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.PredictLineMaterialParams
// Size: 0x10 // Inherited bytes: 0x00
struct FPredictLineMaterialParams {
	// Fields
	struct UMaterialParameterCollection* MaterialParamCollection; // Offset: 0x00 // Size: 0x08
	struct FName ParamName; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomDropRule
// Size: 0x03 // Inherited bytes: 0x00
struct FCustomDropRule {
	// Fields
	bool bTraceIgnorePawn; // Offset: 0x00 // Size: 0x01
	bool bTraceIgnoreWarteringArea; // Offset: 0x01 // Size: 0x01
	bool bAttachToTargetActor; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.PVECircleDeploymentConfig
// Size: 0x20 // Inherited bytes: 0x00
struct FPVECircleDeploymentConfig {
	// Fields
	int CircleID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct AActor* Location; // Offset: 0x08 // Size: 0x08
	float Radius; // Offset: 0x10 // Size: 0x04
	float MoveTime; // Offset: 0x14 // Size: 0x04
	float Pain; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MaternalZombieRatio
// Size: 0x0c // Inherited bytes: 0x00
struct FMaternalZombieRatio {
	// Fields
	int PlayerNum; // Offset: 0x00 // Size: 0x04
	int MaternalZombieNum; // Offset: 0x04 // Size: 0x04
	int MaternalZombieKingNum; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HighArcParam
// Size: 0x08 // Inherited bytes: 0x00
struct FHighArcParam {
	// Fields
	float HeightDiff; // Offset: 0x00 // Size: 0x04
	float GravityScale; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RepBossBornPoint
// Size: 0x10 // Inherited bytes: 0x00
struct FRepBossBornPoint {
	// Fields
	int FlowId; // Offset: 0x00 // Size: 0x04
	struct FVector BornPosition; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.BossBornPoint
// Size: 0x0c // Inherited bytes: 0x00
struct FBossBornPoint {
	// Fields
	struct FVector BornPosition; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.DangerousSignInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FDangerousSignInfo {
	// Fields
	struct FString MsgID; // Offset: 0x00 // Size: 0x10
	struct FVector LastDangerousLocation; // Offset: 0x10 // Size: 0x0c
	float LastMarkDangerousTime; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.QuickSignIDArray
// Size: 0x10 // Inherited bytes: 0x00
struct FQuickSignIDArray {
	// Fields
	struct TArray<struct FString> InnerArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.QuickSignMsg
// Size: 0x70 // Inherited bytes: 0x00
struct FQuickSignMsg {
	// Fields
	struct FString MsgID; // Offset: 0x00 // Size: 0x10
	struct FString PlayerName; // Offset: 0x10 // Size: 0x10
	struct FVector HitPos; // Offset: 0x20 // Size: 0x0c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString ConfigKey; // Offset: 0x30 // Size: 0x10
	int audioID; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString ParamString; // Offset: 0x48 // Size: 0x10
	int BindActorGUID; // Offset: 0x58 // Size: 0x04
	int RelationID; // Offset: 0x5c // Size: 0x04
	uint32_t PlayerKey; // Offset: 0x60 // Size: 0x04
	int MiniMapIconTypeId; // Offset: 0x64 // Size: 0x04
	enum class EQuickSignSubType MsgType; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.RadiationCircleData
// Size: 0x44 // Inherited bytes: 0x00
struct FRadiationCircleData {
	// Fields
	bool bNeedUpdateCircle; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector2D CircleCenter; // Offset: 0x04 // Size: 0x08
	struct FLinearColor CircleColor; // Offset: 0x0c // Size: 0x10
	float CircleRadius; // Offset: 0x1c // Size: 0x04
	float MapWindowExtent; // Offset: 0x20 // Size: 0x04
	struct FVector2D PlayerCoord; // Offset: 0x24 // Size: 0x08
	int OnPaintType; // Offset: 0x2c // Size: 0x04
	bool bAntiAlias; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	struct FVector2D BlueCircleCoord; // Offset: 0x34 // Size: 0x08
	struct FVector2D BlueCircleScale; // Offset: 0x3c // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.BattleDeathPlaybackInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FBattleDeathPlaybackInfo {
	// Fields
	float DeathPlaybackStartTime; // Offset: 0x00 // Size: 0x04
	float DeathPlaybackEndTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RecordTlogBatch
// Size: 0x18 // Inherited bytes: 0x00
struct FRecordTlogBatch {
	// Fields
	char Version; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FRecordTlog> TlogArray; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RecordTlog
// Size: 0x88 // Inherited bytes: 0x00
struct FRecordTlog {
	// Fields
	struct FString UId; // Offset: 0x00 // Size: 0x10
	char EventId; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FString OpenID; // Offset: 0x18 // Size: 0x10
	int64_t TimeStamp; // Offset: 0x28 // Size: 0x08
	float DSElapsedSeconds; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TMap<struct FString, struct FString> KeyValueMap; // Offset: 0x38 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.LobbyWonderfulInfo
// Size: 0x78 // Inherited bytes: 0x00
struct FLobbyWonderfulInfo {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	uint64 GameID; // Offset: 0x08 // Size: 0x08
	uint64 SaveTimestamp; // Offset: 0x10 // Size: 0x08
	struct FString ModeID; // Offset: 0x18 // Size: 0x10
	int SegmentLevel; // Offset: 0x28 // Size: 0x04
	float TotalTime; // Offset: 0x2c // Size: 0x04
	struct TArray<struct FWonderfulTypeInfo> TypeInfoArray; // Offset: 0x30 // Size: 0x10
	struct FString AppVersion; // Offset: 0x40 // Size: 0x10
	struct FString SrcVersion; // Offset: 0x50 // Size: 0x10
	enum class EWonderfulErrorCode ErrorCode; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x7]; // Offset: 0x61 // Size: 0x07
	struct TArray<struct FWonderfulWeSeeInfo> WeSeeInfoArray; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WonderfulWeSeeInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FWonderfulWeSeeInfo {
	// Fields
	float StartTime; // Offset: 0x00 // Size: 0x04
	float EndTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WonderfulTypeInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FWonderfulTypeInfo {
	// Fields
	enum class EWonderfulType WondefulType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<float> AdditionalData; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.BattleWonderfulInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FBattleWonderfulInfo {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	uint64 GameID; // Offset: 0x08 // Size: 0x08
	struct FString PlayerName; // Offset: 0x10 // Size: 0x10
	struct FString OpenID; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FWonderfulPeriodInfo> WonderfulPeriodInfoArray; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WonderfulPeriodInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FWonderfulPeriodInfo {
	// Fields
	float WonderfulStartTime; // Offset: 0x00 // Size: 0x04
	float WonderfulEndTime; // Offset: 0x04 // Size: 0x04
	int WonderfulPeriodIndex; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FWonderfulTypeInfo WondefulTypeInfo; // Offset: 0x10 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.ReplayPawnInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FReplayPawnInfo {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
	bool isEnemy; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int UIIndex; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ReplayTeammateInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FReplayTeammateInfo {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.ReplayPreInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FReplayPreInfo {
	// Fields
	enum class EDemoType ReplayType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString ReplayNameStr; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ReplayEnemyUIInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FReplayEnemyUIInfo {
	// Fields
	int UIIndex; // Offset: 0x00 // Size: 0x04
	struct FVector WordLocation; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.RespawnItemConfigInst
// Size: 0x10 // Inherited bytes: 0x00
struct FRespawnItemConfigInst {
	// Fields
	int RandomWeight; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct URespawnItemConfig* RespawnItemConfigClass; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.RespawnItemMajorGroup
// Size: 0x18 // Inherited bytes: 0x00
struct FRespawnItemMajorGroup {
	// Fields
	int RandomTimes; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FRespawnItemMinorGroup> MinorGroupList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RespawnItemMinorGroup
// Size: 0x18 // Inherited bytes: 0x00
struct FRespawnItemMinorGroup {
	// Fields
	int RandomWeight; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FRespawnItem> ItemList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RespawnItem
// Size: 0x08 // Inherited bytes: 0x00
struct FRespawnItem {
	// Fields
	int ItemTableID; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RollItemData
// Size: 0x10 // Inherited bytes: 0x00
struct FRollItemData {
	// Fields
	uint64 InstanceID; // Offset: 0x00 // Size: 0x08
	uint32_t OwnerPlayerKey; // Offset: 0x08 // Size: 0x04
	bool bFinished; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.RollItemResultData
// Size: 0x18 // Inherited bytes: 0x00
struct FRollItemResultData {
	// Fields
	struct TArray<struct FRollItemResult> RollResults; // Offset: 0x00 // Size: 0x10
	bool bRollFinished; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.RollItemResult
// Size: 0x40 // Inherited bytes: 0x00
struct FRollItemResult {
	// Fields
	struct FPickUpItemData ItemData; // Offset: 0x00 // Size: 0x38
	int Roll; // Offset: 0x38 // Size: 0x04
	bool bIsMine; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.StopFireInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FStopFireInfo {
	// Fields
	uint32_t CurClipID; // Offset: 0x00 // Size: 0x04
	int CurrentBullet; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MoveBaseInfo_NetQuantize
// Size: 0x50 // Inherited bytes: 0x00
struct FMoveBaseInfo_NetQuantize {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.ScreenMarkGroupData
// Size: 0x120 // Inherited bytes: 0x00
struct FScreenMarkGroupData {
	// Fields
	struct FScreenMarkGroupConfig Config; // Offset: 0x00 // Size: 0x50
	struct UUIDuplicatedItemPool* UIPool; // Offset: 0x50 // Size: 0x08
	struct TArray<struct TWeakObjectPtr<struct AActor>> WorldObjectArr; // Offset: 0x58 // Size: 0x10
	struct TArray<struct FVector> WorldLocationArr; // Offset: 0x68 // Size: 0x10
	struct TArray<struct UWidget*> HidingUIArr; // Offset: 0x78 // Size: 0x10
	struct TArray<struct UWidget*> ShowingUIArr; // Offset: 0x88 // Size: 0x10
	struct TArray<struct FActorWidgetPair> BindingActorUIArr; // Offset: 0x98 // Size: 0x10
	struct TMap<struct FVector, struct UWidget*> BindingLocationPairs; // Offset: 0xa8 // Size: 0x50
	char pad_0xF8[0x8]; // Offset: 0xf8 // Size: 0x08
	struct UUAEUserWidget* ScreenMarkPanel; // Offset: 0x100 // Size: 0x08
	struct UCanvasPanel* AddToPanel; // Offset: 0x108 // Size: 0x08
	struct TArray<struct TWeakObjectPtr<struct AActor>> IgnoreBlockArr; // Offset: 0x110 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActorWidgetPair
// Size: 0x10 // Inherited bytes: 0x00
struct FActorWidgetPair {
	// Fields
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x00 // Size: 0x08
	struct UWidget* Widget; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ScreenMarkGroupConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FScreenMarkGroupConfig {
	// Fields
	int MaxWidgetNum; // Offset: 0x00 // Size: 0x04
	float MaxShowDistance; // Offset: 0x04 // Size: 0x04
	float UpdateBindingInterval; // Offset: 0x08 // Size: 0x04
	float UpdateBindingIntervalMax; // Offset: 0x0c // Size: 0x04
	float ReduseBindingVelocityThreshold; // Offset: 0x10 // Size: 0x04
	bool bIsBindingActor; // Offset: 0x14 // Size: 0x01
	bool bIsUpdatedByPanel; // Offset: 0x15 // Size: 0x01
	bool bBindOutScreen; // Offset: 0x16 // Size: 0x01
	bool bBindBlocked; // Offset: 0x17 // Size: 0x01
	struct FString UIPathName; // Offset: 0x18 // Size: 0x10
	bool bCollapseWhenFree; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FName SkeletaSocketName; // Offset: 0x30 // Size: 0x08
	struct FVector WorldPositionOffset; // Offset: 0x38 // Size: 0x0c
	struct FVector2D UIOffset; // Offset: 0x44 // Size: 0x08
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActorVectorPair
// Size: 0x14 // Inherited bytes: 0x00
struct FActorVectorPair {
	// Fields
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x00 // Size: 0x08
	struct FVector Vector; // Offset: 0x08 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.ScreenRotationMarkGroupData
// Size: 0x148 // Inherited bytes: 0x00
struct FScreenRotationMarkGroupData {
	// Fields
	struct FScreenRotationMarkConfig Config; // Offset: 0x00 // Size: 0x50
	struct UUIDuplicatedItemPool* UIPool; // Offset: 0x50 // Size: 0x08
	struct TArray<struct TWeakObjectPtr<struct AActor>> WorldObjectArr; // Offset: 0x58 // Size: 0x10
	struct TArray<struct FVector> WorldLocationArr; // Offset: 0x68 // Size: 0x10
	struct TArray<struct UWidget*> HidingUIArr; // Offset: 0x78 // Size: 0x10
	struct TArray<struct UWidget*> ShowingUIArr; // Offset: 0x88 // Size: 0x10
	struct TMap<struct TWeakObjectPtr<struct AActor>, struct UWidget*> BindingActorUIMap; // Offset: 0x98 // Size: 0x50
	struct TMap<struct FVector, struct UWidget*> BindingLocationUIMap; // Offset: 0xe8 // Size: 0x50
	struct UCanvasPanel* RootPanel; // Offset: 0x138 // Size: 0x08
	char pad_0x140[0x8]; // Offset: 0x140 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ScreenRotationMarkConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FScreenRotationMarkConfig {
	// Fields
	struct FScreenRotationRangeValue DistanceRange; // Offset: 0x00 // Size: 0x10
	struct FScreenRotationRangeValue AngleRange; // Offset: 0x10 // Size: 0x10
	struct TWeakObjectPtr<struct AActor> BindActor; // Offset: 0x20 // Size: 0x08
	struct FString UIPathName; // Offset: 0x28 // Size: 0x10
	float AngleOffset; // Offset: 0x38 // Size: 0x04
	bool bIsIcon; // Offset: 0x3c // Size: 0x01
	bool bIsBindingActor; // Offset: 0x3d // Size: 0x01
	char pad_0x3E[0x2]; // Offset: 0x3e // Size: 0x02
	float UpdateBindingInterval; // Offset: 0x40 // Size: 0x04
	int DefaultNum; // Offset: 0x44 // Size: 0x04
	float Radius; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ScreenRotationRangeValue
// Size: 0x10 // Inherited bytes: 0x00
struct FScreenRotationRangeValue {
	// Fields
	float MaxValue; // Offset: 0x00 // Size: 0x04
	bool IsCloseOutMaxValue; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	float MinValue; // Offset: 0x08 // Size: 0x04
	bool IsCloseInMinValue; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.StatueBaseParam
// Size: 0x30 // Inherited bytes: 0x00
struct FStatueBaseParam {
	// Fields
	struct FString MatPath; // Offset: 0x00 // Size: 0x10
	struct FString TeamFlag; // Offset: 0x10 // Size: 0x10
	struct FString TeamName; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SectorRangeData
// Size: 0x08 // Inherited bytes: 0x00
struct FSectorRangeData {
	// Fields
	float Angle; // Offset: 0x00 // Size: 0x04
	float Distance; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SeekAndLockRPGBulletLaunchParams
// Size: 0x80 // Inherited bytes: 0x00
struct FSeekAndLockRPGBulletLaunchParams {
	// Fields
	struct FProjectileBulletLaunchParams BaseParam; // Offset: 0x00 // Size: 0x60
	struct FRPGBulletSeekAndLockData SeekAndLockData; // Offset: 0x60 // Size: 0x14
	char pad_0x74[0xc]; // Offset: 0x74 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.RPGBulletSeekAndLockData
// Size: 0x14 // Inherited bytes: 0x00
struct FRPGBulletSeekAndLockData {
	// Fields
	float DirectFlyTime; // Offset: 0x00 // Size: 0x04
	float TurnDirectionRadSpeed; // Offset: 0x04 // Size: 0x04
	float FollowTargetTime; // Offset: 0x08 // Size: 0x04
	struct TWeakObjectPtr<struct AActor> FollowTarget; // Offset: 0x0c // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.HistoryLockMapDataItem
// Size: 0x0c // Inherited bytes: 0x00
struct FHistoryLockMapDataItem {
	// Fields
	float LockTime; // Offset: 0x00 // Size: 0x04
	float FrameLength; // Offset: 0x04 // Size: 0x04
	float CacheTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.TraceShootData
// Size: 0x44 // Inherited bytes: 0x00
struct FTraceShootData {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
	struct FRotator ShootRotate; // Offset: 0x04 // Size: 0x0c
	struct FVector TraceStart; // Offset: 0x10 // Size: 0x0c
	struct FVector TraceEnd; // Offset: 0x1c // Size: 0x0c
	enum class ETraceShootType ShootMode; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	struct FVector ShootTargetLoc; // Offset: 0x2c // Size: 0x0c
	float Deviation; // Offset: 0x38 // Size: 0x04
	struct FVector2D BackScreenPos; // Offset: 0x3c // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.TargetBodyData
// Size: 0x08 // Inherited bytes: 0x00
struct FTargetBodyData {
	// Fields
	enum class EAvatarDamagePosition DamagePosition; // Offset: 0x00 // Size: 0x01
	enum class ETargetBodyType TargetBodyType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float DamageScale; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BulletImpactAutoTestData
// Size: 0x18 // Inherited bytes: 0x00
struct FBulletImpactAutoTestData {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.FXDistancaScaleStruct
// Size: 0x10 // Inherited bytes: 0x00
struct FFXDistancaScaleStruct {
	// Fields
	float FXStartScaleDistance; // Offset: 0x00 // Size: 0x04
	float FXEndScaleDistance; // Offset: 0x04 // Size: 0x04
	float FXStartScaleValue; // Offset: 0x08 // Size: 0x04
	float FXEndScaleValue; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ExtendBulletNumAttachment
// Size: 0x08 // Inherited bytes: 0x00
struct FExtendBulletNumAttachment {
	// Fields
	int TypeSpecificID; // Offset: 0x00 // Size: 0x04
	int ExtendMaxBulletNumInOneClip; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShovelAntiCheat
// Size: 0x88 // Inherited bytes: 0x00
struct FShovelAntiCheat {
	// Fields
	float DataSendInterval; // Offset: 0x00 // Size: 0x04
	float DataSampleInterval; // Offset: 0x04 // Size: 0x04
	float SampleMoveVelocityTorelate; // Offset: 0x08 // Size: 0x04
	float CheatLockTime; // Offset: 0x0c // Size: 0x04
	int MaxServerClientDeltaCount; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x6c]; // Offset: 0x14 // Size: 0x6c
	struct UMoveAntiCheatComponent* OwnerMoveAntiCheat; // Offset: 0x80 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShovelInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FShovelInfo {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.ShovelStat
// Size: 0x18 // Inherited bytes: 0x00
struct FShovelStat {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct ShadowTrackerExtra.FrameUITransformData
// Size: 0x40 // Inherited bytes: 0x00
struct FFrameUITransformData {
	// Fields
	struct FTransform Offset; // Offset: 0x00 // Size: 0x30
	float BaseSizeX; // Offset: 0x30 // Size: 0x04
	float BaseSizeY; // Offset: 0x34 // Size: 0x04
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.WingmanInfoInBornIsland
// Size: 0x50 // Inherited bytes: 0x00
struct FWingmanInfoInBornIsland {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString WingmanClassPath; // Offset: 0x08 // Size: 0x10
	char pad_0x18[0x8]; // Offset: 0x18 // Size: 0x08
	struct FTransform WingmanSpawnTransform; // Offset: 0x20 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleInfoInBornIsland
// Size: 0x30 // Inherited bytes: 0x00
struct FVehicleInfoInBornIsland {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString VehiclePath; // Offset: 0x08 // Size: 0x10
	struct FString VehicleContainerPath; // Offset: 0x18 // Size: 0x10
	int ShowAvatarID; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleSpots
// Size: 0x60 // Inherited bytes: 0x00
struct FVehicleSpots {
	// Fields
	struct TArray<struct FTransform> Spots; // Offset: 0x00 // Size: 0x10
	struct TSet<int> UsedSpot; // Offset: 0x10 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimDataPair
// Size: 0x30 // Inherited bytes: 0x00
struct FAnimDataPair {
	// Fields
	int PoseTypeID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UAnimationAsset* AnimSoftPtr; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.RepSnapshot
// Size: 0x38 // Inherited bytes: 0x00
struct FRepSnapshot {
	// Fields
	float TimeStamp; // Offset: 0x00 // Size: 0x04
	struct FVector_NetQuantize Location; // Offset: 0x04 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x10 // Size: 0x0c
	struct FVector_NetQuantize LinearVelocity; // Offset: 0x1c // Size: 0x0c
	struct FVector_NetQuantize AngularVelocity; // Offset: 0x28 // Size: 0x0c
	bool IsTeleport; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimulateSyncSmooth
// Size: 0xd4 // Inherited bytes: 0x00
struct FSimulateSyncSmooth {
	// Fields
	float MaxPredictMoveTime; // Offset: 0x00 // Size: 0x04
	float MaxMoveDeltaTime; // Offset: 0x04 // Size: 0x04
	float SmoothNetUpdateTime; // Offset: 0x08 // Size: 0x04
	float SmoothNetUpdateRotationTime; // Offset: 0x0c // Size: 0x04
	char pad_0x10[0xc4]; // Offset: 0x10 // Size: 0xc4
};

// Object Name: ScriptStruct ShadowTrackerExtra.SingleTrainingData
// Size: 0x01 // Inherited bytes: 0x00
struct FSingleTrainingData {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.SocialIslandInteractEmoteData
// Size: 0x28 // Inherited bytes: 0x00
struct FSocialIslandInteractEmoteData {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	int MyEmoteID; // Offset: 0x04 // Size: 0x04
	int TargetEmoteID; // Offset: 0x08 // Size: 0x04
	int PrepareEmoteId; // Offset: 0x0c // Size: 0x04
	int EmoteTipTextID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString EmoteTipTexPath; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkirtConfigData
// Size: 0x1c0 // Inherited bytes: 0x00
struct FSkirtConfigData {
	// Fields
	struct TArray<enum class EPawnState> PawnStateList; // Offset: 0x00 // Size: 0x10
	struct FSkirtChainData DynamicChainData; // Offset: 0x10 // Size: 0x140
	struct FSkirtModifyListData BoneModifyData; // Offset: 0x150 // Size: 0x70
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkirtModifyListData
// Size: 0x70 // Inherited bytes: 0x00
struct FSkirtModifyListData {
	// Fields
	struct FSkirtBoneModifyData Modify_L; // Offset: 0x00 // Size: 0x1c
	struct FSkirtBoneModifyData Modify_FL; // Offset: 0x1c // Size: 0x1c
	struct FSkirtBoneModifyData Modify_R; // Offset: 0x38 // Size: 0x1c
	struct FSkirtBoneModifyData Modify_FR; // Offset: 0x54 // Size: 0x1c
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkirtBoneModifyData
// Size: 0x1c // Inherited bytes: 0x00
struct FSkirtBoneModifyData {
	// Fields
	enum class EBoneModificationMode TranslationMode; // Offset: 0x00 // Size: 0x01
	enum class EBoneModificationMode RotationMode; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	struct FVector Translation; // Offset: 0x04 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x10 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkirtChainData
// Size: 0x140 // Inherited bytes: 0x00
struct FSkirtChainData {
	// Fields
	struct FSkirtAnimDynamicData Chain_FR; // Offset: 0x00 // Size: 0x50
	struct FSkirtAnimDynamicData Chain_FL; // Offset: 0x50 // Size: 0x50
	struct FSkirtAnimDynamicData Chain_L; // Offset: 0xa0 // Size: 0x50
	struct FSkirtAnimDynamicData Chain_R; // Offset: 0xf0 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkirtAnimDynamicData
// Size: 0x50 // Inherited bytes: 0x00
struct FSkirtAnimDynamicData {
	// Fields
	enum class AnimPhysSimSpaceType SimulationSpace; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float GravityScale; // Offset: 0x04 // Size: 0x04
	bool bOverrideLinearDamping; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float LinearDampingOverride; // Offset: 0x0c // Size: 0x04
	bool bOverrideAngularDamping; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	float AngularDampingOverride; // Offset: 0x14 // Size: 0x04
	struct FVector AngularLimitsMin; // Offset: 0x18 // Size: 0x0c
	struct FVector AngularLimitsMax; // Offset: 0x24 // Size: 0x0c
	struct TArray<struct FAnimPhysPlanarLimit> PlanarLimits; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FAnimPhysSphericalLimit> SphericalLimits; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.TempAvatarSlotDesc
// Size: 0xd0 // Inherited bytes: 0x00
struct FTempAvatarSlotDesc {
	// Fields
	int SlotID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FAvatarTableData RelationData; // Offset: 0x08 // Size: 0xa0
	struct TArray<int> ReplaceDesc; // Offset: 0xa8 // Size: 0x10
	struct TArray<int> HideDesc; // Offset: 0xb8 // Size: 0x10
	bool bForceHideState; // Offset: 0xc8 // Size: 0x01
	char pad_0xC9[0x7]; // Offset: 0xc9 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.SegamentData
// Size: 0x10 // Inherited bytes: 0x00
struct FSegamentData {
	// Fields
	struct FVector TargetLocation; // Offset: 0x00 // Size: 0x0c
	float movespeed; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.IslandItemSpotData
// Size: 0x58 // Inherited bytes: 0x00
struct FIslandItemSpotData {
	// Fields
	struct TMap<struct FString, struct UItemGroupRepeatSpotComponent*> ItemGroups; // Offset: 0x00 // Size: 0x50
	int LandId; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SocialIslandSwitchLand
// Size: 0x10 // Inherited bytes: 0x00
struct FSocialIslandSwitchLand {
	// Fields
	struct TWeakObjectPtr<struct ASTExtraPlayerController> Controller; // Offset: 0x00 // Size: 0x08
	int TargetLandId; // Offset: 0x08 // Size: 0x04
	float SwitchDelayTime; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SocialIslandPlayerStartGroup
// Size: 0x88 // Inherited bytes: 0x00
struct FSocialIslandPlayerStartGroup {
	// Fields
	int LandId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct ASTExtraPlayerStart*> PlayerStarts; // Offset: 0x08 // Size: 0x10
	struct TMap<struct FString, struct FSocialIslandBattleStartGroup> BattleStarts; // Offset: 0x18 // Size: 0x50
	struct FVector LandLeftTop; // Offset: 0x68 // Size: 0x0c
	struct FVector LandRightBottom; // Offset: 0x74 // Size: 0x0c
	char pad_0x80[0x8]; // Offset: 0x80 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SocialIslandBattleStartGroup
// Size: 0x10 // Inherited bytes: 0x00
struct FSocialIslandBattleStartGroup {
	// Fields
	struct TArray<struct ASTExtraPlayerStart*> PlayerStarts; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.IslandRacingData
// Size: 0x10 // Inherited bytes: 0x00
struct FIslandRacingData {
	// Fields
	enum class EIslandBattleState RacingState; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float EndTime; // Offset: 0x04 // Size: 0x04
	struct ASTExtraBaseCharacter* RacingPlayer; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.IslandBattleData
// Size: 0x10 // Inherited bytes: 0x00
struct FIslandBattleData {
	// Fields
	enum class EIslandBattleState BattleState; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float EndTime; // Offset: 0x04 // Size: 0x04
	struct ASTExtraBaseCharacter* BattlePlayer; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.IslandDuelData
// Size: 0x10 // Inherited bytes: 0x00
struct FIslandDuelData {
	// Fields
	enum class EIslandDuelState DState; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float EndTime; // Offset: 0x04 // Size: 0x04
	struct ASTExtraBaseCharacter* DuelPlayer; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SIslandPlayerMarkInfo
// Size: 0x68 // Inherited bytes: 0x00
struct FSIslandPlayerMarkInfo {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString PlayerName; // Offset: 0x08 // Size: 0x10
	struct FGameModePlayerAliasInfo PlayerAliasInfo; // Offset: 0x18 // Size: 0x48
	struct ASocialIslandPlayerState* PlayerState; // Offset: 0x60 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SocialIslandRankData
// Size: 0x01 // Inherited bytes: 0x00
struct FSocialIslandRankData {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpawnerInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FSpawnerInfo {
	// Fields
	struct FGuid SpawnerID; // Offset: 0x00 // Size: 0x10
	int ConfigId; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString State; // Offset: 0x18 // Size: 0x10
	char bAutoSpawn : 1; // Offset: 0x28 // Size: 0x01
	char pad_0x28_1 : 7; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int TeamID; // Offset: 0x2c // Size: 0x04
	struct FString OwnerZone; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SplineBaseData
// Size: 0x70 // Inherited bytes: 0x00
struct FSplineBaseData {
	// Fields
	struct AActor* InstigatorActor; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x20]; // Offset: 0x08 // Size: 0x20
	struct USplineComponent* SplineComponent; // Offset: 0x28 // Size: 0x08
	struct UStaticMeshComponent* HeadMeshComponent; // Offset: 0x30 // Size: 0x08
	struct TArray<struct USplineMeshComponent*> SplineMeshComponents; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x28]; // Offset: 0x48 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.DamageParamters
// Size: 0x14 // Inherited bytes: 0x00
struct FDamageParamters {
	// Fields
	float MinimumDamage; // Offset: 0x00 // Size: 0x04
	float DamageInnerRadius; // Offset: 0x04 // Size: 0x04
	float DamageOuterRadius; // Offset: 0x08 // Size: 0x04
	float DamageFalloff; // Offset: 0x0c // Size: 0x04
	float BaseMomentumMag; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.STAILoopQueryCharactersItems
// Size: 0x50 // Inherited bytes: 0x00
struct FSTAILoopQueryCharactersItems {
	// Fields
	struct FString Tips; // Offset: 0x00 // Size: 0x10
	float Radius; // Offset: 0x10 // Size: 0x04
	float interval; // Offset: 0x14 // Size: 0x04
	float RandomDeviation; // Offset: 0x18 // Size: 0x04
	bool IsQueryFirstValidCharacter; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
	struct TArray<struct FSTConditionConfig> Conditions; // Offset: 0x20 // Size: 0x10
	struct FString SelectBestFuncName; // Offset: 0x30 // Size: 0x10
	struct FString DoEventFuncName; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.STConditionConfig
// Size: 0x28 // Inherited bytes: 0x00
struct FSTConditionConfig {
	// Fields
	struct FString ConditionFuncName; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> ConditionParams; // Offset: 0x10 // Size: 0x10
	bool bInverseCondition; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.STAITriggerPerceptionItems
// Size: 0x50 // Inherited bytes: 0x00
struct FSTAITriggerPerceptionItems {
	// Fields
	struct FString Tips; // Offset: 0x00 // Size: 0x10
	struct FString EventType; // Offset: 0x10 // Size: 0x10
	struct FString EventId; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FSTConditionConfig> Conditions; // Offset: 0x30 // Size: 0x10
	struct FString DoEventFuncName; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.StairsMoveInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FStairsMoveInfo {
	// Fields
	enum class EStairsMoveType Mode; // Offset: 0x00 // Size: 0x01
	bool bMoveDirectIsUp; // Offset: 0x01 // Size: 0x01
	bool bLeftToRightHand; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	struct FVector BeginPos; // Offset: 0x04 // Size: 0x0c
	struct FVector EndPos; // Offset: 0x10 // Size: 0x0c
	float TimeOffset; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.STAINoiseEvent
// Size: 0x38 // Inherited bytes: 0x00
struct FSTAINoiseEvent {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
	struct FVector NoiseLocation; // Offset: 0x04 // Size: 0x0c
	float Loudness; // Offset: 0x10 // Size: 0x04
	float MaxRange; // Offset: 0x14 // Size: 0x04
	struct AActor* Instigator; // Offset: 0x18 // Size: 0x08
	struct FName Tag; // Offset: 0x20 // Size: 0x08
	enum class ESTAINoiseType NoiseType; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	float StartAttenuationDist; // Offset: 0x2c // Size: 0x04
	float EndAttenuationDist; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimalStateMutual
// Size: 0x02 // Inherited bytes: 0x00
struct FAnimalStateMutual {
	// Fields
	enum class EAnimalState state1; // Offset: 0x00 // Size: 0x01
	enum class EAnimalState state2; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.StateType
// Size: 0x10 // Inherited bytes: 0x00
struct FStateType {
	// Fields
	enum class EStateType StateType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	int64_t TimeStamp; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActorMarkData
// Size: 0x18 // Inherited bytes: 0x00
struct FActorMarkData {
	// Fields
	struct AActor* MarkActorClass; // Offset: 0x00 // Size: 0x08
	int TypeId; // Offset: 0x08 // Size: 0x04
	enum class EAddMarkFlag MapAdded; // Offset: 0x0c // Size: 0x01
	bool bLocalData; // Offset: 0x0d // Size: 0x01
	char pad_0xE[0x2]; // Offset: 0x0e // Size: 0x02
	float DistanceToMark; // Offset: 0x10 // Size: 0x04
	bool bUpdateRotation; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuffAttachmentItem
// Size: 0x58 // Inherited bytes: 0x00
struct FBuffAttachmentItem {
	// Fields
	struct USceneComponent* Component; // Offset: 0x00 // Size: 0x08
	struct UParticleSystem* ParticleSystem; // Offset: 0x08 // Size: 0x28
	struct FName SocketName; // Offset: 0x30 // Size: 0x08
	struct FVector LocationOffset; // Offset: 0x38 // Size: 0x0c
	struct FRotator RotationOffset; // Offset: 0x44 // Size: 0x0c
	float Scale; // Offset: 0x50 // Size: 0x04
	enum class EBuffTargetType TargetType; // Offset: 0x54 // Size: 0x01
	char pad_0x55[0x3]; // Offset: 0x55 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuffDotBulletItem
// Size: 0x08 // Inherited bytes: 0x00
struct FBuffDotBulletItem {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int Number; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PropSkillExplodeParam
// Size: 0x24 // Inherited bytes: 0x00
struct FPropSkillExplodeParam {
	// Fields
	float GenProbility; // Offset: 0x00 // Size: 0x04
	int PropSkillLevel; // Offset: 0x04 // Size: 0x04
	float PlayerInnerDamageHealthRatio; // Offset: 0x08 // Size: 0x04
	float PlayerOuterDamageHealthRatio; // Offset: 0x0c // Size: 0x04
	float ZombieInnerDamageHealthRatio; // Offset: 0x10 // Size: 0x04
	float ZombieOuterDamageHealthRatio; // Offset: 0x14 // Size: 0x04
	float WallWeakenDamageRatio; // Offset: 0x18 // Size: 0x04
	float InnerDamageRadius; // Offset: 0x1c // Size: 0x04
	float OuterDamageRadius; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PropSkillPosionParam
// Size: 0x14 // Inherited bytes: 0x00
struct FPropSkillPosionParam {
	// Fields
	float GenProbility; // Offset: 0x00 // Size: 0x04
	int PropSkillLevel; // Offset: 0x04 // Size: 0x04
	float CheckPeriod; // Offset: 0x08 // Size: 0x04
	int HumanBuffID; // Offset: 0x0c // Size: 0x04
	int ZombieBuffID; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuffAttrModifierItem
// Size: 0x18 // Inherited bytes: 0x00
struct FBuffAttrModifierItem {
	// Fields
	struct FString AttrName; // Offset: 0x00 // Size: 0x10
	float ModifyValue; // Offset: 0x10 // Size: 0x04
	enum class EAttrModifyRefType AttrRefValueType; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimatedMaterialParameter_Vector
// Size: 0x10 // Inherited bytes: 0x00
struct FAnimatedMaterialParameter_Vector {
	// Fields
	struct UCurveVector* MaterialParameterCurve; // Offset: 0x00 // Size: 0x08
	struct FName MaterialParameterName; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimatedMaterialParameter_Scalar
// Size: 0x10 // Inherited bytes: 0x00
struct FAnimatedMaterialParameter_Scalar {
	// Fields
	struct UCurveFloat* MaterialParameterCurve; // Offset: 0x00 // Size: 0x08
	struct FName MaterialParameterName; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.PostEventParams
// Size: 0x20 // Inherited bytes: 0x00
struct FPostEventParams {
	// Fields
	struct FString EventType; // Offset: 0x00 // Size: 0x10
	struct FString EventId; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PostEventWithCauserParams
// Size: 0x20 // Inherited bytes: 0x00
struct FPostEventWithCauserParams {
	// Fields
	struct FString EventType; // Offset: 0x00 // Size: 0x10
	struct FString EventId; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CachAirDropMarkSyncData
// Size: 0x88 // Inherited bytes: 0x00
struct FCachAirDropMarkSyncData {
	// Fields
	struct FMarkSyncData MarkSyncData; // Offset: 0x00 // Size: 0x70
	struct FAirDropVisionInfo AirDropVisionInfo; // Offset: 0x70 // Size: 0x14
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuffSpawnActorInstanceItem
// Size: 0x0c // Inherited bytes: 0x00
struct FBuffSpawnActorInstanceItem {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuffSpawnActorItem
// Size: 0x58 // Inherited bytes: 0x00
struct FBuffSpawnActorItem {
	// Fields
	struct UClass* ActorClass; // Offset: 0x00 // Size: 0x28
	struct FName SocketName; // Offset: 0x28 // Size: 0x08
	enum class EBuffTargetSocketType TargetType; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	struct FVector RelLocation; // Offset: 0x34 // Size: 0x0c
	struct FRotator Rotator; // Offset: 0x40 // Size: 0x0c
	enum class EBuffEnabledRole EnableRole; // Offset: 0x4c // Size: 0x01
	bool IsDestroyOnBuffEnd; // Offset: 0x4d // Size: 0x01
	char pad_0x4E[0x2]; // Offset: 0x4e // Size: 0x02
	float NotEndDestroyLifeTime; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PoisonFogStageConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FPoisonFogStageConfig {
	// Fields
	float InTime; // Offset: 0x00 // Size: 0x04
	float OutTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuildingConsumeData
// Size: 0x10 // Inherited bytes: 0x00
struct FBuildingConsumeData {
	// Fields
	int BuildingID; // Offset: 0x00 // Size: 0x04
	int ConsumeItemID; // Offset: 0x04 // Size: 0x04
	int ConsumeItemCount; // Offset: 0x08 // Size: 0x04
	int ReturnItemCount; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.FollowCandidateSortData
// Size: 0x08 // Inherited bytes: 0x00
struct FFollowCandidateSortData {
	// Fields
	struct ASTExtraBaseCharacter* Owner; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterDistanceSquareTickInternal
// Size: 0x08 // Inherited bytes: 0x00
struct FCharacterDistanceSquareTickInternal {
	// Fields
	float DistanceSquare; // Offset: 0x00 // Size: 0x04
	float TickInternal; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomSkillMoveData
// Size: 0x30 // Inherited bytes: 0x00
struct FCustomSkillMoveData {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
	struct UCurveFloat* SpeedCurve; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.UserCmdBitMsg
// Size: 0xf8 // Inherited bytes: 0x00
struct FUserCmdBitMsg {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x00 // Size: 0x30
	struct UPrimitiveComponent* ClientMovementBase; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0xc0]; // Offset: 0x38 // Size: 0xc0
};

// Object Name: ScriptStruct ShadowTrackerExtra.NearDeathRestoredOrignalHealthStruct
// Size: 0x10 // Inherited bytes: 0x00
struct FNearDeathRestoredOrignalHealthStruct {
	// Fields
	struct AUAEGameMode* GameModeClass; // Offset: 0x00 // Size: 0x08
	float Health; // Offset: 0x08 // Size: 0x04
	float BreathDecreathRate; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RestoringDurationWithGameModeStruct
// Size: 0x10 // Inherited bytes: 0x00
struct FRestoringDurationWithGameModeStruct {
	// Fields
	struct AUAEGameMode* GameModeClass; // Offset: 0x00 // Size: 0x08
	float Duration; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.anPickerData
// Size: 0x14 // Inherited bytes: 0x00
struct FanPickerData {
	// Fields
	float Radius; // Offset: 0x00 // Size: 0x04
	float Angle; // Offset: 0x04 // Size: 0x04
	float Offset; // Offset: 0x08 // Size: 0x04
	bool IsShowDebugFan; // Offset: 0x0c // Size: 0x01
	bool bEnableTrace; // Offset: 0x0d // Size: 0x01
	char pad_0xE[0x2]; // Offset: 0x0e // Size: 0x02
	float LowerTraceRatio; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HitEffectItemDataList
// Size: 0x50 // Inherited bytes: 0x00
struct FHitEffectItemDataList {
	// Fields
	struct TMap<enum class EPhysicalSurface, struct UParticleSystem*> ItemDataListMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.DecalData
// Size: 0x20 // Inherited bytes: 0x00
struct FDecalData {
	// Fields
	float DecalSize; // Offset: 0x00 // Size: 0x04
	float LifeSpan; // Offset: 0x04 // Size: 0x04
	struct UMaterial* DecalMaterial; // Offset: 0x08 // Size: 0x08
	float ImpactEffectStartScaleDistance; // Offset: 0x10 // Size: 0x04
	float ImpactEffectEndScaleDistance; // Offset: 0x14 // Size: 0x04
	float ImpactEffectStartScaleValue; // Offset: 0x18 // Size: 0x04
	float ImpactEffectEndScaleValue; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirborneSpeed
// Size: 0x40 // Inherited bytes: 0x00
struct FAirborneSpeed {
	// Fields
	struct FVector minSpeed; // Offset: 0x00 // Size: 0x0c
	struct FVector MaxSpeed; // Offset: 0x0c // Size: 0x0c
	struct FVector NormalSpeed; // Offset: 0x18 // Size: 0x0c
	struct FVector VerticalSpeed; // Offset: 0x24 // Size: 0x0c
	float TurnSpeed; // Offset: 0x30 // Size: 0x04
	struct FVector TurnSpeedV; // Offset: 0x34 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.NodeTargetSpeedOverrides
// Size: 0x10 // Inherited bytes: 0x00
struct FNodeTargetSpeedOverrides {
	// Fields
	float ForwardTargetSpeedOverride; // Offset: 0x00 // Size: 0x04
	float ForwardMaxSpeedOverride; // Offset: 0x04 // Size: 0x04
	float ReverseTargetSpeedOverride; // Offset: 0x08 // Size: 0x04
	float ReverseMaxSpeedOverride; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WaypointNetworkConnectionList
// Size: 0x10 // Inherited bytes: 0x00
struct FWaypointNetworkConnectionList {
	// Fields
	struct TArray<struct FWaypointNetworkConnection> Connections; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WaypointNetworkConnection
// Size: 0x10 // Inherited bytes: 0x00
struct FWaypointNetworkConnection {
	// Fields
	struct ASTExtraAIWaypointSegment* ConnectedSegment; // Offset: 0x00 // Size: 0x08
	int WaypointIndex; // Offset: 0x08 // Size: 0x04
	bool bPathSegmentInReverse; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.PathInputPlayZoneDistanceQuery
// Size: 0x10 // Inherited bytes: 0x00
struct FPathInputPlayZoneDistanceQuery {
	// Fields
	int ForwardDistance; // Offset: 0x00 // Size: 0x04
	bool bForwardQueryMade; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int ReverseDistance; // Offset: 0x08 // Size: 0x04
	bool bReverseQueryMade; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.PathPoint
// Size: 0x10 // Inherited bytes: 0x00
struct FPathPoint {
	// Fields
	struct ASTExtraAIWaypointSegment* Path; // Offset: 0x00 // Size: 0x08
	int InputKey; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.STExtraAnimInstanceProxy
// Size: 0x550 // Inherited bytes: 0x530
struct FSTExtraAnimInstanceProxy : FAnimInstanceProxy {
	// Fields
	struct ASTExtraBaseCharacter* OwnerPawn; // Offset: 0x528 // Size: 0x08
	struct USTExtraAnimInstanceBase* ParentAnimInst; // Offset: 0x530 // Size: 0x08
	char pad_0x540[0x10]; // Offset: 0x540 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ClientLeftUIInfoRecordData
// Size: 0x108 // Inherited bytes: 0x00
struct FClientLeftUIInfoRecordData {
	// Fields
	enum class ELeftUIInfoRecordType RecordType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int PhaseMark; // Offset: 0x04 // Size: 0x04
	struct FClientFatalDamageRecordData DamageInfo; // Offset: 0x08 // Size: 0x100
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomPlayerMakeupPic
// Size: 0x20 // Inherited bytes: 0x00
struct FCustomPlayerMakeupPic {
	// Fields
	struct FString PlayerUID; // Offset: 0x00 // Size: 0x10
	struct FString PlayerMakeupPicPath; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomTeamLogoAndColor
// Size: 0xf0 // Inherited bytes: 0x00
struct FCustomTeamLogoAndColor {
	// Fields
	int TeamNo; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString TeamName; // Offset: 0x08 // Size: 0x10
	struct FString TeamLogoPath; // Offset: 0x18 // Size: 0x10
	struct FColor TeamColor; // Offset: 0x28 // Size: 0x04
	struct FColor PlayerColor; // Offset: 0x2c // Size: 0x04
	struct FString CornerMarkPath; // Offset: 0x30 // Size: 0x10
	struct TMap<struct FString, struct UTexture2D*> TeamLogoTexture; // Offset: 0x40 // Size: 0x50
	struct FString KillInfoPath; // Offset: 0x90 // Size: 0x10
	struct TMap<struct FString, struct UTexture2D*> KillInfoTexture; // Offset: 0xa0 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.UTBuffAttachment
// Size: 0x20 // Inherited bytes: 0x00
struct FUTBuffAttachment {
	// Fields
	struct USceneComponent* Component; // Offset: 0x00 // Size: 0x08
	struct USceneComponent* ComponentEnemy; // Offset: 0x08 // Size: 0x08
	struct FName SocketName; // Offset: 0x10 // Size: 0x08
	bool bShowOnlyFirstPersonView; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuffAnimationTagItem
// Size: 0x28 // Inherited bytes: 0x00
struct FBuffAnimationTagItem {
	// Fields
	struct FName AnimationAssetTag; // Offset: 0x00 // Size: 0x08
	struct FName AnimationAssetTagFPP; // Offset: 0x08 // Size: 0x08
	struct FName AnimationMontageTag; // Offset: 0x10 // Size: 0x08
	struct FName AnimationMontageTagFPP; // Offset: 0x18 // Size: 0x08
	bool NeedReplayByChangFirstView; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuffAnimationItem
// Size: 0xa8 // Inherited bytes: 0x00
struct FBuffAnimationItem {
	// Fields
	struct UAnimationAsset* AnimationAssetToPlay; // Offset: 0x00 // Size: 0x28
	struct UAnimationAsset* AnimationAssetToPlayFPP; // Offset: 0x28 // Size: 0x28
	struct UAnimMontage* AnimationMontageToPlay; // Offset: 0x50 // Size: 0x28
	struct UAnimMontage* AnimationMontageToPlayFPP; // Offset: 0x78 // Size: 0x28
	bool NeedReplayByChangFirstView; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuffApplierConditionPair
// Size: 0x48 // Inherited bytes: 0x00
struct FBuffApplierConditionPair {
	// Fields
	enum class EBuffApplierCondition ConditionVar; // Offset: 0x00 // Size: 0x01
	bool IsShowDebugLine; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float InSightCheckAngle; // Offset: 0x04 // Size: 0x04
	float InnerRangeDistance; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct UCurveFloat* CurveExpirePerDistance; // Offset: 0x10 // Size: 0x08
	struct TArray<struct FName> BuffNameArray; // Offset: 0x18 // Size: 0x10
	struct TArray<int> BuffSkillIdArray; // Offset: 0x28 // Size: 0x10
	struct TArray<int> BuffSkillIdArrayForZombie; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.OBCircleInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FOBCircleInfo {
	// Fields
	int CircleStateStartServerWorldSecond; // Offset: 0x00 // Size: 0x04
	int CircleStatusLastTime; // Offset: 0x04 // Size: 0x04
	int CircleStatus; // Offset: 0x08 // Size: 0x04
	int CurrentCircleIndex; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.GM
// Size: 0x04 // Inherited bytes: 0x00
struct FGM {
	// Fields
	char GrassEnable : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_1 : 7; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.HelicopterTorqueCurveFloat
// Size: 0x10 // Inherited bytes: 0x00
struct FHelicopterTorqueCurveFloat {
	// Fields
	struct UCurveFloat* TorqueCurveFloat; // Offset: 0x00 // Size: 0x08
	float CurveTime; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuildingSearchPath
// Size: 0x18 // Inherited bytes: 0x00
struct FBuildingSearchPath {
	// Fields
	struct TArray<struct FBuildingSearchPathLink> itemPosLinkList; // Offset: 0x00 // Size: 0x10
	uint8_t buildingPartIndext; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuildingSearchPathLink
// Size: 0x18 // Inherited bytes: 0x00
struct FBuildingSearchPathLink {
	// Fields
	struct TArray<struct FVector> WayPointList; // Offset: 0x00 // Size: 0x10
	int targetSpotIndex; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HoverSimulateData
// Size: 0x40 // Inherited bytes: 0x00
struct FHoverSimulateData {
	// Fields
	float TraceLenght; // Offset: 0x00 // Size: 0x04
	float HoverDistance; // Offset: 0x04 // Size: 0x04
	float HoverDelta; // Offset: 0x08 // Size: 0x04
	float HoverDelta_Old; // Offset: 0x0c // Size: 0x04
	float SprintCoefficent; // Offset: 0x10 // Size: 0x04
	float DampingCoefficent; // Offset: 0x14 // Size: 0x04
	bool bInAir; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	float TickInterval; // Offset: 0x1c // Size: 0x04
	struct FVector TraceHitLocation; // Offset: 0x20 // Size: 0x0c
	struct FVector SimulateLocation; // Offset: 0x2c // Size: 0x0c
	struct UArrowComponent* ArrowComp; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionAnimResList
// Size: 0x50 // Inherited bytes: 0x00
struct FInfectionAnimResList {
	// Fields
	struct FPlayerAnimData MovementAnim; // Offset: 0x00 // Size: 0x10
	struct FPlayerAnimData HurtAnim; // Offset: 0x10 // Size: 0x10
	struct FPlayerAnimData TurnAnim; // Offset: 0x20 // Size: 0x10
	struct FPlayerAnimData PoseChangeAnim; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FPlayerAnimData> JumpAnimList; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharacterStatueInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FCharacterStatueInfo {
	// Fields
	int AGender; // Offset: 0x00 // Size: 0x04
	int Head; // Offset: 0x04 // Size: 0x04
	int Hair; // Offset: 0x08 // Size: 0x04
	int WeaponId; // Offset: 0x0c // Size: 0x04
	struct FString Name; // Offset: 0x10 // Size: 0x10
	struct FString Nation; // Offset: 0x20 // Size: 0x10
	struct TArray<int> AvatarList; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FGameModePlayerItem> AvatarInfoList; // Offset: 0x40 // Size: 0x10
	int Index; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirVehicleAudioState
// Size: 0x14 // Inherited bytes: 0x00
struct FAirVehicleAudioState {
	// Fields
	char pad_0x0[0x14]; // Offset: 0x00 // Size: 0x14
};

// Object Name: ScriptStruct ShadowTrackerExtra.RotorDamageConfig
// Size: 0x40 // Inherited bytes: 0x00
struct FRotorDamageConfig {
	// Fields
	float DamageCheckInterval; // Offset: 0x00 // Size: 0x04
	float MinRPMForDamage; // Offset: 0x04 // Size: 0x04
	float MaxSpeedInKmForTrace; // Offset: 0x08 // Size: 0x04
	float Damage; // Offset: 0x0c // Size: 0x04
	float LaunchSpeed; // Offset: 0x10 // Size: 0x04
	float LaunchUpScale; // Offset: 0x14 // Size: 0x04
	struct FName RotorDamageBone; // Offset: 0x18 // Size: 0x08
	struct FVector ComponentTraceOffset; // Offset: 0x20 // Size: 0x0c
	struct FVector BoxExtent; // Offset: 0x2c // Size: 0x0c
	struct UDamageType* DamageType; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.NewBuffApplierConditionPair
// Size: 0x30 // Inherited bytes: 0x00
struct FNewBuffApplierConditionPair {
	// Fields
	enum class ENewBuffApplierCondition ConditionVar; // Offset: 0x00 // Size: 0x01
	bool IsShowDebugLine; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float InSightCheckAngle; // Offset: 0x04 // Size: 0x04
	float InnerRangeDistance; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<int> BuffSkillIdArray; // Offset: 0x10 // Size: 0x10
	struct TArray<int> BuffSkillIdArrayForZombie; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PetLevelInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FPetLevelInfo {
	// Fields
	int PetId; // Offset: 0x00 // Size: 0x04
	int PetLevel; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PetVisibilityInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FPetVisibilityInfo {
	// Fields
	bool Visible; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Time; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.PetEventSyncData
// Size: 0x10 // Inherited bytes: 0x00
struct FPetEventSyncData {
	// Fields
	struct UPetEventItem* EventItem; // Offset: 0x00 // Size: 0x08
	float StartTime; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BuffEffectSettingTableRow
// Size: 0x20 // Inherited bytes: 0x00
struct FBuffEffectSettingTableRow {
	// Fields
	int EffectID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString SkillID; // Offset: 0x08 // Size: 0x10
	int EffectObj; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParachuteStateParams
// Size: 0x34 // Inherited bytes: 0x00
struct FParachuteStateParams {
	// Fields
	float MinForwardForce; // Offset: 0x00 // Size: 0x04
	float MaxForwardForce; // Offset: 0x04 // Size: 0x04
	float DragForceFractor; // Offset: 0x08 // Size: 0x04
	float MinPitchAngle; // Offset: 0x0c // Size: 0x04
	float MaxPitchAngle; // Offset: 0x10 // Size: 0x04
	float MinRollAngle; // Offset: 0x14 // Size: 0x04
	float MaxRollAngle; // Offset: 0x18 // Size: 0x04
	float MinForwardSpeed; // Offset: 0x1c // Size: 0x04
	float MaxForwardSpeed; // Offset: 0x20 // Size: 0x04
	float MinRightSpeed; // Offset: 0x24 // Size: 0x04
	float MaxRightSpeed; // Offset: 0x28 // Size: 0x04
	float MinDownSpeed; // Offset: 0x2c // Size: 0x04
	float MaxDownSpeed; // Offset: 0x30 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CacheTouchData
// Size: 0x34 // Inherited bytes: 0x00
struct FCacheTouchData {
	// Fields
	char pad_0x0[0x34]; // Offset: 0x00 // Size: 0x34
};

// Object Name: ScriptStruct ShadowTrackerExtra.PropSkillCureRangeParam
// Size: 0x10 // Inherited bytes: 0x00
struct FPropSkillCureRangeParam {
	// Fields
	float RangeLifeSpan; // Offset: 0x00 // Size: 0x04
	float CheckPeriod; // Offset: 0x04 // Size: 0x04
	float RangeRadius; // Offset: 0x08 // Size: 0x04
	int CureBuffID; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterBuffEffectSettingTableRow
// Size: 0x20 // Inherited bytes: 0x00
struct FMonsterBuffEffectSettingTableRow {
	// Fields
	int EffectID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString SkillID; // Offset: 0x08 // Size: 0x10
	int EffectObj; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimpleCharAnimParamList
// Size: 0x58 // Inherited bytes: 0x00
struct FSimpleCharAnimParamList {
	// Fields
	struct FVector Velocity; // Offset: 0x00 // Size: 0x0c
	struct FVector movedir; // Offset: 0x0c // Size: 0x0c
	enum class EMovementMode MovementMode; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	struct FRotator ViewRotation; // Offset: 0x1c // Size: 0x0c
	bool IsHurting; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	struct FVector HurtDir; // Offset: 0x2c // Size: 0x0c
	bool IsDying; // Offset: 0x38 // Size: 0x01
	bool IsJumping; // Offset: 0x39 // Size: 0x01
	bool IsTurning; // Offset: 0x3a // Size: 0x01
	bool ShouldPauseAnim; // Offset: 0x3b // Size: 0x01
	bool IsLeftRightMove; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
	int RandomAnimID; // Offset: 0x40 // Size: 0x04
	int IdleBlendSpaceValue; // Offset: 0x44 // Size: 0x04
	float AdditiveYaw; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0xc]; // Offset: 0x4c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimpleCharacterCachedDeathInfo
// Size: 0xc0 // Inherited bytes: 0x00
struct FSimpleCharacterCachedDeathInfo {
	// Fields
	char pad_0x0[0xc0]; // Offset: 0x00 // Size: 0xc0
};

// Object Name: ScriptStruct ShadowTrackerExtra.NightStatusRateMap
// Size: 0x50 // Inherited bytes: 0x00
struct FNightStatusRateMap {
	// Fields
	struct TMap<enum class ENightStatus, float> RateMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.StateMutual
// Size: 0x08 // Inherited bytes: 0x00
struct FStateMutual {
	// Fields
	int state1; // Offset: 0x00 // Size: 0x04
	int state2; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.UAVTorqueCurveFloat
// Size: 0x10 // Inherited bytes: 0x00
struct FUAVTorqueCurveFloat {
	// Fields
	struct UCurveFloat* TorqueCurveFloat; // Offset: 0x00 // Size: 0x08
	float CurveTime; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DriverAttachmentData
// Size: 0x80 // Inherited bytes: 0x00
struct FDriverAttachmentData {
	// Fields
	struct FName AttachmentDataName; // Offset: 0x00 // Size: 0x08
	struct UStaticMesh* AttachmentMesh; // Offset: 0x08 // Size: 0x28
	struct UStaticMesh* AttachmentMeshLod; // Offset: 0x30 // Size: 0x28
	struct FName AttachSocket; // Offset: 0x58 // Size: 0x08
	float AttachDelayTime; // Offset: 0x60 // Size: 0x04
	float DettachDelayTime; // Offset: 0x64 // Size: 0x04
	char pad_0x68[0x8]; // Offset: 0x68 // Size: 0x08
	struct UStaticMeshComponent* AttachmentComponentInstance; // Offset: 0x70 // Size: 0x08
	struct ASTExtraPlayerCharacter* AttachDriverCache; // Offset: 0x78 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.TextrueAsyncRequest
// Size: 0x30 // Inherited bytes: 0x00
struct FTextrueAsyncRequest {
	// Fields
	struct FString Path; // Offset: 0x00 // Size: 0x10
	struct UObject* ImageOuter; // Offset: 0x10 // Size: 0x08
	bool KeepSize; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	DelegateProperty Callback; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WidgetAsyncCreateData
// Size: 0x30 // Inherited bytes: 0x00
struct FWidgetAsyncCreateData {
	// Fields
	struct FString WidgetPath; // Offset: 0x00 // Size: 0x10
	struct TWeakObjectPtr<struct UObject> Outer; // Offset: 0x10 // Size: 0x08
	int InstID; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	DelegateProperty Callback; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DebugVehicleSpawn
// Size: 0x40 // Inherited bytes: 0x00
struct FDebugVehicleSpawn {
	// Fields
	int SpawnCount; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FName SpawnTag; // Offset: 0x08 // Size: 0x08
	bool bSpawnAtLocation; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	struct FVector SpawnLocation; // Offset: 0x14 // Size: 0x0c
	struct FRotator SpawnRotation; // Offset: 0x20 // Size: 0x0c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FWaypointNetworkConnection StartingPath; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleBehaviorPayload
// Size: 0x28 // Inherited bytes: 0x00
struct FVehicleBehaviorPayload {
	// Fields
	struct APawn* VehiclePawn; // Offset: 0x00 // Size: 0x08
	struct UBehaviorTree* BehaviorTree; // Offset: 0x08 // Size: 0x08
	struct UBlackboardData* BlackboardData; // Offset: 0x10 // Size: 0x08
	struct FWaypointNetworkConnection StartingPath; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleSpawn
// Size: 0xd0 // Inherited bytes: 0x08
struct FVehicleSpawn : FTableRowBase {
	// Fields
	struct FGuid ID; // Offset: 0x08 // Size: 0x10
	enum class ESpawnType SpawnType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct UClass* VehicleClass; // Offset: 0x20 // Size: 0x28
	struct UBehaviorTree* BehaviorTreeAsset; // Offset: 0x48 // Size: 0x28
	struct UBlackboardData* BlackboardDataAsset; // Offset: 0x70 // Size: 0x28
	float InitialSpawnDelay; // Offset: 0x98 // Size: 0x04
	float SubsequentSpawnDelay; // Offset: 0x9c // Size: 0x04
	int MaxTriggers; // Offset: 0xa0 // Size: 0x04
	char MinToSpawn; // Offset: 0xa4 // Size: 0x01
	char MaxToSpawn; // Offset: 0xa5 // Size: 0x01
	char pad_0xA6[0x2]; // Offset: 0xa6 // Size: 0x02
	struct FSpawnFilter SpawnFilter; // Offset: 0xa8 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpawnFilter
// Size: 0x28 // Inherited bytes: 0x00
struct FSpawnFilter {
	// Fields
	bool bLimitSpawnPoints; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FName> ValidSpawnPoints; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FName> InvalidSpawnPoints; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActiveVehicleList
// Size: 0x20 // Inherited bytes: 0x00
struct FActiveVehicleList {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
	struct TArray<struct APawn*> Vehicles; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.QueuedVehicleSpawn
// Size: 0x60 // Inherited bytes: 0x00
struct FQueuedVehicleSpawn {
	// Fields
	struct FGuid ID; // Offset: 0x00 // Size: 0x10
	struct FString SpawnId; // Offset: 0x10 // Size: 0x10
	struct APawn* VehicleClass; // Offset: 0x20 // Size: 0x08
	struct UBehaviorTree* BehaviorTree; // Offset: 0x28 // Size: 0x08
	struct UBlackboardData* BlackboardData; // Offset: 0x30 // Size: 0x08
	struct FSpawnFilter SpawnSettings; // Offset: 0x38 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.AutoDriveAIDataRow
// Size: 0x78 // Inherited bytes: 0x00
struct FAutoDriveAIDataRow {
	// Fields
	struct UClass* VehicleClass; // Offset: 0x00 // Size: 0x28
	struct UBehaviorTree* BehaviorTreeAsset; // Offset: 0x28 // Size: 0x28
	struct UBlackboardData* BlackboardDataAsset; // Offset: 0x50 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.ArmedVehicleWeaponConfig
// Size: 0x88 // Inherited bytes: 0x60
struct FArmedVehicleWeaponConfig : FSTExtraVehicleWeaponConfig {
	// Fields
	enum class EVehicleWeaponType WeaponType; // Offset: 0x5c // Size: 0x01
	enum class EVehicleWeaponParentType ParentType; // Offset: 0x5d // Size: 0x01
	struct FName PlayerSocket; // Offset: 0x60 // Size: 0x08
	struct TArray<int> AuthoritySeats; // Offset: 0x68 // Size: 0x10
	struct TArray<int> DefaultControlSeats; // Offset: 0x78 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterSpawnInfo
// Size: 0x68 // Inherited bytes: 0x00
struct FMonsterSpawnInfo {
	// Fields
	int FlowId; // Offset: 0x00 // Size: 0x04
	int MonsterID; // Offset: 0x04 // Size: 0x04
	int MonsterRebornTimes; // Offset: 0x08 // Size: 0x04
	int MonsterReBornDelay; // Offset: 0x0c // Size: 0x04
	int MonsterWaveId; // Offset: 0x10 // Size: 0x04
	int MonsterChapterID; // Offset: 0x14 // Size: 0x04
	int MonsterLevelID; // Offset: 0x18 // Size: 0x04
	float GenerateTime; // Offset: 0x1c // Size: 0x04
	struct FVector pos; // Offset: 0x20 // Size: 0x0c
	struct FRotator Rot; // Offset: 0x2c // Size: 0x0c
	int PosRadius; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct TArray<struct FRoadPointInfo> RoadPoints; // Offset: 0x40 // Size: 0x10
	enum class EMonsterSpawnSourceType SourceType; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
	struct APawn* CallPawn; // Offset: 0x58 // Size: 0x08
	uint32_t CallPawnKey; // Offset: 0x60 // Size: 0x04
	int CallType; // Offset: 0x64 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.LootProjectileRepMovement
// Size: 0x54 // Inherited bytes: 0x00
struct FLootProjectileRepMovement {
	// Fields
	struct FVector LinearVelocity; // Offset: 0x00 // Size: 0x0c
	struct FVector Location; // Offset: 0x0c // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x18 // Size: 0x0c
	struct FVector MeshLinearVelocity; // Offset: 0x24 // Size: 0x0c
	struct FVector MeshAngularVelocity; // Offset: 0x30 // Size: 0x0c
	struct FVector MeshLocation; // Offset: 0x3c // Size: 0x0c
	struct FRotator MeshRotation; // Offset: 0x48 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.StrongholdWeaponBoxConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FStrongholdWeaponBoxConfig {
	// Fields
	struct FString WeaponBoxType; // Offset: 0x00 // Size: 0x10
	struct FVector RelativeLocation; // Offset: 0x10 // Size: 0x0c
	struct FRotator RelativeRotation; // Offset: 0x1c // Size: 0x0c
	bool bAttachToLifer; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.StrongholdMiniMapData
// Size: 0x88 // Inherited bytes: 0x00
struct FStrongholdMiniMapData {
	// Fields
	char pad_0x0[0x70]; // Offset: 0x00 // Size: 0x70
	int MapIconID; // Offset: 0x70 // Size: 0x04
	int DelayShowCD; // Offset: 0x74 // Size: 0x04
	int UnActivatedIndex; // Offset: 0x78 // Size: 0x04
	int ActivatedIndex; // Offset: 0x7c // Size: 0x04
	int GrayIndex; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MultiAppearanceMeshData
// Size: 0x18 // Inherited bytes: 0x00
struct FMultiAppearanceMeshData {
	// Fields
	struct UStaticMeshComponent* MultiAppearanceMesh; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x10]; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AppearanceMeshData
// Size: 0x40 // Inherited bytes: 0x00
struct FAppearanceMeshData {
	// Fields
	struct UStaticMeshComponent* AppearanceMeshComp; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x38]; // Offset: 0x08 // Size: 0x38
};

// Object Name: ScriptStruct ShadowTrackerExtra.ScreenParticleEffectData
// Size: 0x80 // Inherited bytes: 0x00
struct FScreenParticleEffectData {
	// Fields
	enum class EScreenParticleEffectType EffectType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString ScreenParticleEffectName; // Offset: 0x08 // Size: 0x10
	struct UParticleSystem* ParticleEffect; // Offset: 0x18 // Size: 0x28
	struct FName ParticleParamName; // Offset: 0x40 // Size: 0x08
	struct TArray<struct FString> ExtraScreenAppearanceList; // Offset: 0x48 // Size: 0x10
	struct FVector ScreenParticleEffectLoc; // Offset: 0x58 // Size: 0x0c
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct UParticleSystemComponent* EffectComponent; // Offset: 0x68 // Size: 0x08
	bool KeepWorldRotation; // Offset: 0x70 // Size: 0x01
	bool bNeedReset; // Offset: 0x71 // Size: 0x01
	bool IsShowing; // Offset: 0x72 // Size: 0x01
	char pad_0x73[0x1]; // Offset: 0x73 // Size: 0x01
	float CurrentParamValue; // Offset: 0x74 // Size: 0x04
	enum class EPlatformDeviceLevel DisableDeviceLevel; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x7]; // Offset: 0x79 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.MltAppearanceMatData
// Size: 0x80 // Inherited bytes: 0x00
struct FMltAppearanceMatData {
	// Fields
	struct FString AppearanceKey; // Offset: 0x00 // Size: 0x10
	struct FName AppearanceTag; // Offset: 0x10 // Size: 0x08
	char pad_0x18[0x8]; // Offset: 0x18 // Size: 0x08
	struct FTransform AppearanceMeshRelativeTransform; // Offset: 0x20 // Size: 0x30
	struct UMaterialInterface* ParentMaterial; // Offset: 0x50 // Size: 0x08
	float MatialAlpha; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct UMaterialInstanceDynamic* AppearanceMat; // Offset: 0x60 // Size: 0x08
	struct UStaticMeshComponent* OwnerAppearanceMesh; // Offset: 0x68 // Size: 0x08
	bool IsLogicShow; // Offset: 0x70 // Size: 0x01
	bool IsShowOut; // Offset: 0x71 // Size: 0x01
	bool IsShowIn; // Offset: 0x72 // Size: 0x01
	char pad_0x73[0x1]; // Offset: 0x73 // Size: 0x01
	float GradualFrag; // Offset: 0x74 // Size: 0x04
	float DelayTime; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AppearanceMatData
// Size: 0xb0 // Inherited bytes: 0x00
struct FAppearanceMatData {
	// Fields
	struct FString AppearanceKey; // Offset: 0x00 // Size: 0x10
	float LifeSpan; // Offset: 0x10 // Size: 0x04
	bool IgnoreIndoor; // Offset: 0x14 // Size: 0x01
	bool HideUI; // Offset: 0x15 // Size: 0x01
	char pad_0x16[0x2]; // Offset: 0x16 // Size: 0x02
	struct UMaterialInterface* ParentMaterial; // Offset: 0x18 // Size: 0x28
	struct UMaterialInstanceDynamic* AppearanceMat; // Offset: 0x40 // Size: 0x08
	struct UStaticMeshComponent* AppearanceMeshComp; // Offset: 0x48 // Size: 0x08
	char pad_0x50[0x10]; // Offset: 0x50 // Size: 0x10
	struct FTransform AppearanceMeshRelativeTransform; // Offset: 0x60 // Size: 0x30
	struct FName MatInstParamName; // Offset: 0x90 // Size: 0x08
	struct UCurveFloat* ParamCurve; // Offset: 0x98 // Size: 0x08
	char pad_0xA0[0x10]; // Offset: 0xa0 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SelectTouchPointCach
// Size: 0x10 // Inherited bytes: 0x00
struct FSelectTouchPointCach {
	// Fields
	int FingerIndex; // Offset: 0x00 // Size: 0x04
	struct FVector2D TouchLoc; // Offset: 0x04 // Size: 0x08
	float TouchTime; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SupplySpotConfig
// Size: 0x14 // Inherited bytes: 0x00
struct FSupplySpotConfig {
	// Fields
	struct FVector SSLocation; // Offset: 0x00 // Size: 0x0c
	int SSCount; // Offset: 0x0c // Size: 0x04
	int SSBulletCount; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimpleCrossHairData
// Size: 0x20 // Inherited bytes: 0x00
struct FSimpleCrossHairData {
	// Fields
	struct FString Tag; // Offset: 0x00 // Size: 0x10
	struct UTexture2D* CrossHairTexture; // Offset: 0x10 // Size: 0x08
	float Scale; // Offset: 0x18 // Size: 0x04
	int Priority; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.HitPerformData
// Size: 0x90 // Inherited bytes: 0x00
struct FHitPerformData {
	// Fields
	struct TArray<struct FWeaponCrossHairIconData> IconList; // Offset: 0x00 // Size: 0x10
	float DefaultSpread; // Offset: 0x10 // Size: 0x04
	float SpreadMax; // Offset: 0x14 // Size: 0x04
	float HeadExtraScale; // Offset: 0x18 // Size: 0x04
	float AddSpreadScale; // Offset: 0x1c // Size: 0x04
	float SpreadDecreaseSpeed; // Offset: 0x20 // Size: 0x04
	float DefaultOffset; // Offset: 0x24 // Size: 0x04
	float DefaultAlpha; // Offset: 0x28 // Size: 0x04
	float AlphaDecreaseSpeed; // Offset: 0x2c // Size: 0x04
	char IsHeadShot : 1; // Offset: 0x30 // Size: 0x01
	char pad_0x30_1 : 7; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	struct FLinearColor HitBodyDrawColor; // Offset: 0x34 // Size: 0x10
	struct FLinearColor HitHeadDrawColor; // Offset: 0x44 // Size: 0x10
	struct FLinearColor HitToDeathDrawColor; // Offset: 0x54 // Size: 0x10
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct UAkAudioEvent* HeadShotSound; // Offset: 0x68 // Size: 0x08
	struct UAkAudioEvent* BodyShotSound; // Offset: 0x70 // Size: 0x08
	struct UAkAudioEvent* DeadlyShotSound; // Offset: 0x78 // Size: 0x08
	float CurCrosshairSpread; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0xc]; // Offset: 0x84 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.TankTrackEffect
// Size: 0x40 // Inherited bytes: 0x00
struct FTankTrackEffect {
	// Fields
	struct TArray<enum class EPhysicalSurface> TrackEffectMatList; // Offset: 0x00 // Size: 0x10
	struct UParticleSystem* MoveFx; // Offset: 0x10 // Size: 0x08
	struct TArray<struct FTransform> EffectTransforms; // Offset: 0x18 // Size: 0x10
	int ValidDeviceLevel; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString AudioSwitchState; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.TaskAreaData
// Size: 0x18 // Inherited bytes: 0x00
struct FTaskAreaData {
	// Fields
	int TaskAreaType; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString TaskAreaAnchorsStr; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AutoChooseParachuteTeamLeaderData
// Size: 0x48 // Inherited bytes: 0x00
struct FAutoChooseParachuteTeamLeaderData {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	struct FString PlayerName; // Offset: 0x08 // Size: 0x10
	float MaxRankingScore; // Offset: 0x18 // Size: 0x04
	int LeaderCount; // Offset: 0x1c // Size: 0x04
	uint64 LastGameLeaderUID; // Offset: 0x20 // Size: 0x08
	struct TArray<uint64> LastGameTeammatesUID; // Offset: 0x28 // Size: 0x10
	uint64 LastGameBattleID; // Offset: 0x38 // Size: 0x08
	bool bDoInitialFollow; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.TeamRelevantHealth
// Size: 0x08 // Inherited bytes: 0x00
struct FTeamRelevantHealth {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	float Health; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.TickListItem
// Size: 0x10 // Inherited bytes: 0x00
struct FTickListItem {
	// Fields
	struct UActorComponent* Comp; // Offset: 0x00 // Size: 0x08
	enum class ECustomTickRoleType RoleType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.RegisterTimerInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FRegisterTimerInfo {
	// Fields
	struct TArray<struct FRegisterDelayTime> DelayTimes; // Offset: 0x00 // Size: 0x10
	char pad_0x10[0x10]; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RegisterDelayTime
// Size: 0x20 // Inherited bytes: 0x00
struct FRegisterDelayTime {
	// Fields
	float DelayTime; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> CallBackPar; // Offset: 0x08 // Size: 0x10
	bool IsDone; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.RegisterTimer
// Size: 0x28 // Inherited bytes: 0x00
struct FRegisterTimer {
	// Fields
	int waveIndex; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<float> Times; // Offset: 0x08 // Size: 0x10
	char pad_0x18[0x10]; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.TrailMarkInputData
// Size: 0x50 // Inherited bytes: 0x00
struct FTrailMarkInputData {
	// Fields
	bool bContainValidData; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0xf]; // Offset: 0x01 // Size: 0x0f
	struct FTransform Trans; // Offset: 0x10 // Size: 0x30
	struct FVector Normal; // Offset: 0x40 // Size: 0x0c
	enum class ETrailMarkType Type; // Offset: 0x4c // Size: 0x01
	bool bBackWheel; // Offset: 0x4d // Size: 0x01
	char pad_0x4E[0x2]; // Offset: 0x4e // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.ActorHealthSegment
// Size: 0x08 // Inherited bytes: 0x00
struct FActorHealthSegment {
	// Fields
	float MinRatio; // Offset: 0x00 // Size: 0x04
	float MaxRatio; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.Action_PendDestroyActor
// Size: 0x10 // Inherited bytes: 0x00
struct FAction_PendDestroyActor {
	// Fields
	struct AActor* DestroyActor; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.Action_DestroyActorTag
// Size: 0x18 // Inherited bytes: 0x00
struct FAction_DestroyActorTag {
	// Fields
	struct FString Tag; // Offset: 0x00 // Size: 0x10
	enum class KilledReason Reason; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RevivalBackpackTimelineParam
// Size: 0x18 // Inherited bytes: 0x00
struct FRevivalBackpackTimelineParam {
	// Fields
	int TimelineSeconds; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FRevivalBackpackParam> RevivalBackbackCfgs; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RevivalBackpackParam
// Size: 0x28 // Inherited bytes: 0x00
struct FRevivalBackpackParam {
	// Fields
	struct FRevivalWithAllItemData ItemCfg; // Offset: 0x00 // Size: 0x20
	int Weight; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RevivalWithAllItemData
// Size: 0x20 // Inherited bytes: 0x00
struct FRevivalWithAllItemData {
	// Fields
	struct TArray<struct FRevivalWithItemData> ItemDatas; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FRevivalWithWeaponData> WeaponDatas; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RevivalWithItemData
// Size: 0x18 // Inherited bytes: 0x00
struct FRevivalWithItemData {
	// Fields
	int ItemTypeID; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
	char pad_0x8[0x10]; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RevivalWithWeaponData
// Size: 0x30 // Inherited bytes: 0x18
struct FRevivalWithWeaponData : FRevivalWithItemData {
	// Fields
	enum class ESurviveWeaponPropSlot WeaponSlot; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct TArray<struct FRevivalWithItemData> AttachmentDatas; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirplaneParam
// Size: 0x38 // Inherited bytes: 0x00
struct FAirplaneParam {
	// Fields
	struct APawn* PlaneClass; // Offset: 0x00 // Size: 0x08
	float Radius1; // Offset: 0x08 // Size: 0x04
	float Radius3; // Offset: 0x0c // Size: 0x04
	float Radius2; // Offset: 0x10 // Size: 0x04
	struct FVector MapCenter; // Offset: 0x14 // Size: 0x0c
	float PlaneSpeed; // Offset: 0x20 // Size: 0x04
	float PlaneHeight; // Offset: 0x24 // Size: 0x04
	float CanOpenParachuteHeight; // Offset: 0x28 // Size: 0x04
	float ForceOpenParachuteHeight; // Offset: 0x2c // Size: 0x04
	float CloseParachuteHeight; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RepeatSpawnItemCD
// Size: 0x08 // Inherited bytes: 0x00
struct FRepeatSpawnItemCD {
	// Fields
	int idx; // Offset: 0x00 // Size: 0x04
	float CurrentSpawnItemCD; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RandomRule
// Size: 0x28 // Inherited bytes: 0x00
struct FRandomRule {
	// Fields
	struct TArray<int> ItemIDs; // Offset: 0x00 // Size: 0x10
	struct TArray<int> ItemCounts; // Offset: 0x10 // Size: 0x10
	int RuleID; // Offset: 0x20 // Size: 0x04
	int Weight; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DropItemRule
// Size: 0x10 // Inherited bytes: 0x00
struct FDropItemRule {
	// Fields
	int ItemDropPercent; // Offset: 0x00 // Size: 0x04
	int ItemDropRuleStartID; // Offset: 0x04 // Size: 0x04
	int ItemDropRuleEndID; // Offset: 0x08 // Size: 0x04
	int ItemDropMode; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DropItemData
// Size: 0x0c // Inherited bytes: 0x00
struct FDropItemData {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int ItemCount; // Offset: 0x04 // Size: 0x04
	int DropMode; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpawnItemCfg
// Size: 0x1b8 // Inherited bytes: 0x00
struct FSpawnItemCfg {
	// Fields
	enum class ESpawnActorCollisionHandlingMethod SpawnActorCollisionHandlingMethod; // Offset: 0x00 // Size: 0x01
	enum class ESpawnItemFunction SpawnItemFunction; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct TArray<struct FSecondsSegment> SecondsSegmentCondition; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FString> LineTracePlaceInclude; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FString> LineTracePlaceExclude; // Offset: 0x28 // Size: 0x10
	int GenerateSpotCountPerTick; // Offset: 0x38 // Size: 0x04
	bool bItemGenerateOffset; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
	struct FVector ItemGenerateOffset; // Offset: 0x40 // Size: 0x0c
	bool bSpawnLocationZOffset; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
	float SpawnLocationZOffset; // Offset: 0x50 // Size: 0x04
	bool bRandomSpawnRotatorYaw; // Offset: 0x54 // Size: 0x01
	bool bSpawnRotatorYaw; // Offset: 0x55 // Size: 0x01
	char pad_0x56[0x2]; // Offset: 0x56 // Size: 0x02
	float ItemSpawnRotatorYaw; // Offset: 0x58 // Size: 0x04
	bool bUseCookedRotator; // Offset: 0x5c // Size: 0x01
	bool bUseSpotPercent; // Offset: 0x5d // Size: 0x01
	bool bNetCullDistance; // Offset: 0x5e // Size: 0x01
	char pad_0x5F[0x1]; // Offset: 0x5f // Size: 0x01
	float NetCullDistance; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct FString CookedFilePath; // Offset: 0x68 // Size: 0x10
	struct TArray<struct FString> DeleteCategoryList; // Offset: 0x78 // Size: 0x10
	int DropHeight; // Offset: 0x88 // Size: 0x04
	int AppearRadiusStart; // Offset: 0x8c // Size: 0x04
	int AppearRadius; // Offset: 0x90 // Size: 0x04
	int AppearRadiusSecondLevel; // Offset: 0x94 // Size: 0x04
	bool bExpressUseSpotLocation; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x3]; // Offset: 0x99 // Size: 0x03
	float ExpressUseSpotLocationMinDistance; // Offset: 0x9c // Size: 0x04
	float ExpressUseSpotLocationMaxDistance; // Offset: 0xa0 // Size: 0x04
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
	struct FString MonsterSpawnDataTablePath; // Offset: 0xa8 // Size: 0x10
	struct FString TreasureBoxTablePath; // Offset: 0xb8 // Size: 0x10
	struct FString ItemSpawnDataTablePath; // Offset: 0xc8 // Size: 0x10
	bool bCombinationCategoryAndValue; // Offset: 0xd8 // Size: 0x01
	bool bSpotPerGroupNumCtrl; // Offset: 0xd9 // Size: 0x01
	char pad_0xDA[0x2]; // Offset: 0xda // Size: 0x02
	int NeedSpotPerGroupMin; // Offset: 0xdc // Size: 0x04
	int NeedSpotPerGroupMax; // Offset: 0xe0 // Size: 0x04
	bool bGroupNumCtrl; // Offset: 0xe4 // Size: 0x01
	char pad_0xE5[0x3]; // Offset: 0xe5 // Size: 0x03
	int NeedGroupMin; // Offset: 0xe8 // Size: 0x04
	int NeedGroupMax; // Offset: 0xec // Size: 0x04
	bool bGeneratedBySpotFileDirect; // Offset: 0xf0 // Size: 0x01
	enum class EAirDropType AirDropType; // Offset: 0xf1 // Size: 0x01
	bool RandomItemAtItemSpotUseSpotPercent; // Offset: 0xf2 // Size: 0x01
	bool bExcludeUsedGroup; // Offset: 0xf3 // Size: 0x01
	bool bExcludeUsedSpot; // Offset: 0xf4 // Size: 0x01
	bool bNeedInBlueCircle; // Offset: 0xf5 // Size: 0x01
	bool UseGroupInBlueCircle; // Offset: 0xf6 // Size: 0x01
	bool bNeedInWhiteCircle; // Offset: 0xf7 // Size: 0x01
	bool UseGroupInWhiteCircle; // Offset: 0xf8 // Size: 0x01
	bool UseExcludeAirLine; // Offset: 0xf9 // Size: 0x01
	char pad_0xFA[0x2]; // Offset: 0xfa // Size: 0x02
	float ExcludeAirLineDistance; // Offset: 0xfc // Size: 0x04
	bool UseIncludeAirLine; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x3]; // Offset: 0x101 // Size: 0x03
	float IncludeAirLineDistance; // Offset: 0x104 // Size: 0x04
	bool UseItemGeneratorAreaItem; // Offset: 0x108 // Size: 0x01
	bool UseItemGeneratorAreaIIDItem; // Offset: 0x109 // Size: 0x01
	bool UseSpotTriggerOtherSpot; // Offset: 0x10a // Size: 0x01
	char pad_0x10B[0x5]; // Offset: 0x10b // Size: 0x05
	struct TArray<struct FSpotTriggerOtherSpot> SpotTriggerOtherSpotList; // Offset: 0x110 // Size: 0x10
	bool UseCleanUpSpot; // Offset: 0x120 // Size: 0x01
	bool bNeedAircraft; // Offset: 0x121 // Size: 0x01
	bool bExpressItemNumCtrl; // Offset: 0x122 // Size: 0x01
	char pad_0x123[0x1]; // Offset: 0x123 // Size: 0x01
	int ExpressItemNumMin; // Offset: 0x124 // Size: 0x04
	int ExpressItemNumMax; // Offset: 0x128 // Size: 0x04
	bool bExpressItemNumPerPlayerCtrl; // Offset: 0x12c // Size: 0x01
	char pad_0x12D[0x3]; // Offset: 0x12d // Size: 0x03
	int ExpressItemNumPerPlayer; // Offset: 0x130 // Size: 0x04
	int ExpressItemNumPerPlayerTotal; // Offset: 0x134 // Size: 0x04
	bool bSpawnExpressItemPerPlayerCD; // Offset: 0x138 // Size: 0x01
	char pad_0x139[0x3]; // Offset: 0x139 // Size: 0x03
	float SpawnExpressItemPerPlayerCD; // Offset: 0x13c // Size: 0x04
	bool bSupplementExpressItemCD; // Offset: 0x140 // Size: 0x01
	char pad_0x141[0x3]; // Offset: 0x141 // Size: 0x03
	float SupplementExpressItemCD; // Offset: 0x144 // Size: 0x04
	bool bExpressReplaceZombie; // Offset: 0x148 // Size: 0x01
	bool bDestroySpots; // Offset: 0x149 // Size: 0x01
	bool bAISpawnExpressItem; // Offset: 0x14a // Size: 0x01
	bool bAttachToHostActor; // Offset: 0x14b // Size: 0x01
	bool bCaculateRelativeTransform; // Offset: 0x14c // Size: 0x01
	bool bAttachToHostActorIsStatic; // Offset: 0x14d // Size: 0x01
	bool UseSpawnTogetherClass; // Offset: 0x14e // Size: 0x01
	bool IsTogetherItemSameAsMainItem; // Offset: 0x14f // Size: 0x01
	bool UseDropLifeTime; // Offset: 0x150 // Size: 0x01
	char pad_0x151[0x3]; // Offset: 0x151 // Size: 0x03
	float DropLifeTime; // Offset: 0x154 // Size: 0x04
	bool UseDropItem; // Offset: 0x158 // Size: 0x01
	char pad_0x159[0x7]; // Offset: 0x159 // Size: 0x07
	struct FDropItemCfg DropItemCfg; // Offset: 0x160 // Size: 0x30
	bool UseRepeatItem; // Offset: 0x190 // Size: 0x01
	char pad_0x191[0x3]; // Offset: 0x191 // Size: 0x03
	struct FRepeatItemCfg RepeatItemCfg; // Offset: 0x194 // Size: 0x04
	int FuelPercentMax; // Offset: 0x198 // Size: 0x04
	bool ActiveByStartVolume; // Offset: 0x19c // Size: 0x01
	bool UseLocationID; // Offset: 0x19d // Size: 0x01
	bool bRegistHostActor; // Offset: 0x19e // Size: 0x01
	bool bUseItemIndex; // Offset: 0x19f // Size: 0x01
	bool bSpawnPedestal; // Offset: 0x1a0 // Size: 0x01
	char pad_0x1A1[0x7]; // Offset: 0x1a1 // Size: 0x07
	struct TArray<struct FSpotGroupProperty> SpotGroupProperties; // Offset: 0x1a8 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.RepeatItemCfg
// Size: 0x04 // Inherited bytes: 0x00
struct FRepeatItemCfg {
	// Fields
	float RepeatSpawnItemCD; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DropItemCfg
// Size: 0x30 // Inherited bytes: 0x00
struct FDropItemCfg {
	// Fields
	struct FString DropConfigTablePath; // Offset: 0x00 // Size: 0x10
	struct FString DropRuleConfigTablePath; // Offset: 0x10 // Size: 0x10
	bool UseDropID; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	int DropID; // Offset: 0x24 // Size: 0x04
	bool UseActorLocation; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int MaxRandomWeight; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpotTriggerOtherSpot
// Size: 0x20 // Inherited bytes: 0x00
struct FSpotTriggerOtherSpot {
	// Fields
	struct FString SrcSpotTag; // Offset: 0x00 // Size: 0x10
	struct FString DstSpotTag; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SecondsSegment
// Size: 0x08 // Inherited bytes: 0x00
struct FSecondsSegment {
	// Fields
	float BeginSeconds; // Offset: 0x00 // Size: 0x04
	float EndSeconds; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ItemGenerateSpawnDatas
// Size: 0x20 // Inherited bytes: 0x00
struct FItemGenerateSpawnDatas {
	// Fields
	struct FString ValueCatetory; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FItemGenerateSpawnData> AllGenerateSpawnDatas; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.GroupLocationToID
// Size: 0x10 // Inherited bytes: 0x00
struct FGroupLocationToID {
	// Fields
	struct FVector GroupLocation; // Offset: 0x00 // Size: 0x0c
	int ID; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.GroupLocationPercent
// Size: 0x10 // Inherited bytes: 0x00
struct FGroupLocationPercent {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	int percent; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.Location2HostActor
// Size: 0x18 // Inherited bytes: 0x00
struct FLocation2HostActor {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct AActor* Host; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ScmHitbox
// Size: 0x50 // Inherited bytes: 0x00
struct FScmHitbox {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimpleCollisionEvent
// Size: 0x10 // Inherited bytes: 0x00
struct FSimpleCollisionEvent {
	// Fields
	struct UObject* Target; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.BoundingSpherePersistentChecker
// Size: 0x528 // Inherited bytes: 0x00
struct FBoundingSpherePersistentChecker {
	// Fields
	char pad_0x0[0x528]; // Offset: 0x00 // Size: 0x528
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimpleSpherePersistentChecker
// Size: 0x20 // Inherited bytes: 0x00
struct FSimpleSpherePersistentChecker {
	// Fields
	struct UPrimitiveComponent* TargetComponent; // Offset: 0x00 // Size: 0x08
	struct FSimpleCollisionSphere Sphere; // Offset: 0x08 // Size: 0x10
	float PassedTime; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimpleCollisionSphere
// Size: 0x10 // Inherited bytes: 0x00
struct FSimpleCollisionSphere {
	// Fields
	struct FVector Origin; // Offset: 0x00 // Size: 0x0c
	float Radius; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimpleCapsulePersistentChecker
// Size: 0x28 // Inherited bytes: 0x00
struct FSimpleCapsulePersistentChecker {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimpleCapsuleCheck
// Size: 0x28 // Inherited bytes: 0x00
struct FSimpleCapsuleCheck {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimpleCollisionLine
// Size: 0x3c // Inherited bytes: 0x00
struct FSimpleCollisionLine {
	// Fields
	struct FVector Start; // Offset: 0x00 // Size: 0x0c
	struct FVector End; // Offset: 0x0c // Size: 0x0c
	struct FVector HitLocation; // Offset: 0x18 // Size: 0x0c
	struct FVector ImpactLocation; // Offset: 0x24 // Size: 0x0c
	struct FVector HitNormal; // Offset: 0x30 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimpleCollisionHull
// Size: 0x68 // Inherited bytes: 0x00
struct FSimpleCollisionHull {
	// Fields
	struct FVector Origin; // Offset: 0x00 // Size: 0x0c
	char pad_0xC[0x5c]; // Offset: 0x0c // Size: 0x5c
};

// Object Name: ScriptStruct ShadowTrackerExtra.SimpleCollisionCapsule
// Size: 0x1c // Inherited bytes: 0x00
struct FSimpleCollisionCapsule {
	// Fields
	struct FVector Start; // Offset: 0x00 // Size: 0x0c
	struct FVector End; // Offset: 0x0c // Size: 0x0c
	float Radius; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.FocusTargetItem
// Size: 0x38 // Inherited bytes: 0x00
struct FFocusTargetItem {
	// Fields
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x00 // Size: 0x08
	struct FVector Position; // Offset: 0x08 // Size: 0x0c
	bool IsStartTurnTarget; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	float TurnTargetVelocity; // Offset: 0x18 // Size: 0x04
	struct FRotator LastActorRotation; // Offset: 0x1c // Size: 0x0c
	struct FString CurveName; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.DynamicMatImageInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FDynamicMatImageInfo {
	// Fields
	struct FName MatParmName; // Offset: 0x00 // Size: 0x08
	struct UImage* DynamicMatImage; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.UIElemLayoutDetail
// Size: 0x30 // Inherited bytes: 0x00
struct FUIElemLayoutDetail {
	// Fields
	int Type; // Offset: 0x00 // Size: 0x04
	float Opacity; // Offset: 0x04 // Size: 0x04
	struct FVector2D Scale; // Offset: 0x08 // Size: 0x08
	struct FAnchors AnchorType; // Offset: 0x10 // Size: 0x10
	struct FVector2D RelativePos; // Offset: 0x20 // Size: 0x08
	struct FVector2D OriginSize; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillGSLisenterWarpper
// Size: 0x08 // Inherited bytes: 0x00
struct FSkillGSLisenterWarpper {
	// Fields
	struct UGSListenerBase* ListenerBase; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionAsyncloadAnimParams
// Size: 0x08 // Inherited bytes: 0x00
struct FInfectionAsyncloadAnimParams {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionJumpPhaseAnimData
// Size: 0xc8 // Inherited bytes: 0x00
struct FInfectionJumpPhaseAnimData {
	// Fields
	enum class EInfectionJumpType JumpType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FInfectionJumpTypeAnimData JumpPhase_PreJump; // Offset: 0x08 // Size: 0x30
	struct FInfectionJumpTypeAnimData JumpPhase_FallLoop; // Offset: 0x38 // Size: 0x30
	struct FInfectionJumpTypeAnimData JumpPhase_Land; // Offset: 0x68 // Size: 0x30
	struct FInfectionJumpTypeAnimData JumpPhase_LandHard; // Offset: 0x98 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionJumpTypeAnimData
// Size: 0x30 // Inherited bytes: 0x00
struct FInfectionJumpTypeAnimData {
	// Fields
	enum class EInfectionJumpPhase PhaseType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UAnimationAsset* JumpAnimSoftPtr; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionMovementAnimData
// Size: 0x68 // Inherited bytes: 0x00
struct FInfectionMovementAnimData {
	// Fields
	enum class EInfectionAnimType AnimType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FInfectionPoseAnimData PoseAnim_Stand; // Offset: 0x08 // Size: 0x30
	struct FInfectionPoseAnimData PoseAnim_Crouch; // Offset: 0x38 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.InfectionPoseAnimData
// Size: 0x30 // Inherited bytes: 0x00
struct FInfectionPoseAnimData {
	// Fields
	enum class EInfectionPoseType PoseType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UAnimationAsset* PoseAnimSoftPtr; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.MonsterAnimPhaseData
// Size: 0x30 // Inherited bytes: 0x00
struct FMonsterAnimPhaseData {
	// Fields
	enum class EMonsterPoseType PosType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UAnimationAsset* PhaseAnimSoftPtr; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.PVELinkLevelData
// Size: 0x10 // Inherited bytes: 0x00
struct FPVELinkLevelData {
	// Fields
	struct TArray<struct FString> levelList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimDeviceConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FAnimDeviceConfig {
	// Fields
	int SameScreenFreeCount; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FAnimLODConfig> LODGroups; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimLODConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FAnimLODConfig {
	// Fields
	int SameScreenRange; // Offset: 0x00 // Size: 0x04
	float MaxDistanceFactorRange; // Offset: 0x04 // Size: 0x04
	int SkipFrame; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AnimUpdateRateParamDebugOptions
// Size: 0x78 // Inherited bytes: 0x00
struct FAnimUpdateRateParamDebugOptions {
	// Fields
	char bShouldUseLodMap : 1; // Offset: 0x00 // Size: 0x01
	char bUseSkipMapForDistanceFactor : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_2 : 6; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TMap<int, int> LODToFrameSkipMap; // Offset: 0x08 // Size: 0x50
	struct TArray<float> BaseVisibleDistanceFactorThesholds; // Offset: 0x58 // Size: 0x10
	int MinDistFromMainChar; // Offset: 0x68 // Size: 0x04
	int MaxDistFromMainChar; // Offset: 0x6c // Size: 0x04
	int BaseNonRenderedUpdateRate; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.LODToSkipFrame
// Size: 0x08 // Inherited bytes: 0x00
struct FLODToSkipFrame {
	// Fields
	int LODLevel; // Offset: 0x00 // Size: 0x04
	int SkipFrame; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BunchAction
// Size: 0x10 // Inherited bytes: 0x00
struct FBunchAction {
	// Fields
	struct UUTSkillEffect* Effect; // Offset: 0x00 // Size: 0x08
	bool bExeReset; // Offset: 0x08 // Size: 0x01
	bool bExeUndo; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
};

// Object Name: ScriptStruct ShadowTrackerExtra.ViewInfoCurve
// Size: 0x5e0 // Inherited bytes: 0x00
struct FViewInfoCurve {
	// Fields
	float DistanceThreshold; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0xc]; // Offset: 0x04 // Size: 0x0c
	struct FMinimalViewInfo AdditiveCameraViewInfo; // Offset: 0x10 // Size: 0x5c0
	struct UCurveFloat* FovCurve; // Offset: 0x5d0 // Size: 0x08
	char pad_0x5D8[0x8]; // Offset: 0x5d8 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AddCameraViewInfoStruct
// Size: 0x20 // Inherited bytes: 0x00
struct FAddCameraViewInfoStruct {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
	struct UCurveFloat* CurFOVCurve; // Offset: 0x10 // Size: 0x08
	char pad_0x18[0x8]; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AddMapMarkInstanceStruct
// Size: 0xa0 // Inherited bytes: 0x00
struct FAddMapMarkInstanceStruct {
	// Fields
	struct FMarkDispatchAction MarkDispatchAction; // Offset: 0x00 // Size: 0xa0
};

// Object Name: ScriptStruct ShadowTrackerExtra.RandomBuffItem
// Size: 0x20 // Inherited bytes: 0x00
struct FRandomBuffItem {
	// Fields
	int Probability; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FName BuffName; // Offset: 0x08 // Size: 0x08
	int BuffID; // Offset: 0x10 // Size: 0x04
	int SkillID; // Offset: 0x14 // Size: 0x04
	int AddLayerCount; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWeaponBoardDataConfigItem
// Size: 0x18 // Inherited bytes: 0x00
struct FVehicleWeaponBoardDataConfigItem {
	// Fields
	int SeatId; // Offset: 0x00 // Size: 0x04
	int WeaponListID; // Offset: 0x04 // Size: 0x04
	enum class EVehicleWeaponBoardDataType DataType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct FUAEBlackboardKeySelector BlackboardKey; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillAction_AttachActorCreateData
// Size: 0x30 // Inherited bytes: 0x00
struct FSkillAction_AttachActorCreateData {
	// Fields
	struct AActor* ActorTemplate; // Offset: 0x00 // Size: 0x08
	struct FName AttachSocketName; // Offset: 0x08 // Size: 0x08
	struct FVector RelativeLocation; // Offset: 0x10 // Size: 0x0c
	struct FRotator RelativeRotation; // Offset: 0x1c // Size: 0x0c
	bool DestroyAfterSkill; // Offset: 0x28 // Size: 0x01
	bool DestroyAfterPhase; // Offset: 0x29 // Size: 0x01
	bool SnapToTargetIncludingScale; // Offset: 0x2a // Size: 0x01
	char pad_0x2B[0x1]; // Offset: 0x2b // Size: 0x01
	float DestroyAfterTime; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SAAttachPawnPlayMontageInstanceStruct
// Size: 0x08 // Inherited bytes: 0x00
struct FSAAttachPawnPlayMontageInstanceStruct {
	// Fields
	struct TWeakObjectPtr<struct UAnimMontage> AnimMontageCurrent; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AirAttackConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FAirAttackConfig {
	// Fields
	float AttackLastingTime; // Offset: 0x00 // Size: 0x04
	float AttackAreaRadius; // Offset: 0x04 // Size: 0x04
	int TotalBombs; // Offset: 0x08 // Size: 0x04
	float BombsRadius; // Offset: 0x0c // Size: 0x04
	struct AAirAttackBombActor* BombActorTemplate; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpawnVehicleConfig
// Size: 0x14 // Inherited bytes: 0x00
struct FSpawnVehicleConfig {
	// Fields
	int VehicleSpawnID; // Offset: 0x00 // Size: 0x04
	struct FVector OffsetLocation; // Offset: 0x04 // Size: 0x0c
	bool AutoEnterVehicle; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.AKRTPCParam
// Size: 0x28 // Inherited bytes: 0x00
struct FAKRTPCParam {
	// Fields
	struct FString RTPC; // Offset: 0x00 // Size: 0x10
	float Value; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct UCurveFloat* ValueCurve; // Offset: 0x18 // Size: 0x08
	int InterpolationTimeMs; // Offset: 0x20 // Size: 0x04
	bool NeedTick; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.AKSwitchParam
// Size: 0x20 // Inherited bytes: 0x00
struct FAKSwitchParam {
	// Fields
	struct FString SwitchGroup; // Offset: 0x00 // Size: 0x10
	struct FString SwitchState; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.ChangeAkRT
// Size: 0x10 // Inherited bytes: 0x00
struct FChangeAkRT {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct UAkComponent* CachedAK; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.DisablePawnStateInfo
// Size: 0x03 // Inherited bytes: 0x00
struct FDisablePawnStateInfo {
	// Fields
	enum class EPawnState State; // Offset: 0x00 // Size: 0x01
	bool bNewDisable; // Offset: 0x01 // Size: 0x01
	bool bResetOnEnable; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillAction_DropItemData
// Size: 0x20 // Inherited bytes: 0x00
struct FSkillAction_DropItemData {
	// Fields
	struct FItemDefineID Item; // Offset: 0x00 // Size: 0x18
	int Num; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillAction_HideMainUIData
// Size: 0x10 // Inherited bytes: 0x00
struct FSkillAction_HideMainUIData {
	// Fields
	struct FString RegistUIName; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.CollisionChannelResModify
// Size: 0x02 // Inherited bytes: 0x00
struct FCollisionChannelResModify {
	// Fields
	enum class ECollisionChannel CollisionChannel; // Offset: 0x00 // Size: 0x01
	enum class ECollisionResponse ModifyResponse; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.MoveSpeedCurve
// Size: 0x10 // Inherited bytes: 0x00
struct FMoveSpeedCurve {
	// Fields
	float DistanceThreshold; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UCurveFloat* LaunchSpeedCurve; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SALaunchMove
// Size: 0x40 // Inherited bytes: 0x00
struct FSALaunchMove {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x00 // Size: 0x38
	struct UCurveFloat* SpeedCurve; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.LockCameraViewTypeData
// Size: 0x08 // Inherited bytes: 0x00
struct FLockCameraViewTypeData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SAPlayMontageInstanceStruct
// Size: 0x08 // Inherited bytes: 0x00
struct FSAPlayMontageInstanceStruct {
	// Fields
	struct TWeakObjectPtr<struct UAnimMontage> AnimMontageCurrent; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.PlayMontageAsyncloadParams
// Size: 0x38 // Inherited bytes: 0x00
struct FPlayMontageAsyncloadParams {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x00 // Size: 0x38
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillPoseMontageData
// Size: 0xd0 // Inherited bytes: 0x00
struct FSkillPoseMontageData {
	// Fields
	struct UAnimMontage* AnimMontage_Stand; // Offset: 0x00 // Size: 0x28
	struct UAnimMontage* AnimMontage_Crouch; // Offset: 0x28 // Size: 0x28
	struct UAnimMontage* AnimMontage_Prone; // Offset: 0x50 // Size: 0x28
	struct UAnimMontage* AnimMontage_Vehicle; // Offset: 0x78 // Size: 0x28
	struct UAnimMontage* AnimMontage_Max; // Offset: 0xa0 // Size: 0x28
	enum class EAnimPlayFlag AnimPlayFlag; // Offset: 0xc8 // Size: 0x01
	char pad_0xC9[0x7]; // Offset: 0xc9 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponStateToAnimPair
// Size: 0x1a8 // Inherited bytes: 0x00
struct FWeaponStateToAnimPair {
	// Fields
	enum class EWeaponTypeNew weaponTypeNew; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FSkillPoseMontageData PoseMontageData; // Offset: 0x08 // Size: 0xd0
	struct FSkillPoseMontageData FPPPoseMontageData; // Offset: 0xd8 // Size: 0xd0
};

// Object Name: ScriptStruct ShadowTrackerExtra.SAPlayMontageWeaponStateInstanceStruct
// Size: 0x08 // Inherited bytes: 0x00
struct FSAPlayMontageWeaponStateInstanceStruct {
	// Fields
	struct TWeakObjectPtr<struct UAnimMontage> AnimMontageCurrent; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.AvatarSlotAnimData
// Size: 0x38 // Inherited bytes: 0x00
struct FAvatarSlotAnimData {
	// Fields
	struct UAnimationAsset* PropAnim; // Offset: 0x00 // Size: 0x28
	float PlayRate; // Offset: 0x28 // Size: 0x04
	float StartingPosition; // Offset: 0x2c // Size: 0x04
	struct FName StartingSection; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillAction_SequenceCreateData
// Size: 0x68 // Inherited bytes: 0x00
struct FSkillAction_SequenceCreateData {
	// Fields
	struct FSoftClassPath SequenceActorTemplate; // Offset: 0x00 // Size: 0x18
	struct FSoftObjectPath LevelSequence; // Offset: 0x18 // Size: 0x18
	bool bUseSelfTransformOrigin; // Offset: 0x30 // Size: 0x01
	bool bPickFromTarget; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
	struct UUTSkillLocationPicker* LocationPicker; // Offset: 0x38 // Size: 0x08
	struct UUAESkillPicker* DamagePicker; // Offset: 0x40 // Size: 0x08
	bool bSetLocationToBB; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
	struct FName BBName; // Offset: 0x50 // Size: 0x08
	bool bDestroyedAtSkillEnd; // Offset: 0x58 // Size: 0x01
	bool bForceDestroyedAtSkillEnd; // Offset: 0x59 // Size: 0x01
	char pad_0x5A[0x6]; // Offset: 0x5a // Size: 0x06
	struct FUAEBlackboardKeySelector CachedSpawnActorKey; // Offset: 0x60 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.RandomActionGroup
// Size: 0x10 // Inherited bytes: 0x00
struct FRandomActionGroup {
	// Fields
	struct TArray<struct UUTSkillAction*> Actions; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillAction_ShowMainUIData
// Size: 0x18 // Inherited bytes: 0x00
struct FSkillAction_ShowMainUIData {
	// Fields
	struct FString RegistUIName; // Offset: 0x00 // Size: 0x10
	bool AutoHideOnPhaseEnd; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillAction_SpawnActorCreateData
// Size: 0xb8 // Inherited bytes: 0x00
struct FSkillAction_SpawnActorCreateData {
	// Fields
	struct AActor* ActorTemplate; // Offset: 0x00 // Size: 0x08
	struct UClass* SoftActorTemplate; // Offset: 0x08 // Size: 0x28
	bool bPickFromTarget; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct UUAESkillPicker* DamagePicker; // Offset: 0x38 // Size: 0x08
	bool bSetLocationToBB; // Offset: 0x40 // Size: 0x01
	bool bSetLocationToSkillBB; // Offset: 0x41 // Size: 0x01
	char pad_0x42[0x6]; // Offset: 0x42 // Size: 0x06
	struct FName BBName; // Offset: 0x48 // Size: 0x08
	bool bTraceGround; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x3]; // Offset: 0x51 // Size: 0x03
	struct FVector TraceGroundOffset; // Offset: 0x54 // Size: 0x0c
	struct UUTSkillLocationPicker* LocationPicker; // Offset: 0x60 // Size: 0x08
	bool bLocalSpawn; // Offset: 0x68 // Size: 0x01
	bool bClientSpawn; // Offset: 0x69 // Size: 0x01
	bool bDestroyedAtSkillEnd; // Offset: 0x6a // Size: 0x01
	bool bForceDestroyedAtSkillEnd; // Offset: 0x6b // Size: 0x01
	bool bUseOffsetWithOutLocationPicker; // Offset: 0x6c // Size: 0x01
	bool bUseOffsetWithDamagePicker; // Offset: 0x6d // Size: 0x01
	bool bEnableAttach; // Offset: 0x6e // Size: 0x01
	char pad_0x6F[0x1]; // Offset: 0x6f // Size: 0x01
	struct FName AttachSocket; // Offset: 0x70 // Size: 0x08
	bool bAlignMainMesh; // Offset: 0x78 // Size: 0x01
	bool bAlignRotation; // Offset: 0x79 // Size: 0x01
	char pad_0x7A[0x2]; // Offset: 0x7a // Size: 0x02
	struct FVector OffsetLocationStand; // Offset: 0x7c // Size: 0x0c
	struct FVector OffsetLocationCrouch; // Offset: 0x88 // Size: 0x0c
	struct FVector OffsetLocationProne; // Offset: 0x94 // Size: 0x0c
	struct FRotator OffsetRotation; // Offset: 0xa0 // Size: 0x0c
	bool bAllowChangePoseWillUpdating; // Offset: 0xac // Size: 0x01
	char pad_0xAD[0x3]; // Offset: 0xad // Size: 0x03
	struct FUAEBlackboardKeySelector CachedSpawnActorKey; // Offset: 0xb0 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.BeamEffectDataParams
// Size: 0x18 // Inherited bytes: 0x00
struct FBeamEffectDataParams {
	// Fields
	struct FVector SourceLocation; // Offset: 0x00 // Size: 0x0c
	struct FVector TargetLocation; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.BeamEffectData
// Size: 0x30 // Inherited bytes: 0x00
struct FBeamEffectData {
	// Fields
	enum class EBeamEffectDataFromType DataFromType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector Location; // Offset: 0x04 // Size: 0x0c
	struct FVector LocationOffset; // Offset: 0x10 // Size: 0x0c
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FName BlackBoardParam; // Offset: 0x20 // Size: 0x08
	struct FName AttachPointName; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpawnMonsterConfig
// Size: 0x14 // Inherited bytes: 0x00
struct FSpawnMonsterConfig {
	// Fields
	int MonsterID; // Offset: 0x00 // Size: 0x04
	struct FVector pos; // Offset: 0x04 // Size: 0x0c
	bool bIsRelativePos; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillAction_SpawnProjectileCreateData
// Size: 0x20 // Inherited bytes: 0x00
struct FSkillAction_SpawnProjectileCreateData {
	// Fields
	struct AActor* ProjectileTemplate; // Offset: 0x00 // Size: 0x08
	struct FVector OffsetLocation; // Offset: 0x08 // Size: 0x0c
	struct FRotator OffsetRotation; // Offset: 0x14 // Size: 0x0c
};

// Object Name: ScriptStruct ShadowTrackerExtra.CharPoseSwitch
// Size: 0x02 // Inherited bytes: 0x00
struct FCharPoseSwitch {
	// Fields
	enum class ECharacterPoseType from; // Offset: 0x00 // Size: 0x01
	enum class ECharacterPoseType to; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillTableRow
// Size: 0x108 // Inherited bytes: 0x00
struct FSkillTableRow {
	// Fields
	int SkillID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Name; // Offset: 0x08 // Size: 0x10
	struct FString IconPath; // Offset: 0x18 // Size: 0x10
	int SkillType; // Offset: 0x28 // Size: 0x04
	float Coeff1; // Offset: 0x2c // Size: 0x04
	float CoolTime; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString BPPath; // Offset: 0x38 // Size: 0x10
	struct FString Desc; // Offset: 0x48 // Size: 0x10
	struct TArray<int> BuffIDs; // Offset: 0x58 // Size: 0x10
	struct TMap<int, int> BuffLoadTypes; // Offset: 0x68 // Size: 0x50
	struct TMap<int, struct FMultiStringMap> Buffs; // Offset: 0xb8 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillReplaceJumpAnimData
// Size: 0x28 // Inherited bytes: 0x00
struct FSkillReplaceJumpAnimData {
	// Fields
	enum class ECharacterJumpType JumpAnimType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct UAnimationAsset*> JumpAnimList; // Offset: 0x08 // Size: 0x10
	struct TArray<struct UAnimationAsset*> FPPJumpAnimList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.PropSkillMapTableRow
// Size: 0x58 // Inherited bytes: 0x00
struct FPropSkillMapTableRow {
	// Fields
	int SkillMapID; // Offset: 0x00 // Size: 0x04
	int PropID; // Offset: 0x04 // Size: 0x04
	int PropSkillLevel; // Offset: 0x08 // Size: 0x04
	int PropSkillID; // Offset: 0x0c // Size: 0x04
	int AuxPropSkillID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<int> FilterGunIDs; // Offset: 0x18 // Size: 0x10
	struct FString PropSkillIconPath; // Offset: 0x28 // Size: 0x10
	struct FString PropSkillUseIconPath; // Offset: 0x38 // Size: 0x10
	struct FString PropSkillDesc; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.UTSkillPicker_CapsuleCreateData
// Size: 0x40 // Inherited bytes: 0x00
struct FUTSkillPicker_CapsuleCreateData {
	// Fields
	float Radius; // Offset: 0x00 // Size: 0x04
	float HalfHeight; // Offset: 0x04 // Size: 0x04
	float MinCosValue; // Offset: 0x08 // Size: 0x04
	struct FRotator ActionRotationOffset; // Offset: 0x0c // Size: 0x0c
	struct FVector Offset; // Offset: 0x18 // Size: 0x0c
	float HorizonOffset; // Offset: 0x24 // Size: 0x04
	float VerticalOffset; // Offset: 0x28 // Size: 0x04
	bool IsShowDebugFan; // Offset: 0x2c // Size: 0x01
	bool bIsBoneCheck; // Offset: 0x2d // Size: 0x01
	bool bPickUpMonsters; // Offset: 0x2e // Size: 0x01
	bool bCanApplyTrainModel; // Offset: 0x2f // Size: 0x01
	char pad_0x30[0x10]; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.UTSkillPicker_FanCreateData
// Size: 0x50 // Inherited bytes: 0x00
struct FUTSkillPicker_FanCreateData {
	// Fields
	float Radius; // Offset: 0x00 // Size: 0x04
	float MinRadius; // Offset: 0x04 // Size: 0x04
	float Angle; // Offset: 0x08 // Size: 0x04
	float CapsuleRadius; // Offset: 0x0c // Size: 0x04
	struct FVector Offset; // Offset: 0x10 // Size: 0x0c
	struct FVector CapsuleOffset; // Offset: 0x1c // Size: 0x0c
	bool Random; // Offset: 0x28 // Size: 0x01
	bool IsCheckHeadshot; // Offset: 0x29 // Size: 0x01
	bool IsShowDebugFan; // Offset: 0x2a // Size: 0x01
	bool IsHeadJudgeWithoutOwner; // Offset: 0x2b // Size: 0x01
	bool bPickUpMonsters; // Offset: 0x2c // Size: 0x01
	bool bIgnoreAimCheck; // Offset: 0x2d // Size: 0x01
	bool bIgnoreInSmoke; // Offset: 0x2e // Size: 0x01
	bool bSortByAngle; // Offset: 0x2f // Size: 0x01
	struct TArray<struct AActor*> IgnoredActors; // Offset: 0x30 // Size: 0x10
	bool bForwardHitAim; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
	struct AActor* DebugObjectSpawnForLocation; // Offset: 0x48 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.InRangeWithCircleState
// Size: 0x08 // Inherited bytes: 0x00
struct FInRangeWithCircleState {
	// Fields
	float Time; // Offset: 0x00 // Size: 0x04
	float Range; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillInstArrayTemplate
// Size: 0x50 // Inherited bytes: 0x00
struct FSkillInstArrayTemplate {
	// Fields
	struct TMap<struct FString, struct TWeakObjectPtr<struct AUTSkill>> SkillInstMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkillIconConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FSkillIconConfig {
	// Fields
	struct FString IconPath; // Offset: 0x00 // Size: 0x10
	int IconWidth; // Offset: 0x10 // Size: 0x04
	int IconHeight; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.NewSkillItemTable_Row
// Size: 0x68 // Inherited bytes: 0x00
struct FNewSkillItemTable_Row {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	int SkillID; // Offset: 0x04 // Size: 0x04
	int GrenadeType; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString WeaponPath; // Offset: 0x10 // Size: 0x10
	struct FString GrenadeSlotName; // Offset: 0x20 // Size: 0x10
	struct FString SkillIconPath; // Offset: 0x30 // Size: 0x10
	int SkillIconX; // Offset: 0x40 // Size: 0x04
	int SkillIconY; // Offset: 0x44 // Size: 0x04
	struct FString GrenadeIconPath; // Offset: 0x48 // Size: 0x10
	int GrenadeIconX; // Offset: 0x58 // Size: 0x04
	int GrenadeIconY; // Offset: 0x5c // Size: 0x04
	int OrderID; // Offset: 0x60 // Size: 0x04
	bool HideCancleFlag; // Offset: 0x64 // Size: 0x01
	char pad_0x65[0x3]; // Offset: 0x65 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.NewSkillTable_Row
// Size: 0x90 // Inherited bytes: 0x00
struct FNewSkillTable_Row {
	// Fields
	int SkillID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Name; // Offset: 0x08 // Size: 0x10
	struct FString IconPath; // Offset: 0x18 // Size: 0x10
	int SkillType; // Offset: 0x28 // Size: 0x04
	float Coeff1; // Offset: 0x2c // Size: 0x04
	float CoolTime; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString BPPath; // Offset: 0x38 // Size: 0x10
	struct FString UIPanelPath; // Offset: 0x48 // Size: 0x10
	struct FString LuaDataPath; // Offset: 0x58 // Size: 0x10
	struct FString LuaDataKey; // Offset: 0x68 // Size: 0x10
	struct FString ModeStrings; // Offset: 0x78 // Size: 0x10
	int ModeOpen; // Offset: 0x88 // Size: 0x04
	int TemplateID; // Offset: 0x8c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.UAVSyncRouteInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FUAVSyncRouteInfo {
	// Fields
	uint32_t UAVPawnID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	uint64 OwnerPlayerStateUID; // Offset: 0x08 // Size: 0x08
	struct FVector_NetQuantize AirDropLoc; // Offset: 0x10 // Size: 0x0c
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct AActor* UAVPawn; // Offset: 0x20 // Size: 0x08
	struct FVector UAVPawnLoc; // Offset: 0x28 // Size: 0x0c
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.UAVMoveAroundConfig
// Size: 0x20 // Inherited bytes: 0x00
struct FUAVMoveAroundConfig {
	// Fields
	float RelativeCharacterXMin; // Offset: 0x00 // Size: 0x04
	float RelativeCharacterXMax; // Offset: 0x04 // Size: 0x04
	float RelativeCharacterYMin; // Offset: 0x08 // Size: 0x04
	float RelativeCharacterYMax; // Offset: 0x0c // Size: 0x04
	float RelativeCharacterZMin; // Offset: 0x10 // Size: 0x04
	float RelativeCharacterZMax; // Offset: 0x14 // Size: 0x04
	float MoveAroundStaySeconds; // Offset: 0x18 // Size: 0x04
	float MoveAroundSpeed; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.UAVBehaviorConfig
// Size: 0x34 // Inherited bytes: 0x00
struct FUAVBehaviorConfig {
	// Fields
	struct FRotator RotationOffset; // Offset: 0x00 // Size: 0x0c
	float BornFlyTime; // Offset: 0x0c // Size: 0x04
	float MoveInTime; // Offset: 0x10 // Size: 0x04
	float MoveInScaleTime; // Offset: 0x14 // Size: 0x04
	float MoveInStartScale; // Offset: 0x18 // Size: 0x04
	float StayTime; // Offset: 0x1c // Size: 0x04
	float DelayAttackTime; // Offset: 0x20 // Size: 0x04
	float AttackInterval; // Offset: 0x24 // Size: 0x04
	float MoveAwayTime; // Offset: 0x28 // Size: 0x04
	enum class EUAVFlyType FlyType; // Offset: 0x2c // Size: 0x01
	bool bStayMoveAround; // Offset: 0x2d // Size: 0x01
	char SameTimeFireMax; // Offset: 0x2e // Size: 0x01
	char pad_0x2F[0x1]; // Offset: 0x2f // Size: 0x01
	float SameTimeFireDuration; // Offset: 0x30 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ComsumableItemSortData
// Size: 0x68 // Inherited bytes: 0x00
struct FComsumableItemSortData {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int H1S1; // Offset: 0x04 // Size: 0x04
	int H1S2; // Offset: 0x08 // Size: 0x04
	int H1S3; // Offset: 0x0c // Size: 0x04
	int H1S4; // Offset: 0x10 // Size: 0x04
	int H1S5; // Offset: 0x14 // Size: 0x04
	int H2S1; // Offset: 0x18 // Size: 0x04
	int H2S2; // Offset: 0x1c // Size: 0x04
	int H2S3; // Offset: 0x20 // Size: 0x04
	int H2S4; // Offset: 0x24 // Size: 0x04
	int H2S5; // Offset: 0x28 // Size: 0x04
	int H3S1; // Offset: 0x2c // Size: 0x04
	int H3S2; // Offset: 0x30 // Size: 0x04
	int H3S3; // Offset: 0x34 // Size: 0x04
	int H3S4; // Offset: 0x38 // Size: 0x04
	int H3S5; // Offset: 0x3c // Size: 0x04
	int H4S1; // Offset: 0x40 // Size: 0x04
	int H4S2; // Offset: 0x44 // Size: 0x04
	int H4S3; // Offset: 0x48 // Size: 0x04
	int H4S4; // Offset: 0x4c // Size: 0x04
	int H4S5; // Offset: 0x50 // Size: 0x04
	int H5S1; // Offset: 0x54 // Size: 0x04
	int H5S2; // Offset: 0x58 // Size: 0x04
	int H5S3; // Offset: 0x5c // Size: 0x04
	int H5S4; // Offset: 0x60 // Size: 0x04
	int H5S5; // Offset: 0x64 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ComparableGrenadeItemType
// Size: 0xc0 // Inherited bytes: 0x00
struct FComparableGrenadeItemType {
	// Fields
	struct FBattleItemData BattleItemData; // Offset: 0x00 // Size: 0xb8
	int ItemPriority; // Offset: 0xb8 // Size: 0x04
	int GrenadeItemID; // Offset: 0xbc // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CompatableComsumableItemType
// Size: 0xc0 // Inherited bytes: 0x00
struct FCompatableComsumableItemType {
	// Fields
	struct FBattleItemData BattleItemData; // Offset: 0x00 // Size: 0xb8
	enum class EConsumeItemType ConsumableItemType; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x3]; // Offset: 0xb9 // Size: 0x03
	int ItemPriority; // Offset: 0xbc // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SpeciesParams
// Size: 0x18 // Inherited bytes: 0x00
struct FSpeciesParams {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
	int ID; // Offset: 0x04 // Size: 0x04
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
	int SingleId; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.RevivalPointIconChangeFactor
// Size: 0x18 // Inherited bytes: 0x00
struct FRevivalPointIconChangeFactor {
	// Fields
	int MinDis; // Offset: 0x00 // Size: 0x04
	int MaxDis; // Offset: 0x04 // Size: 0x04
	float MinScaleFactorFactor; // Offset: 0x08 // Size: 0x04
	float MaxScaleFactorFactor; // Offset: 0x0c // Size: 0x04
	float MinTransparencyFactor; // Offset: 0x10 // Size: 0x04
	float MaxTransparencyFactor; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.UTSkillAppearance_ParticleSystem_Item
// Size: 0x78 // Inherited bytes: 0x00
struct FUTSkillAppearance_ParticleSystem_Item {
	// Fields
	struct UUTSkillPicker* TargetPicker; // Offset: 0x00 // Size: 0x08
	struct UParticleSystem* TemplateSelfTeam_Effect; // Offset: 0x08 // Size: 0x08
	struct UParticleSystem* TemplateEnermyTeam_Effect; // Offset: 0x10 // Size: 0x08
	struct UParticleSystem* TemplateSelfTeamFPP_Effect; // Offset: 0x18 // Size: 0x08
	bool bLoop; // Offset: 0x20 // Size: 0x01
	bool StopAfterPhase; // Offset: 0x21 // Size: 0x01
	char pad_0x22[0x2]; // Offset: 0x22 // Size: 0x02
	float Scale; // Offset: 0x24 // Size: 0x04
	struct FName SocketName; // Offset: 0x28 // Size: 0x08
	struct FVector LocationOffset; // Offset: 0x30 // Size: 0x0c
	struct FRotator RotationOffset; // Offset: 0x3c // Size: 0x0c
	struct FVector LocationOffsetTPP; // Offset: 0x48 // Size: 0x0c
	struct FRotator RotationOffsetTPP; // Offset: 0x54 // Size: 0x0c
	float ScaleTPP; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct FName HurtRotationSocketName; // Offset: 0x68 // Size: 0x08
	float AutoDispearTime; // Offset: 0x70 // Size: 0x04
	bool bAttachToPawn; // Offset: 0x74 // Size: 0x01
	bool DisableOnLowCPU; // Offset: 0x75 // Size: 0x01
	char pad_0x76[0x2]; // Offset: 0x76 // Size: 0x02
};

// Object Name: ScriptStruct ShadowTrackerExtra.CurPlayingAKEvent
// Size: 0x04 // Inherited bytes: 0x00
struct FCurPlayingAKEvent {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.UTSkillAppearance_SoundCue_Item
// Size: 0x18 // Inherited bytes: 0x00
struct FUTSkillAppearance_SoundCue_Item {
	// Fields
	enum class UTSkill_SoundCue_ListenType ListenType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UAkAudioEvent* AkEvent; // Offset: 0x08 // Size: 0x08
	bool bLoop; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.AINavStateData
// Size: 0x38 // Inherited bytes: 0x00
struct FAINavStateData {
	// Fields
	int CurrentTargetWaypointIdx; // Offset: 0x00 // Size: 0x04
	struct FVector TargetPosition; // Offset: 0x04 // Size: 0x0c
	struct FVector StartPosition; // Offset: 0x10 // Size: 0x0c
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<int> PathWayPoints; // Offset: 0x20 // Size: 0x10
	int PathWayPointNum; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleItem
// Size: 0x60 // Inherited bytes: 0x00
struct FParticleItem {
	// Fields
	struct UParticleSystem* AssetParticle; // Offset: 0x00 // Size: 0x28
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FTransform RelativeTransform; // Offset: 0x30 // Size: 0x30
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleMeshPackage
// Size: 0x120 // Inherited bytes: 0x08
struct FVehicleMeshPackage : FAssetPackage {
	// Fields
	struct UStaticMesh* stMesh; // Offset: 0x08 // Size: 0x28
	struct USkeletalMesh* skMesh; // Offset: 0x30 // Size: 0x28
	struct UMaterialInterface* Mat; // Offset: 0x58 // Size: 0x28
	struct UMaterialInterface* BrokenMat; // Offset: 0x80 // Size: 0x28
	struct UMaterialInterface* MatBase; // Offset: 0xa8 // Size: 0x28
	struct TArray<struct FMaterialAsset> additionalMats; // Offset: 0xd0 // Size: 0x10
	struct UClass* animBP; // Offset: 0xe0 // Size: 0x28
	struct TArray<struct FParticleAsset> ParticleData; // Offset: 0x108 // Size: 0x10
	char pad_0x118[0x8]; // Offset: 0x118 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleAvatarEntry
// Size: 0x38 // Inherited bytes: 0x00
struct FVehicleAvatarEntry {
	// Fields
	struct USkeletalMesh* Mesh; // Offset: 0x00 // Size: 0x28
	struct TArray<struct FVehicleAvatarMat> MatInstances; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleAvatarMat
// Size: 0x30 // Inherited bytes: 0x00
struct FVehicleAvatarMat {
	// Fields
	struct FName SlotID; // Offset: 0x00 // Size: 0x08
	struct UMaterialInterface* MatInstance; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleDamageRecord
// Size: 0x18 // Inherited bytes: 0x00
struct FVehicleDamageRecord {
	// Fields
	struct AController* Instigator; // Offset: 0x00 // Size: 0x08
	float Time; // Offset: 0x08 // Size: 0x04
	float Damage; // Offset: 0x0c // Size: 0x04
	int DamageType; // Offset: 0x10 // Size: 0x04
	int AdditionalParam; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.MaterialDamage
// Size: 0x10 // Inherited bytes: 0x00
struct FMaterialDamage {
	// Fields
	struct UPhysicalMaterial* PhysicalMaterial; // Offset: 0x00 // Size: 0x08
	float DamageScale; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.TriggeredCustomDamageEvent
// Size: 0xf0 // Inherited bytes: 0x00
struct FTriggeredCustomDamageEvent {
	// Fields
	struct FCustomDamageEventRow Event; // Offset: 0x00 // Size: 0xe8
	float TimeTriggered; // Offset: 0xe8 // Size: 0x04
	char pad_0xEC[0x4]; // Offset: 0xec // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CustomDamageEventRow
// Size: 0xe8 // Inherited bytes: 0x08
struct FCustomDamageEventRow : FTableRowBase {
	// Fields
	bool bProcessedLocally; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	struct FGuid EventId; // Offset: 0x0c // Size: 0x10
	bool bEnabled; // Offset: 0x1c // Size: 0x01
	bool bClientOnly; // Offset: 0x1d // Size: 0x01
	bool bReplicate; // Offset: 0x1e // Size: 0x01
	bool bOnlyReplicateWhenRelevant; // Offset: 0x1f // Size: 0x01
	enum class ECustomDamageEventTriggerType EventTriggerType; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	float TriggerCooldown; // Offset: 0x24 // Size: 0x04
	float HealthPercentageThreshold; // Offset: 0x28 // Size: 0x04
	bool bTriggerWhenDead; // Offset: 0x2c // Size: 0x01
	enum class ECustomDamageEventReactionType EventReactionType; // Offset: 0x2d // Size: 0x01
	char pad_0x2E[0x2]; // Offset: 0x2e // Size: 0x02
	struct UClass* ActorClassToSpawn; // Offset: 0x30 // Size: 0x28
	bool bTriggersGlobalCooldown; // Offset: 0x58 // Size: 0x01
	bool bLockedByGlobalCooldown; // Offset: 0x59 // Size: 0x01
	char pad_0x5A[0x6]; // Offset: 0x5a // Size: 0x06
	struct UClass* OnCooldownActorClassToSpawn; // Offset: 0x60 // Size: 0x28
	bool bDestroySpawnedParticlesWithOwner; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x7]; // Offset: 0x89 // Size: 0x07
	struct FName AttachComponentTag; // Offset: 0x90 // Size: 0x08
	struct FName SpawnSocketName; // Offset: 0x98 // Size: 0x08
	struct FName CustomSpawnTransformTag; // Offset: 0xa0 // Size: 0x08
	bool bSpawnAtRandomPointInBoundingBox; // Offset: 0xa8 // Size: 0x01
	bool bUseCustomSpawnRotation; // Offset: 0xa9 // Size: 0x01
	char MinToSpawn; // Offset: 0xaa // Size: 0x01
	char MaxToSpawn; // Offset: 0xab // Size: 0x01
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct FName ActorSpawnTag; // Offset: 0xb0 // Size: 0x08
	struct FName MeshComponentTag; // Offset: 0xb8 // Size: 0x08
	int MeshInstanceIndex; // Offset: 0xc0 // Size: 0x04
	char pad_0xC4[0x4]; // Offset: 0xc4 // Size: 0x04
	struct FName BoneName; // Offset: 0xc8 // Size: 0x08
	struct FName PhysicsAssetProfileName; // Offset: 0xd0 // Size: 0x08
	struct FName CollisionPrimitiveTag; // Offset: 0xd8 // Size: 0x08
	enum class ECollisionEnabled CollisionEnabledType; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0x7]; // Offset: 0xe1 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleCustomImpulse
// Size: 0x30 // Inherited bytes: 0x00
struct FVehicleCustomImpulse {
	// Fields
	struct TArray<struct AActor*> IgnoreClasses; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FVehicleCustomImpulseFilter> ImpulseFilters; // Offset: 0x10 // Size: 0x10
	struct UDamageType* DamageType; // Offset: 0x20 // Size: 0x08
	bool bApplyImpulseWhileDestroyed; // Offset: 0x28 // Size: 0x01
	bool bApplyImpulseWhileStopped; // Offset: 0x29 // Size: 0x01
	bool bUseHitActorAsDamageInstigator; // Offset: 0x2a // Size: 0x01
	char pad_0x2B[0x5]; // Offset: 0x2b // Size: 0x05
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleCustomImpulseFilter
// Size: 0x28 // Inherited bytes: 0x00
struct FVehicleCustomImpulseFilter {
	// Fields
	struct AActor* ImpulseAbsorberType; // Offset: 0x00 // Size: 0x08
	bool bApplyRadialImpulse; // Offset: 0x08 // Size: 0x01
	bool bApplyImpulseAsVelocityChange; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x2]; // Offset: 0x0a // Size: 0x02
	float MaxDamagingImpulseMagnituge; // Offset: 0x0c // Size: 0x04
	float MaxImpulseDamage; // Offset: 0x10 // Size: 0x04
	float ImpulseStrength; // Offset: 0x14 // Size: 0x04
	float RadialImpulseStrength; // Offset: 0x18 // Size: 0x04
	float ImpulseRadius; // Offset: 0x1c // Size: 0x04
	enum class ERadialImpulseFalloff ImpulseFalloffType; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.CachedWheelData
// Size: 0x10 // Inherited bytes: 0x00
struct FCachedWheelData {
	// Fields
	bool WheelsInAir; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float WheelSuspensionOffset; // Offset: 0x04 // Size: 0x04
	struct UPhysicalMaterial* WheelContactMaterial; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleParticleParachuteSteering
// Size: 0x10 // Inherited bytes: 0x00
struct FVehicleParticleParachuteSteering {
	// Fields
	struct TArray<struct FVehicleParticleParachute> Particles; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleParticleParachute
// Size: 0x20 // Inherited bytes: 0x00
struct FVehicleParticleParachute {
	// Fields
	struct UParticleSystem* Particle; // Offset: 0x00 // Size: 0x08
	struct FName socket; // Offset: 0x08 // Size: 0x08
	struct FVector Scale; // Offset: 0x10 // Size: 0x0c
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.STVehicleWheelDust
// Size: 0x28 // Inherited bytes: 0x00
struct FSTVehicleWheelDust {
	// Fields
	enum class EPhysicalSurface ContactSurface; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UParticleSystem* MoveFx; // Offset: 0x08 // Size: 0x08
	struct UParticleSystem* SlipFx; // Offset: 0x10 // Size: 0x08
	struct UParticleSystem* HubFx; // Offset: 0x18 // Size: 0x08
	float minSpeed; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.TankPivotSteering
// Size: 0x24 // Inherited bytes: 0x00
struct FTankPivotSteering {
	// Fields
	bool bEnable; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float MinSteeringInput; // Offset: 0x04 // Size: 0x04
	float MaxSpeed; // Offset: 0x08 // Size: 0x04
	float EnterSpeed; // Offset: 0x0c // Size: 0x04
	float EnterThrottle; // Offset: 0x10 // Size: 0x04
	float EnterBrake; // Offset: 0x14 // Size: 0x04
	float ThrottleInput; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x8]; // Offset: 0x1c // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.TankTransmissionData
// Size: 0x38 // Inherited bytes: 0x00
struct FTankTransmissionData {
	// Fields
	bool bUseGearAutoBox; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float GearSwitchTime; // Offset: 0x04 // Size: 0x04
	float GearAutoBoxLatency; // Offset: 0x08 // Size: 0x04
	enum class EVehicleDriveTankControlMode ControlMode; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float FinalRatio; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FTankGearData> ForwardGears; // Offset: 0x18 // Size: 0x10
	float ReverseGearRatio; // Offset: 0x28 // Size: 0x04
	float NeutralGearUpRatio; // Offset: 0x2c // Size: 0x04
	float ClutchStrength; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.TankGearData
// Size: 0x0c // Inherited bytes: 0x00
struct FTankGearData {
	// Fields
	float Ratio; // Offset: 0x00 // Size: 0x04
	float DownRatio; // Offset: 0x04 // Size: 0x04
	float UpRatio; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.TankEngineData
// Size: 0x90 // Inherited bytes: 0x00
struct FTankEngineData {
	// Fields
	struct FRuntimeFloatCurve TorqueCurve; // Offset: 0x00 // Size: 0x78
	float MaxRPM; // Offset: 0x78 // Size: 0x04
	float MOI; // Offset: 0x7c // Size: 0x04
	float DampingRateFullThrottle; // Offset: 0x80 // Size: 0x04
	float DampingRateZeroThrottleClutchEngaged; // Offset: 0x84 // Size: 0x04
	float DampingRateZeroThrottleClutchDisengaged; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehilcePropsInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FVehilcePropsInfo {
	// Fields
	struct TArray<int> SkillIDList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.TankMovementState
// Size: 0x20 // Inherited bytes: 0x00
struct FTankMovementState {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleStatesDataRecord
// Size: 0x14 // Inherited bytes: 0x00
struct FVehicleStatesDataRecord {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	float Time; // Offset: 0x04 // Size: 0x04
	bool always; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float Param1; // Offset: 0x0c // Size: 0x04
	float Param2; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleStatesData
// Size: 0x0c // Inherited bytes: 0x00
struct FVehicleStatesData {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	float Time; // Offset: 0x04 // Size: 0x04
	bool always; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleSyncPostPhysxTick
// Size: 0x58 // Inherited bytes: 0x50
struct FVehicleSyncPostPhysxTick : FTickFunction {
	// Fields
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.NetTankMovementState
// Size: 0x38 // Inherited bytes: 0x00
struct FNetTankMovementState {
	// Fields
	struct FVector_NetQuantize100 Location; // Offset: 0x00 // Size: 0x0c
	struct FVector_NetQuantize100 LinVel; // Offset: 0x0c // Size: 0x0c
	struct FVector_NetQuantizeNormal Rotation; // Offset: 0x18 // Size: 0x0c
	struct FVector_NetQuantize100 AngVel; // Offset: 0x24 // Size: 0x0c
	float TurretYaw; // Offset: 0x30 // Size: 0x04
	float MainGunPitch; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleUserReconnRepData
// Size: 0x18 // Inherited bytes: 0x00
struct FVehicleUserReconnRepData {
	// Fields
	struct ASTExtraVehicleBase* Vehicle; // Offset: 0x00 // Size: 0x08
	struct ASTExtraPlayerCharacter* Character; // Offset: 0x08 // Size: 0x08
	enum class ESTExtraVehicleUserState VehicleUserState; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int SeatIdx; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleQueryParams
// Size: 0x68 // Inherited bytes: 0x00
struct FVehicleQueryParams {
	// Fields
	char pad_0x0[0x68]; // Offset: 0x00 // Size: 0x68
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarRespawnInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FVehicleWarRespawnInfo {
	// Fields
	struct TWeakObjectPtr<struct AActor> CauserActor; // Offset: 0x00 // Size: 0x08
	bool bDied; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.NetVehilceProps
// Size: 0x38 // Inherited bytes: 0x00
struct FNetVehilceProps {
	// Fields
	int ItemNum; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FItemDefineID> PropsItem; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FVehicleWarEquipItem> ChooseEquip; // Offset: 0x18 // Size: 0x10
	int PlayerChoose; // Offset: 0x28 // Size: 0x04
	int FirstWeaponID; // Offset: 0x2c // Size: 0x04
	int SecondWeaponID; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarEquipItem
// Size: 0x08 // Inherited bytes: 0x00
struct FVehicleWarEquipItem {
	// Fields
	int ItemId; // Offset: 0x00 // Size: 0x04
	int ItemNum; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AutoChangeSeatData
// Size: 0x08 // Inherited bytes: 0x00
struct FAutoChangeSeatData {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	bool bCanAutoChangeSeat; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleBeAttackMapData
// Size: 0x50 // Inherited bytes: 0x00
struct FVehicleBeAttackMapData {
	// Fields
	struct TMap<uint32_t, float> BeAttackedMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.TeamMedalBeAttackedData
// Size: 0x50 // Inherited bytes: 0x00
struct FTeamMedalBeAttackedData {
	// Fields
	struct TMap<uint32_t, float> BeAttackedMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.TeamMedalTotalKillData
// Size: 0x50 // Inherited bytes: 0x00
struct FTeamMedalTotalKillData {
	// Fields
	struct TSet<int> TotalKillData; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleGemRoundData
// Size: 0x08 // Inherited bytes: 0x00
struct FVehicleGemRoundData {
	// Fields
	float RoundTime; // Offset: 0x00 // Size: 0x04
	int TreasureNum; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleWarRouteDetailData
// Size: 0x38 // Inherited bytes: 0x00
struct FVehicleWarRouteDetailData {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	int RoundNo; // Offset: 0x04 // Size: 0x04
	float Distance; // Offset: 0x08 // Size: 0x04
	bool IsFinish; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float FinishTime; // Offset: 0x10 // Size: 0x04
	struct FVector ProjectionPoint; // Offset: 0x14 // Size: 0x0c
	int CompleteLogicCircleNum; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct TArray<int> LastRoutePointRecord; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VerifySwitch
// Size: 0x0c // Inherited bytes: 0x00
struct FVerifySwitch {
	// Fields
	int PunishThresHold; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x1]; // Offset: 0x04 // Size: 0x01
	bool bShouldPunish; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	int VerifyFailedCnt; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VisualFieldFrame
// Size: 0x50 // Inherited bytes: 0x00
struct FVisualFieldFrame {
	// Fields
	struct TMap<int, struct FVisualFieldCamp> VisualFieldFrameMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.VisualFieldCamp
// Size: 0x10 // Inherited bytes: 0x00
struct FVisualFieldCamp {
	// Fields
	struct TArray<struct FVisibleActorInfo> VisibleActorList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VisibleActorInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FVisibleActorInfo {
	// Fields
	struct FVisualFieldMetaInfo VisibleActorMetaInfo; // Offset: 0x00 // Size: 0x10
	struct TWeakObjectPtr<struct AActor> VisibleActor; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.VisualFieldLayerConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FVisualFieldLayerConfig {
	// Fields
	struct TArray<struct FVisualFieldLayer> VisualLayerList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.VisualFieldLayer
// Size: 0x0c // Inherited bytes: 0x00
struct FVisualFieldLayer {
	// Fields
	float LayerFloorHeight; // Offset: 0x00 // Size: 0x04
	float LayerRoofHeight; // Offset: 0x04 // Size: 0x04
	int LayerID; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.VoiceCheckSorttNode
// Size: 0x08 // Inherited bytes: 0x00
struct FVoiceCheckSorttNode {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.VoiceCheckObjectNode
// Size: 0x68 // Inherited bytes: 0x00
struct FVoiceCheckObjectNode {
	// Fields
	struct ASTExtraBaseCharacter* nowCharacter; // Offset: 0x00 // Size: 0x08
	struct ASTExtraVehicleBase* nowVehicle; // Offset: 0x08 // Size: 0x08
	struct UImage* moveImage; // Offset: 0x10 // Size: 0x08
	struct UImage* weaponImage; // Offset: 0x18 // Size: 0x08
	struct UImage* silencerWeaponImage; // Offset: 0x20 // Size: 0x08
	struct UImage* VehicleImage; // Offset: 0x28 // Size: 0x08
	struct UImage* GlassImage; // Offset: 0x30 // Size: 0x08
	struct UImage* ExplosionImage; // Offset: 0x38 // Size: 0x08
	struct UImage* HeightImage; // Offset: 0x40 // Size: 0x08
	struct UImage* LandingImage; // Offset: 0x48 // Size: 0x08
	char pad_0x50[0x10]; // Offset: 0x50 // Size: 0x10
	struct UTextBlock* DistanceText; // Offset: 0x60 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ScoreChangeValue
// Size: 0x08 // Inherited bytes: 0x00
struct FScoreChangeValue {
	// Fields
	int Score_RescueOthers; // Offset: 0x00 // Size: 0x04
	int Score_Kill; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WarGameTeamScore
// Size: 0x10 // Inherited bytes: 0x00
struct FWarGameTeamScore {
	// Fields
	int CampID; // Offset: 0x00 // Size: 0x04
	int TeamID; // Offset: 0x04 // Size: 0x04
	int TeamRank; // Offset: 0x08 // Size: 0x04
	int TeamScore; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.BunnyDanceSyncData
// Size: 0x0c // Inherited bytes: 0x00
struct FBunnyDanceSyncData {
	// Fields
	int CurrentIndex; // Offset: 0x00 // Size: 0x04
	bool bIsDancing; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	float TimeStamp; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SocketAttachmentNameTable
// Size: 0x28 // Inherited bytes: 0x00
struct FSocketAttachmentNameTable {
	// Fields
	struct FName SocketName; // Offset: 0x00 // Size: 0x08
	struct FVector OffsetLoc; // Offset: 0x08 // Size: 0x0c
	struct FRotator OffsetRot; // Offset: 0x14 // Size: 0x0c
	struct UAnimMontage* AnimMontage; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SocketAttachmentInternalData
// Size: 0x38 // Inherited bytes: 0x00
struct FSocketAttachmentInternalData {
	// Fields
	struct FName SocketName; // Offset: 0x00 // Size: 0x08
	struct USceneComponent* SocketBase; // Offset: 0x08 // Size: 0x08
	struct AActor* AttachedPlayer; // Offset: 0x10 // Size: 0x08
	struct FVector OffsetLoc; // Offset: 0x18 // Size: 0x0c
	struct FRotator OffsetRot; // Offset: 0x24 // Size: 0x0c
	struct UAnimMontage* AnimMontage; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.SkeletalAnimationSyncData
// Size: 0x10 // Inherited bytes: 0x00
struct FSkeletalAnimationSyncData {
	// Fields
	struct USceneComponent* SocketBase; // Offset: 0x00 // Size: 0x08
	bool Status; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
};

// Object Name: ScriptStruct ShadowTrackerExtra.LoveTreeData
// Size: 0x18 // Inherited bytes: 0x00
struct FLoveTreeData {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	struct FVector Loc; // Offset: 0x04 // Size: 0x0c
	float minRate; // Offset: 0x10 // Size: 0x04
	float maxRate; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WaterDropItemData
// Size: 0x18 // Inherited bytes: 0x00
struct FWaterDropItemData {
	// Fields
	struct AActor* HostActor; // Offset: 0x00 // Size: 0x08
	struct FVector DropLocation; // Offset: 0x08 // Size: 0x0c
	int DropID; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.GuidActorsArray
// Size: 0x10 // Inherited bytes: 0x00
struct FGuidActorsArray {
	// Fields
	struct TArray<struct AWeakGuidActor*> GuidActors; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeakGuidTableRow
// Size: 0x40 // Inherited bytes: 0x00
struct FWeakGuidTableRow {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString UIName; // Offset: 0x08 // Size: 0x10
	struct FString UILayer; // Offset: 0x18 // Size: 0x10
	struct FString RootClass; // Offset: 0x28 // Size: 0x10
	int GuidTxt; // Offset: 0x38 // Size: 0x04
	int GuidNum; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.CompareEnemyInfo
// Size: 0x01 // Inherited bytes: 0x00
struct FCompareEnemyInfo {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct ShadowTrackerExtra.AutoAimEnemyInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FAutoAimEnemyInfo {
	// Fields
	struct ASTExtraPlayerCharacter* EnemyPawn; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x10]; // Offset: 0x08 // Size: 0x10
	struct FName BoneName; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.ParticleEffectGroup
// Size: 0x20 // Inherited bytes: 0x00
struct FParticleEffectGroup {
	// Fields
	struct TArray<struct UParticleSystemComponent*> ParticleCompList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FParticleRes> ParticleRes; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.MiniItem
// Size: 0x08 // Inherited bytes: 0x00
struct FMiniItem {
	// Fields
	int Type; // Offset: 0x00 // Size: 0x04
	int TypeSpecificID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.DefaultWeaponHolderInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FDefaultWeaponHolderInfo {
	// Fields
	struct ASTExtraWeapon* WeaponClass; // Offset: 0x00 // Size: 0x08
	struct FName WeaponSocket; // Offset: 0x08 // Size: 0x08
	int WeaponSepcificID; // Offset: 0x10 // Size: 0x04
	int WeaponTypeID; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.AutoTriggerWeaponEventTask
// Size: 0x38 // Inherited bytes: 0x00
struct FAutoTriggerWeaponEventTask {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x00 // Size: 0x38
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeaponReconnectReplicateDataWrapper
// Size: 0x88 // Inherited bytes: 0x00
struct FWeaponReconnectReplicateDataWrapper {
	// Fields
	struct FWeaponReconnectReplicateData WeaponReconnectReplicateData; // Offset: 0x00 // Size: 0x80
	struct ASTExtraWeapon* Weapon; // Offset: 0x80 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.WarmAttrModify
// Size: 0x58 // Inherited bytes: 0x00
struct FWarmAttrModify {
	// Fields
	int WarmBegin; // Offset: 0x00 // Size: 0x04
	int WarmEnd; // Offset: 0x04 // Size: 0x04
	struct TMap<struct FString, struct FWarmAttrModifyCell> AttributeMap; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.WarmAttrModifyCell
// Size: 0x0c // Inherited bytes: 0x00
struct FWarmAttrModifyCell {
	// Fields
	enum class EAttrOperator ModifierOp; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float ModifierValue; // Offset: 0x04 // Size: 0x04
	bool ClientSimulate; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherUIType
// Size: 0x18 // Inherited bytes: 0x00
struct FWeatherUIType {
	// Fields
	enum class WeatherUICountDownType UIType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FWeatherUIStatus> StatusList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WeatherUIStatus
// Size: 0xc0 // Inherited bytes: 0x00
struct FWeatherUIStatus {
	// Fields
	enum class EWeatherStatusType WeatherStatus; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FSlateBrush PVENightBrush; // Offset: 0x08 // Size: 0xb8
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleHitInOneFrame
// Size: 0x58 // Inherited bytes: 0x00
struct FVehicleHitInOneFrame {
	// Fields
	char pad_0x0[0x58]; // Offset: 0x00 // Size: 0x58
};

// Object Name: ScriptStruct ShadowTrackerExtra.VehicleStuckInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FVehicleStuckInfo {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ShadowTrackerExtra.PreventBodyPeneSockets
// Size: 0x10 // Inherited bytes: 0x00
struct FPreventBodyPeneSockets {
	// Fields
	struct FName StartSocket; // Offset: 0x00 // Size: 0x08
	struct FName EndSocket; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.WheelSfxOnSurface
// Size: 0x18 // Inherited bytes: 0x00
struct FWheelSfxOnSurface {
	// Fields
	struct UPhysicalMaterial* SurfaceMaterial; // Offset: 0x00 // Size: 0x08
	struct UAkAudioEvent* EventStart; // Offset: 0x08 // Size: 0x08
	struct UAkAudioEvent* EventStop; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ShadowTrackerExtra.TextureRenderTarget2DManagerWidgetInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FTextureRenderTarget2DManagerWidgetInfo {
	// Fields
	struct UClass* UserWidgetClass; // Offset: 0x00 // Size: 0x28
	struct UUserWidget* LoadedUserWidgetClass; // Offset: 0x28 // Size: 0x08
	struct UUserWidget* UserWidget; // Offset: 0x30 // Size: 0x08
	struct FName UpdateWidgetFunctionName; // Offset: 0x38 // Size: 0x08
	char pad_0x40[0x10]; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WingManUserDataStruct
// Size: 0xc0 // Inherited bytes: 0x00
struct FWingManUserDataStruct {
	// Fields
	int UId; // Offset: 0x00 // Size: 0x04
	int RPScore; // Offset: 0x04 // Size: 0x04
	struct FString Name; // Offset: 0x08 // Size: 0x10
	int SkinId; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FGameModePlayerShowUpassInfo UnPassInfo; // Offset: 0x20 // Size: 0xa0
};

// Object Name: ScriptStruct ShadowTrackerExtra.WonderfulCutContinuousKillOutputData
// Size: 0x10 // Inherited bytes: 0x00
struct FWonderfulCutContinuousKillOutputData {
	// Fields
	float BeginTimeSecs; // Offset: 0x00 // Size: 0x04
	float EndTimeSecs; // Offset: 0x04 // Size: 0x04
	int KillNum; // Offset: 0x08 // Size: 0x04
	float FarthestKillDistance; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.WonderfulCutOutputData
// Size: 0x20 // Inherited bytes: 0x00
struct FWonderfulCutOutputData {
	// Fields
	float BeginTimeSecs; // Offset: 0x00 // Size: 0x04
	float EndTimeSecs; // Offset: 0x04 // Size: 0x04
	enum class EWonderfulCutOutputType WonderfulCutType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float ShootDistance; // Offset: 0x0c // Size: 0x04
	struct FString CauserName; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WonderfulCutShootDamageSortData
// Size: 0x20 // Inherited bytes: 0x00
struct FWonderfulCutShootDamageSortData {
	// Fields
	float DamageIntervalSecs; // Offset: 0x00 // Size: 0x04
	float DamageTimeSecs; // Offset: 0x04 // Size: 0x04
	bool bVictimAI; // Offset: 0x08 // Size: 0x01
	enum class EWonderfulCutCaptureType CaptureType; // Offset: 0x09 // Size: 0x01
	enum class EWonderfulCutShootDamageType ShootDamageType; // Offset: 0x0a // Size: 0x01
	char pad_0xB[0x1]; // Offset: 0x0b // Size: 0x01
	float ShootDistance; // Offset: 0x0c // Size: 0x04
	struct FString CauserName; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WonderfulCutShootDamageData
// Size: 0x18 // Inherited bytes: 0x00
struct FWonderfulCutShootDamageData {
	// Fields
	int DamagePlayerID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FWonderfulCut_OneShootDamage> ShootDamageList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WonderfulCut_OneShootDamage
// Size: 0x20 // Inherited bytes: 0x00
struct FWonderfulCut_OneShootDamage {
	// Fields
	bool bVictimAI; // Offset: 0x00 // Size: 0x01
	enum class EWonderfulCutCaptureType CaptureType; // Offset: 0x01 // Size: 0x01
	enum class EWonderfulCutShootDamageType ShootDamageType; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	float DamageTimeSecs; // Offset: 0x04 // Size: 0x04
	float ShootDistance; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString CauserName; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WorldActorFlagList
// Size: 0x10 // Inherited bytes: 0x00
struct FWorldActorFlagList {
	// Fields
	struct TArray<struct FWorldActorFlagData> FlagList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ShadowTrackerExtra.WorldActorFlagData
// Size: 0x08 // Inherited bytes: 0x00
struct FWorldActorFlagData {
	// Fields
	int ActorNetGUID; // Offset: 0x00 // Size: 0x04
	uint32_t PlayerKey; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.XTBetrayInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FXTBetrayInfo {
	// Fields
	bool IsInBetray; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int BetrayTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct ShadowTrackerExtra.SyncRelevantPlayerTask
// Size: 0x18 // Inherited bytes: 0x00
struct FSyncRelevantPlayerTask {
	// Fields
	int TaskId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct AActor*> TaskTargets; // Offset: 0x08 // Size: 0x10
};

