#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Rifle_SCAR_10001.BP_Rifle_SCAR_10000_C
// Size: 0xb30 // Inherited bytes: 0xb21
struct ABP_Rifle_SCAR_10000_C : ABP_LobbyWeapon_C {
	// Fields
	char pad_0xB21[0x7]; // Offset: 0xb21 // Size: 0x07
	struct ULobbyWeaponAnimList_Rifle_C* LobbyWeaponAnimList_Rifle; // Offset: 0xb28 // Size: 0x08

	// Functions

	// Object Name: Function BP_Rifle_SCAR_10001.BP_Rifle_SCAR_10000_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)
};

