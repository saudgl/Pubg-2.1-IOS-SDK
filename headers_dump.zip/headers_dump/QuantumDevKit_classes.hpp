#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class QuantumDevKit.QuantumFirebaseRemoteConfig
// Size: 0x90 // Inherited bytes: 0x28
struct UQuantumFirebaseRemoteConfig : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct TArray<struct FString> QueryConfigNamesArray; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x50]; // Offset: 0x40 // Size: 0x50

	// Functions

	// Object Name: Function QuantumDevKit.QuantumFirebaseRemoteConfig.GetStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	enum class EQuantumFirebaseRemoteConfigStatus GetStatus(); // Offset: 0x1022a56c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function QuantumDevKit.QuantumFirebaseRemoteConfig.GetRemoteConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetRemoteConfig(struct FString ConfigNameToQuery); // Offset: 0x1022a55cc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function QuantumDevKit.QuantumFirebaseRemoteConfig.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UQuantumFirebaseRemoteConfig* GetInstance(); // Offset: 0x1022a5598 // Return & Params: Num(1) Size(0x8)
};

