#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Activty_Tip_UIBP.Activty_Tip_UIBP_C
// Size: 0x278 // Inherited bytes: 0x248
struct UActivty_Tip_UIBP_C : UUserWidget {
	// Fields
	struct UCommon_Item_BP_C* Common_Item_BP; // Offset: 0x248 // Size: 0x08
	struct UTextBlock* cost_num; // Offset: 0x250 // Size: 0x08
	struct UHorizontalBox* cost_root; // Offset: 0x258 // Size: 0x08
	struct UTextBlock* have_num; // Offset: 0x260 // Size: 0x08
	struct UTextBlock* TextBlock_1; // Offset: 0x268 // Size: 0x08
	struct UTextBlock* TextBlock_7; // Offset: 0x270 // Size: 0x08
};

