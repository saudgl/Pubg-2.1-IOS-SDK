#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ItemCoBrandedConfig_type.BP_STRUCT_ItemCoBrandedConfig_type
// Size: 0x08 // Inherited bytes: 0x00
struct FBP_STRUCT_ItemCoBrandedConfig_type {
	// Fields
	int coType_0_17FB544075F0919365D66DDB03705845; // Offset: 0x00 // Size: 0x04
	int itemID_1_0E668640726F23B95CD0C0A704FE59F4; // Offset: 0x04 // Size: 0x04
};

