#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Main_Match_Entry_UIBP.Lobby_Main_Match_Entry_UIBP_C
// Size: 0x5a8 // Inherited bytes: 0x248
struct ULobby_Main_Match_Entry_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Animation_MatchingGuide; // Offset: 0x248 // Size: 0x08
	struct UWidgetAnimation* Anim_Weapon; // Offset: 0x250 // Size: 0x08
	struct UWidgetAnimation* Anina_Permanent; // Offset: 0x258 // Size: 0x08
	struct UWidgetAnimation* Animation_Hand_Loop; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Animation_Mask; // Offset: 0x268 // Size: 0x08
	struct UWidgetAnimation* NewAnimation_2; // Offset: 0x270 // Size: 0x08
	struct UWidgetAnimation* Animation_Hand; // Offset: 0x278 // Size: 0x08
	struct UWidgetAnimation* Animation_ShrinkAndExpansion; // Offset: 0x280 // Size: 0x08
	struct UCanvasPanel* Battle_NewbieGuide; // Offset: 0x288 // Size: 0x08
	struct UBorder* Border_1; // Offset: 0x290 // Size: 0x08
	struct UBorder* Border_MatchInfo; // Offset: 0x298 // Size: 0x08
	struct UButton* Button_1; // Offset: 0x2a0 // Size: 0x08
	struct UButton* Button_ArenaWeapon; // Offset: 0x2a8 // Size: 0x08
	struct UButton* Button_Close; // Offset: 0x2b0 // Size: 0x08
	struct UButton* Button_Entry; // Offset: 0x2b8 // Size: 0x08
	struct UButton* Button_Expand; // Offset: 0x2c0 // Size: 0x08
	struct UButton* Button_FirstWin; // Offset: 0x2c8 // Size: 0x08
	struct UButton* Button_Mask; // Offset: 0x2d0 // Size: 0x08
	struct UButton* Button_Ploy_2; // Offset: 0x2d8 // Size: 0x08
	struct UButton* Button_RecPlay1; // Offset: 0x2e0 // Size: 0x08
	struct UButton* Button_RecPlay2; // Offset: 0x2e8 // Size: 0x08
	struct UButton* Button_Shrink; // Offset: 0x2f0 // Size: 0x08
	struct UButton* Button_SpMode; // Offset: 0x2f8 // Size: 0x08
	struct UCanvasPanel* Canvas_FirstBattle_Newbie; // Offset: 0x300 // Size: 0x08
	struct UCanvasPanel* Canvas_Panel_HandGuide; // Offset: 0x308 // Size: 0x08
	struct UCanvasPanel* Canvas_Panel_HandGuide2; // Offset: 0x310 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_20; // Offset: 0x318 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_FirstWin; // Offset: 0x320 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_JK; // Offset: 0x328 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Matching; // Offset: 0x330 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Pre; // Offset: 0x338 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_SpMode; // Offset: 0x340 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_TeamCnt; // Offset: 0x348 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_tips; // Offset: 0x350 // Size: 0x08
	struct UCanvasPanel* Effect_StartGame; // Offset: 0x358 // Size: 0x08
	struct UCanvasPanel* EntryGuide_FX; // Offset: 0x360 // Size: 0x08
	struct UCommon_Item_BP_C* FirstWinReward; // Offset: 0x368 // Size: 0x08
	struct UCanvasPanel* FX_Mask; // Offset: 0x370 // Size: 0x08
	struct UGridPanel* GridPanel_1; // Offset: 0x378 // Size: 0x08
	struct UGridPanel* GridPanel_LTMatch; // Offset: 0x380 // Size: 0x08
	struct UButton* GuideBtn; // Offset: 0x388 // Size: 0x08
	struct UCanvasPanel* GuidePanel; // Offset: 0x390 // Size: 0x08
	struct UTextBlock* GuideTip; // Offset: 0x398 // Size: 0x08
	struct UImage* Image_3; // Offset: 0x3a0 // Size: 0x08
	struct UImage* Image_4; // Offset: 0x3a8 // Size: 0x08
	struct UImage* Image_8; // Offset: 0x3b0 // Size: 0x08
	struct UImage* Image_9; // Offset: 0x3b8 // Size: 0x08
	struct UImage* Image_12; // Offset: 0x3c0 // Size: 0x08
	struct UImage* Image_14; // Offset: 0x3c8 // Size: 0x08
	struct UImage* Image_16; // Offset: 0x3d0 // Size: 0x08
	struct UImage* Image_17; // Offset: 0x3d8 // Size: 0x08
	struct UImage* Image_18; // Offset: 0x3e0 // Size: 0x08
	struct UImage* Image_20; // Offset: 0x3e8 // Size: 0x08
	struct UImage* Image_21; // Offset: 0x3f0 // Size: 0x08
	struct UImage* Image_22; // Offset: 0x3f8 // Size: 0x08
	struct UImage* Image_29; // Offset: 0x400 // Size: 0x08
	struct UImage* Image_37; // Offset: 0x408 // Size: 0x08
	struct UImage* Image_44; // Offset: 0x410 // Size: 0x08
	struct UImage* Image_45; // Offset: 0x418 // Size: 0x08
	struct UImage* Image_51; // Offset: 0x420 // Size: 0x08
	struct UImage* Image_52; // Offset: 0x428 // Size: 0x08
	struct UImage* Image_53; // Offset: 0x430 // Size: 0x08
	struct UImage* Image_54; // Offset: 0x438 // Size: 0x08
	struct UImage* Image_Cover; // Offset: 0x440 // Size: 0x08
	struct UImage* Image_guide; // Offset: 0x448 // Size: 0x08
	struct UImage* Image_Ploy; // Offset: 0x450 // Size: 0x08
	struct UImage* Image_SpMode; // Offset: 0x458 // Size: 0x08
	struct UImage* Image_TeamFlag; // Offset: 0x460 // Size: 0x08
	struct UTextBlock* Language1; // Offset: 0x468 // Size: 0x08
	struct UTextBlock* Language2; // Offset: 0x470 // Size: 0x08
	struct UMaskBoxItem_C* MaskBoxItem; // Offset: 0x478 // Size: 0x08
	struct UVerticalBox* MatchInfo; // Offset: 0x480 // Size: 0x08
	struct UImage* MatchInfo_HorizontalSplitLine; // Offset: 0x488 // Size: 0x08
	struct UCanvasPanel* MatchTips; // Offset: 0x490 // Size: 0x08
	struct UCanvasPanel* New_Mode; // Offset: 0x498 // Size: 0x08
	struct UCanvasPanel* Panel_laodaixin; // Offset: 0x4a0 // Size: 0x08
	struct UCanvasPanel* ParachuteTactics; // Offset: 0x4a8 // Size: 0x08
	struct UCanvasPanel* SameLanguageMatch; // Offset: 0x4b0 // Size: 0x08
	struct UScaleBox* ScaleBox_EstimateTime; // Offset: 0x4b8 // Size: 0x08
	struct UCanvasPanel* TeammateMatch; // Offset: 0x4c0 // Size: 0x08
	struct UTextBlock* Text_ParachuteTactics; // Offset: 0x4c8 // Size: 0x08
	struct UTextBlock* Text_State; // Offset: 0x4d0 // Size: 0x08
	struct UTextBlock* Text_TeamCnt; // Offset: 0x4d8 // Size: 0x08
	struct UTextBlock* Text_WaitForMatchNum; // Offset: 0x4e0 // Size: 0x08
	struct UTextBlock* TextBlock_5; // Offset: 0x4e8 // Size: 0x08
	struct UTextBlock* TextBlock_6; // Offset: 0x4f0 // Size: 0x08
	struct UTextBlock* TextBlock_8; // Offset: 0x4f8 // Size: 0x08
	struct UTextBlock* TextBlock_14; // Offset: 0x500 // Size: 0x08
	struct UTextBlock* TextBlock_15; // Offset: 0x508 // Size: 0x08
	struct UTextBlock* TextBlock_Cross; // Offset: 0x510 // Size: 0x08
	struct UTextBlock* TextBlock_LModeName1; // Offset: 0x518 // Size: 0x08
	struct UTextBlock* TextBlock_LModeName2; // Offset: 0x520 // Size: 0x08
	struct UTextBlock* TextBlock_LTMatchType1; // Offset: 0x528 // Size: 0x08
	struct UTextBlock* TextBlock_LTMatchType2; // Offset: 0x530 // Size: 0x08
	struct UTextBlock* TextBlock_Matching; // Offset: 0x538 // Size: 0x08
	struct UTextBlock* TextBlock_MatchingTime; // Offset: 0x540 // Size: 0x08
	struct UTextBlock* TextBlock_Readying; // Offset: 0x548 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_LPerspective1; // Offset: 0x550 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_LPerspective2; // Offset: 0x558 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_LTime1; // Offset: 0x560 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_LTime2; // Offset: 0x568 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_RemainingTime; // Offset: 0x570 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_TeamMatch; // Offset: 0x578 // Size: 0x08
	struct UVerticalBox* VerticalBox_8; // Offset: 0x580 // Size: 0x08
	struct UCanvasPanel* WaitForMatch; // Offset: 0x588 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_1; // Offset: 0x590 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_State; // Offset: 0x598 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Top; // Offset: 0x5a0 // Size: 0x08
};

