#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_AchievementCondTypeCfg_type.BP_STRUCT_AchievementCondTypeCfg_type
// Size: 0x20 // Inherited bytes: 0x00
struct FBP_STRUCT_AchievementCondTypeCfg_type {
	// Fields
	int ID_0_124A108068BC54B25737CDE003D23914; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Desc_1_22FF0D001ABF1F687AF9D1CC02396F43; // Offset: 0x08 // Size: 0x10
	int Param2ID_2_484DF940440BA7657281E92B0B563E74; // Offset: 0x18 // Size: 0x04
	int Param2TypeID_3_218821C069425DED6E4CDA260F2B3FE4; // Offset: 0x1c // Size: 0x04
};

