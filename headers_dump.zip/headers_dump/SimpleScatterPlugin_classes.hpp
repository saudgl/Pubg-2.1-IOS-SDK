#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SimpleScatterPlugin.SimpleScatter
// Size: 0x528 // Inherited bytes: 0x3d8
struct ASimpleScatter : AActor {
	// Fields
	char pad_0x3D8[0x68]; // Offset: 0x3d8 // Size: 0x68
	bool bEnabled; // Offset: 0x440 // Size: 0x01
	char pad_0x441[0x3]; // Offset: 0x441 // Size: 0x03
	int RandomSeed; // Offset: 0x444 // Size: 0x04
	struct TArray<struct FInstancedMesh> InstancedMeshes; // Offset: 0x448 // Size: 0x10
	struct TArray<struct FScatterSurface> ScatterSurfaces; // Offset: 0x458 // Size: 0x10
	enum class EDistributionMode DistributionMode; // Offset: 0x468 // Size: 0x01
	char pad_0x469[0x3]; // Offset: 0x469 // Size: 0x03
	int InstanceSpacing; // Offset: 0x46c // Size: 0x04
	struct FVector2D GridScale; // Offset: 0x470 // Size: 0x08
	struct FSlopeDistributionLimit SlopeDistributionLimit; // Offset: 0x478 // Size: 0x10
	struct FHeightDistributionLimit HeightDistributionLimit; // Offset: 0x488 // Size: 0x10
	struct TArray<struct AActor*> ExcludeMeshes; // Offset: 0x498 // Size: 0x10
	struct FVector MoveMin; // Offset: 0x4a8 // Size: 0x0c
	struct FVector MoveMax; // Offset: 0x4b4 // Size: 0x0c
	float MoveZ_BySurface; // Offset: 0x4c0 // Size: 0x04
	struct FRotator RotateMin; // Offset: 0x4c4 // Size: 0x0c
	struct FRotator RotateMax; // Offset: 0x4d0 // Size: 0x0c
	float AlignToSurface; // Offset: 0x4dc // Size: 0x04
	enum class ESurfaceAlignMode AlignMode; // Offset: 0x4e0 // Size: 0x01
	char pad_0x4E1[0x3]; // Offset: 0x4e1 // Size: 0x03
	struct FVector ScaleMin; // Offset: 0x4e4 // Size: 0x0c
	struct FVector ScaleMax; // Offset: 0x4f0 // Size: 0x0c
	enum class EScaleMode ScaleMode; // Offset: 0x4fc // Size: 0x01
	char pad_0x4FD[0x3]; // Offset: 0x4fd // Size: 0x03
	float MaterialScaleEffect; // Offset: 0x500 // Size: 0x04
	struct FSlopeScaleFalloff SlopeScaleFalloff; // Offset: 0x504 // Size: 0x10
	int MinCullDistance; // Offset: 0x514 // Size: 0x04
	int MaxCullDistance; // Offset: 0x518 // Size: 0x04
	int MaxInstancesLimit; // Offset: 0x51c // Size: 0x04
	bool bShowDebugMessages; // Offset: 0x520 // Size: 0x01
	char pad_0x521[0x7]; // Offset: 0x521 // Size: 0x07

	// Functions

	// Object Name: Function SimpleScatterPlugin.SimpleScatter.ManualRefresh
	// Flags: [Final|Native|Private]
	void ManualRefresh(); // Offset: 0x1021ed10c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class SimpleScatterPlugin.SimpleScatterSpline
// Size: 0x820 // Inherited bytes: 0x7f0
struct USimpleScatterSpline : USplineComponent {
	// Fields
	bool bExcludeSpline; // Offset: 0x7e5 // Size: 0x01
	bool bClosedSpline; // Offset: 0x7e6 // Size: 0x01
	float DensityDistanceEffect; // Offset: 0x7e8 // Size: 0x04
	float DensityDistanceMin; // Offset: 0x7ec // Size: 0x04
	float DensityDistanceMax; // Offset: 0x7f0 // Size: 0x04
	float DensityDistanceCurve; // Offset: 0x7f4 // Size: 0x04
	float ScaleDistanceEffect; // Offset: 0x7f8 // Size: 0x04
	float ScaleDistanceMin; // Offset: 0x7fc // Size: 0x04
	float ScaleDistanceMax; // Offset: 0x800 // Size: 0x04
	float ScaleDistanceCurve; // Offset: 0x804 // Size: 0x04
	char pad_0x812[0xe]; // Offset: 0x812 // Size: 0x0e
};

