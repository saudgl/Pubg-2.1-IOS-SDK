#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: AnimBlueprintGeneratedClass Lobby_AnimBP.Lobby_AnimBP_C
// Size: 0x4581 // Inherited bytes: 0x490
struct ULobby_AnimBP_C : USTPawnAnimInstanceBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 // Size: 0x08
	struct FAnimNode_Root AnimGraphNode_Root_AFF52F6C457272B774D5C286273B97F4; // Offset: 0x498 // Size: 0x50
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2BE462B7452BD6CC7AA9BEB99A15F46B; // Offset: 0x4e8 // Size: 0x2c0
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_9A8BCB494C60C4E6B163B69FBF189C85; // Offset: 0x7a8 // Size: 0x50
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_9E8CA6A84B12F57225A6DB8E983D5123; // Offset: 0x7f8 // Size: 0x50
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_473AC4274B4CEED81B20C9A9ACC2EB17; // Offset: 0x848 // Size: 0x70
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_47BBD58E47BA952B4BC65BB1577F4EF6; // Offset: 0x8b8 // Size: 0x80
	struct FAnimNode_Slot AnimGraphNode_Slot_32F8A3014A4B2F525C7DD4B2D614EA15; // Offset: 0x938 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_F7A0422648E25AB4352F9A96EDFC9CC3; // Offset: 0x9a8 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4BF41F204D641F3C8FA2F1AC89979187; // Offset: 0xa18 // Size: 0x70
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_736936E84C48BB5C4165BA8DD7CEB90D; // Offset: 0xa88 // Size: 0x80
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3A66873B4D49DFF418B19B8623248317; // Offset: 0xb08 // Size: 0x50
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_D1F9C59643EF5AB6506D33B1FAF9BEAE; // Offset: 0xb58 // Size: 0x80
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4F7536174C45371D788EBA946ED43248; // Offset: 0xbd8 // Size: 0x70
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_F8943D434E6AAE1B07C0F1B3ABB0DA78; // Offset: 0xc48 // Size: 0x50
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_D25BB41445101287DBCE3EB4CAB67171; // Offset: 0xc98 // Size: 0xc0
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_17F5FAB949FCF7C783F62AAB483AC447; // Offset: 0xd58 // Size: 0x50
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_A5A477CB4316043DAC6FF4A95217783D; // Offset: 0xda8 // Size: 0x50
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_C2D2D97E414325A1E172869DEE2DE416; // Offset: 0xdf8 // Size: 0xc0
	struct FAnimNode_Slot AnimGraphNode_Slot_B65895564C080E77F70DF7AA5C4C1300; // Offset: 0xeb8 // Size: 0x70
	struct FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt_4A815C384984B5A2B5386299F2DEED85; // Offset: 0xf28 // Size: 0xd0
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_986285904B872DCB94CF8CBAB9A90888; // Offset: 0xff8 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5E0C64FC43AAF3BD99CE0D84DCFD52A2; // Offset: 0x1068 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_D49905424D9E64B1DC1DB58770E63F03; // Offset: 0x10d8 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2A1BA28C41B59FDC94DD439E6E4AA51F; // Offset: 0x1148 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_EE27731C4EE1344DDB785FBD062BE8C6; // Offset: 0x11b8 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_07AFE46040E954CBDBB3088F734467E2; // Offset: 0x1228 // Size: 0x70
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_9A8F47724807B36A5929E3A6B1860F7F; // Offset: 0x1298 // Size: 0xe8
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_0E60BE884F4F2D4D549762803828DD05; // Offset: 0x1380 // Size: 0xd0
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_DDCBB29A4A3C78BA06EDE9BE0F603F0F; // Offset: 0x1450 // Size: 0xd0
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_EDCBB4A3451F17C986B87E830382CD73; // Offset: 0x1520 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3608C9064898C777D090B8A2B9FD3A3F; // Offset: 0x1590 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8B9AEDA847AFF35B2E42148070E80DB9; // Offset: 0x1600 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_35658A8340547480AEB0B78E19C1027F; // Offset: 0x1670 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_DF4F569A4918899597E2E89D3D11B3E5; // Offset: 0x16e0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_222D007B405FDA5EFDB3568AEF39D531; // Offset: 0x1750 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_561B31A044E65E1E340CFB9B6FFB51F4; // Offset: 0x17c0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2B079C8B4A4419E004261EA1DA8759A6; // Offset: 0x1830 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_191DC67A40173F2F0C4DA0BFA2CB665E; // Offset: 0x18a0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_92153E9547C3807F57A62BB6447C559F; // Offset: 0x1910 // Size: 0x70
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_A513AE2D43A39ABB4CF95CBA42F46E4F; // Offset: 0x1980 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_2FC4424843DAD0EDAC532EA346B5B3D5; // Offset: 0x1a68 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_626A8657450B700E04EA978275350404; // Offset: 0x1b50 // Size: 0xe8
	struct FAnimNode_Root AnimGraphNode_StateResult_DBA75E85412A18376FC1B782D7D7E62C; // Offset: 0x1c38 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_7C66CC2046E30C0FE71EDAA15CA235DE; // Offset: 0x1c88 // Size: 0xd8
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_522010E9411D43F7B58CC1AF78D43D8A; // Offset: 0x1d60 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_A3B9C9E74B16C14BA3BA058316F50B1E; // Offset: 0x1dd0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_DE62A7724E25812FD8462382C57B45E9; // Offset: 0x1e40 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5D9907374142A88F15EE6B90BB047A33; // Offset: 0x1eb0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_154F5C224665119F224224BFB88AB20B; // Offset: 0x1f20 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5DCE8DF8407A1A155A85C9A64A110AB3; // Offset: 0x1f90 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9A993A8E41FF247B76D393AE30694D7A; // Offset: 0x2000 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6832A2A44278A823895A78B13D0407AE; // Offset: 0x2070 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_FB8EC6B14686D6CA087EF683B30E4775; // Offset: 0x20e0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_25A38C25417C4448092CE6B9B98EFA0B; // Offset: 0x2150 // Size: 0x70
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_C898A5D7416E49C0B875F381E8BFDFD3; // Offset: 0x21c0 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_C095363F4AC15D76C347A2BFF205FCE4; // Offset: 0x22a8 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_696616664DC8F8B31B7072B548CDF566; // Offset: 0x2390 // Size: 0xe8
	struct FAnimNode_Root AnimGraphNode_StateResult_CE1AF3FA4F5795623E54058D50259456; // Offset: 0x2478 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_ECEB81AF4DF2907A26DEEDB8C9420083; // Offset: 0x24c8 // Size: 0xd8
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_C324BED34DCE43458C6D94B3C571BD2B; // Offset: 0x25a0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_BF7DAE5C4CDEC269AD6AA192CF1FD6E3; // Offset: 0x2610 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_08930DDA4CE34DAC3601EA9E39D422B7; // Offset: 0x2680 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_F8307FC74803EA2024D30A983FE9ACB8; // Offset: 0x26f0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_A33B190241873044F5EBE3B405869D1E; // Offset: 0x2760 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_894802A74CD4DA76D55CC2821BC7E8B8; // Offset: 0x27d0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_B0F3F91644D9E68047C8B29D4E54742B; // Offset: 0x2840 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_00960CA54A347CA1F2B7D0A0D94B4130; // Offset: 0x28b0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_14188E96493882B251D35C9BA78D0203; // Offset: 0x2920 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_0300AC2D4493E991FCFCB9898896AB33; // Offset: 0x2990 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_96B8F204402ECDB76F7B92ACC8A0BE2E; // Offset: 0x2a00 // Size: 0x70
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_8EBE0B9340BA1548E3FEF392CAAB88A2; // Offset: 0x2a70 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_A347A3ED47331AAA671B7A9F8D626390; // Offset: 0x2b58 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_59BB895B4FABFB558D844FBD547DA6DF; // Offset: 0x2c40 // Size: 0xe8
	struct FAnimNode_Root AnimGraphNode_StateResult_384935F8419BF996A60784881AF1D3B3; // Offset: 0x2d28 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_809461744C84751F661513B46DECC19B; // Offset: 0x2d78 // Size: 0xd8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_19A367B64AA6A6E557F95895FD546B0C; // Offset: 0x2e50 // Size: 0xe8
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_99BEBB72474B296808E67BA89EF360C4; // Offset: 0x2f38 // Size: 0xd0
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_321CC3564AC8D96DE5675E932E6FEF7D; // Offset: 0x3008 // Size: 0x50
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_7C925F734DBE08D09FE001810C0F531B; // Offset: 0x3058 // Size: 0x50
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_5053D59846A79D34177D06809EAC19A4; // Offset: 0x30a8 // Size: 0x80
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_02C27FD84D09FAB2A76F7B819BE4E02E; // Offset: 0x3128 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6B1B765D4DFCF3ED170D2CA6BA912335; // Offset: 0x3198 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_DC74B3834291C85A1C11BB907AA1CC44; // Offset: 0x3208 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1CD7157D4AA33BBC8A249794003DA92D; // Offset: 0x3278 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_26E2FBDA45BCCD35C178208267A47E3C; // Offset: 0x32e8 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_19EA61F347E92E523233C0973F710EDD; // Offset: 0x3358 // Size: 0x70
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_D7A166DD41A3E24756434FA7A0BABDE8; // Offset: 0x33c8 // Size: 0xe8
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_74C05CBE44C7AF6CB793908D2C8B0F08; // Offset: 0x34b0 // Size: 0xd0
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_7AA3FDDC4DB88E4C3BF7D381DD41B451; // Offset: 0x3580 // Size: 0xd0
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_BF58387E48A88C32CE645889704BEDAD; // Offset: 0x3650 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4783BF5640FA982A7AA637AA42C69C70; // Offset: 0x36c0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_04BD4ED24183152C50D642A1D4388436; // Offset: 0x3730 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7DC95E0E4A9B2D7D1EBCB89DE4EF31C1; // Offset: 0x37a0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_29E59FC34629BD25792B509EFC764F4A; // Offset: 0x3810 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_48692B984CAAD645C93D54810082B97C; // Offset: 0x3880 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_DAFCF9AD457485E2574BE0BEC62DD94E; // Offset: 0x38f0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6C98737A4088A65309A42492B704105D; // Offset: 0x3960 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_D91B8B374C9F3B0AD4F3A3B6D5BD2362; // Offset: 0x39d0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1390D01F41C22BB4411FF9A65A7635C2; // Offset: 0x3a40 // Size: 0x70
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_30941A2F402EFF78369C75A196BA5486; // Offset: 0x3ab0 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_8C3B06B446591B5653A365BDE61AB753; // Offset: 0x3b98 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_8C14C676414683DF8D852A8698630DF8; // Offset: 0x3c80 // Size: 0xe8
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5638270D44D89786C59D70AC2704C84B; // Offset: 0x3d68 // Size: 0x70
	struct FAnimNode_Root AnimGraphNode_StateResult_710EE3A34294511D18494BB9EE5DAA05; // Offset: 0x3dd8 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_21B5B7CA42AEE0A65B4BD5B8D92EB13C; // Offset: 0x3e28 // Size: 0xd8
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_D7D50B3640A5D47DAC35FD98719D344C; // Offset: 0x3f00 // Size: 0x48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_95D7A7E54AE984099D67D6B88CE47F33; // Offset: 0x3f48 // Size: 0x48
	struct FAnimNode_Root AnimGraphNode_StateResult_5F4DD97047315E04527D889B2EE19674; // Offset: 0x3f90 // Size: 0x50
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_E4910DA347A6CAE2BAEDCA8E3EC3E099; // Offset: 0x3fe0 // Size: 0x70
	struct FAnimNode_Slot AnimGraphNode_Slot_5B4CA56049D0126526D84C8EBB0D0BCF; // Offset: 0x4050 // Size: 0x70
	struct FAnimNode_Root AnimGraphNode_StateResult_463FA7834E6D9D089FD601BF2B3FF7D9; // Offset: 0x40c0 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_3EBEABE248532586A00036A71F2AA1CB; // Offset: 0x4110 // Size: 0xd8
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_279239D64DB636652BBE09A92658848B; // Offset: 0x41e8 // Size: 0xd0
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_FBBDCD0F49F1D2BD9D457BBBF2FC29DA; // Offset: 0x42b8 // Size: 0xd0
	bool Man; // Offset: 0x4388 // Size: 0x01
	bool IsFront; // Offset: 0x4389 // Size: 0x01
	bool IsChange; // Offset: 0x438a // Size: 0x01
	bool bUseHairAnimDynamics; // Offset: 0x438b // Size: 0x01
	struct FAnimParamList CharacterAnimParam; // Offset: 0x438c // Size: 0x138
	bool IsWeaponGrip; // Offset: 0x44c4 // Size: 0x01
	bool Positon; // Offset: 0x44c5 // Size: 0x01
	char pad_0x44C6[0x2]; // Offset: 0x44c6 // Size: 0x02
	struct ASTExtraLobbyCharacter* LobbyCharacter; // Offset: 0x44c8 // Size: 0x08
	struct UAnimSequenceBase* WeaponAnimSeqBase; // Offset: 0x44d0 // Size: 0x08
	struct UAnimSequenceBase* WeaponAnimSeqBaseAdd; // Offset: 0x44d8 // Size: 0x08
	enum class ELobbyCharacterAnimType LobbyGenderType; // Offset: 0x44e0 // Size: 0x01
	enum class ECharacterShowSceneType charSceneType; // Offset: 0x44e1 // Size: 0x01
	char LobbyCharPosIdx; // Offset: 0x44e2 // Size: 0x01
	char pad_0x44E3[0x1]; // Offset: 0x44e3 // Size: 0x01
	struct FVector C_HurtDir; // Offset: 0x44e4 // Size: 0x0c
	int PoseStateIndex; // Offset: 0x44f0 // Size: 0x04
	char pad_0x44F4[0x4]; // Offset: 0x44f4 // Size: 0x04
	struct UPoseWithFriendComponent* PoseWithFriendComp; // Offset: 0x44f8 // Size: 0x08
	struct UAnimSequenceBase* PoseWithFriendAnimSeq; // Offset: 0x4500 // Size: 0x08
	bool bPoseWithFriend; // Offset: 0x4508 // Size: 0x01
	char pad_0x4509[0x3]; // Offset: 0x4509 // Size: 0x03
	float LastRotationYaw; // Offset: 0x450c // Size: 0x04
	float DeltaTimeX; // Offset: 0x4510 // Size: 0x04
	struct FVector ExternalForce; // Offset: 0x4514 // Size: 0x0c
	struct ABP_PlayerLobbyPawn_C* BP_LobbyPawn; // Offset: 0x4520 // Size: 0x08
	bool IsBPLobbyPawnValid; // Offset: 0x4528 // Size: 0x01
	char pad_0x4529[0x7]; // Offset: 0x4529 // Size: 0x07
	struct UAnimSequenceBase* WeaponPlayAnimSeqBase; // Offset: 0x4530 // Size: 0x08
	bool bWeaponPlaying; // Offset: 0x4538 // Size: 0x01
	char pad_0x4539[0x3]; // Offset: 0x4539 // Size: 0x03
	float WeaponIdleTimer; // Offset: 0x453c // Size: 0x04
	int ItemHasIdleAnim; // Offset: 0x4540 // Size: 0x04
	char pad_0x4544[0x4]; // Offset: 0x4544 // Size: 0x04
	struct UAnimSequence* SpecialIdle; // Offset: 0x4548 // Size: 0x08
	bool UseSpecialIdle; // Offset: 0x4550 // Size: 0x01
	bool ForceUseIdle; // Offset: 0x4551 // Size: 0x01
	char pad_0x4552[0x6]; // Offset: 0x4552 // Size: 0x06
	struct UAnimMontage* GoSkateAnim; // Offset: 0x4558 // Size: 0x08
	bool isAircast; // Offset: 0x4560 // Size: 0x01
	char pad_0x4561[0x7]; // Offset: 0x4561 // Size: 0x07
	struct UAnimSequenceBase* IdleSkateAnim; // Offset: 0x4568 // Size: 0x08
	float weaponAnimCountDownTime; // Offset: 0x4570 // Size: 0x04
	float lobbyIdleP1StartPosition; // Offset: 0x4574 // Size: 0x04
	bool bTPosActive; // Offset: 0x4578 // Size: 0x01
	char pad_0x4579[0x3]; // Offset: 0x4579 // Size: 0x03
	float skateAnimTime; // Offset: 0x457c // Size: 0x04
	bool GlideNeedRotate; // Offset: 0x4580 // Size: 0x01

	// Functions

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetTposActive
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetTposActive(bool bTPosActive); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.HandleSkatePose
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void HandleSkatePose(struct UBackpackAvatarHandle* AvatarHandle, bool IsEquiped, int ItemId, int SlotID); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0x14)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.UseSkatePose
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UseSkatePose(int SlotID, struct FItemDefineID newID, struct FItemDefineID OldID); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.CancleSkatePose
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CancleSkatePose(int SlotID, struct FItemDefineID OldItemID); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetSkatePose
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSkatePose(struct UAnimMontage* start_SkateAnim, struct UAnimSequenceBase* idle_SKateAnim); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetIsUsingSpecialIdle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsUsingSpecialIdle(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.ProcessAvatarEquipmentChange
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ProcessAvatarEquipmentChange(struct UBackpackAvatarHandle* AvatarHandle, bool IsEquiped, int ItemId, int SlotID); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0x14)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.WeaponPlayAnimEnd
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void WeaponPlayAnimEnd(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.StartWeaponPlayAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void StartWeaponPlayAnim(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.CountDownForWeaponPlay
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CountDownForWeaponPlay(float Delta); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.ProcessSceneTypeChange
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ProcessSceneTypeChange(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.ProcessPosChange
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ProcessPosChange(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.ProcessGenderChange
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ProcessGenderChange(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.GetWeaponUseGenderType
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetWeaponUseGenderType(char PosIdx, enum class ELobbyCharacterAnimType gender, enum class ELobbyCharacterAnimType& gender_type); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x3)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetWeaponAnimation
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetWeaponAnimation(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.UpdatePoseStateIndex
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdatePoseStateIndex(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetWeaponGrip
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetWeaponGrip(bool WeaponGrip); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.OnCancelPoseWithFriend
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnCancelPoseWithFriend(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.OnPoseWithFriend
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnPoseWithFriend(struct UAnimSequence* AnimSeq); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.PlayWeaponAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayWeaponAnim(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_8EBE0B9340BA1548E3FEF392CAAB88A2
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_8EBE0B9340BA1548E3FEF392CAAB88A2(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_A347A3ED47331AAA671B7A9F8D626390
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_A347A3ED47331AAA671B7A9F8D626390(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_59BB895B4FABFB558D844FBD547DA6DF
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_59BB895B4FABFB558D844FBD547DA6DF(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_696616664DC8F8B31B7072B548CDF566
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_696616664DC8F8B31B7072B548CDF566(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_19A367B64AA6A6E557F95895FD546B0C
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_19A367B64AA6A6E557F95895FD546B0C(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_99BEBB72474B296808E67BA89EF360C4
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_99BEBB72474B296808E67BA89EF360C4(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_02C27FD84D09FAB2A76F7B819BE4E02E
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_02C27FD84D09FAB2A76F7B819BE4E02E(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_6B1B765D4DFCF3ED170D2CA6BA912335
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_6B1B765D4DFCF3ED170D2CA6BA912335(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_DC74B3834291C85A1C11BB907AA1CC44
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_DC74B3834291C85A1C11BB907AA1CC44(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_1CD7157D4AA33BBC8A249794003DA92D
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_1CD7157D4AA33BBC8A249794003DA92D(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_26E2FBDA45BCCD35C178208267A47E3C
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_26E2FBDA45BCCD35C178208267A47E3C(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_19EA61F347E92E523233C0973F710EDD
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_19EA61F347E92E523233C0973F710EDD(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_D7A166DD41A3E24756434FA7A0BABDE8
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_D7A166DD41A3E24756434FA7A0BABDE8(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_74C05CBE44C7AF6CB793908D2C8B0F08
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_74C05CBE44C7AF6CB793908D2C8B0F08(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_7AA3FDDC4DB88E4C3BF7D381DD41B451
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_7AA3FDDC4DB88E4C3BF7D381DD41B451(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_30941A2F402EFF78369C75A196BA5486
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_30941A2F402EFF78369C75A196BA5486(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_8C3B06B446591B5653A365BDE61AB753
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_8C3B06B446591B5653A365BDE61AB753(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_8C14C676414683DF8D852A8698630DF8
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_8C14C676414683DF8D852A8698630DF8(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_5638270D44D89786C59D70AC2704C84B
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_5638270D44D89786C59D70AC2704C84B(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_C095363F4AC15D76C347A2BFF205FCE4
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_C095363F4AC15D76C347A2BFF205FCE4(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_C898A5D7416E49C0B875F381E8BFDFD3
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_C898A5D7416E49C0B875F381E8BFDFD3(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_626A8657450B700E04EA978275350404
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_626A8657450B700E04EA978275350404(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_2FC4424843DAD0EDAC532EA346B5B3D5
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_2FC4424843DAD0EDAC532EA346B5B3D5(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_A513AE2D43A39ABB4CF95CBA42F46E4F
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_A513AE2D43A39ABB4CF95CBA42F46E4F(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_8B9AEDA847AFF35B2E42148070E80DB9
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_8B9AEDA847AFF35B2E42148070E80DB9(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_TransitionResult_D7D50B3640A5D47DAC35FD98719D344C
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_TransitionResult_D7D50B3640A5D47DAC35FD98719D344C(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_3608C9064898C777D090B8A2B9FD3A3F
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_3608C9064898C777D090B8A2B9FD3A3F(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_TransitionResult_95D7A7E54AE984099D67D6B88CE47F33
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_TransitionResult_95D7A7E54AE984099D67D6B88CE47F33(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_EDCBB4A3451F17C986B87E830382CD73
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_EDCBB4A3451F17C986B87E830382CD73(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequenceEvaluator_E4910DA347A6CAE2BAEDCA8E3EC3E099
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequenceEvaluator_E4910DA347A6CAE2BAEDCA8E3EC3E099(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_DDCBB29A4A3C78BA06EDE9BE0F603F0F
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_DDCBB29A4A3C78BA06EDE9BE0F603F0F(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_279239D64DB636652BBE09A92658848B
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_279239D64DB636652BBE09A92658848B(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_FBBDCD0F49F1D2BD9D457BBBF2FC29DA
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_FBBDCD0F49F1D2BD9D457BBBF2FC29DA(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_0E60BE884F4F2D4D549762803828DD05
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_0E60BE884F4F2D4D549762803828DD05(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_9A8F47724807B36A5929E3A6B1860F7F
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_9A8F47724807B36A5929E3A6B1860F7F(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_07AFE46040E954CBDBB3088F734467E2
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_07AFE46040E954CBDBB3088F734467E2(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_EE27731C4EE1344DDB785FBD062BE8C6
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_EE27731C4EE1344DDB785FBD062BE8C6(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_2A1BA28C41B59FDC94DD439E6E4AA51F
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_2A1BA28C41B59FDC94DD439E6E4AA51F(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_D49905424D9E64B1DC1DB58770E63F03
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_D49905424D9E64B1DC1DB58770E63F03(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_5E0C64FC43AAF3BD99CE0D84DCFD52A2
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_5E0C64FC43AAF3BD99CE0D84DCFD52A2(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_986285904B872DCB94CF8CBAB9A90888
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_986285904B872DCB94CF8CBAB9A90888(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByInt_4A815C384984B5A2B5386299F2DEED85
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByInt_4A815C384984B5A2B5386299F2DEED85(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_ModifyBone_C2D2D97E414325A1E172869DEE2DE416
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_ModifyBone_C2D2D97E414325A1E172869DEE2DE416(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_ModifyBone_D25BB41445101287DBCE3EB4CAB67171
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_ModifyBone_D25BB41445101287DBCE3EB4CAB67171(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_4BF41F204D641F3C8FA2F1AC89979187
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_4BF41F204D641F3C8FA2F1AC89979187(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_F7A0422648E25AB4352F9A96EDFC9CC3
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_F7A0422648E25AB4352F9A96EDFC9CC3(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_AnimDynamics_2BE462B7452BD6CC7AA9BEB99A15F46B
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_AnimDynamics_2BE462B7452BD6CC7AA9BEB99A15F46B(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.BlueprintUpdateAnimation
	// Flags: [Event|Public|BlueprintEvent]
	void BlueprintUpdateAnimation(float DeltaTimeX); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.BlueprintInitializeAnimation
	// Flags: [Event|Public|BlueprintEvent]
	void BlueprintInitializeAnimation(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.OnLobbyGenderAnimChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnLobbyGenderAnimChange(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.OnLobbyCharSceneTypeChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnLobbyCharSceneTypeChange(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.OnLobbyCharWeaponChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnLobbyCharWeaponChange(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.OnLobbyCharPosChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnLobbyCharPosChange(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetForceuseIdle
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SetForceuseIdle(bool force); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.BindSkate
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BindSkate(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.UnEquip
	// Flags: [BlueprintCallable|BlueprintEvent]
	void UnEquip(int SlotID, struct FItemDefineID OldItemID); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.ExecuteUbergraph_Lobby_AnimBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Lobby_AnimBP(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

