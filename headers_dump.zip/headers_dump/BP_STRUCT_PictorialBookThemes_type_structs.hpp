#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_PictorialBookThemes_type.BP_STRUCT_PictorialBookThemes_type
// Size: 0xc0 // Inherited bytes: 0x00
struct FBP_STRUCT_PictorialBookThemes_type {
	// Fields
	struct FString background_image_0_4332CC007C4FEBAE1A1DAE3104C8D995; // Offset: 0x00 // Size: 0x10
	int general_model_1_78983F0023B0F1044BA722300E02252C; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString image_2_1B216C400C654BDF089F735C08001165; // Offset: 0x18 // Size: 0x10
	int item_num_3_0087C3001F1C8E8E2508DD6208EAE5BD; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString name_4_77B473C06347728759E93A0F0B804655; // Offset: 0x30 // Size: 0x10
	struct FString online_time_5_135B30405A0A09D36219FBA30CB0DC65; // Offset: 0x40 // Size: 0x10
	int order_6_4441128036D59DF60A5017050806AC72; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FString poster_7_357612C016C9FE933E6DBB5D0E74C1B2; // Offset: 0x58 // Size: 0x10
	struct FString preview_image_8_6BDF848074150086309953650CF64FF5; // Offset: 0x68 // Size: 0x10
	struct FString preview_time_9_48BC6F8077AD5CF27858615A02CC09B5; // Offset: 0x78 // Size: 0x10
	int quality_style_10_591A51C0735763916ED5EE7207F81975; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
	struct FString reward_image_11_55B9E5405A1D587D4C5FD81A08D28425; // Offset: 0x90 // Size: 0x10
	int season_12_59FEEDC014EC3EA54A95504A0E99E32E; // Offset: 0xa0 // Size: 0x04
	int style_13_759937C05342C3CB099B01B807EA9A95; // Offset: 0xa4 // Size: 0x04
	int topic_id_14_243DBE405A2106ED453F873B04050B44; // Offset: 0xa8 // Size: 0x04
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct FString version_15_6953CD0061BA4B644E1C66BA0CEF29BE; // Offset: 0xb0 // Size: 0x10
};

