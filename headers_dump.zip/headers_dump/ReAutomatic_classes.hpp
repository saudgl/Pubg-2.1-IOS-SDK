#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ReAutomatic.AutomaticCommonHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UAutomaticCommonHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function ReAutomatic.AutomaticCommonHelper.IsClassOf
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsClassOf(struct UObject* Object, struct UObject* Class); // Offset: 0x10233c178 // Return & Params: Num(3) Size(0x11)
};

// Object Name: Class ReAutomatic.AutomaticPlatformHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UAutomaticPlatformHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function ReAutomatic.AutomaticPlatformHelper.GetDeviceName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceName(); // Offset: 0x10233c3cc // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class ReAutomatic.AutomaticUIHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UAutomaticUIHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function ReAutomatic.AutomaticUIHelper.IsWidgetVisibleWithUICondition
	// Flags: [Final|Native|Static|Public|HasOutParms]
	bool IsWidgetVisibleWithUICondition(struct FFindUICondition& Condition, int Index); // Offset: 0x10233caa0 // Return & Params: Num(3) Size(0x2d)

	// Object Name: Function ReAutomatic.AutomaticUIHelper.IsWidgetVisible
	// Flags: [Final|Native|Static|Public]
	bool IsWidgetVisible(struct UWidget* Widget); // Offset: 0x10233ca24 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function ReAutomatic.AutomaticUIHelper.IsWidgetTextMatchRegex
	// Flags: [Final|Native|Static|Public]
	bool IsWidgetTextMatchRegex(struct UWidget* Widget, struct FString Text); // Offset: 0x10233c950 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function ReAutomatic.AutomaticUIHelper.IsWidgetMatchType
	// Flags: [Final|Native|Static|Public]
	bool IsWidgetMatchType(struct UWidget* Widget, enum class EUIType Type); // Offset: 0x10233c898 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function ReAutomatic.AutomaticUIHelper.FindWidgetObjectWithUICondition
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct UWidget* FindWidgetObjectWithUICondition(struct FFindUICondition& Condition, int Index); // Offset: 0x10233c7a0 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function ReAutomatic.AutomaticUIHelper.FindUWidgetObject
	// Flags: [Final|Native|Static|Public]
	struct UWidget* FindUWidgetObject(struct FString Name, int Index); // Offset: 0x10233c6c8 // Return & Params: Num(3) Size(0x20)
};

