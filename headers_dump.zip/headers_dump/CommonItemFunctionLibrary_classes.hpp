#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass CommonItemFunctionLibrary.CommonItemFunctionLibrary_C
// Size: 0x28 // Inherited bytes: 0x28
struct UCommonItemFunctionLibrary_C : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetBigItemIconAndQuality
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetBigItemIconAndQuality(int resID, struct UImage* qualityBottom, struct UImage* qualityBg, struct UImage* Icon, struct UImage* SpecialIcon, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(6) Size(0x30)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetOriginalItemSize
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetOriginalItemSize(struct UImage* Icon, struct UTextBlock* Text, struct UTextBlock* TextL, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetSmallItemSize
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetSmallItemSize(struct UImage* Icon, struct UTextBlock* Text, struct FString Count, struct UTextBlock* TextL, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(5) Size(0x30)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetGrayBg
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetGrayBg(bool IsShow, struct UImage* BG, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetSpecialIcon
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetSpecialIcon(struct UImage* SpecialIcon, struct FString Path, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetItemIconAndQuality
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetItemIconAndQuality(int resID, int render, struct UImage* qualityBottom, struct UImage* qualityBg, struct UImage* Icon, struct UImage* SpecialIcon, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(7) Size(0x30)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetImageAlpha
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetImageAlpha(struct UImage* Image, float Alpha, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetDefaultBg
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetDefaultBg(bool IsShow, struct UImage* BG, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetIsNew
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetIsNew(bool isNew, struct UTextBlock* newTexture, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetBlackBg
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetBlackBg(bool IsShow, struct UImage* BG, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetHasGet
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetHasGet(bool hasGet, struct UImage* GetTexture, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetIsLock
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetIsLock(bool isLock, struct UImage* lockTexture, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetIsShowSubTransparentBg
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetIsShowSubTransparentBg(bool IsShow, struct UImage* BG, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetColorAndPattern
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetColorAndPattern(struct UImage* tag1, struct UImage* tag2, int ColorID, int PatternID, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetCountText
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetCountText(int Count, struct UTextBlock* Text, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetIsWearing
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetIsWearing(bool isWear, struct UCanvasPanel* wearContainer, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetIsSelect
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetIsSelect(bool IsShow, struct UImage* selectImage, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetItemSmallIcon
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetItemSmallIcon(struct FString IconPath, struct UImage* smallIcon, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetItemName
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetItemName(int resID, struct UTextBlock* TextName, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CommonItemFunctionLibrary.CommonItemFunctionLibrary_C.SetQuality
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetQuality(struct UImage* iconQuality bottom, int Quality, struct UImage* iconQualityBg, struct UObject* __WorldContext); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0x20)
};

