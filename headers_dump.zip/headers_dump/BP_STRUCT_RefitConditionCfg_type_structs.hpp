#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_RefitConditionCfg_type.BP_STRUCT_RefitConditionCfg_type
// Size: 0x30 // Inherited bytes: 0x00
struct FBP_STRUCT_RefitConditionCfg_type {
	// Fields
	int groupID_0_198F004036460FB501F1C72D02489FA4; // Offset: 0x00 // Size: 0x04
	int minLevel_1_67E460C01B3A631105CE0DB105D7744C; // Offset: 0x04 // Size: 0x04
	int refitCostItem1_2_782F0E8025FD81701883AFAE0AC5EC21; // Offset: 0x08 // Size: 0x04
	int refitCostItem2_3_78300EC025FD81711883AFAD0AC5EC22; // Offset: 0x0c // Size: 0x04
	int refitCostItemNum1_4_1EA3DA801754088C54C5BBE70EC4F851; // Offset: 0x10 // Size: 0x04
	int refitCostItemNum2_5_1EA4DAC01754088D54C5BBE40EC4F852; // Offset: 0x14 // Size: 0x04
	int refitNumber_6_6A77B2800EDF6E226557FC7104403B92; // Offset: 0x18 // Size: 0x04
	int refitGroupID_7_505CDEC023C35A550BDDBA2E08D6F1E4; // Offset: 0x1c // Size: 0x04
	struct FString refitName_8_0D41D88033F9BDDA7818241A03542435; // Offset: 0x20 // Size: 0x10
};

