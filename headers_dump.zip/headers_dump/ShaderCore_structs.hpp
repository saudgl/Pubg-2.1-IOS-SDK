#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ShaderCore.GraphicsProfile
// Size: 0x30 // Inherited bytes: 0x00
struct FGraphicsProfile {
	// Fields
	struct FName FormatName; // Offset: 0x00 // Size: 0x08
	struct FName FeatureLevel; // Offset: 0x08 // Size: 0x08
	int QualityType; // Offset: 0x10 // Size: 0x04
	int UserQualitySetting; // Offset: 0x14 // Size: 0x04
	struct FName MaterialQualityLevel; // Offset: 0x18 // Size: 0x08
	int MobileHDR; // Offset: 0x20 // Size: 0x04
	int MobileSimplerShader; // Offset: 0x24 // Size: 0x04
	int ShadowQuality; // Offset: 0x28 // Size: 0x04
	int MaxCSMShadowResolution; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ShaderCore.ShaderGroupDesc
// Size: 0x60 // Inherited bytes: 0x00
struct FShaderGroupDesc {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> Exclude; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FString> Include; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FString> IncludePath; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FString> Prerequisite; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FString> Parent; // Offset: 0x50 // Size: 0x10
};

