#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: AnimBlueprintGeneratedClass MiniTv_Anim.MiniTv_Anim_C
// Size: 0x1280 // Inherited bytes: 0x3d0
struct UMiniTv_Anim_C : UAnimInstance {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3d0 // Size: 0x08
	struct FAnimNode_Root AnimGraphNode_Root_08B11A174EC514BEC5718882DF0694B4; // Offset: 0x3d8 // Size: 0x50
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_D7B72BE24EB04364FE178FA026E65FE8; // Offset: 0x428 // Size: 0x48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_0521CBB44E0764B8E506168619B29A22; // Offset: 0x470 // Size: 0x48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_811140BD498D35A8201AB8B06403744E; // Offset: 0x4b8 // Size: 0x48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_349A9286459785A6CB82098B48FCF413; // Offset: 0x500 // Size: 0x48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_A93D5F8A437DED85C8B89B9E294029A3; // Offset: 0x548 // Size: 0x48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_0E5571924803012EA1CFC59830FE0225; // Offset: 0x590 // Size: 0x48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4CB4C5BE4408EC09DBEE9E870E288122; // Offset: 0x5d8 // Size: 0x48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11656A624D79C3DC29F0D295D7CA8E92; // Offset: 0x620 // Size: 0x48
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6C82B2B94DC6B6124AB64C9B16986275; // Offset: 0x668 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_50B2D83C49FCFEBAA0C66690BB547CC1; // Offset: 0x6d8 // Size: 0x70
	struct FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt_F687C8584002A801512D1DAF2DDCCDBA; // Offset: 0x748 // Size: 0xd0
	struct FAnimNode_Root AnimGraphNode_StateResult_ABC4182C40F5631C99CE1A9DD7D88D05; // Offset: 0x818 // Size: 0x50
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_3C0D3C8A4900719BE1ABE094CC1DDEE6; // Offset: 0x868 // Size: 0x128
	struct FAnimNode_Root AnimGraphNode_StateResult_845B86564C1C5616585BA6A9D7E9CACE; // Offset: 0x990 // Size: 0x50
	struct FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt_FC35BFAE4A181D44BE9A8A8BBA1B0930; // Offset: 0x9e0 // Size: 0xd0
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_0A287ED04F1F139739ED75A408C8F23C; // Offset: 0xab0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1C1F5FD84276BEC4F90F089C2B5B3C4E; // Offset: 0xb20 // Size: 0x70
	struct FAnimNode_Root AnimGraphNode_StateResult_60CA9EAF49B1B1A9FA49EF8DC6AE54D8; // Offset: 0xb90 // Size: 0x50
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_CC84DB55440EEAAF56501DA63DB25227; // Offset: 0xbe0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_D8EC7C874F3EDFDE51853B86BA6C4D91; // Offset: 0xc50 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_B980C78D41E73DDD6E275789333FEA60; // Offset: 0xcc0 // Size: 0x70
	struct FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt_56D75B364E148F814C2A84BA44A164EB; // Offset: 0xd30 // Size: 0xd0
	struct FAnimNode_Root AnimGraphNode_StateResult_FBA9529D42F96C12A81DA68CBB3BC818; // Offset: 0xe00 // Size: 0x50
	struct FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt_B794831A434D87C0385C60A7F2BD37F6; // Offset: 0xe50 // Size: 0xd0
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_70A1BC124B94725E3F818E8C45ABFF22; // Offset: 0xf20 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_E1EAF320477428B9FE06A684837F6733; // Offset: 0xf90 // Size: 0x70
	struct FAnimNode_Root AnimGraphNode_StateResult_F85F89DB49653DC5E62B58A377FF4EB9; // Offset: 0x1000 // Size: 0x50
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_0354D8144427E351A277C68424D354D7; // Offset: 0x1050 // Size: 0x70
	struct FAnimNode_Root AnimGraphNode_StateResult_73DD72644053FB7030ED09B702D27900; // Offset: 0x10c0 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_3E2B818E407DC77B185786B072C94F9F; // Offset: 0x1110 // Size: 0xd8
	struct FAnimNode_Slot AnimGraphNode_Slot_80DC844D4570789EAAC2F3AEB7A9301D; // Offset: 0x11e8 // Size: 0x70
	int IdleState; // Offset: 0x1258 // Size: 0x04
	bool BStartDrag; // Offset: 0x125c // Size: 0x01
	bool BRotate; // Offset: 0x125d // Size: 0x01
	bool BWalk; // Offset: 0x125e // Size: 0x01
	bool BWin; // Offset: 0x125f // Size: 0x01
	int DoubleState; // Offset: 0x1260 // Size: 0x04
	char pad_0x1264[0x4]; // Offset: 0x1264 // Size: 0x04
	struct FScriptMulticastDelegate OnWalkEnd; // Offset: 0x1268 // Size: 0x10
	float Speed; // Offset: 0x1278 // Size: 0x04
	int dragType; // Offset: 0x127c // Size: 0x04

	// Functions

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.SetDragType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDragType(int dragType); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.SetSpeed
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSpeed(float Speed); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.SetDouble
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDouble(int Double); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.SetWin
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetWin(bool win); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.SetWalk
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetWalk(bool Walk); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.SetRotate
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRotate(bool Rotate); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.SetIdleState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIdleState(int State); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.SetDrag
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDrag(bool Drag); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_0E5571924803012EA1CFC59830FE0225
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_0E5571924803012EA1CFC59830FE0225(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_4CB4C5BE4408EC09DBEE9E870E288122
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_4CB4C5BE4408EC09DBEE9E870E288122(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_349A9286459785A6CB82098B48FCF413
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_349A9286459785A6CB82098B48FCF413(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_11656A624D79C3DC29F0D295D7CA8E92
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_11656A624D79C3DC29F0D295D7CA8E92(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_BlendListByInt_F687C8584002A801512D1DAF2DDCCDBA
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_BlendListByInt_F687C8584002A801512D1DAF2DDCCDBA(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_BlendSpacePlayer_3C0D3C8A4900719BE1ABE094CC1DDEE6
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_BlendSpacePlayer_3C0D3C8A4900719BE1ABE094CC1DDEE6(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_811140BD498D35A8201AB8B06403744E
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_811140BD498D35A8201AB8B06403744E(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_BlendListByInt_FC35BFAE4A181D44BE9A8A8BBA1B0930
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_BlendListByInt_FC35BFAE4A181D44BE9A8A8BBA1B0930(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_BlendListByInt_56D75B364E148F814C2A84BA44A164EB
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_BlendListByInt_56D75B364E148F814C2A84BA44A164EB(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_0521CBB44E0764B8E506168619B29A22
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_0521CBB44E0764B8E506168619B29A22(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_BlendListByInt_B794831A434D87C0385C60A7F2BD37F6
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_BlendListByInt_B794831A434D87C0385C60A7F2BD37F6(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_D7B72BE24EB04364FE178FA026E65FE8
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_MiniTv_Anim_AnimGraphNode_TransitionResult_D7B72BE24EB04364FE178FA026E65FE8(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.ExecuteUbergraph_MiniTv_Anim
	// Flags: [None]
	void ExecuteUbergraph_MiniTv_Anim(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MiniTv_Anim.MiniTv_Anim_C.OnWalkEnd__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnWalkEnd__DelegateSignature(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)
};

