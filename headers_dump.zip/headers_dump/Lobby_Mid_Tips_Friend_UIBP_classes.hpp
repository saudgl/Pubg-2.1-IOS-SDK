#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Mid_Tips_Friend_UIBP.Lobby_Mid_Tips_Friend_UIBP_C
// Size: 0x250 // Inherited bytes: 0x248
struct ULobby_Mid_Tips_Friend_UIBP_C : UUserWidget {
	// Fields
	struct UTextBlock* Text_Friend_Tips; // Offset: 0x248 // Size: 0x08
};

