#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass AchievementItem256_UIBP.AchievementItem256_UIBP_C
// Size: 0x4c8 // Inherited bytes: 0x400
struct UAchievementItem256_UIBP_C : UUAEUserWidget {
	// Fields
	struct UWidgetAnimation* Blink; // Offset: 0x400 // Size: 0x08
	struct UCanvasPanel* FX; // Offset: 0x408 // Size: 0x08
	struct UImage* Icon; // Offset: 0x410 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x418 // Size: 0x08
	struct UImage* Image_2; // Offset: 0x420 // Size: 0x08
	struct UImage* Image_3; // Offset: 0x428 // Size: 0x08
	struct UImage* Image_4; // Offset: 0x430 // Size: 0x08
	struct UImage* Image_5; // Offset: 0x438 // Size: 0x08
	struct UImage* Image_6; // Offset: 0x440 // Size: 0x08
	struct UImage* Image_7; // Offset: 0x448 // Size: 0x08
	struct UImage* Image_8; // Offset: 0x450 // Size: 0x08
	struct UImage* Image_9; // Offset: 0x458 // Size: 0x08
	struct UImage* Image_10; // Offset: 0x460 // Size: 0x08
	struct UImage* Image_11; // Offset: 0x468 // Size: 0x08
	struct UImage* Image_12; // Offset: 0x470 // Size: 0x08
	struct UImage* Image_13; // Offset: 0x478 // Size: 0x08
	struct UImage* Image_14; // Offset: 0x480 // Size: 0x08
	struct UImage* Star01; // Offset: 0x488 // Size: 0x08
	struct UImage* Star02; // Offset: 0x490 // Size: 0x08
	struct UImage* Star03; // Offset: 0x498 // Size: 0x08
	struct UImage* Star04; // Offset: 0x4a0 // Size: 0x08
	struct UImage* Star05; // Offset: 0x4a8 // Size: 0x08
	struct UImage* Star06; // Offset: 0x4b0 // Size: 0x08
	struct UGridPanel* StarGrid; // Offset: 0x4b8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_1; // Offset: 0x4c0 // Size: 0x08

	// Functions

	// Object Name: Function AchievementItem256_UIBP.AchievementItem256_UIBP_C.ShowFx
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowFx(bool Flag); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AchievementItem256_UIBP.AchievementItem256_UIBP_C.SetData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetData(int GroupID, int GroupNum, struct FString IconPath); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0x18)
};

