#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VideoTable_type.BP_STRUCT_VideoTable_type
// Size: 0x30 // Inherited bytes: 0x00
struct FBP_STRUCT_VideoTable_type {
	// Fields
	struct FString VideoPath_0_1098BE4009094E9F47A9152E089BE8B8; // Offset: 0x00 // Size: 0x10
	int VideoState_1_05385B40506E1F73600D2A1709B2A925; // Offset: 0x10 // Size: 0x04
	int FirstPlay_Skip_2_3D50C2400676B2E7577D206F066DF230; // Offset: 0x14 // Size: 0x04
	int Skip_Ctrl_3_066EC0007273ABB4379C3B35027C2C8C; // Offset: 0x18 // Size: 0x04
	int VideoID_4_394B1E404B0E5C797DE48E6700189C54; // Offset: 0x1c // Size: 0x04
	struct FString VideoKey_5_6D6B85404252568D21EE62CE0189D9C9; // Offset: 0x20 // Size: 0x10
};

