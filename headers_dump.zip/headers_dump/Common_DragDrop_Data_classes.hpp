#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Common_DragDrop_Data.Common_DragDrop_Data_C
// Size: 0xa4 // Inherited bytes: 0x88
struct UCommon_DragDrop_Data_C : UDragDropOperation {
	// Fields
	int dragItem; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
	struct FString dragExtendData; // Offset: 0x90 // Size: 0x10
	int dragInst; // Offset: 0xa0 // Size: 0x04
};

