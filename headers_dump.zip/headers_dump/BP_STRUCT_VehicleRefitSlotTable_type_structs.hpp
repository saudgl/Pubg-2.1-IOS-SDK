#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VehicleRefitSlotTable_type.BP_STRUCT_VehicleRefitSlotTable_type
// Size: 0x70 // Inherited bytes: 0x00
struct FBP_STRUCT_VehicleRefitSlotTable_type {
	// Fields
	struct FString ReplaceFlags_0_05F1A0C02EE0129D489AD6E4040BA313; // Offset: 0x00 // Size: 0x10
	int SlotID_1_4D80C2402E1D00ED6F4D2ECA0D997E54; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString RecoverHideFlagsWhenSelfReplaced_2_160BD4C0341420713A06A15207885244; // Offset: 0x18 // Size: 0x10
	struct FString RecoverReplaceFlagsWhenSelfReplaced_3_3906E5402E34FD5B79DF23B70E8786C4; // Offset: 0x28 // Size: 0x10
	struct FString HideFlags_4_4F1A50407DB02E0957920A660BF5E8B3; // Offset: 0x38 // Size: 0x10
	struct FString RecoverReplaceFlagsWhenSelfHidden_5_5B2090405954ADF5368610F50E1DBF4E; // Offset: 0x48 // Size: 0x10
	int SubSlotID_6_098A6CC00809E429766E695E070BB3C4; // Offset: 0x58 // Size: 0x04
	int ID_7_1A5BD9C0434833694B20FCFA0A168CC4; // Offset: 0x5c // Size: 0x04
	struct FString RecoverHideFlagsWhenSelfHidden_8_68C4FFC066E82D0D57E11B8D0A94B09E; // Offset: 0x60 // Size: 0x10
};

