#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ShaderCore.PrecompileShaderGameConfig
// Size: 0x88 // Inherited bytes: 0x28
struct UPrecompileShaderGameConfig : UObject {
	// Fields
	struct TArray<struct FGraphicsProfile> GraphicsProfiles; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x18]; // Offset: 0x38 // Size: 0x18
	int MobileEnableHardwarePCF; // Offset: 0x50 // Size: 0x04
	int MobileEnableIBL; // Offset: 0x54 // Size: 0x04
	int MobileEarlyZPass; // Offset: 0x58 // Size: 0x04
	int MobileEnableEarlyZDepthBias; // Offset: 0x5c // Size: 0x04
	int MobileUseAlphaToCoverage; // Offset: 0x60 // Size: 0x04
	int MobileBypassTranslucentMaterialPointLight; // Offset: 0x64 // Size: 0x04
	int MobileMSAA; // Offset: 0x68 // Size: 0x04
	int AllowStaticLighting; // Offset: 0x6c // Size: 0x04
	int SupportAllShaderPermutations; // Offset: 0x70 // Size: 0x04
	int SupportLowQualityLightmaps; // Offset: 0x74 // Size: 0x04
	int MobileEnableVertexPointLight; // Offset: 0x78 // Size: 0x04
	int MobileFallbackMSAAToFXAA; // Offset: 0x7c // Size: 0x04
	int IndirectLightingCache; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
};

// Object Name: Class ShaderCore.ShaderGroupSettings
// Size: 0xa0 // Inherited bytes: 0x28
struct UShaderGroupSettings : UObject {
	// Fields
	struct TArray<struct FShaderGroupDesc> Groups_IOS; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FShaderGroupDesc> Groups_AOS; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x58]; // Offset: 0x48 // Size: 0x58
};

