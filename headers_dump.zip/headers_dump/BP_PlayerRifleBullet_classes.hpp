#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_PlayerRifleBullet.BP_PlayerRifleBullet_C
// Size: 0x708 // Inherited bytes: 0x700
struct ABP_PlayerRifleBullet_C : ASTExtraShootWeaponBulletBase {
	// Fields
	struct UStaticMeshComponent* BulletMesh; // Offset: 0x700 // Size: 0x08

	// Functions

	// Object Name: Function BP_PlayerRifleBullet.BP_PlayerRifleBullet_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)
};

