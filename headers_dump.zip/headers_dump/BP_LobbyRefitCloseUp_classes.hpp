#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_LobbyRefitCloseUp.BP_LobbyRefitCloseUp_C
// Size: 0x410 // Inherited bytes: 0x3d8
struct ABP_LobbyRefitCloseUp_C : AActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3d8 // Size: 0x08
	struct UCameraComponent* Camera; // Offset: 0x3e0 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3e8 // Size: 0x08
	float ____0_time_5C46C2804013FEE671133C8FDC77B8D4; // Offset: 0x3f0 // Size: 0x04
	enum class ETimelineDirection ____0__Direction_5C46C2804013FEE671133C8FDC77B8D4; // Offset: 0x3f4 // Size: 0x01
	char pad_0x3F5[0x3]; // Offset: 0x3f5 // Size: 0x03
	struct UTimelineComponent* �e��t�_1; // Offset: 0x3f8 // Size: 0x08
	int closeUpSlotId; // Offset: 0x400 // Size: 0x04
	char pad_0x404[0x4]; // Offset: 0x404 // Size: 0x04
	struct ABP_LobbyRefitCloseUp_C* tempCameraCloseUp; // Offset: 0x408 // Size: 0x08

	// Functions

	// Object Name: Function BP_LobbyRefitCloseUp.BP_LobbyRefitCloseUp_C.GetCameraWorldLocation
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetCameraWorldLocation(struct FVector& cameraWorldLocation); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function BP_LobbyRefitCloseUp.BP_LobbyRefitCloseUp_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitCloseUp.BP_LobbyRefitCloseUp_C.�e��t�_
	// Flags: [BlueprintEvent]
	void �e��t�_(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitCloseUp.BP_LobbyRefitCloseUp_C.�e��t�_
	// Flags: [BlueprintEvent]
	void �e��t�_(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyRefitCloseUp.BP_LobbyRefitCloseUp_C.ChanTransformWithBlend
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	void ChanTransformWithBlend(struct FTransform& B); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function BP_LobbyRefitCloseUp.BP_LobbyRefitCloseUp_C.ExecuteUbergraph_BP_LobbyRefitCloseUp
	// Flags: [HasDefaults]
	void ExecuteUbergraph_BP_LobbyRefitCloseUp(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

