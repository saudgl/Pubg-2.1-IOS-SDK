#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Ammo_556mm_PickUp.BP_Ammo_556mm_Pickup_C
// Size: 0x838 // Inherited bytes: 0x830
struct ABP_Ammo_556mm_Pickup_C : APickUpWrapperActor {
	// Fields
	struct UStaticMeshComponent* SM_Ammo_556mm; // Offset: 0x830 // Size: 0x08

	// Functions

	// Object Name: Function BP_Ammo_556mm_PickUp.BP_Ammo_556mm_Pickup_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)
};

