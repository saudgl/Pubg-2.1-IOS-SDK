#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SegmentProtected_type.BP_STRUCT_SegmentProtected_type
// Size: 0x48 // Inherited bytes: 0x00
struct FBP_STRUCT_SegmentProtected_type {
	// Fields
	struct FString Describe_0_7610ED001E0A6CB6566076E606A97885; // Offset: 0x00 // Size: 0x10
	struct FString IconPath_1_15A88A404CAD6D0B5B66F80904709FF8; // Offset: 0x10 // Size: 0x10
	int ID_2_6C034800416770D8124F4EE20A33F774; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString Title_3_2ADAC5400345F35B7CAA43E00F61AA15; // Offset: 0x28 // Size: 0x10
	struct FString ScrollText_4_1998A9C0777720BB02837D3607E79C34; // Offset: 0x38 // Size: 0x10
};

