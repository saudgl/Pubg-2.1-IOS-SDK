#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass VideoPlayer.VideoPlayer_C
// Size: 0x5b0 // Inherited bytes: 0x400
struct UVideoPlayer_C : UUAEUserWidget {
	// Fields
	struct UWidgetAnimation* Root6_Out; // Offset: 0x400 // Size: 0x08
	struct UWidgetAnimation* Root6_In; // Offset: 0x408 // Size: 0x08
	struct UWidgetAnimation* Root5_Out; // Offset: 0x410 // Size: 0x08
	struct UWidgetAnimation* Root5_In; // Offset: 0x418 // Size: 0x08
	struct UWidgetAnimation* Root4_Out; // Offset: 0x420 // Size: 0x08
	struct UWidgetAnimation* Root4_In; // Offset: 0x428 // Size: 0x08
	struct UWidgetAnimation* Root3_Out; // Offset: 0x430 // Size: 0x08
	struct UWidgetAnimation* Root3_In; // Offset: 0x438 // Size: 0x08
	struct UWidgetAnimation* Root2_Out; // Offset: 0x440 // Size: 0x08
	struct UWidgetAnimation* Root2_In; // Offset: 0x448 // Size: 0x08
	struct UWidgetAnimation* Root1_Out; // Offset: 0x450 // Size: 0x08
	struct UWidgetAnimation* Root1_In; // Offset: 0x458 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_1; // Offset: 0x460 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_video; // Offset: 0x468 // Size: 0x08
	struct UImage* Image_2; // Offset: 0x470 // Size: 0x08
	struct UImage* Image_3; // Offset: 0x478 // Size: 0x08
	struct UImage* Image_4; // Offset: 0x480 // Size: 0x08
	struct UImage* Image_5; // Offset: 0x488 // Size: 0x08
	struct UImage* Image_6; // Offset: 0x490 // Size: 0x08
	struct UImage* Image_7; // Offset: 0x498 // Size: 0x08
	struct UImage* Image_loading; // Offset: 0x4a0 // Size: 0x08
	struct UMaskBox* MaskBox_1; // Offset: 0x4a8 // Size: 0x08
	struct UMaskBox* MaskBox_3; // Offset: 0x4b0 // Size: 0x08
	struct UMaskBox* MaskBox_4; // Offset: 0x4b8 // Size: 0x08
	struct UMaskBox* MaskBox_5; // Offset: 0x4c0 // Size: 0x08
	struct UMaskBox* MaskBox_6; // Offset: 0x4c8 // Size: 0x08
	struct UMaskBox* MaskBox_7; // Offset: 0x4d0 // Size: 0x08
	struct UImage* MediaContainer; // Offset: 0x4d8 // Size: 0x08
	struct UScaleBox* ScaleBox_1; // Offset: 0x4e0 // Size: 0x08
	struct UCanvasPanel* TextRoot1; // Offset: 0x4e8 // Size: 0x08
	struct UCanvasPanel* TextRoot2; // Offset: 0x4f0 // Size: 0x08
	struct UCanvasPanel* TextRoot3; // Offset: 0x4f8 // Size: 0x08
	struct UCanvasPanel* TextRoot4; // Offset: 0x500 // Size: 0x08
	struct UCanvasPanel* TextRoot5; // Offset: 0x508 // Size: 0x08
	struct UCanvasPanel* TextRoot6; // Offset: 0x510 // Size: 0x08
	struct UScaleBox* TextRootCenter1; // Offset: 0x518 // Size: 0x08
	struct UScaleBox* TextRootCenter2; // Offset: 0x520 // Size: 0x08
	struct UScaleBox* TextRootCenter3; // Offset: 0x528 // Size: 0x08
	struct UScaleBox* TextRootCenter4; // Offset: 0x530 // Size: 0x08
	struct UScaleBox* TextRootCenter5; // Offset: 0x538 // Size: 0x08
	struct UScaleBox* TextRootCenter6; // Offset: 0x540 // Size: 0x08
	struct UCanvasPanel* Texture_Mount; // Offset: 0x548 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_2; // Offset: 0x550 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_3; // Offset: 0x558 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_4; // Offset: 0x560 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_5; // Offset: 0x568 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_6; // Offset: 0x570 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_7; // Offset: 0x578 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_8; // Offset: 0x580 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_9; // Offset: 0x588 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_10; // Offset: 0x590 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_11; // Offset: 0x598 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_12; // Offset: 0x5a0 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_13; // Offset: 0x5a8 // Size: 0x08
};

