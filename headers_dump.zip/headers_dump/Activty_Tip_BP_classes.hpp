#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Activty_Tip_BP.Activty_Tip_BP_C
// Size: 0x2a9 // Inherited bytes: 0x248
struct UActivty_Tip_BP_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x248 // Size: 0x08
	struct UActivty_Tip_UIBP_C* Activty_Tip_UIBP; // Offset: 0x250 // Size: 0x08
	struct UButton* click_btn; // Offset: 0x258 // Size: 0x08
	struct UImage* SelectBox_2; // Offset: 0x260 // Size: 0x08
	struct UTextBlock* MyAwardNum; // Offset: 0x268 // Size: 0x08
	struct UTextBlock* MyHaveNum; // Offset: 0x270 // Size: 0x08
	int MyResID; // Offset: 0x278 // Size: 0x04
	int ItemNum; // Offset: 0x27c // Size: 0x04
	struct UHorizontalBox* MyCostRoot; // Offset: 0x280 // Size: 0x08
	struct UTextBlock* MyCostNum; // Offset: 0x288 // Size: 0x08
	struct UTextBlock* MyCostHaveNum; // Offset: 0x290 // Size: 0x08
	int MyFirstTime; // Offset: 0x298 // Size: 0x04
	int Quality; // Offset: 0x29c // Size: 0x04
	struct FDateTime TimeStamp; // Offset: 0x2a0 // Size: 0x08
	bool dontShowPreviewItem; // Offset: 0x2a8 // Size: 0x01

	// Functions

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.OnDownloadState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnDownloadState(int DownloadState); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.SetData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetData(int resID, int ItemNum, int TimeInfo); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.UnBindPicBtnClick
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UnBindPicBtnClick(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.SetDontShowItemPreview
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDontShowItemPreview(bool bShow); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.ShowPreviewPanel
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ShowPreviewPanel(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.SetTimeInfo
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetTimeInfo(int TimeInfo); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.SetBagNum
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetBagNum(int bag_num); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.IsShowBagNum
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void IsShowBagNum(bool show_bag_num); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.SetIcon
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetIcon(int res_id); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.HideItemTip
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void HideItemTip(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.ShowItemTip
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ShowItemTip(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.BindPicBtnClick
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void BindPicBtnClick(struct UButton* MyItemPicBtn1); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.SetAwardItemNum
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetAwardItemNum(int item_num); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.InitUIControl
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitUIControl(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Activty_Tip_BP.Activty_Tip_BP_C.ExecuteUbergraph_Activty_Tip_BP
	// Flags: [None]
	void ExecuteUbergraph_Activty_Tip_BP(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

