#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_ScriptBinder.BP_ScriptBinder_C
// Size: 0x4a8 // Inherited bytes: 0x4a0
struct ABP_ScriptBinder_C : ALuaActor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x4a0 // Size: 0x08

	// Functions

	// Object Name: Function BP_ScriptBinder.BP_ScriptBinder_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)
};

