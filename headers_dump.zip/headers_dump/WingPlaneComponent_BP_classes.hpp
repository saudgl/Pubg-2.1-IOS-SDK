#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass WingPlaneComponent_BP.WingPlaneComponent_BP_C
// Size: 0x1f0 // Inherited bytes: 0x1e8
struct UWingPlaneComponent_BP_C : UWingPlaneComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x1e8 // Size: 0x08

	// Functions

	// Object Name: Function WingPlaneComponent_BP.WingPlaneComponent_BP_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function WingPlaneComponent_BP.WingPlaneComponent_BP_C.ExecuteUbergraph_WingPlaneComponent_BP
	// Flags: [None]
	void ExecuteUbergraph_WingPlaneComponent_BP(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

