#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VehicleRefitColorTable_type.BP_STRUCT_VehicleRefitColorTable_type
// Size: 0x48 // Inherited bytes: 0x00
struct FBP_STRUCT_VehicleRefitColorTable_type {
	// Fields
	int ID_0_7607F1003C307130785E051708091744; // Offset: 0x00 // Size: 0x04
	int Gray_1_23C2528073E753A86CAE45C709177089; // Offset: 0x04 // Size: 0x04
	struct FString Color3_2_133F1A40217781872E65F412071E3F43; // Offset: 0x08 // Size: 0x10
	struct FString Color2_3_133E1A00217781862E65F413071E3F42; // Offset: 0x18 // Size: 0x10
	struct FString Color1_4_133D19C0217781852E65F410071E3F41; // Offset: 0x28 // Size: 0x10
	struct FString ColorBPPath_5_507BD54027F0DEF913818BAA07048B58; // Offset: 0x38 // Size: 0x10
};

