#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Bottom_right_UIBP.Lobby_Bottom_Right_UIBP_C
// Size: 0x268 // Inherited bytes: 0x248
struct ULobby_Bottom_Right_UIBP_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x248 // Size: 0x08
	struct ULobby_Main_Expression_UIBP_C* Lobby_Main_Expression_UIBP; // Offset: 0x250 // Size: 0x08
	struct ULobby_Main_Pet_UIBP_C* Lobby_Main_Pet_UIBP; // Offset: 0x258 // Size: 0x08
	int preWidth; // Offset: 0x260 // Size: 0x04
	int preHeight; // Offset: 0x264 // Size: 0x04

	// Functions

	// Object Name: Function Lobby_Bottom_right_UIBP.Lobby_Bottom_Right_UIBP_C.CheckAdaption
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CheckAdaption(bool& bAdapt, float& Width, float& Height); // Offset: 0x103bcc798 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Lobby_Bottom_right_UIBP.Lobby_Bottom_Right_UIBP_C.GetAdaptWidthHeight
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetAdaptWidthHeight(float Width, float Height, float& adaptWidth, float& adaptHeight); // Offset: 0x103bcc798 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Lobby_Bottom_right_UIBP.Lobby_Bottom_Right_UIBP_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x103bcc798 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function Lobby_Bottom_right_UIBP.Lobby_Bottom_Right_UIBP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103bcc798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Bottom_right_UIBP.Lobby_Bottom_Right_UIBP_C.ExecuteUbergraph_Lobby_Bottom_Right_UIBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Lobby_Bottom_Right_UIBP(int EntryPoint); // Offset: 0x103bcc798 // Return & Params: Num(1) Size(0x4)
};

