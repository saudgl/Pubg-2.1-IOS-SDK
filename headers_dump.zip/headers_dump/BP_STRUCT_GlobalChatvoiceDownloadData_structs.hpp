#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_GlobalChatvoiceDownloadData.BP_STRUCT_GlobalChatvoiceDownloadData
// Size: 0x40 // Inherited bytes: 0x00
struct FBP_STRUCT_GlobalChatvoiceDownloadData {
	// Fields
	struct FString fileId_0_27A7E9814AFBC6BF898DD088626C4C44; // Offset: 0x00 // Size: 0x10
	int msgLength_1_AA0B7A75470EBDA4A1B263A9DF37786C; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString msgSenderGID_2_A17583F444CD82A19E60DBB86D8EBDD7; // Offset: 0x18 // Size: 0x10
	struct FString msgContextGID_3_4DC6B36A4ADBF5BA22228B9262D45E49; // Offset: 0x28 // Size: 0x10
	int msgId_4_6367BF0A434687426F510F81D8518471; // Offset: 0x38 // Size: 0x04
	int msgChannel_5_B110640C4860EF195694518E5BD4BA4E; // Offset: 0x3c // Size: 0x04
};

